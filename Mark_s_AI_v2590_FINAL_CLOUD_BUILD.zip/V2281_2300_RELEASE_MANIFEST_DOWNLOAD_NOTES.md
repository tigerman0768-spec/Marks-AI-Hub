# Mark's AI v2281–2300

- v2281–2290: Added a real Release Manifest download endpoint.
- The endpoint serves the persisted JSON manifest with an attachment filename.
- v2291–2300: Added Flutter Download Release Manifest action.
- The Android app retrieves the actual JSON file, stores it temporarily, and opens the native share sheet using share_plus.
- Full Flutter compilation was not performed because the Flutter SDK is not installed.
