# Mark's AI v2590 — Rebuilt APK Build Package

This package is rebuilt from the recovered **Mark_s_AI_v2590** source.

## Fixed build blocker
The source had the Flutter entry point at the project root (`main.dart`) but did not have the standard Flutter entry point at `lib/main.dart`. A connected `lib/main.dart` is now present and launches the existing Mark AI dashboard.

## Release identity
- Milestone: v2590
- Flutter version: 1.0.0+2590
- Android application ID: com.marksai.app
- APK command: `flutter build apk --release --split-per-abi=false`
- Expected APK: `build/app/outputs/flutter-apk/app-release.apk`

## Cloud build
GitHub Actions generates the Android host, verifies the application ID, builds the APK and uploads `marks-ai-v2590-apk`. It also builds and uploads the AAB.

No APK is claimed to exist until the cloud build actually produces it.
