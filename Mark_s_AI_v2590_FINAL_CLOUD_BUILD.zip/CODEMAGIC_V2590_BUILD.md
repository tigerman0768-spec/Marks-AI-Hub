# Mark's AI v2590 — Cloud Build

This package keeps the exact v2590 application version (`1.0.0+2590`) and adds a Codemagic cloud-build workflow.

The workflow:
1. Checks the restored Flutter project.
2. Generates the Android host in the cloud.
3. Enforces application ID `com.marksai.app`.
4. Builds the production APK as `Mark_s_AI_v2590.apk`.
5. Records the APK SHA-256 checksum.
6. Builds the release AAB.

No APK is included in this source ZIP. The APK/AAB are created by the cloud build.
