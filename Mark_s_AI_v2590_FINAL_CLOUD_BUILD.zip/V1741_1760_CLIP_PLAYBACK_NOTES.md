# Mark's AI v1741–1760

- v1741–1750: Added secure project-scoped media serving for downloaded generated clips.
- v1751–1760: Added generated-clip inventory and Flutter playback viewer using video_player.
- The app can now request a downloaded generated MP4 from the server and play it in the Flutter UI.
- Missing project, missing clip and missing-file cases return clear errors.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
