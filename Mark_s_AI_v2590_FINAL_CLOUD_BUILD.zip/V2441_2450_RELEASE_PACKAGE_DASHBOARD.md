# Mark's AI v2441–2450 — Release Package Dashboard

Adds a unified final release package dashboard.

## Included
- Backend dashboard endpoint aggregating final release, film file, certificate, manifest and verification state.
- Live SHA-256 and file-size verification against the release record where available.
- Flutter dashboard showing final release status, file details, release documents, verification checks and blockers.
- The dashboard is read-only and does not claim a package is verified when a blocker remains.

## Endpoint
GET `/api/projects/:id/final-render/release-package-dashboard`

## Build note
Flutter/Android compilation was not performed because the current environment does not include the Flutter SDK/Android toolchain.
