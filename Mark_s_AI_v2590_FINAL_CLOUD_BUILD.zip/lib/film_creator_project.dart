import 'dart:convert';
import 'package:http/http.dart' as http;

class FilmCreatorProject {
  static const base='http://10.0.2.2:3000';
  final Map<String,dynamic> state;
  FilmCreatorProject(this.state);

  String get id=>state['id']?.toString()??'';
  String get title=>state['title']?.toString()??'Untitled Film';
  String get idea=>state['idea']?.toString()??'';
  String get genre=>state['genre']?.toString()??'Drama';
  int get length=>int.tryParse(state['length']?.toString()??'5')??5;
  String get style=>state['style']?.toString()??'Cinematic';
  String get aspectRatio=>state['aspectRatio']?.toString()??'16:9';

  static Future<FilmCreatorProject?> resume(String id) async{
    final r=await http.get(Uri.parse('$base/api/projects/$id/resume'));
    if(r.statusCode!=200)return null;
    final data=jsonDecode(r.body) as Map<String,dynamic>;
    return FilmCreatorProject(Map<String,dynamic>.from(data['creatorState'] as Map));
  }

  Future<FilmCreatorProject?> save(Map<String,dynamic> changes) async{
    final r=await http.put(Uri.parse('$base/api/projects/$id/creator-state'),
      headers:{'Content-Type':'application/json'},body:jsonEncode(changes));
    if(r.statusCode!=200)return null;
    return FilmCreatorProject(Map<String,dynamic>.from(jsonDecode(r.body)));
  }
}
