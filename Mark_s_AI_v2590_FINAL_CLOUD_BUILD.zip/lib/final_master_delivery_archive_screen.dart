import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String archiveApi='http://10.0.2.2:3000';
class FinalMasterDeliveryArchiveScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterDeliveryArchiveScreen({super.key,required this.projectId});
  @override State<FinalMasterDeliveryArchiveScreen> createState()=>_FinalMasterDeliveryArchiveScreenState();
}
class _FinalMasterDeliveryArchiveScreenState extends State<FinalMasterDeliveryArchiveScreen>{
  Map<String,dynamic>? archive;bool busy=false;
  Future<void> createArchive()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$archiveApi/api/projects/${widget.projectId}/final-render/delivery-archive/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>archive=b['archive'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery archive created.':'Archive blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=archive?['status']=='archived';
    return Scaffold(appBar:AppBar(title:const Text('Delivery Archive')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.inventory_2:Icons.archive),
        title:Text(ready?'DELIVERY ARCHIVED':'DELIVERY NOT ARCHIVED'),
        subtitle:Text(ready?'Archive ID: ${archive?['archiveId']??''}':'All delivery evidence must verify first.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('File: ${archive?['filename']??''}'),
        Text('Size: ${archive?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${archive?['sha256']??''}'),
        Text('Archived: ${archive?['archivedAt']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:createArchive,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.archive),
        label:Text(busy?'Archiving…':'Archive Delivery'))
    ]));
  }
}
