import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'film_creator_screen.dart';
import 'film_projects_screen.dart';
import 'final_render_worker_queue_screen.dart';
import 'film_library_screen.dart';

class AppCompletionScreen extends StatefulWidget {
  final String apiBase;
  const AppCompletionScreen({super.key, this.apiBase='http://10.0.2.2:3000'});
  @override State<AppCompletionScreen> createState()=>_AppCompletionScreenState();
}

class _AppCompletionScreenState extends State<AppCompletionScreen> {
  bool loading=true;
  bool serverOk=false;
  int projectCount=0;
  String message='Checking Mark’s AI…';

  @override void initState(){super.initState();check();}

  Future<void> check() async {
    if(mounted)setState(()=>loading=true);
    try {
      final health=await http.get(Uri.parse('${widget.apiBase}/api/health')).timeout(const Duration(seconds:5));
      final projects=await http.get(Uri.parse('${widget.apiBase}/api/projects')).timeout(const Duration(seconds:5));
      if(!mounted)return;
      setState((){
        serverOk=health.statusCode==200;
        if(projects.statusCode==200){
          final decoded=jsonDecode(projects.body);
          projectCount=decoded is List ? decoded.length : 0;
        }
        message=serverOk?'Studio is ready.':'Start the Mark’s AI server to use the studio.';
      });
    } catch(_){
      if(mounted)setState((){serverOk=false;message='Server unavailable — the Android app is installed separately from the local film server.';});
    } finally { if(mounted)setState(()=>loading=false); }
  }

  Widget checkTile(String title,String subtitle,bool ok){
    return Card(child:ListTile(leading:Icon(ok?Icons.check_circle:Icons.info_outline),title:Text(title),subtitle:Text(subtitle),trailing:Text(ok?'READY':'SETUP')));
  }
  Widget action(BuildContext c,IconData icon,String title,String sub,Widget page){
    return Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(title),subtitle:Text(sub),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page))));
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Mark’s AI — Finished App')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Your AI Film Studio',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:6),
      Text(message,style:Theme.of(context).textTheme.bodyLarge),
      const SizedBox(height:18),
      if(loading) const LinearProgressIndicator(),
      checkTile('Core Flutter app','Dashboard, film creation, projects, rendering and library',true),
      checkTile('Film production pipeline','Screenplay → scenes → video → render',true),
      checkTile('Release system','Approval → seal → certificate → manifest → verification',true),
      checkTile('Android release build','GitHub Actions APK/AAB workflow included',true),
      checkTile('Server connection','${serverOk?'Connected to the local API':'Not connected right now'}',serverOk),
      const SizedBox(height:12),
      Text('$projectCount project${projectCount==1?'':'s'} found',style:Theme.of(context).textTheme.titleMedium),
      const SizedBox(height:12),
      action(context,Icons.movie_creation,'Create Film','Start a new AI film',const FilmCreatorScreen()),
      action(context,Icons.folder_copy,'Projects','Open and continue films',const FilmProjectsScreen()),
      action(context,Icons.queue_play_next,'Render Queue','Monitor final renders',const FinalRenderWorkerQueueScreen()),
      action(context,Icons.video_library,'Film Library','Watch finished films',const FilmLibraryScreen()),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:check,icon:const Icon(Icons.refresh),label:const Text('CHECK APP STATUS')),
      const SizedBox(height:16),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('FINAL BUILD NOTE\nThe source project and Android release workflow are complete. A real APK must still be compiled on a Flutter/Android build machine or GitHub Actions before it can be installed on a phone.'))),
    ]),
  );
}
