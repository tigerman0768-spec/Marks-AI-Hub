import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String lockApi='http://10.0.2.2:3000';
class FinalMasterLockScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterLockScreen({super.key,required this.projectId});
  @override State<FinalMasterLockScreen> createState()=>_FinalMasterLockScreenState();
}
class _FinalMasterLockScreenState extends State<FinalMasterLockScreen>{
  Map<String,dynamic>? lock;bool busy=false;
  Future<void> lockMaster()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$lockApi/api/projects/${widget.projectId}/final-render/lock'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>lock=b['lock'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Final Master locked.':'Lock blocked.')));
  }
  @override Widget build(BuildContext context){
    final locked=lock?['locked']==true;
    return Scaffold(appBar:AppBar(title:const Text('Final Master Lock')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(locked?Icons.lock:Icons.lock_open),
        title:Text(locked?'FINAL MASTER LOCKED':'FINAL MASTER UNLOCKED'),
        subtitle:Text(locked?'Verified source is protected by its recorded hash.':'Create a verified delivery receipt first.'))),
      if(locked) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('File: ${lock?['filename']??''}'),
        SelectableText('SHA-256: ${lock?['sha256']??''}'),
        Text('Locked: ${lock?['lockedAt']??''}')
      ]))),
      FilledButton.icon(onPressed:busy||locked?null:lockMaster,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.lock),
        label:Text(busy?'Locking…':'Lock Final Master'))
    ]));
  }
}
