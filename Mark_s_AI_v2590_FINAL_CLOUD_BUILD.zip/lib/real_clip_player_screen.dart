import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const String realClipPlayerApi='http://10.0.2.2:3000';

class RealClipPlayerScreen extends StatefulWidget{
  final String projectId;
  const RealClipPlayerScreen({super.key,required this.projectId});
  @override State<RealClipPlayerScreen> createState()=>_RealClipPlayerScreenState();
}
class _RealClipPlayerScreenState extends State<RealClipPlayerScreen>{
  List<dynamic> clips=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$realClipPlayerApi/api/projects/${widget.projectId}/clips/real/media-list'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>clips=(jsonDecode(r.body)['clips'] as List<dynamic>));
    }finally{if(mounted)setState(()=>loading=false);}
  }
  void play(Map<String,dynamic> clip){
    Navigator.push(context,MaterialPageRoute(builder:(_)=>_ClipViewer(projectId:widget.projectId,clip:clip)));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Generated Clips'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),
    body:loading?const Center(child:CircularProgressIndicator()):
      clips.isEmpty?const Center(child:Text('No downloaded clips yet.')):
      ListView.builder(itemCount:clips.length,itemBuilder:(c,i){
        final x=clips[i] as Map<String,dynamic>;
        return Card(child:ListTile(leading:const Icon(Icons.video_library),title:Text('${x['provider']??'AI'} clip'),subtitle:Text('${x['bytes']??0} bytes\n${x['clipId']??''}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.play_circle_fill),onPressed:()=>play(x))));
      }));
}
class _ClipViewer extends StatefulWidget{
  final String projectId; final Map<String,dynamic> clip;
  const _ClipViewer({required this.projectId,required this.clip});
  @override State<_ClipViewer> createState()=>_ClipViewerState();
}
class _ClipViewerState extends State<_ClipViewer>{
  VideoPlayerController? controller; String? error;
  @override void initState(){super.initState();_open();}
  Future<void> _open()async{
    try{
      final id=widget.clip['clipId'];
      final c=VideoPlayerController.networkUrl(Uri.parse('$realClipPlayerApi/api/projects/${widget.projectId}/clips/real/$id/media'));
      await c.initialize();
      if(!mounted){c.dispose();return;}
      setState(()=>controller=c);
    }catch(e){if(mounted)setState(()=>error='$e');}
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final c=controller;
    return Scaffold(appBar:AppBar(title:const Text('Play Clip')),body:Center(
      child:error!=null?Padding(padding:const EdgeInsets.all(20),child:Text('Unable to play clip: $error')):
      c==null?const CircularProgressIndicator():
      Column(mainAxisAlignment:MainAxisAlignment.center,children:[
        AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c)),
        const SizedBox(height:16),
        IconButton(icon:Icon(c.value.isPlaying?Icons.pause_circle:Icons.play_circle,size:56),onPressed:(){setState(()=>c.value.isPlaying?c.pause():c.play());})
      ])));
  }
}
