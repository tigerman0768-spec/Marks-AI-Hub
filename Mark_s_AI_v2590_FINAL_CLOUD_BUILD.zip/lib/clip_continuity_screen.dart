import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ClipContinuityScreen extends StatefulWidget{
  final String projectId;
  const ClipContinuityScreen({super.key,required this.projectId});
  @override State<ClipContinuityScreen> createState()=>_ClipContinuityScreenState();
}
class _ClipContinuityScreenState extends State<ClipContinuityScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? report;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/continuity'));
      if(r.statusCode<300)setState(()=>report=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final r=report;
    return Scaffold(
      appBar:AppBar(title:const Text('Continuity Checker'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
        r==null?const Center(child:Text('Unable to check continuity.')):
        ListView(padding:const EdgeInsets.all(12),children:[
          Card(child:ListTile(
            leading:Icon(r['consistent']==true?Icons.check_circle:Icons.warning),
            title:Text('Continuity Score: ${r['score']??0}/100'),
            subtitle:Text(r['consistent']==true?'No mismatches found':'Potential continuity mismatches found'),
          )),
          ...((r['pairs'] as List?)??[]).map((p){
            final m=Map<String,dynamic>.from(p as Map);
            return Card(child:ExpansionTile(
              title:Text('${m['fromJobId']} → ${m['toJobId']}'),
              subtitle:Text('Score ${m['score']??0}/100'),
              children:[...((m['checks'] as List?)??[]).map((c){
                final x=Map<String,dynamic>.from(c as Map);
                return ListTile(
                  dense:true,title:Text('${x['field']}'),
                  trailing:Icon(x['status']=='mismatch'?Icons.warning:Icons.check),
                  subtitle:Text(x['status'].toString()),
                );
              })],
            ));
          })
        ])
    );
  }
}
