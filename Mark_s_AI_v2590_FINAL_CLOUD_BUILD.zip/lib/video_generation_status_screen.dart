import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoGenerationStatusScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationStatusScreen({super.key, required this.projectId});
  @override State<VideoGenerationStatusScreen> createState()=>_VideoGenerationStatusScreenState();
}
class _VideoGenerationStatusScreenState extends State<VideoGenerationStatusScreen>{
  static const base='http://10.0.2.2:3000';
  Timer? timer; Map<String,dynamic>? data; String? error;
  @override void initState(){super.initState();_load();timer=Timer.periodic(const Duration(seconds:2),(_)=>_load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/video-generation/status'));
      if(r.statusCode<300)data=jsonDecode(r.body) as Map<String,dynamic>;
      else error='Status request failed (${r.statusCode})';
    }catch(e){error=e.toString();}
    if(mounted)setState((){});
  }
  @override Widget build(BuildContext c){
    final d=data??{}; final total=Number(d['total']); final done=Number(d['completed']);
    final progress=total>0?(done/total).clamp(0.0,1.0):0.0;
    final jobs=(d['jobs'] as List?)??[];
    return Scaffold(appBar:AppBar(title:const Text('Video Generation')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text('Video Generation',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:8),Text('Status: ${d['status']??'loading'}'),
        const SizedBox(height:14),LinearProgressIndicator(value:progress),
        const SizedBox(height:8),Text('$done / $total clips completed'),
        const SizedBox(height:20),
        ...jobs.map((j)=>Card(child:ListTile(
          leading:Icon(j['status']=='completed'?Icons.check_circle:j['status']=='failed'?Icons.error:Icons.movie),
          title:Text('Shot ${j['shotNumber']??''}'),
          subtitle:Text('${j['status']??'queued'}${j['error']!=null?' — ${j['error']}':''}'),
        ))),
        if(error!=null)Padding(padding:const EdgeInsets.only(top:16),child:Text(error!)),
      ]));
  }
}
class Number { static num call(dynamic x)=>x is num?x:num.tryParse('$x')??0; }
