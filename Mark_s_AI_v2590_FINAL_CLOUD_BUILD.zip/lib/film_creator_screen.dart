import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'film_creator_project.dart';
import 'screenplay_screen.dart';

// v138: expanded Create Film workflow helpers
const List<String> kMarkAiGenres = [
  'Action','Comedy','Drama','Horror','Romance','Sci-Fi','Fantasy','Thriller'
];
const List<String> kMarkAiStyles = [
  'Cinematic','Realistic','Animation','Anime','Fantasy','Vintage'
];
const List<int> kMarkAiLengths = [1,5,10,30,60];

class FilmCreatorScreen extends StatefulWidget{
  final String? projectId;
  const FilmCreatorScreen({super.key,this.projectId});
  @override State<FilmCreatorScreen> createState()=>_FilmCreatorScreenState();
}
class _FilmCreatorScreenState extends State<FilmCreatorScreen>{
  static const base='http://10.0.2.2:3000';
  final title=TextEditingController(),idea=TextEditingController();
  String genre='Drama',style='Cinematic',aspect='16:9';
  int length=5; String? projectId; bool loading=true,saving=false;
  final genres=['Action','Comedy','Drama','Horror','Romance','Sci-Fi','Fantasy','Thriller'];
  final styles=['Cinematic','Realistic','Animation','Anime','Fantasy','Vintage'];
  final aspects=['16:9','9:16','1:1'];
  @override void initState(){super.initState();projectId=widget.projectId;_load();}
  @override void dispose(){title.dispose();idea.dispose();super.dispose();}
  Future<void> _load() async{
    try{
      if(projectId!=null){
        final p=await FilmCreatorProject.resume(projectId!);
        if(p!=null){title.text=p.title;idea.text=p.idea;genre=p.genre;length=p.length;style=p.style;aspect=p.aspectRatio;}
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }

  Future<void> _generateScreenplay() async {
    if (projectId == null) {
      await _save(create: true);
    }
    if (projectId == null) return;
    if (!mounted) return;
    setState(() => saving = true);
    try {
      final r = await http.post(
        Uri.parse('$base/api/projects/$projectId/screenplay/generate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'title': title.text.trim().isEmpty ? 'Untitled Film' : title.text.trim(),
          'idea': idea.text.trim(),
          'genre': genre,
          'length': length,
          'style': style,
          'aspectRatio': aspect,
        }),
      );
      if (r.statusCode >= 200 && r.statusCode < 300) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Screenplay generation started')),
          );
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ScreenplayScreen(projectId: projectId!),
            ),
          );
        }
      } else {
        throw Exception('Screenplay request failed (${r.statusCode})');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Screenplay generation failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _save({bool create=false}) async{
    setState(()=>saving=true);
    try{
      final body={'title':title.text.trim().isEmpty?'Untitled Film':title.text.trim(),'idea':idea.text.trim(),
        'genre':genre,'length':length,'style':style,'aspectRatio':aspect,'status':'draft'};
      if(projectId==null||create){
        final r=await http.post(Uri.parse('$base/api/projects'),headers:{'Content-Type':'application/json'},body:jsonEncode(body));
        if(r.statusCode<300){projectId=(jsonDecode(r.body) as Map)['id']?.toString();}
      }else{
        await http.put(Uri.parse('$base/api/projects/$projectId/creator-state'),
          headers:{'Content-Type':'application/json'},body:jsonEncode(body));
      }
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Project saved')));
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Save failed: $e')));
    }
    if(mounted)setState(()=>saving=false);
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('Film Creator'),actions:[
      IconButton(onPressed:saving?null:()=>_save(),icon:const Icon(Icons.save)),
          const SizedBox(height: 22),
      FilledButton.icon(
        onPressed: saving ? null : _generateScreenplay,
        icon: const Icon(Icons.auto_awesome),
        label: const Text('Generate Screenplay'),
      ),
]),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Create your film',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:8),
      Text('Start with the idea and production settings. Your project is saved so you can continue later.'),
      const SizedBox(height:20),
      TextField(controller:title,decoration:const InputDecoration(labelText:'Film title',border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:idea,minLines:5,maxLines:9,decoration:const InputDecoration(
        labelText:'What is your film about?',hintText:'Describe the story, characters, setting and what you want to happen…',border:OutlineInputBorder())),
      const SizedBox(height:16),
      DropdownButtonFormField<String>(value:genre,decoration:const InputDecoration(labelText:'Genre',border:OutlineInputBorder()),
        items:genres.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v){if(v!=null)setState(()=>genre=v);}),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(value:style,decoration:const InputDecoration(labelText:'Visual style',border:OutlineInputBorder()),
        items:styles.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v){if(v!=null)setState(()=>style=v);}),
      const SizedBox(height:12),
      DropdownButtonFormField<int>(value:length,decoration:const InputDecoration(labelText:'Film length (minutes)',border:OutlineInputBorder()),
        items:[1,5,10,30,60].map((x)=>DropdownMenuItem(value:x,child:Text('$x minutes'))).toList(),onChanged:(v){if(v!=null)setState(()=>length=v);}),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(value:aspect,decoration:const InputDecoration(labelText:'Aspect ratio',border:OutlineInputBorder()),
        items:aspects.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v){if(v!=null)setState(()=>aspect=v);}),
      const SizedBox(height:24),
      FilledButton.icon(onPressed:saving?null:()=>_save(),icon:saving?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save),
        label:Text(saving?'SAVING…':'SAVE PROJECT')),
      const SizedBox(height:10),
      OutlinedButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content:Text('Next creation stage will generate the screenplay and scenes from this saved project.'))),
        icon:const Icon(Icons.auto_awesome),label:const Text('GENERATE SCREENPLAY')),
    ]));
  }
}
