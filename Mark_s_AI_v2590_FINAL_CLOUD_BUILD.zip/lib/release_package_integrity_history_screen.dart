import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ReleasePackageIntegrityHistoryScreen extends StatefulWidget {
  final String projectId;
  final String apiBase;
  const ReleasePackageIntegrityHistoryScreen({super.key,required this.projectId,this.apiBase='http://10.0.2.2:3000'});
  @override State<ReleasePackageIntegrityHistoryScreen> createState()=>_ReleasePackageIntegrityHistoryScreenState();
}
class _ReleasePackageIntegrityHistoryScreenState extends State<ReleasePackageIntegrityHistoryScreen>{
  Map<String,dynamic>? data; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {setState(()=>loading=true);try{final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-package/integrity-history'));final b=jsonDecode(r.body);if(mounted)setState(()=>data=r.statusCode==200?Map<String,dynamic>.from(b):{'error':b['error']??'Unable to load'});}catch(e){if(mounted)setState(()=>data={'error':'Integrity history unavailable'});}if(mounted)setState(()=>loading=false);}
  @override Widget build(BuildContext context){
    final d=data;
    return Scaffold(appBar:AppBar(title:const Text('Package Integrity History'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):d?['error']!=null?Center(child:Text('${d['error']}')):ListView(padding:const EdgeInsets.all(16),children:[Text(d?['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:8),Text('${d?['count']??0} verification record(s)'),const SizedBox(height:12),...((d?['history'] as List?)??const []).map((raw){final h=Map<String,dynamic>.from(raw as Map);final ok=h['verified']==true;final failed=(h['failedFiles'] as List?)??const [];return Card(child:ExpansionTile(leading:Icon(ok?Icons.check_circle:Icons.error),title:Text(ok?'VERIFIED':'FAILED'),subtitle:Text('${h['checkedAt']??'Unknown time'} • ${h['fileCount']??0} files'),children:[Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Package SHA-256: ${h['package']?['sha256']??'—'}',style:const TextStyle(fontSize:11)),if(failed.isNotEmpty)Text('Failed files: ${failed.join(', ')}'),if(h['reason']!=null)Text('${h['reason']}')]))]));})]:const SizedBox());
  }
}
