import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releaseApi='http://10.0.2.2:3000';
class FinalMasterReleaseReadinessScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterReleaseReadinessScreen({super.key,required this.projectId});
  @override State<FinalMasterReleaseReadinessScreen> createState()=>_FinalMasterReleaseReadinessScreenState();
}
class _FinalMasterReleaseReadinessScreenState extends State<FinalMasterReleaseReadinessScreen>{
  Map<String,dynamic>? readiness;bool busy=false;
  Future<void> check()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$releaseApi/api/projects/${widget.projectId}/final-render/release-readiness/check'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>readiness=b['readiness'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Film is release ready.':'Film is not release ready.')));
  }
  @override Widget build(BuildContext context){
    final ready=readiness?['ready']==true;
    final blockers=(readiness?['blockers'] as List?)?.map((e)=>e.toString()).toList()??[];
    final ev=readiness?['evidence'] as Map<String,dynamic>?;
    return Scaffold(appBar:AppBar(title:const Text('Release Readiness')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.rocket_launch:Icons.block),
        title:Text(ready?'RELEASE READY':'RELEASE BLOCKED'),
        subtitle:Text(readiness==null?'Run the complete release check.':'${blockers.length} blocker(s)'))),
      if(ev!=null) Card(child:Column(children:ev.entries.map((e)=>ListTile(
        dense:true,leading:Icon(e.value==true?Icons.check:Icons.close),
        title:Text(e.key),subtitle:Text(e.value==true?'Passed':'Not passed'))).toList())),
      if(blockers.isNotEmpty) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Blockers',style:TextStyle(fontWeight:FontWeight.bold)),...blockers.map((x)=>Text('• $x'))
      ]))),
      FilledButton.icon(onPressed:busy?null:check,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rule),
        label:Text(busy?'Checking…':'Check Release Readiness'))
    ]));
  }
}
