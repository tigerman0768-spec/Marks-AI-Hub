import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'film_creator_project.dart';

class FilmProjectsScreen extends StatefulWidget{
  final void Function(FilmCreatorProject project)? onResume;
  const FilmProjectsScreen({super.key,this.onResume});
  @override State<FilmProjectsScreen> createState()=>_FilmProjectsScreenState();
}
class _FilmProjectsScreenState extends State<FilmProjectsScreen>{
  static const base='http://10.0.2.2:3000';
  List<Map<String,dynamic>> projects=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects'));
      projects=(jsonDecode(r.body) as List).map((e)=>Map<String,dynamic>.from(e)).toList();
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> createProject() async{
    final c=TextEditingController();
    final title=await showDialog<String>(context:context,builder:(_)=>AlertDialog(
      title:const Text('New film project'),content:TextField(controller:c,autofocus:true,decoration:const InputDecoration(hintText:'Film title')),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(context,c.text.trim()),child:const Text('Create'))]));
    c.dispose();
    if(title==null||title.isEmpty)return;
    await http.post(Uri.parse('$base/api/projects'),headers:{'Content-Type':'application/json'},
      body:jsonEncode({'title':title,'status':'draft'}));
    await load();
  }
  Future<void> remove(Map<String,dynamic> p) async{
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:const Text('Delete project?'),content:Text('Delete "${p['title']??'Untitled Film'}"?'),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Delete'))]));
    if(ok==true){await http.delete(Uri.parse('$base/api/projects/${p['id']}'));await load();}
  }
  Future<void> resume(Map<String,dynamic> p) async{
    final project=await FilmCreatorProject.resume(p['id'].toString());
    if(project==null||!mounted)return;
    if(widget.onResume!=null){widget.onResume!(project);return;}
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content:Text('Loaded "${project.title}" into the creator')));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Film Projects'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
    floatingActionButton:FloatingActionButton.extended(onPressed:createProject,icon:const Icon(Icons.add),label:const Text('New Film')),
    body:loading?const Center(child:CircularProgressIndicator()):
      projects.isEmpty?const Center(child:Text('No saved projects yet.')):
      ListView.separated(padding:const EdgeInsets.all(12),itemCount:projects.length,
        separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(context,i){
          final p=projects[i];
          return Card(child:ListTile(
            onTap:()=>resume(p),
            leading:const CircleAvatar(child:Icon(Icons.movie_outlined)),
            title:Text(p['title']?.toString()??'Untitled Film'),
            subtitle:Text('${p['genre']??'Drama'} • ${p['style']??'Cinematic'} • ${p['status']??'draft'}'),
            trailing:Wrap(mainAxisSize:MainAxisSize.min,children:[
              IconButton(tooltip:'Continue',icon:const Icon(Icons.play_arrow),onPressed:()=>resume(p)),
              IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>remove(p)),
            ]),
          ));
        }));
}
