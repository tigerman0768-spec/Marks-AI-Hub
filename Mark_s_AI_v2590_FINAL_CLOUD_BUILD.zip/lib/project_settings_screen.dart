import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class ProjectSettingsScreen extends StatefulWidget{
  final String projectId; const ProjectSettingsScreen({super.key,required this.projectId});
  @override State<ProjectSettingsScreen> createState()=>_ProjectSettingsScreenState();
}
class _ProjectSettingsScreenState extends State<ProjectSettingsScreen>{
  static const base='http://10.0.2.2:3000'; bool loading=true,saving=false;
  Map<String,dynamic> d={}; String? error; final title=TextEditingController();
  @override void initState(){super.initState();_load();}
  @override void dispose(){title.dispose();super.dispose();}
  Future<void> _load() async{try{final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/settings'));
    if(r.statusCode>=300)throw Exception('Settings unavailable'); d=jsonDecode(r.body); title.text=d['title']?.toString()??'';
  }catch(e){error=e.toString();}if(mounted)setState(()=>loading=false);}
  Future<void> _save() async{setState(()=>saving=true);try{final body={...d,'title':title.text.trim()};
    body.remove('projectId');body.remove('updatedAt');
    final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/settings'),
      headers:{'Content-Type':'application/json'},body:jsonEncode(body));
    if(r.statusCode>=300)throw Exception('Save failed');
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Project settings saved')));
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>saving=false);}
  @override Widget build(BuildContext c){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Settings')),body:Center(child:Text(error!)));
    return Scaffold(appBar:AppBar(title:const Text('Project Settings')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Project Settings',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:16),
      TextField(controller:title,decoration:const InputDecoration(labelText:'Film title',border:OutlineInputBorder())),
      const SizedBox(height:12),_info('Genre',d['genre']),_info('Style',d['style']),_info('Length',d['length']),
      _info('Aspect Ratio',d['aspectRatio']),_info('Resolution',d['resolution']??'1080p'),_info('Frame Rate','${d['fps']??24} fps'),
      _info('Export','${d['exportFormat']??'mp4'}'),const SizedBox(height:16),
      FilledButton.icon(onPressed:saving?null:_save,icon:const Icon(Icons.save),label:Text(saving?'SAVING...':'SAVE SETTINGS'))
    ]));}
  Widget _info(String a,d)=>Card(child:ListTile(title:Text(a),subtitle:Text('${d??'Not set'}')));
}
