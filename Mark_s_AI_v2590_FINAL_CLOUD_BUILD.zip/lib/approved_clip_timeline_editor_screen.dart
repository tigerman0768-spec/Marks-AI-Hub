import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String timelineApi='http://10.0.2.2:3000';

class ApprovedClipTimelineEditorScreen extends StatefulWidget {
  final String projectId;
  const ApprovedClipTimelineEditorScreen({super.key,required this.projectId});
  @override State<ApprovedClipTimelineEditorScreen> createState()=>_ApprovedClipTimelineEditorScreenState();
}
class _ApprovedClipTimelineEditorScreenState extends State<ApprovedClipTimelineEditorScreen>{
  List<Map<String,dynamic>> items=[]; bool loading=true,applying=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    final r=await http.get(Uri.parse('$timelineApi/api/projects/${widget.projectId}/edit-input-timeline'));
    if(r.statusCode==200&&mounted)setState(()=>items=List<Map<String,dynamic>>.from((jsonDecode(r.body)['timeline'] as List).map((x)=>Map<String,dynamic>.from(x))));
    if(mounted)setState(()=>loading=false);
  }
  Future<void> edit(Map<String,dynamic> x) async{
    final tr=await showDialog<String>(context:context,builder:(c)=>SimpleDialog(title:const Text('Transition'),children:[
      for(final t in ['cut','dissolve','fade','dip-to-black'])SimpleDialogOption(onPressed:()=>Navigator.pop(c,t),child:Text(t))
    ]));
    if(tr==null)return;
    await http.patch(Uri.parse('$timelineApi/api/projects/${widget.projectId}/edit-input-timeline/${x['id']}'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'transition':tr}));
    load();
  }
  Future<void> apply() async{
    setState(()=>applying=true);
    final v=await http.post(Uri.parse('$timelineApi/api/projects/${widget.projectId}/edit-input-timeline/validate'));
    if(v.statusCode==200&&jsonDecode(v.body)['valid']==true){
      final r=await http.post(Uri.parse('$timelineApi/api/projects/${widget.projectId}/edit-input-timeline/apply'));
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Timeline applied to editor.':'Could not apply timeline.')));
    }else if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Fix timeline validation issues first.')));
    setState(()=>applying=false); load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('Edit Timeline')),
      body:ListView(padding:const EdgeInsets.all(12),children:[
        Card(child:ListTile(title:Text('${items.length} approved clips'),subtitle:const Text('Arrange and set transitions before applying to the editor.'))),
        ...items.map((x)=>Card(child:ListTile(
          leading:CircleAvatar(child:Text('${(x['order']??0)+1}')),
          title:Text('Scene ${x['scene']??'-'} • Shot ${x['shotId']??'-'}'),
          subtitle:Text('Transition: ${x['transition']??'cut'}'),
          trailing:IconButton(icon:const Icon(Icons.tune),onPressed:()=>edit(x)),
        ))),
        const SizedBox(height:8),
        FilledButton.icon(onPressed:items.isEmpty||applying?null:apply,
          icon:applying?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.movie_edit),
          label:Text(applying?'Applying…':'Validate & Apply Timeline'))
      ]));
  }
}
