import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProductionSummaryCard extends StatefulWidget{
  final String projectId;
  const ProductionSummaryCard({super.key,required this.projectId});
  @override State<ProductionSummaryCard> createState()=>_ProductionSummaryCardState();
}
class _ProductionSummaryCardState extends State<ProductionSummaryCard>{
  static const base='http://10.0.2.2:3000';
  Map<String,dynamic>? d;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    try{final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/production-summary'));
      if(r.statusCode==200&&mounted)setState(()=>d=jsonDecode(r.body));}catch(_){}
  }
  @override Widget build(BuildContext c){
    if(d==null)return const SizedBox.shrink();
    final ready=['hasScreenplay','hasProductionPlan','hasEdit','hasFinalCut','hasAudio','hasSubtitles','hasFinishing']
      .where((k)=>d![k]==true).length;
    return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Production Summary',style:Theme.of(c).textTheme.titleLarge),
      const SizedBox(height:6),Text('$ready / 7 production stages ready'),
      const SizedBox(height:8),LinearProgressIndicator(value:ready/7),
      const SizedBox(height:6),Text('${d!['scenes']??0} scenes • ${d!['videoJobs']??0} video jobs • ${d!['acceptedClips']??0} accepted clips'),
    ])));
  }
}
