import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String approvedClipApi='http://10.0.2.2:3000';

class ApprovedClipEditBridgeScreen extends StatefulWidget {
  final String projectId;
  const ApprovedClipEditBridgeScreen({super.key,required this.projectId});
  @override State<ApprovedClipEditBridgeScreen> createState()=>_ApprovedClipEditBridgeScreenState();
}
class _ApprovedClipEditBridgeScreenState extends State<ApprovedClipEditBridgeScreen>{
  Map<String,dynamic> readiness={}; Map<String,dynamic> inventory={}; bool loading=true,preparing=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final a=await http.get(Uri.parse('$approvedClipApi/api/projects/${widget.projectId}/approved-clips'));
      final r=await http.get(Uri.parse('$approvedClipApi/api/projects/${widget.projectId}/approved-clips/edit-readiness'));
      if(mounted)setState((){
        if(a.statusCode==200)inventory=jsonDecode(a.body);
        if(r.statusCode==200)readiness=jsonDecode(r.body);
        loading=false;
      });
    }catch(_){if(mounted)setState(()=>loading=false);}
  }
  Future<void> prepare() async{
    setState(()=>preparing=true);
    final r=await http.post(Uri.parse('$approvedClipApi/api/projects/${widget.projectId}/approved-clips/prepare-edit'));
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode==200?'Edit timeline prepared.':'Cannot prepare edit timeline yet.')));
    setState(()=>preparing=false); load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final clips=List<Map<String,dynamic>>.from((inventory['clips'] as List? ?? []).map((x)=>Map<String,dynamic>.from(x)));
    final ready=readiness['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Approved Clips → Edit')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(
          leading:Icon(ready?Icons.check_circle:Icons.edit_note),
          title:Text(ready?'Edit input ready':'Prepare approved clips for editing'),
          subtitle:Text('${inventory['availableCount']??0}/${inventory['count']??0} source files available'),
        )),
        ...clips.map((c)=>ListTile(
          leading:Icon(c['available']==true?Icons.video_file:Icons.error),
          title:Text('Shot ${c['index']??'-'} • Scene ${c['scene']??'-'}'),
          subtitle:Text(c['available']==true?'Approved':'Missing source file'),
        )),
        const SizedBox(height:12),
        FilledButton.icon(
          onPressed:preparing?null:prepare,
          icon:preparing?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_fix_high),
          label:Text(preparing?'Preparing…':'Prepare Edit Timeline'))
      ]));
  }
}
