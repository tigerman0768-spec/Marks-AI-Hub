import 'package:flutter/material.dart';

class TimelineTransitionPicker extends StatelessWidget{
  final String type; final double duration;
  final ValueChanged<Map<String,dynamic>> onChanged;
  const TimelineTransitionPicker({
    super.key,required this.type,required this.duration,required this.onChanged
  });
  static const types=['cut','fade','dissolve','dip-to-black'];
  @override Widget build(BuildContext context)=>Column(
    crossAxisAlignment:CrossAxisAlignment.start,
    children:[
      DropdownButtonFormField<String>(
        initialValue:types.contains(type)?type:'cut',
        decoration:const InputDecoration(labelText:'Transition'),
        items:types.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(v){if(v!=null)onChanged({'type':v,'duration':duration});},
      ),
      const SizedBox(height:8),
      Text('Duration: ${duration.toStringAsFixed(1)}s'),
      Slider(
        min:0,max:5,divisions:10,value:duration,
        onChanged:(v)=>onChanged({'type':type,'duration':v}),
      ),
    ],
  );
}
