import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String snapshotVerifyApi='http://10.0.2.2:3000';

class ReleasedFilmDeliverySnapshotVerifyScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliverySnapshotVerifyScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliverySnapshotVerifyScreen> createState()=>_ReleasedFilmDeliverySnapshotVerifyScreenState();
}
class _ReleasedFilmDeliverySnapshotVerifyScreenState extends State<ReleasedFilmDeliverySnapshotVerifyScreen>{
  Map<String,dynamic>? verification;bool busy=false;
  Future<void> verify()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$snapshotVerifyApi/api/projects/${widget.projectId}/final-render/release-delivery-snapshot/verify'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>verification=b['verification'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Snapshot verified.':'Snapshot verification failed.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final ok=verification?['verified']==true;
    final blockers=(verification?['blockers'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Snapshot Verification')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ok?Icons.verified:Icons.warning),title:Text(ok?'SNAPSHOT VERIFIED':'SNAPSHOT NOT VERIFIED'),
        subtitle:Text(verification==null?'Verify the captured delivery snapshot.':'Checked: ${verification?['verifiedAt']??''}'))),
      if(verification!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Snapshot ID: ${verification?['snapshotId']??''}'),Text('Size: ${verification?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${verification?['sha256']??''}'),
        if(blockers.isNotEmpty)...[const SizedBox(height:10),const Text('Blockers:'),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:verify,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.verified),
        label:Text(busy?'Verifying…':'Verify Snapshot'))
    ]));
  }
}
