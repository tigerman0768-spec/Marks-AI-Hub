import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AppConfigScreen extends StatefulWidget{
 const AppConfigScreen({super.key});
 @override State<AppConfigScreen> createState()=>_AppConfigScreenState();
}
class _AppConfigScreenState extends State<AppConfigScreen>{
 static const base='http://10.0.2.2:3000'; bool loading=true; Map<String,dynamic>? data;
 Future<void> load()async{
  setState(()=>loading=true);
  try{
   final r=await http.get(Uri.parse('$base/api/config')).timeout(const Duration(seconds:5));
   if(r.statusCode>=300)throw Exception('Configuration request failed');
   setState(()=>data=jsonDecode(r.body));
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>loading=false);
 }
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c)=>Scaffold(
  appBar:AppBar(title:const Text('App Configuration')),
  body:loading?const Center(child:CircularProgressIndicator()):ListView(
   padding:const EdgeInsets.all(16),children:[
    Text('Mark’s AI Configuration',style:Theme.of(c).textTheme.headlineMedium),
    const SizedBox(height:12),
    Card(child:ListTile(title:Text(data?['service']?.toString()??'marks-ai'),
      subtitle:Text('API version ${data?['apiVersion']??'-'}'))),
    const SizedBox(height:8),
    ...((data?['capabilities']??{}) as Map).entries.map((e)=>ListTile(
      leading:Icon(e.value==true?Icons.check_circle:Icons.cancel),
      title:Text(e.key.toString()),trailing:Text(e.value==true?'AVAILABLE':'UNAVAILABLE'))),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:load,icon:const Icon(Icons.refresh),label:const Text('REFRESH'))
   ]));
}
