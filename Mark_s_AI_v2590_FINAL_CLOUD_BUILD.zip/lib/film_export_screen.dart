import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FilmExportScreen extends StatefulWidget{
  final String projectId;
  const FilmExportScreen({super.key,required this.projectId});
  @override State<FilmExportScreen> createState()=>_FilmExportScreenState();
}
class _FilmExportScreenState extends State<FilmExportScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic> data={}; String? error;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/export-info'));
      if(r.statusCode>=300)throw Exception('Export information unavailable');
      data=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Export Film')),body:Center(child:Text(error!)));
    final ready=data['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Export Film')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text(data['title']?.toString()??'Untitled Film',style:Theme.of(c).textTheme.headlineMedium),
      const SizedBox(height:18),
      Card(child:ListTile(leading:Icon(ready?Icons.check_circle:Icons.info_outline),
        title:Text(ready?'Film ready to export':'Film not ready'),
        subtitle:Text('${data['format']??'MP4'} • ${data['resolution']??'1080p'} • ${data['aspectRatio']??'16:9'}'))),
      if(ready)const Padding(padding:EdgeInsets.only(top:16),
        child:Text('The final master is available. Use the Film Library/player to access the finished film file.')),
    ]));
  }
}
