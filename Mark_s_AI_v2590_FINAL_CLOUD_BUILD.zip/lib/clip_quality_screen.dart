import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ClipQualityScreen extends StatefulWidget{
  final String projectId;
  const ClipQualityScreen({super.key,required this.projectId});
  @override State<ClipQualityScreen> createState()=>_ClipQualityScreenState();
}
class _ClipQualityScreenState extends State<ClipQualityScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<dynamic> results=[];
  @override void initState(){super.initState();check();}
  Future<void> check()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/quality'));
      if(r.statusCode<300)setState(()=>results=(jsonDecode(r.body)['results'] as List));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Clip Quality Inspector'),actions:[
      IconButton(onPressed:loading?null:check,icon:const Icon(Icons.refresh))
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):results.isEmpty
      ?const Center(child:Text('No downloaded clips to inspect.'))
      :ListView.builder(
        padding:const EdgeInsets.all(12),itemCount:results.length,
        itemBuilder:(context,i){
          final m=Map<String,dynamic>.from(results[i] as Map);
          final status=m['status']??'failed';
          final passed=status=='passed';
          return Card(child:ListTile(
            leading:Icon(passed?Icons.check_circle:Icons.warning),
            title:Text('Shot ${m['shotNumber']??''} — ${status.toString().toUpperCase()}'),
            subtitle:Text('${m['width']??0}×${m['height']??0} • ${NumberFormatHelper.duration(m['duration'])}\n${(m['issues'] as List?)?.join(', ')??''}'),
            isThreeLine:true,
          ));
        })
  );
}
class NumberFormatHelper{
  static String duration(dynamic value){
    final d=double.tryParse('$value')??0;
    return '${d.toStringAsFixed(1)}s';
  }
}
