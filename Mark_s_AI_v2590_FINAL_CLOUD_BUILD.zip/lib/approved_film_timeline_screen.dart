import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String approvedFilmApi='http://10.0.2.2:3000';

class ApprovedFilmTimelineScreen extends StatefulWidget{
  final String projectId;
  const ApprovedFilmTimelineScreen({super.key,required this.projectId});
  @override State<ApprovedFilmTimelineScreen> createState()=>_ApprovedFilmTimelineScreenState();
}
class _ApprovedFilmTimelineScreenState extends State<ApprovedFilmTimelineScreen>{
  Map<String,dynamic>? timeline; bool loading=true; String message='';
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$approvedFilmApi/api/projects/${widget.projectId}/approved-film-timeline'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>timeline=jsonDecode(r.body)['timeline'] as Map<String,dynamic>?);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> buildTimeline()async{
    setState(()=>message='Building film timeline…');
    final r=await http.post(Uri.parse('$approvedFilmApi/api/projects/${widget.projectId}/approved-film-timeline/build'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200?'Film timeline ready.':'Blocked: ${b['blockers']??b['error']??''}');
    if(r.statusCode==200)load();
  }
  @override Widget build(BuildContext context){
    final clips=(timeline?['clips'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Film Timeline'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
      body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(leading:const Icon(Icons.movie),title:Text('${timeline?['title']??'No timeline'}'),subtitle:Text('${timeline?['clipCount']??0} clips • ${timeline?['totalDuration']??0}s'))),
        FilledButton.icon(onPressed:buildTimeline,icon:const Icon(Icons.build),label:const Text('Build From Approved Clips')),
        if(message.isNotEmpty)Padding(padding:const EdgeInsets.all(12),child:Text(message)),
        const SizedBox(height:8),
        ...List.generate(clips.length,(i){
          final c=clips[i] as Map<String,dynamic>;
          return Card(child:ListTile(leading:CircleAvatar(child:Text('${c['order']}')),title:Text('Shot ${c['shotId']??c['clipId']}'),subtitle:Text('${c['duration']}s • ${c['status']}'),trailing:const Icon(Icons.drag_handle)));
        })
      ]));
  }
}
