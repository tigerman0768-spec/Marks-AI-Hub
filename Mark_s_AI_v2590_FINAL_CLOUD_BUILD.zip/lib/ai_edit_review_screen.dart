import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiEditReviewScreen extends StatefulWidget{
  final String projectId;
  const AiEditReviewScreen({super.key,required this.projectId});
  @override State<AiEditReviewScreen> createState()=>_AiEditReviewScreenState();
}
class _AiEditReviewScreenState extends State<AiEditReviewScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; String? error; Map<String,dynamic> edit={};
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/ai-edit'));
      if(r.statusCode>=300)throw Exception('Edit plan unavailable (${r.statusCode})');
      edit=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> _apply() async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/edit-pipeline/apply'),
        headers:{'Content-Type':'application/json'});
      if(r.statusCode>=300)throw Exception('Could not apply edit (${r.statusCode})');
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('AI edit applied')));
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('AI Edit')),body:Center(child:Text(error!)));
    final items=(edit['items'] as List?)??[];
    return Scaffold(appBar:AppBar(title:const Text('AI Edit Review')),body:ListView(
      padding:const EdgeInsets.all(16),children:[
        Text('Automatic Edit',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:6),
        Text('${items.length} clips • ${edit['cutCount']??0} cuts • ${edit['transitionCount']??0} transitions'),
        const SizedBox(height:16),
        ...items.map((x)=>Card(child:ListTile(
          leading:const Icon(Icons.content_cut),
          title:Text('Shot ${x['shotNumber']??''} • ${x['pacing']??'normal'}'),
          subtitle:Text('${x['transition']??'cut'} ${x['transitionDuration']??0}s\n${x['transitionReason']??''}'),
          isThreeLine:true,
        ))),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:items.isEmpty?null:_apply,
          icon:const Icon(Icons.check),label:const Text('APPLY AI EDIT')),
      ]));
  }
}
