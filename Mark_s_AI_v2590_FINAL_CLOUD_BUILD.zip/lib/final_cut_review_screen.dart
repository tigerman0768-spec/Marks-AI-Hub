import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String finalCutReviewApi='http://10.0.2.2:3000';

class FinalCutReviewScreen extends StatefulWidget{
  final String projectId;
  const FinalCutReviewScreen({super.key,required this.projectId});
  @override State<FinalCutReviewScreen> createState()=>_FinalCutReviewScreenState();
}
class _FinalCutReviewScreenState extends State<FinalCutReviewScreen>{
  Map<String,dynamic> data={};bool loading=true,working=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final r=await http.get(Uri.parse('$finalCutReviewApi/api/projects/${widget.projectId}/final-cut/review'));
    if(r.statusCode==200&&mounted)setState(()=>data=jsonDecode(r.body));
    if(mounted)setState(()=>loading=false);
  }
  Future<void> start()async{
    await http.post(Uri.parse('$finalCutReviewApi/api/projects/${widget.projectId}/final-cut/review/start'));load();
  }
  Future<void> decide(String id,String s)async{
    await http.patch(Uri.parse('$finalCutReviewApi/api/projects/${widget.projectId}/final-cut/review/$id'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'status':s}));load();
  }
  Future<void> finish()async{
    setState(()=>working=true);
    final r=await http.post(Uri.parse('$finalCutReviewApi/api/projects/${widget.projectId}/final-cut/review/finalize'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Final Cut review finalized.':'Complete all decisions first.')));
    setState(()=>working=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final clips=List<Map<String,dynamic>>.from((data['clips'] as List???[]).map((x)=>Map<String,dynamic>.from(x)));
    final rev=Map<String,dynamic>.from((data['review'] as Map???{}));
    final ds=List<Map<String,dynamic>>.from((rev['decisions'] as List???[]).map((x)=>Map<String,dynamic>.from(x)));
    final done=rev['status']=='finalized';
    return Scaffold(appBar:AppBar(title:const Text('Final Cut Review')),body:ListView(padding:const EdgeInsets.all(12),children:[
      Card(child:ListTile(title:Text('${clips.length} Final Cut clips'),subtitle:Text(done?'Final Cut review complete':'Approve the final sequence before finishing.'))),
      if(rev.isEmpty)FilledButton.icon(onPressed:start,icon:const Icon(Icons.rate_review),label:const Text('Start Final Cut Review')),
      ...clips.map((x){
        final d=ds.where((z)=>z['timelineId']==x['id']).isNotEmpty?ds.firstWhere((z)=>z['timelineId']==x['id']):{};
        return Card(child:ListTile(title:Text('Scene ${x['scene']??'-'} • Shot ${x['shotId']??'-'}'),
          subtitle:Text('Decision: ${d['status']??'pending'}'),
          trailing:PopupMenuButton<String>(onSelected:(s)=>decide(x['id'],s),itemBuilder:(_)=>const[
            PopupMenuItem(value:'keep',child:Text('Keep')),PopupMenuItem(value:'remove',child:Text('Remove')),
            PopupMenuItem(value:'trim',child:Text('Trim'))
          ])));
      }),
      FilledButton.icon(onPressed:ds.isEmpty||done||working?null:finish,
        icon:working?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.done_all),
        label:Text(working?'Finalizing…':'Finalize Final Cut Review'))
    ]));
  }
}
