import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProjectRecoveryScreen extends StatefulWidget{
 final String projectId; const ProjectRecoveryScreen({super.key,required this.projectId});
 @override State<ProjectRecoveryScreen> createState()=>_ProjectRecoveryScreenState();
}
class _ProjectRecoveryScreenState extends State<ProjectRecoveryScreen>{
 static const base='http://10.0.2.2:3000'; bool loading=true,busy=false; List points=[];
 Future<void> load()async{setState(()=>loading=true);try{
  final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/recovery'));
  if(r.statusCode>=300)throw Exception('Recovery check failed');
  setState(()=>points=(jsonDecode(r.body)['recoveryPoints'] as List));
 }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
 if(mounted)setState(()=>loading=false);}
 Future<void> recover(String type)async{
  setState(()=>busy=true);try{
   final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/recover'),headers:{'Content-Type':'application/json'},body:jsonEncode({'type':type}));
   if(r.statusCode>=300)throw Exception('Recovery failed');
   if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Recovered from $type')));
   await load();
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>busy=false);
 }
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Project Recovery')),
 body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
  Text('Recovery Points',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:8),
  const Text('Restore a saved backup or archive if the working project becomes damaged or needs to be rolled back.'),
  const SizedBox(height:16),
  if(points.isEmpty)const Card(child:ListTile(title:Text('No recovery points found'))),
  ...points.map((p)=>Card(child:ListTile(leading:Icon(p['type']=='archive'?Icons.archive:Icons.backup),
    title:Text('${p['type']}'.toUpperCase()),subtitle:Text(p['modifiedAt']??''),
    trailing:FilledButton(onPressed:busy?null:()=>recover(p['type']),child:const Text('RESTORE'))))),
  const SizedBox(height:12),OutlinedButton.icon(onPressed:busy?null:load,icon:const Icon(Icons.refresh),label:const Text('REFRESH'))
 ]));
}
