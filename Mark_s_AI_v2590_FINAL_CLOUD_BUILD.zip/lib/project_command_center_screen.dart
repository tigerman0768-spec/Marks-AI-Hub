import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'production_workflow_screen.dart';

const String commandCenterApi = 'http://10.0.2.2:3000';

class ProjectCommandCenterScreen extends StatefulWidget {
  final String projectId;
  const ProjectCommandCenterScreen({super.key, required this.projectId});

  @override
  State<ProjectCommandCenterScreen> createState() => _ProjectCommandCenterScreenState();
}

class _ProjectCommandCenterScreenState extends State<ProjectCommandCenterScreen> {
  Map<String, dynamic>? data;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final response = await http.get(Uri.parse(
        '$commandCenterApi/api/projects/${widget.projectId}/command-center',
      ));
      if (response.statusCode != 200) {
        throw Exception('Server returned ${response.statusCode}');
      }
      setState(() {
        data = jsonDecode(response.body) as Map<String, dynamic>;
        loading = false;
      });
    } catch (e) {
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Command Centre')),
        body: Center(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: load, child: const Text('Retry')),
          ]),
        )),
      );
    }

    final p = data!;
    final commands = List<Map<String, dynamic>>.from(
      (p['commands'] as List? ?? []).map((x) => Map<String, dynamic>.from(x)),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(p['title'] ?? 'Command Centre'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: const Icon(Icons.movie),
            title: Text(p['title'] ?? 'Untitled Film'),
            subtitle: Text('Status: ${p['status'] ?? 'draft'}'),
          )),
          const SizedBox(height: 12),
          const Text('Production Command Centre',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...commands.map((c) {
            final ready = c['ready'] == true;
            return Card(
              child: ListTile(
                leading: Icon(ready ? Icons.check_circle : Icons.play_circle_outline),
                title: Text(c['label'] ?? c['id']),
                subtitle: Text(ready ? 'Prepared' : 'Needs attention'),
                trailing: ready
                    ? const Icon(Icons.chevron_right)
                    : FilledButton(
                        onPressed: () => _openStudio(),
                        child: const Text('Open'),
                      ),
                onTap: _openStudio,
              ),
            );
          }),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _openStudio,
            icon: const Icon(Icons.movie_creation),
            label: const Text('Open Full Production Studio'),
          ),
        ],
      ),
    );
  }

  void _openStudio() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductionWorkflowScreen(projectId: widget.projectId),
      ),
    );
  }
}
