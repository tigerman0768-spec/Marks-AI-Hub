import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'timeline_transition_picker.dart';
import 'timeline_preview_screen.dart';
import 'audio_library_screen.dart';
import 'timeline_audio_editor_screen.dart';
import 'dialogue_timeline_screen.dart';
import 'voice_generation_screen.dart';
import 'character_voice_profiles_screen.dart';
import 'scene_performance_director_screen.dart';
import 'cinematic_shot_director_screen.dart';
import 'visual_continuity_screen.dart';
import 'video_prompt_director_screen.dart';
import 'video_generation_orchestrator_screen.dart';
import 'video_generation_monitor_screen.dart';
import 'clip_download_screen.dart';
import 'clip_quality_screen.dart';
import 'smart_clip_review_screen.dart';
import 'clip_version_screen.dart';
import 'best_clip_selector_screen.dart';
import 'clip_continuity_screen.dart';
import 'cinematic_consistency_screen.dart';
import 'film_level_director_screen.dart';
import 'ai_final_cut_screen.dart';
import 'ai_timeline_builder_screen.dart';
import 'ai_editing_engine_screen.dart';
import 'ai_shot_content_analysis_screen.dart';
import 'ai_editing_decisions_screen.dart';
import 'ai_timeline_trim_renderer_screen.dart';
import 'ai_film_assembler_screen.dart';
import 'ai_transition_renderer_screen.dart';
import 'ai_final_finishing_screen.dart';
import 'ai_master_finish_screen.dart';
import 'ai_audio_ducking_screen.dart';
import 'one_click_final_film_screen.dart';
import 'complete_final_film_screen.dart';
import 'final_film_quality_screen.dart';
import 'final_film_auto_repair_screen.dart';
import 'smart_one_click_final_render_screen.dart';
import 'final_render_status_card.dart';

class FilmTimelineScreen extends StatefulWidget{
  final String projectId;
  const FilmTimelineScreen({super.key,required this.projectId});
  @override State<FilmTimelineScreen> createState()=>_FilmTimelineScreenState();
}
class _FilmTimelineScreenState extends State<FilmTimelineScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> items=[]; bool dirty=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/timeline'));
      if(r.statusCode==200){
        final d=jsonDecode(r.body);
        items=(d['items'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> saveReorder(int from,int to) async{
    final r=await http.patch(
      Uri.parse('$base/api/projects/${widget.projectId}/timeline'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'action':'reorder','from':from,'to':to}),
    );
    if(r.statusCode<300){dirty=false;await load();}
  }
  Future<void> removeAt(int index) async{
    final removed=items[index];
    setState(()=>items.removeAt(index));
    final r=await http.patch(
      Uri.parse('$base/api/projects/${widget.projectId}/timeline'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'action':'remove','index':index}),
    );
    if(r.statusCode>=300){
      setState(()=>items.insert(index,removed));
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not remove shot')));
    }
  }
  Future<void> rebuild() async{
    setState(()=>loading=true);
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/timeline/build'));
    if(r.statusCode<300)await load();
    else if(mounted){setState(()=>loading=false);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Timeline could not be rebuilt')));}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Film Timeline'),actions:[
      IconButton(onPressed:rebuild,icon:const Icon(Icons.refresh),tooltip:'Rebuild'),
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):
      items.isEmpty?const Center(child:Text('No approved clips in the timeline yet.')):
      Column(children:[
        FinalRenderStatusCard(projectId:widget.projectId),
        const SizedBox(height:8),
        Padding(padding:const EdgeInsets.fromLTRB(16,12,16,4),
          child:Row(children:[
            const Icon(Icons.drag_indicator),const SizedBox(width:8),
            Text('${items.length} shots • drag to reorder',
              style:const TextStyle(fontWeight:FontWeight.w600)),
          ])),
        Expanded(child:ReorderableListView.builder(
          padding:const EdgeInsets.all(12),
          itemCount:items.length,
          onReorder:(oldIndex,newIndex)async{
            if(newIndex>oldIndex)newIndex--;
            setState((){
              final item=items.removeAt(oldIndex);
              items.insert(newIndex,item);
              dirty=true;
            });
            await saveReorder(oldIndex,newIndex);
          },
          itemBuilder:(context,i){
            final j=items[i];
            final tr=j['transition'];
            final type=tr is Map ? (tr['type']?.toString()??'cut') : (tr?.toString()??'cut');
            final dur=tr is Map ? (double.tryParse('${tr['duration']??0}')??0) : 0.0;
            return Card(
              key:ValueKey(j['id']??j['jobId']??i),
              child:ExpansionTile(
                leading:CircleAvatar(child:Text('${i+1}')),
                title:Text('${j['sceneTitle']??'Scene'} — Shot ${j['shotNumber']??''}'),
                subtitle:Text('${j['shotType']??'shot'} • ${j['duration']??5}s • $type'),
                trailing:IconButton(
                  icon:const Icon(Icons.delete_outline),
                  tooltip:'Remove shot',
                  onPressed:()=>removeAt(i),
                ),
                children:[
                  Padding(
                    padding:const EdgeInsets.fromLTRB(16,0,16,12),
                    child:TimelineTransitionPicker(
                      type:type,duration:dur,
                      onChanged:(value)async{
                        final r=await http.patch(
                          Uri.parse('$base/api/projects/${widget.projectId}/timeline/$i/transition'),
                          headers:{'Content-Type':'application/json'},
                          body:jsonEncode({'transition':value}),
                        );
                        if(r.statusCode<300)await load();
                      },
                    ),
                  ),
                ],
              ),
            );
          }
        )),
      ]),
  );
}
