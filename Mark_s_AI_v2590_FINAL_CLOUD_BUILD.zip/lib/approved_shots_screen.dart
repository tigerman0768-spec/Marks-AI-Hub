import 'film_timeline_screen.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'clip_review_screen.dart';

class ApprovedShotsScreen extends StatefulWidget{
  final String projectId;
  const ApprovedShotsScreen({super.key,required this.projectId});
  @override State<ApprovedShotsScreen> createState()=>_ApprovedShotsScreenState();
}
class _ApprovedShotsScreenState extends State<ApprovedShotsScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> shots=[]; Map<String,dynamic> summary={};
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/approved-shots'));
      if(r.statusCode==200){
        final d=jsonDecode(r.body);
        shots=(d['shots'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
        summary=Map<String,dynamic>.from(d['summary']??{});
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Approved Shots')),
    body:loading?const Center(child:CircularProgressIndicator()):
      RefreshIndicator(
        onRefresh:load,
        child:ListView(
          padding:const EdgeInsets.all(16),
          children:[
            Card(child:ListTile(
              leading:const Icon(Icons.verified),
              title:Text('${summary['approved']??shots.length} approved'),
              subtitle:Text('${summary['total']??0} total • ${summary['rejected']??0} rejected • ${summary['pending']??0} pending'),
            )),
            if(shots.isEmpty)
              const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('No clips have been approved yet.')))
            else ...shots.map((j)=>Card(child:ListTile(
              leading:const Icon(Icons.video_library),
              title:Text('Shot ${j['shotNumber']??''}'),
              subtitle:Text('${j['sceneTitle']??''} • ${j['shotType']??'shot'}'),
              trailing:const Icon(Icons.check_circle),
            ))),
            const SizedBox(height:12),
            FilledButton.icon(
              onPressed:()=>Navigator.push(context,MaterialPageRoute(
                builder:(_)=>FilmTimelineScreen(projectId:widget.projectId))),
              icon:const Icon(Icons.movie_creation),label:const Text('BUILD FILM TIMELINE'),
            ),
            const SizedBox(height:12),
            OutlinedButton.icon(
              onPressed:()=>Navigator.push(context,MaterialPageRoute(
                builder:(_)=>ClipReviewScreen(projectId:widget.projectId,jobs:shots))),
              icon:const Icon(Icons.rate_review),label:const Text('REVIEW APPROVED SHOTS'),
            ),
          ],
        ),
      ),
  );
}
