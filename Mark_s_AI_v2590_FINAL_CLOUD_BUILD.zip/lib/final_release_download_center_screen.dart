import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'release_package_integrity_history_screen.dart';

class FinalReleaseDownloadCenterScreen extends StatefulWidget {
  final String projectId;
  final String apiBase;
  const FinalReleaseDownloadCenterScreen({super.key,required this.projectId,this.apiBase='http://10.0.2.2:3000'});
  @override State<FinalReleaseDownloadCenterScreen> createState()=>_FinalReleaseDownloadCenterScreenState();
}
class _FinalReleaseDownloadCenterScreenState extends State<FinalReleaseDownloadCenterScreen>{
  Map<String,dynamic>? data; bool loading=true; String message=''; String? busyId; bool packageBusy=false; bool verifyBusy=false; Map<String,dynamic>? verification;
  @override void initState(){super.initState();load();}
  Future<void> load() async { setState(()=>loading=true); try{final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/download-center')); final b=jsonDecode(r.body); if(!mounted)return; setState(()=>data=r.statusCode==200?Map<String,dynamic>.from(b):{'error':b['error']??'Unable to load'});}catch(e){if(mounted)setState(()=>data={'error':'Download Centre unavailable'});} if(mounted)setState(()=>loading=false); }
  Future<void> downloadAndShare(Map<String,dynamic> item) async {
    final id='${item['id']}'; final url=item['downloadPath']; if(url is! String)return;
    setState(()=>busyId=id);
    try{final r=await http.get(Uri.parse('${widget.apiBase}$url')); if(r.statusCode!=200)throw Exception('File is not available'); final dir=await getTemporaryDirectory(); final name=(item['info']?['name'] as String?)??'marks_ai_${id}'; final f=File('${dir.path}/$name'); await f.writeAsBytes(r.bodyBytes,flush:true); await Share.shareXFiles([XFile(f.path)],text:'Mark’s AI — ${item['label']}'); if(mounted)setState(()=>message='${item['label']} is ready to save or share.');}catch(e){if(mounted)setState(()=>message='${item['label']} unavailable: $e');}finally{if(mounted)setState(()=>busyId=null);}
  }

  Future<void> shareCompletePackage() async {
    if(packageBusy)return;
    setState(()=>packageBusy=true);
    try{
      final build=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-package'));
      final b=jsonDecode(build.body);
      if(build.statusCode!=200 || b['available']!=true) throw Exception(b['reason']??'Release package unavailable');
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-package/download'));
      if(r.statusCode!=200)throw Exception('Package download failed');
      final dir=await getTemporaryDirectory();
      final name=(b['name'] as String?)??'marks_ai_release_package.zip';
      final f=File('${dir.path}/$name');
      await f.writeAsBytes(r.bodyBytes,flush:true);
      await Share.shareXFiles([XFile(f.path)],text:'Mark’s AI — complete verified release package');
      if(mounted)setState(()=>message='Complete release package is ready to save or share.');
    }catch(e){if(mounted)setState(()=>message='Release package unavailable: $e');}
    finally{if(mounted)setState(()=>packageBusy=false);}
  }

  Future<void> verifyCompletePackage() async {
    if(verifyBusy)return;
    setState(()=>verifyBusy=true);
    try{
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-package/verify'));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      setState(()=>verification=Map<String,dynamic>.from(b));
      if(r.statusCode!=200) setState(()=>message='Package verification could not be completed.');
      else setState(()=>message=b['verified']==true?'Complete release package verified successfully.':'Package verification found a problem.');
    }catch(e){if(mounted)setState(()=>message='Verification unavailable: $e');}
    finally{if(mounted)setState(()=>verifyBusy=false);}
  }

  String size(dynamic n){final x=n is num?n.toDouble():double.tryParse('$n')??0;if(x<1024)return '${x.toInt()} B';if(x<1048576)return '${(x/1024).toStringAsFixed(1)} KB';if(x<1073741824)return '${(x/1048576).toStringAsFixed(1)} MB';return '${(x/1073741824).toStringAsFixed(2)} GB';}
  @override Widget build(BuildContext context){
    final d=data;
    return Scaffold(appBar:AppBar(title:const Text('Final Release Download Centre'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):d==null?const SizedBox():d['error']!=null?Center(child:Text('${d['error']}')):ListView(padding:const EdgeInsets.all(16),children:[Text(d['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:8),Text('${d['availableCount']}/${d['totalCount']} release files available'),const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:packageBusy?null:shareCompletePackage,icon:packageBusy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.inventory_2),label:Text(packageBusy?'Preparing package…':'Share Complete Release Package'))),const SizedBox(height:8),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:verifyBusy?null:verifyCompletePackage,icon:verifyBusy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.verified_user),label:Text(verifyBusy?'Verifying package…':'Verify Complete Release Package'))),const SizedBox(height:8),SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>ReleasePackageIntegrityHistoryScreen(projectId:widget.projectId,apiBase:widget.apiBase))),icon:const Icon(Icons.history),label:const Text('Integrity Verification History'))),if(verification!=null)Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(verification!['verified']==true?Icons.check_circle:Icons.error),const SizedBox(width:8),Text(verification!['verified']==true?'PACKAGE VERIFIED':'VERIFICATION FAILED',style:Theme.of(context).textTheme.titleMedium)]),const SizedBox(height:8),Text('Package SHA-256: ${verification!['package']?['sha256']??'—'}',style:const TextStyle(fontSize:11)),Text('Files checked: ${verification!['manifest']?['fileCount']??0}')]))),const SizedBox(height:12),for(final raw in (d['items'] as List? ?? const [])){final item=Map<String,dynamic>.from(raw as Map);final available=item['available']==true;Card(child:ListTile(leading:Icon(available?Icons.check_circle:Icons.cloud_off),title:Text(item['label']??'File'),subtitle:Text(available?size(item['info']?['bytes']):'Not available'),trailing:FilledButton(onPressed:available&&busyId==null?()=>downloadAndShare(item):null,child:busyId==item['id']?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Text('Download')))},if(message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:12),child:Text(message))]);
  }
}
