import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AudioLibraryScreen extends StatefulWidget{
  const AudioLibraryScreen({super.key});
  @override State<AudioLibraryScreen> createState()=>_AudioLibraryScreenState();
}
class _AudioLibraryScreenState extends State<AudioLibraryScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> tracks=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/audio-library'));
      if(r.statusCode==200){
        final d=jsonDecode(r.body);
        tracks=(d['tracks'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Music & SFX Library')),
    body:loading?const Center(child:CircularProgressIndicator()):
      RefreshIndicator(onRefresh:load,child:ListView(
        padding:const EdgeInsets.all(16),
        children:[
          const Text('Timeline Audio Library',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('Music and sound-effect tracks can be stored with start/end times, volume and fades.'),
          const SizedBox(height:16),
          if(tracks.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('No audio tracks configured yet.')))
          else ...tracks.map((t)=>Card(child:ListTile(
            leading:Icon(t['type']=='sfx'?Icons.graphic_eq:Icons.music_note),
            title:Text(t['name']??'Audio'),
            subtitle:Text('${t['type']??'music'} • start ${t['start']??0}s • volume ${t['volume']??0.35}'),
          ))),
        ],
      )),
  );
}
