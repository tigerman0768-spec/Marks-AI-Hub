import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'production_plan_review_screen.dart';
import 'character_bible_screen.dart';
import 'storyboard_screen.dart';

class ScreenplayScreen extends StatefulWidget{
  final String projectId;
  const ScreenplayScreen({super.key,required this.projectId});
  @override State<ScreenplayScreen> createState()=>_ScreenplayScreenState();
}
class _ScreenplayScreenState extends State<ScreenplayScreen>{
  static const base='http://10.0.2.2:3000';
  Map<String,dynamic>? project; bool loading=true,generating=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}'));
    if(r.statusCode==200)project=Map<String,dynamic>.from(jsonDecode(r.body));
    if(mounted)setState(()=>loading=false);
  }
  Future<void> generate() async{
    setState(()=>generating=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/generate-screenplay'));
      if(r.statusCode>=300)throw Exception(r.body);
      await load();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Screenplay draft generated')));
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Generation failed: $e')));
    }
    if(mounted)setState(()=>generating=false);
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final p=project??{}; final scenes=(p['scenes'] as List? ?? []);
    final screenplay=p['screenplay'];
    return Scaffold(appBar:AppBar(title:Text(p['title']?.toString()??'Screenplay')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('AI Screenplay',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:8),
      Text('${p['genre']??'Drama'} • ${p['length']??5} minutes • ${p['style']??'Cinematic'}'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:generating?null:generate,icon:generating?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(generating?'GENERATING…':'GENERATE SCREENPLAY')),
      if(screenplay!=null) ...[
        const SizedBox(height:20),
        const Text('Screenplay structure',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        ...scenes.map((s)=>Card(child:ListTile(
          leading:CircleAvatar(child:Text('${s['number']??''}')),
          title:Text(s['title']?.toString()??'Scene'),
          subtitle:Text(s['action']?.toString()??'')))),
        const SizedBox(height:12),
        OutlinedButton.icon(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(
          title:const Text('Generation prompt'),content:SingleChildScrollView(child:Text((screenplay is Map?screenplay['prompt']:'')?.toString()??'')),
          actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])),
          icon:const Icon(Icons.description),label:const Text('VIEW AI PROMPT')),
        const SizedBox(height:10),
        OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(
          builder:(_)=>CharacterBibleScreen(projectId:widget.projectId))),
          icon:const Icon(Icons.people),label:const Text('CHARACTER BIBLE')),
        const SizedBox(height:10),
        OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(
          builder:(_)=>StoryboardScreen(projectId:widget.projectId))),
          icon:const Icon(Icons.view_carousel),label:const Text('BUILD STORYBOARD')),
      ],
    ]));
  }
}
