import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String deliveryAuditApi='http://10.0.2.2:3000';

class ReleasedFilmDeliveryAuditScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliveryAuditScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliveryAuditScreen> createState()=>_ReleasedFilmDeliveryAuditScreenState();
}
class _ReleasedFilmDeliveryAuditScreenState extends State<ReleasedFilmDeliveryAuditScreen>{
  List<dynamic> audit=[];bool busy=false;
  Future<void> load()async{
    setState(()=>busy=true);
    try{
      final r=await http.get(Uri.parse('$deliveryAuditApi/api/projects/${widget.projectId}/final-render/release-delivery-audit'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>audit=(jsonDecode(r.body)['audit'] as List<dynamic>? ?? []));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> addReview()async{
    await http.post(Uri.parse('$deliveryAuditApi/api/projects/${widget.projectId}/final-render/release-delivery-audit'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'event':'manual_review','details':{'source':'flutter'}}));
    if(mounted)await load();
  }
  @override void initState(){super.initState();load();}
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Audit'),actions:[
      IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))
    ]),body:Column(children:[
      Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:addReview,
        icon:const Icon(Icons.note_add),label:const Text('Record Manual Review'))),
      Expanded(child:busy?const Center(child:CircularProgressIndicator()):
        audit.isEmpty?const Center(child:Text('No delivery audit events yet.')):
        ListView.builder(itemCount:audit.length,itemBuilder:(c,i){
          final a=audit[i] as Map<String,dynamic>;
          return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(
            leading:const Icon(Icons.history),title:Text('${a['event']??''}'),
            subtitle:Text('${a['timestamp']??''}\nAudit ID: ${a['auditId']??''}'),
            isThreeLine:true));
        }))
    ]));
  }
}
