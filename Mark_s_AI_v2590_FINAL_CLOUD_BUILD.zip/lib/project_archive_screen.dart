import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class ProjectArchiveScreen extends StatefulWidget{
  final String projectId;const ProjectArchiveScreen({super.key,required this.projectId});
  @override State<ProjectArchiveScreen> createState()=>_ProjectArchiveScreenState();
}
class _ProjectArchiveScreenState extends State<ProjectArchiveScreen>{
  static const base='http://10.0.2.2:3000';bool busy=false;String status='Not archived';
  Future<void> _archive()async{setState(()=>busy=true);try{
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/archive'));
    if(r.statusCode>=300)throw Exception('Archive failed');setState(()=>status='Archived');
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>busy=false);}
  Future<void> _remove()async{setState(()=>busy=true);try{
    final r=await http.delete(Uri.parse('$base/api/projects/${widget.projectId}/archive'));
    if(r.statusCode>=300)throw Exception('Archive removal failed');setState(()=>status='Archive removed');
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>busy=false);}
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Project Archive')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Project Archive',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:8),
      const Text('Keep an archived snapshot of the current project state.'),const SizedBox(height:18),
      Card(child:ListTile(leading:const Icon(Icons.archive),title:const Text('Archive status'),subtitle:Text(status))),
      const SizedBox(height:14),FilledButton.icon(onPressed:busy?null:_archive,icon:const Icon(Icons.archive),label:Text(busy?'WORKING...':'ARCHIVE PROJECT')),
      const SizedBox(height:8),OutlinedButton.icon(onPressed:busy?null:_remove,icon:const Icon(Icons.delete_outline),label:const Text('DELETE ARCHIVE'))
    ]));
}
