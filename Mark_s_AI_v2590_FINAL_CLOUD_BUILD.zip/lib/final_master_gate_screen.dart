import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String masterGateApi='http://10.0.2.2:3000';
class FinalMasterGateScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterGateScreen({super.key,required this.projectId});
  @override State<FinalMasterGateScreen> createState()=>_FinalMasterGateScreenState();
}
class _FinalMasterGateScreenState extends State<FinalMasterGateScreen>{
  Map<String,dynamic>? gate;bool busy=false;
  Future<void> evaluate()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$masterGateApi/api/projects/${widget.projectId}/final-render/master-gate/evaluate'));
    if(!mounted)return;
    final body=jsonDecode(r.body);
    setState(()=>gate=body['gate'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode==200?'Final Master is ready.':'Final Master is not ready yet.')));
  }
  @override Widget build(BuildContext context){
    final ready=gate?['ready']==true;
    final blockers=(gate?['blockers'] as List?)?.map((e)=>e.toString()).toList()??[];
    return Scaffold(appBar:AppBar(title:const Text('Final Master Gate')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(
        leading:Icon(ready?Icons.verified:Icons.lock),
        title:Text(ready?'FINAL MASTER READY':'FINAL MASTER BLOCKED'),
        subtitle:Text(gate==null?'Run the gate check before delivery.':'${gate?['status']??'unknown'} • ${gate?['stage']??'waiting'}'))),
      if(gate!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Video: ${gate?['width']??0} × ${gate?['height']??0}'),
        Text('Duration: ${gate?['duration']??0}s'),
        Text('Codec: ${gate?['codec']??'unknown'}'),
        if(blockers.isNotEmpty) ...[
          const SizedBox(height:12),const Text('Blockers:',style:TextStyle(fontWeight:FontWeight.bold)),
          ...blockers.map((b)=>Padding(padding:const EdgeInsets.only(top:6),child:Text('• $b')))
        ]
      ]))),
      FilledButton.icon(onPressed:busy?null:evaluate,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rule),
        label:Text(busy?'Evaluating…':'Evaluate Master Gate'))
    ]));
  }
}
