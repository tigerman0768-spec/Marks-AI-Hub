import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String libraryReleaseApi='http://10.0.2.2:3000';
class FinalMasterLibraryReleaseScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterLibraryReleaseScreen({super.key,required this.projectId});
  @override State<FinalMasterLibraryReleaseScreen> createState()=>_FinalMasterLibraryReleaseScreenState();
}
class _FinalMasterLibraryReleaseScreenState extends State<FinalMasterLibraryReleaseScreen>{
  Map<String,dynamic>? release;bool busy=false;
  Future<void> prepare()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$libraryReleaseApi/api/projects/${widget.projectId}/final-render/library-release/prepare'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>release=b['release'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Library release is ready.':'Library release blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=release?['status']=='ready_for_library';
    return Scaffold(appBar:AppBar(title:const Text('Film Library Release')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.video_library:Icons.lock),
        title:Text(ready?'READY FOR FILM LIBRARY':'NOT READY FOR LIBRARY'),
        subtitle:Text(ready?'Library release ID: ${release?['libraryReleaseId']??''}':'Catalogue the released master first.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Title: ${release?['title']??''}'),Text('File: ${release?['filename']??''}'),
        Text('Duration: ${release?['duration']??0}s'),Text('Size: ${release?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${release?['sha256']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:prepare,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.video_library),
        label:Text(busy?'Preparing…':'Prepare Library Release'))
    ]));
  }
}
