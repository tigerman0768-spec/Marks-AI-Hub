import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ScenePerformanceDirectorScreen extends StatefulWidget{
  final String projectId;
  const ScenePerformanceDirectorScreen({super.key,required this.projectId});
  @override State<ScenePerformanceDirectorScreen> createState()=>_ScenePerformanceDirectorScreenState();
}
class _ScenePerformanceDirectorScreenState extends State<ScenePerformanceDirectorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; List<dynamic> scenes=[];
  Future<void> generate()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/performance-director/generate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300){setState(()=>scenes=(jsonDecode(r.body)['performancePlan'] as List));}
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Scene Performance Director')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.movie_filter,size:72),
      const SizedBox(height:12),
      const Text('Coordinate acting, reactions, camera beats and pacing for every scene.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('This creates a production performance plan from the existing screenplay, dialogue, acting direction and shot plan.'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:generate,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(loading?'DIRECTING...':'DIRECT SCENES')),
      const SizedBox(height:20),
      ...scenes.map((s){
        final m=Map<String,dynamic>.from(s as Map);
        final beats=(m['beats'] as List?)??[];
        final shots=(m['shotDirection'] as List?)??[];
        return Card(child:ExpansionTile(
          title:Text(m['sceneTitle']??'Scene'),
          subtitle:Text('Pacing: ${m['pacing']??'normal'} • ${beats.length} dialogue beats • ${shots.length} shots'),
          children:[
            for(final b in beats)
              ListTile(leading:const Icon(Icons.record_voice_over),
                title:Text('${b['character']??'Speaker'} • ${b['beat']??''}'),
                subtitle:Text('${b['emotion']??'neutral'} / ${b['intensity']??'medium'} • reaction ${b['reactionRequired']==true?'yes':'no'}')),
            for(final sh in shots)
              ListTile(leading:const Icon(Icons.videocam),
                title:Text('Shot ${sh['shotNumber']??''} • ${sh['shotType']??''}'),
                subtitle:Text('${sh['cameraMovement']??''} • focus: ${sh['performanceFocus']??''}')),
          ],
        ));
      })
    ]),
  );
}
