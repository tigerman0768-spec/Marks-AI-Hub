import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'release_package_dashboard_screen.dart';

class ReleaseCenterScreen extends StatefulWidget {
  final String projectId;
  final String apiBase;
  const ReleaseCenterScreen({super.key, required this.projectId, this.apiBase='http://10.0.2.2:3000'});
  @override State<ReleaseCenterScreen> createState()=>_ReleaseCenterScreenState();
}
class _ReleaseCenterScreenState extends State<ReleaseCenterScreen>{
  Map<String,dynamic>? data; String message='Loading…'; String? releaseJobId; Map<String,dynamic>? releaseProgress; bool running=false;
  Future<void> showFinalizePlan() async {
    try {
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-center/one-tap-plan'));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      showDialog(context:context,builder:(_)=>AlertDialog(
        title:const Text('Finalize & Release'),
        content:Text(b['complete']==true ? 'All release stages are complete.' : 'Next required stage: ${b['nextStep'] ?? 'unknown'}\n\nPress Run One-Tap Release to execute the remaining stages.'),
        actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close')),
          if(b['complete']!=true) FilledButton(onPressed:(){Navigator.pop(context); executeOneTapRelease();},child:const Text('Run One-Tap Release'))],
      ));
    } catch(_){
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Release plan unavailable')));
    }
  }
  Future<void> executeOneTapRelease() async {
    try {
      if(mounted) setState(()=>running=true);
      final r=await http.post(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-center/one-tap-execute'));
      final b=jsonDecode(r.body);
      if(r.statusCode!=202) throw Exception(b['error']??'Unable to start release');
      releaseJobId=b['jobId'];
      await pollReleaseProgress();
    } catch(e){
      if(mounted) setState(()=>running=false);
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('One-Tap Release failed: $e')));
    }
  }
  Future<void> pollReleaseProgress() async {
    if(releaseJobId==null)return;
    while(mounted && running){
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-center/one-tap-execute/$releaseJobId'));
      if(r.statusCode!=200)break;
      final b=jsonDecode(r.body);
      if(mounted)setState(()=>releaseProgress=b);
      final status=b['status'];
      if(status=='complete'||status=='blocked'||status=='failed'){
        if(mounted)setState(()=>running=false);
        await load();
        if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(status=='complete'?'Release package completed successfully':'Release stopped at ${b['currentStep']??'unknown'}')));
        break;
      }
      await Future.delayed(const Duration(milliseconds:400));
    }
  }
  Future<void> load() async {
    try {
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-center'));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      setState((){data=b;message=r.statusCode==200?'Release Center loaded':'${b['error']??'Unable to load'}';});
    } catch(e){if(mounted)setState(()=>message='Release Center unavailable');}
  }
  @override void initState(){super.initState();load();}
  Widget _progressStage(String name, Map<String,dynamic>? p){
    final current=p?['currentStep'];
    final completed=(p?['completedSteps'] as List?)?.cast<String>()??const <String>[];
    final done=completed.contains(name);
    final active=current==name;
    return ListTile(dense:true,contentPadding:EdgeInsets.zero,leading:Icon(done?Icons.check_circle:active?Icons.sync:Icons.radio_button_unchecked),title:Text(name[0].toUpperCase()+name.substring(1)),trailing:Text(done?'DONE':active?'RUNNING':'WAITING'));
  }
  Widget stage(String name,bool done)=>ListTile(
    leading:Icon(done?Icons.check_circle:Icons.radio_button_unchecked),
    title:Text(name),
    trailing:Text(done?'READY':'PENDING'),
  );
  @override Widget build(BuildContext context){
    final d=data;
    return Scaffold(
      appBar:AppBar(title:const Text('Release Center')),
      body: d==null
        ? Center(child:Text(message))
        : ListView(padding:const EdgeInsets.all(16),children:[
            Text(d['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height:8),
            stage('Release readiness',d['ready']==true),
            stage('Final release approved',d['approved']==true),
            stage('Release sealed',d['sealed']==true),
            stage('Release certificate',d['certified']==true),
            stage('Release manifest saved',d['manifestSaved']==true),
            const Divider(),
            if(running || releaseProgress!=null) ...[
              const SizedBox(height:8),
              Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text('One-Tap Release Progress',style:Theme.of(context).textTheme.titleMedium),
                const SizedBox(height:10),
                for(final name in ['readiness','approval','seal','certificate','manifest']) _progressStage(name, releaseProgress),
                if(running) const Padding(padding:EdgeInsets.only(top:8),child:LinearProgressIndicator()),
              ]))),
            ],
            Card(child:ListTile(
              leading:const Icon(Icons.play_circle_fill),
              title:const Text('Next action'),
              subtitle:Text(d['nextAction']??'—'),
            )),
            const SizedBox(height:12),
            FilledButton.icon(onPressed:load,icon:const Icon(Icons.refresh),label:const Text('Refresh Release Center')),
            const SizedBox(height:8),
            OutlinedButton.icon(onPressed:showFinalizePlan,icon:const Icon(Icons.rocket_launch),label:const Text('Finalize & Release')),
            const SizedBox(height:8),
            OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReleasePackageDashboardScreen(projectId:widget.projectId,apiBase:widget.apiBase))),icon:const Icon(Icons.inventory_2),label:const Text('Release Package Dashboard')),
          ]),
    );
  }
}
