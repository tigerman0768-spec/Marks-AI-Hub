import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String receiptApi='http://10.0.2.2:3000';
class FinalMasterDeliveryReceiptScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterDeliveryReceiptScreen({super.key,required this.projectId});
  @override State<FinalMasterDeliveryReceiptScreen> createState()=>_FinalMasterDeliveryReceiptScreenState();
}
class _FinalMasterDeliveryReceiptScreenState extends State<FinalMasterDeliveryReceiptScreen>{
  Map<String,dynamic>? receipt;bool busy=false;
  Future<void> createReceipt()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$receiptApi/api/projects/${widget.projectId}/final-render/delivery-receipt/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>receipt=b['receipt'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery receipt verified.':'Receipt blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=receipt?['status']=='verified';
    return Scaffold(appBar:AppBar(title:const Text('Delivery Receipt')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.verified:Icons.receipt_long),
        title:Text(ready?'DELIVERY VERIFIED':'DELIVERY NOT VERIFIED'),
        subtitle:Text(ready?'Receipt: ${receipt?['receiptId']??''}':'Create only after the manifest passes.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${receipt?['title']??''}'),
        Text('File: ${receipt?['filename']??''}'),
        Text('Size: ${receipt?['bytes']??0} bytes'),
        Text('Verified: ${receipt?['verifiedAt']??''}'),
        SelectableText('SHA-256: ${receipt?['sha256']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:createReceipt,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.fact_check),
        label:Text(busy?'Verifying…':'Create Delivery Receipt'))
    ]));
  }
}
