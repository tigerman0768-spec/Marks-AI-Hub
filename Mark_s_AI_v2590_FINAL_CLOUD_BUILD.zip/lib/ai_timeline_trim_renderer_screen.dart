import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiTimelineTrimRendererScreen extends StatefulWidget{
  final String projectId;
  const AiTimelineTrimRendererScreen({super.key,required this.projectId});
  @override State<AiTimelineTrimRendererScreen> createState()=>_AiTimelineTrimRendererScreenState();
}
class _AiTimelineTrimRendererScreenState extends State<AiTimelineTrimRendererScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? result;
  Future<void> render()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-edit/render'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('AI trims rendered to video clips')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final items=(result?['items'] as List?)??[];
    return Scaffold(appBar:AppBar(title:const Text('AI Timeline Trim Renderer')),
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:loading?null:render,
            icon:const Icon(Icons.content_cut),label:Text(loading?'RENDERING…':'RENDER AI TRIMS')))),
        if(result!=null)Padding(padding:const EdgeInsets.all(12),
          child:Text('${result!['renderedCount']??0} clips rendered • ${(result!['totalDuration']??0).toStringAsFixed(1)}s')),
        Expanded(child:ListView.builder(itemCount:items.length,itemBuilder:(c,i){
          final x=Map<String,dynamic>.from(items[i] as Map);
          return ListTile(leading:CircleAvatar(child:Text('${x['order']??i+1}')),
            title:Text('Shot ${x['shotNumber']??''} • ${x['renderedDuration']??0}s'),
            subtitle:Text(x['trimApplied']==true?'Trim applied':'Not rendered'));
        }))
      ]));
  }
}
