import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalFilmAutoRepairScreen extends StatefulWidget{
  final String projectId;
  const FinalFilmAutoRepairScreen({super.key,required this.projectId});
  @override State<FinalFilmAutoRepairScreen> createState()=>_FinalFilmAutoRepairScreenState();
}
class _FinalFilmAutoRepairScreenState extends State<FinalFilmAutoRepairScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false;Map<String,dynamic>? result;
  Future<void> repair()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/final-film-auto-repair'));
      if(r.statusCode<300)setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('AI Final Film Auto-Repair')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.build_circle,size:76),const SizedBox(height:16),
          const Text('Check the final film and automatically repair common encoding or stream problems.',
            textAlign:TextAlign.center),const SizedBox(height:20),
          FilledButton.icon(onPressed:loading?null:repair,icon:const Icon(Icons.build),
            label:Text(loading?'REPAIRING…':'CHECK & AUTO-REPAIR')),
          if(result!=null)...[
            const SizedBox(height:24),
            Text('Result: ${result!['status']??'unknown'}',
              style:Theme.of(context).textTheme.titleLarge),
            Text('${result!['repairedPath']??result!['sourcePath']??''}',
              textAlign:TextAlign.center)
          ]
        ])));
  }
}
