import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalRenderJobDetailsScreen extends StatefulWidget{
  final String jobId;
  const FinalRenderJobDetailsScreen({super.key,required this.jobId});
  @override State<FinalRenderJobDetailsScreen> createState()=>_FinalRenderJobDetailsScreenState();
}
class _FinalRenderJobDetailsScreenState extends State<FinalRenderJobDetailsScreen>{
  static const base='http://10.0.2.2:3000';
  Map<String,dynamic>? data;Timer? timer;bool actionBusy=false;
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$base/api/final-render/jobs/${widget.jobId}/history'));
      if(r.statusCode<300&&mounted)setState(()=>data=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
  }
  Future<void> control(String action)async{
    setState(()=>actionBusy=true);
    try{
      await http.post(Uri.parse('$base/api/final-render/jobs/${widget.jobId}/control'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'action':action}));
      await load();
    }catch(_){}
    if(mounted)setState(()=>actionBusy=false);
  }
  String stateLabel(String? s){
    switch(s){
      case 'completed':return 'COMPLETED';
      case 'running':return 'RUNNING';
      case 'recovering':return 'RECOVERING';
      case 'recovery_exhausted':return 'RECOVERY LIMIT REACHED';
      case 'cancelled':return 'CANCELLED';
      case 'cancel_requested':return 'CANCELLATION REQUESTED';
      case 'recoverable':return 'READY TO RECOVER';
      default:return (s??'UNKNOWN').toUpperCase();
    }
  }
  @override void initState(){super.initState();load();timer=Timer.periodic(const Duration(seconds:2),(_)=>load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  @override Widget build(BuildContext context){
    final d=data;if(d==null)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final status=d['status']?.toString();final history=List<dynamic>.from(d['history']??[]);
    final active=status=='running'||status=='recovering';
    final exhausted=status=='recovery_exhausted';
    return Scaffold(appBar:AppBar(title:const Text('Final Render Job Details')),
      body:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text(stateLabel(status),style:Theme.of(context).textTheme.titleLarge),
        Text('Stage: ${d['stage']??'unknown'} • ${d['progress']??0}%'),
        Text('Recovery attempts: ${d['recoveryAttempts']??0}/3'),
        const SizedBox(height:10),
        LinearProgressIndicator(value:((d['progress']??0) as num).toDouble()/100),
        if(d['error']!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text('Error: ${d['error']}')),
        const SizedBox(height:10),
        Wrap(spacing:8,children:[
          if(!active&&status!='completed'&&status!='cancelled'&&!exhausted)
            OutlinedButton.icon(onPressed:actionBusy?null:()=>control('restart'),icon:const Icon(Icons.restart_alt),label:const Text('RESTART')),
          if(active)OutlinedButton.icon(onPressed:actionBusy?null:()=>control('cancel'),icon:const Icon(Icons.stop),label:const Text('CANCEL')),
          if(exhausted)OutlinedButton.icon(onPressed:actionBusy?null:()=>control('reset_recovery'),icon:const Icon(Icons.lock_open),label:const Text('RESET LIMIT')),
        ]),
        if(exhausted)const Padding(padding:EdgeInsets.only(top:6),child:Text('Automatic recovery is blocked until you reset the limit.')),
        const SizedBox(height:14),
        const Text('Stage history',style:TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:6),
        Expanded(child:history.isEmpty?const Center(child:Text('No stage events yet.')):
          ListView.builder(itemCount:history.length,itemBuilder:(c,i){
            final h=Map<String,dynamic>.from(history[i]);
            return ListTile(dense:true,leading:const Icon(Icons.timeline),
              title:Text(h['event']?.toString()??'event'),
              subtitle:Text('${h['progress']??''}% • ${h['at']??''}'));
          }))
      ])));
  }
}
