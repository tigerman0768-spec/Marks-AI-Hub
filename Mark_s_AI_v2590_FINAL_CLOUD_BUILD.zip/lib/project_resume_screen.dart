import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProjectResumeScreen extends StatefulWidget{
 final String projectId;
 const ProjectResumeScreen({super.key,required this.projectId});
 @override State<ProjectResumeScreen> createState()=>_ProjectResumeScreenState();
}
class _ProjectResumeScreenState extends State<ProjectResumeScreen>{
 static const base='http://10.0.2.2:3000';
 Map<String,dynamic>? data; bool loading=true;
 Future<void> load()async{
  setState(()=>loading=true);
  try{
   final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/resume'));
   if(r.statusCode>=300)throw Exception('Resume check failed');
   setState(()=>data=jsonDecode(r.body));
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  if(mounted)setState(()=>loading=false);
 }
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c){
  final d=data;
  return Scaffold(appBar:AppBar(title:const Text('Resume Film')),
   body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
    Text(d?['title']?.toString()??'Film',style:Theme.of(c).textTheme.headlineMedium),
    const SizedBox(height:8),Text('Current status: ${(d?['status']??'draft').toString().toUpperCase()}'),
    const SizedBox(height:20),
    Card(child:ListTile(leading:const Icon(Icons.play_circle_outline),title:Text(d?['nextLabel']?.toString()??'Continue'),subtitle:Text('Next stage: ${d?['nextStage']??'creator'}'))),
    const SizedBox(height:16),
    FilledButton.icon(onPressed:load,icon:const Icon(Icons.refresh),label:const Text('REFRESH RESUME STATE'))
   ]));
 }
}
