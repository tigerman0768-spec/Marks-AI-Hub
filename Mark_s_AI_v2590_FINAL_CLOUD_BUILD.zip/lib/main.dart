import 'package:flutter/material.dart';
import 'mark_ai_dashboard_screen.dart';

void main() => runApp(const MarksAI());

class MarksAI extends StatelessWidget {
  const MarksAI({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Mark's AI",
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const MarkAiDashboardScreen(),
    );
  }
}
