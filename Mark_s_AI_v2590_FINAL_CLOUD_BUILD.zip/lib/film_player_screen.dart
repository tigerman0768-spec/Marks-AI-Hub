import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class FilmPlayerScreen extends StatefulWidget {
  final Map<String,dynamic> film;
  const FilmPlayerScreen({super.key,required this.film});
  @override State<FilmPlayerScreen> createState()=>_FilmPlayerScreenState();
}
class _FilmPlayerScreenState extends State<FilmPlayerScreen>{
  VideoPlayerController? controller;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async{
    final p=widget.film['outputPath']?.toString()??'';
    if(p.isEmpty||!File(p).existsSync())return;
    final c=VideoPlayerController.file(File(p));
    controller=c;
    await c.initialize();
    if(mounted)setState((){});
    c.play();
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final c=controller;
    return Scaffold(
      appBar:AppBar(title:Text(widget.film['title']?.toString()??'Film')),
      body:c==null||!c.value.isInitialized
        ? const Center(child:Icon(Icons.movie,size:80))
        : Center(child:AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c))),
      floatingActionButton:c==null?null:FloatingActionButton(
        onPressed:(){setState(()=>c.value.isPlaying?c.pause():c.play());},
        child:Icon(c.value.isPlaying?Icons.pause:Icons.play_arrow)),
    );
  }
}
