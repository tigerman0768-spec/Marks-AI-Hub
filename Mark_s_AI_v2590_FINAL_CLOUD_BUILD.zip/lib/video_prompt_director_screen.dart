import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoPromptDirectorScreen extends StatefulWidget{
  final String projectId;
  const VideoPromptDirectorScreen({super.key,required this.projectId});
  @override State<VideoPromptDirectorScreen> createState()=>_VideoPromptDirectorScreenState();
}
class _VideoPromptDirectorScreenState extends State<VideoPromptDirectorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; List<dynamic> prompts=[];
  Future<void> generate()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/video-prompts/generate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300)setState(()=>prompts=(jsonDecode(r.body)['prompts'] as List));
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Video Prompt Director')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.auto_awesome_motion,size:72),
      const SizedBox(height:12),
      const Text('Build production-ready prompts for every video shot.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('Combines story, character performance, visual continuity and cinematography into one shot prompt.'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:generate,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(loading?'BUILDING PROMPTS...':'BUILD VIDEO PROMPTS')),
      const SizedBox(height:16),
      ...prompts.map((p){
        final m=Map<String,dynamic>.from(p as Map);
        return Card(child:ExpansionTile(
          title:Text('Scene ${m['sceneId']??''} • Shot ${m['shotNumber']??''}'),
          children:[Padding(padding:const EdgeInsets.all(16),child:SelectableText(m['prompt']??''))]
        ));
      })
    ]),
  );
}
