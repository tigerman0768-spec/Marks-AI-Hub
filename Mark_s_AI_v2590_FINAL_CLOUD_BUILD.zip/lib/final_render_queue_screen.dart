import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String finalQueueApi='http://10.0.2.2:3000';

class FinalRenderQueueScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderQueueScreen({super.key,required this.projectId});
  @override State<FinalRenderQueueScreen> createState()=>_FinalRenderQueueScreenState();
}
class _FinalRenderQueueScreenState extends State<FinalRenderQueueScreen>{
  Map<String,dynamic> readiness={},queue={};bool loading=true,queuing=false;Timer? timer;
  @override void initState(){super.initState();load();timer=Timer.periodic(const Duration(seconds:3),(_)=>load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> load()async{
    try{
      final a=await http.get(Uri.parse('$finalQueueApi/api/projects/${widget.projectId}/final-render/queue-readiness'));
      final b=await http.get(Uri.parse('$finalQueueApi/api/projects/${widget.projectId}/final-render/queue'));
      if(mounted)setState((){
        if(a.statusCode==200)readiness=jsonDecode(a.body);
        if(b.statusCode==200)queue=jsonDecode(b.body)['queue']??{};
        loading=false;
      });
    }catch(_){if(mounted)setState(()=>loading=false);}
  }
  Future<void> enqueue()async{
    setState(()=>queuing=true);
    final r=await http.post(Uri.parse('$finalQueueApi/api/projects/${widget.projectId}/final-render/queue'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==202?'Final render queued.':'Render is not ready to queue.')));
    setState(()=>queuing=false);load();
  }
  Future<void> setStatus(String s)async{
    await http.post(Uri.parse('$finalQueueApi/api/projects/${widget.projectId}/final-render/queue/status'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'status':s}));
    load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final ready=readiness['ready']==true, status=queue['status']??'not queued';
    return Scaffold(appBar:AppBar(title:const Text('Final Render Queue')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.check_circle:Icons.warning),
        title:Text(ready?'Ready to queue final render':'Final render not ready'),
        subtitle:Text('Package: ${readiness['checks']?['package']==true?'OK':'Pending'} • Config: ${readiness['checks']?['config']==true?'OK':'Pending'}'))),
      Card(child:ListTile(title:Text('Status: $status'),subtitle:Text('Progress: ${queue['progress']??0}% • ${queue['stage']??'waiting'}'))),
      FilledButton.icon(onPressed:ready&&queue.isEmpty&&!queuing?enqueue:null,
        icon:queuing?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.queue_play_next),
        label:Text(queuing?'Queueing…':'Queue Final Render')),
      if(status=='queued')TextButton(onPressed:()=>setStatus('cancelled'),child:const Text('Cancel Queue')),
      if(status=='failed'||status=='cancelled')TextButton(onPressed:()=>setStatus('queued'),child:const Text('Retry Queue'))
    ]));
  }
}
