import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'final_render_job_details_screen.dart';

class FinalRenderStatusCard extends StatefulWidget{
  final String projectId;
  const FinalRenderStatusCard({super.key,required this.projectId});
  @override State<FinalRenderStatusCard> createState()=>_FinalRenderStatusCardState();
}
class _FinalRenderStatusCardState extends State<FinalRenderStatusCard>{
  static const base='http://10.0.2.2:3000';
  Map<String,dynamic>? data;Timer? timer;
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-render-status'));
      if(r.statusCode<300&&mounted)setState(()=>data=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
  }
  @override void initState(){super.initState();load();timer=Timer.periodic(const Duration(seconds:2),(_)=>load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> restart()async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/final-render-restart'));
      if(r.statusCode<300) await load();
    }catch(_){}
  }
  @override Widget build(BuildContext context){
    final d=data;if(d==null)return const SizedBox.shrink();
    final status=d['finalRenderStatus']?.toString()??'not_run';
    final recovery=d['recoveryStatus']?.toString();
    final attempts=d['recoveryAttempts']??0;
    final busy=status=='completed'?false:(recovery=='recovering'||status=='running');
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[const Icon(Icons.movie),const SizedBox(width:8),const Text('Final Render Status',style:TextStyle(fontWeight:FontWeight.bold))]),
        const SizedBox(height:8),
        Text('Render: $status'),
        if(recovery!=null)Text('Recovery: $recovery ($attempts/3 attempts)'),
        if(d['recoveryMessage']!=null)Text(d['recoveryMessage'].toString()),
        if(busy)const Padding(padding:EdgeInsets.only(top:8),child:LinearProgressIndicator()),
        if(!busy && recovery!=null && recovery!='recovery_exhausted')
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(
            onPressed:restart,icon:const Icon(Icons.restart_alt),label:const Text('RESTART RECOVERY'))),
        if(d['progressId']!=null)
          TextButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(
            builder:(_)=>FinalRenderJobDetailsScreen(jobId:d['progressId'].toString()))),
            icon:const Icon(Icons.list_alt),label:const Text('VIEW JOB DETAILS')),
        if(recovery=='recovery_exhausted')
          const Text('Automatic recovery limit reached. Manual review required.')

      ])));
  }
}
