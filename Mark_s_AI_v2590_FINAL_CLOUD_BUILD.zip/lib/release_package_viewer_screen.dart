import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import 'approved_film_library_player_screen.dart';
import 'final_release_download_center_screen.dart';

class ReleasePackageViewerScreen extends StatefulWidget {
  final String projectId;
  final String apiBase;
  final Map<String,dynamic> data;
  const ReleasePackageViewerScreen({super.key,required this.projectId,required this.apiBase,required this.data});
  @override State<ReleasePackageViewerScreen> createState()=>_ReleasePackageViewerScreenState();
}

class _ReleasePackageViewerScreenState extends State<ReleasePackageViewerScreen>{
  VideoPlayerController? controller;
  bool playerError=false;
  bool actionBusy=false;
  String actionMessage='';

  @override void initState(){super.initState();_initPlayer();}
  Future<void> _initPlayer() async {
    final mediaPath=widget.data['film']?['mediaPath'];
    if(mediaPath is! String || mediaPath.isEmpty)return;
    try{
      final uri=Uri.parse('${widget.apiBase}$mediaPath');
      final c=VideoPlayerController.networkUrl(uri);
      await c.initialize();
      if(!mounted){await c.dispose();return;}
      setState(()=>controller=c);
    }catch(_){if(mounted)setState(()=>playerError=true);}
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  String prettyBytes(dynamic value){
    final n=value is num?value.toDouble():double.tryParse('$value')??0;
    if(n<1024)return '${n.toInt()} B'; if(n<1024*1024)return '${(n/1024).toStringAsFixed(1)} KB'; if(n<1024*1024*1024)return '${(n/1024/1024).toStringAsFixed(1)} MB'; return '${(n/1024/1024/1024).toStringAsFixed(2)} GB';
  }
  Widget badge(String text,bool good){return Chip(avatar:Icon(good?Icons.check_circle:Icons.error,size:18),label:Text(text));}
  Future<void> _shareFilm() async {
    if(actionBusy)return;
    setState(()=>actionBusy=true);
    try {
      final info=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/approved-film/share-info'));
      if(info.statusCode!=200) throw Exception('Film is not ready to share');
      final b=jsonDecode(info.body) as Map<String,dynamic>;
      final r=await http.get(Uri.parse('${widget.apiBase}${b['downloadPath']}'));
      if(r.statusCode!=200) throw Exception('Could not retrieve the MP4');
      final dir=await getTemporaryDirectory();
      final name=(b['filename'] as String?)?.isNotEmpty==true?b['filename']:'marks_ai_film.mp4';
      final file=File('${dir.path}/$name');
      await file.writeAsBytes(r.bodyBytes,flush:true);
      await Share.shareXFiles([XFile(file.path)],text:b['title'] as String? ?? 'Mark’s AI film');
      if(mounted)setState(()=>actionMessage='Film shared from the final MP4.');
    } catch(e) { if(mounted)setState(()=>actionMessage='Share unavailable: $e'); }
    finally { if(mounted)setState(()=>actionBusy=false); }
  }

  Future<void> _exportFilm() async {
    if(actionBusy)return;
    setState(()=>actionBusy=true);
    try {
      final r=await http.post(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/approved-film/export/create'),headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      final b=jsonDecode(r.body) as Map<String,dynamic>;
      if(r.statusCode!=200) throw Exception(b['error']??b['blockers']??'Export could not be prepared');
      if(mounted)setState(()=>actionMessage='Film export is ready.');
    } catch(e) { if(mounted)setState(()=>actionMessage='Export unavailable: $e'); }
    finally { if(mounted)setState(()=>actionBusy=false); }
  }

  Future<void> _openLibrary() async {
    if(!mounted)return;
    await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>ApprovedFilmLibraryPlayerScreen(projectId:widget.projectId)));
  }

  @override Widget build(BuildContext context){
    final d=widget.data; final v=d['verification'] as Map<String,dynamic>? ?? {}; final file=d['film']?['file'] as Map<String,dynamic>?;
    final verified=v['verified']==true;
    return Scaffold(appBar:AppBar(title:const Text('Final Release Viewer')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text(d['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:8),
      Row(children:[badge(verified?'VERIFIED':'NEEDS ATTENTION',verified),const Spacer(),Text('${d['finalRelease']?['status']??'not released'}')]),
      const SizedBox(height:16),
      Card(clipBehavior:Clip.antiAlias,child:controller?.value.isInitialized==true?Column(children:[AspectRatio(aspectRatio:controller!.value.aspectRatio,child:VideoPlayer(controller!)),Row(children:[IconButton(onPressed:()=>setState(()=>controller!.value.isPlaying?controller!.pause():controller!.play()),icon:Icon(controller!.value.isPlaying?Icons.pause:Icons.play_arrow)),Expanded(child:VideoProgressIndicator(controller!,allowScrubbing:true,padding:const EdgeInsets.symmetric(horizontal:8)))])]):AspectRatio(aspectRatio:16/9,child:Center(child:playerError?const Text('Preview unavailable'):const CircularProgressIndicator()))),
      const SizedBox(height:12),
      Wrap(spacing:8,runSpacing:8,children:[
        FilledButton.icon(onPressed:actionBusy?null:_shareFilm,icon:const Icon(Icons.share),label:const Text('Share Film')),
        OutlinedButton.icon(onPressed:actionBusy?null:_exportFilm,icon:const Icon(Icons.file_download),label:const Text('Export Film')),
        OutlinedButton.icon(onPressed:actionBusy?null:_openLibrary,icon:const Icon(Icons.video_library),label:const Text('Open Film Library')),
        OutlinedButton.icon(onPressed:actionBusy?null:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>FinalReleaseDownloadCenterScreen(projectId:widget.projectId,apiBase:widget.apiBase))),icon:const Icon(Icons.download),label:const Text('Download Centre')),
      ]),
      if(actionBusy)const Padding(padding:EdgeInsets.all(8),child:LinearProgressIndicator()),
      if(actionMessage.isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(actionMessage)),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Release package',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),
        ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.movie),title:Text(file?['name']??'Final film'),subtitle:Text(prettyBytes(file?['bytes']))),
        ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.verified),title:const Text('SHA-256'),subtitle:Text(file?['sha256']??'—',style:const TextStyle(fontSize:12)),),
        ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.workspace_premium),title:const Text('Certificate'),subtitle:Text(d['certificate']?['id']??'Not issued')),
        ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.description),title:const Text('Manifest'),subtitle:Text(d['manifest']?['path']??'Not saved')),
      ]))),
      const SizedBox(height:8),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Verification',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),for(final e in <String,String>{'Final film':'filePresent','SHA-256':'hashMatches','File size':'sizeMatches','Certificate':'certificate','Manifest':'manifest'}.entries)ListTile(contentPadding:EdgeInsets.zero,leading:Icon(v[e.value]==true?Icons.check_circle:Icons.cancel),title:Text(e.key),trailing:Text(v[e.value]==true?'PASS':'FAIL'))]))),
    ]));
  }
}
