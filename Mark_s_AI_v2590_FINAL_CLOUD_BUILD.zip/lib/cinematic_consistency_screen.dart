import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CinematicConsistencyScreen extends StatefulWidget{
  final String projectId;
  const CinematicConsistencyScreen({super.key,required this.projectId});
  @override State<CinematicConsistencyScreen> createState()=>_CinematicConsistencyScreenState();
}
class _CinematicConsistencyScreenState extends State<CinematicConsistencyScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? report;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/cinematic-consistency'));
      if(r.statusCode<300)setState(()=>report=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final r=report;
    return Scaffold(
      appBar:AppBar(title:const Text('Cinematic Consistency'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
        r==null?const Center(child:Text('Unable to check cinematic consistency.')):
        ListView(padding:const EdgeInsets.all(12),children:[
          Card(child:ListTile(
            leading:Icon(r['consistent']==true?Icons.movie_filter:Icons.warning),
            title:Text('Cinematic Score: ${r['score']??0}/100'),
            subtitle:Text(r['consistent']==true?'Cinematic direction is consistent':'Potential cinematic inconsistencies found'),
          )),
          ...((r['recommendations'] as List?)??[]).map((x)=>ListTile(
            leading:const Icon(Icons.lightbulb_outline),title:Text(x.toString()),
          )),
          ...((r['pairs'] as List?)??[]).map((p){
            final m=Map<String,dynamic>.from(p as Map);
            return Card(child:ExpansionTile(
              title:Text('${m['fromJobId']} → ${m['toJobId']}'),
              subtitle:Text('Score ${m['score']??0}/100'),
              children:[...((m['checks'] as List?)??[]).map((c){
                final x=Map<String,dynamic>.from(c as Map);
                return ListTile(dense:true,title:Text('${x['field']}'),
                  trailing:Icon(x['status']=='mismatch'?Icons.warning:Icons.check),
                  subtitle:Text(x['status'].toString()));
              })],
            ));
          })
        ])
    );
  }
}
