import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'approved_film_library_player_screen.dart';

const String filmExportApi='http://10.0.2.2:3000';

class ApprovedFilmExportScreen extends StatefulWidget{
  final String projectId;
  const ApprovedFilmExportScreen({super.key,required this.projectId});
  @override State<ApprovedFilmExportScreen> createState()=>_ApprovedFilmExportScreenState();
}
class _ApprovedFilmExportScreenState extends State<ApprovedFilmExportScreen>{
  Map<String,dynamic>? export; bool loading=true; String message='';
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>export=jsonDecode(r.body)['export'] as Map<String,dynamic>?);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> create()async{
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/create'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({}));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200?'Export package ready.':'Blocked: ${b['blockers']??b['error']??''}');
    if(r.statusCode==200)load();
  }

















  Future<void> downloadReleaseManifest()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-manifest/download'));
    if(!mounted)return;
    if(r.statusCode!=200){
      setState(()=>message='Release manifest download failed');
      return;
    }
    final dir=await getTemporaryDirectory();
    final file=File('${dir.path}/release-manifest-${widget.projectId}.json');
    await file.writeAsBytes(r.bodyBytes);
    await Share.shareXFiles([XFile(file.path)],text:'Mark’s AI Release Manifest');
    setState(()=>message='Release manifest ready to share ✓');
  }

  Future<void> verifyReleaseManifest()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-manifest/verify'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'Release manifest verified ✓'
      :'Manifest verification failed: ${b['reason']??'SHA-256 mismatch'}');
  }

  Future<void> showReleaseManifest()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-manifest'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Release manifest unavailable.');return;}
    final b=jsonDecode(r.body);
    showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        const Text('Release Manifest',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        SelectableText('Status: ${b['status']}'),
        SelectableText('Certificate: ${b['certificateId']??'—'}'),
        SelectableText('Seal: ${b['sealId']??'—'}'),
        SelectableText('SHA-256: ${b['sha256']??'—'}'),
        SelectableText('Bytes: ${b['bytes']??'—'}'),
      ],
    )));
  }
  Future<void> saveReleaseManifest()async{
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-manifest/save'));
    if(!mounted)return;
    setState(()=>message=r.statusCode==200?'Release manifest saved ✓':'Could not save release manifest.');
  }

  Future<void> showReleaseHistory()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-history'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Release history unavailable.');return;}
    final items=(jsonDecode(r.body)['history'] as List).cast<Map<String,dynamic>>();
    showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        const Text('Release History',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        if(items.isEmpty)const Padding(padding:EdgeInsets.all(12),child:Text('No release events recorded yet.')),
        ...items.map((e)=>ListTile(
          leading:const Icon(Icons.history),
          title:Text(e['event']?.toString()??'release event'),
          subtitle:Text('${e['id']??''}\n${e['at']??''}'),
        )),
      ],
    )));
  }

  Future<void> showReleaseStatus()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-status'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Release status unavailable.');return;}
    final b=jsonDecode(r.body);
    showDialog(context:context,builder:(c)=>AlertDialog(
      title:const Text('Release Status'),
      content:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text((b['status']??'unknown').toString().toUpperCase(),style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),Text('File: ${b['filename']??'—'}'),
        Text('Size: ${b['bytes']??'—'} bytes'),
        Text('Certificate: ${b['certificateId']??'—'}'),
        Text('Seal: ${b['sealId']??'—'}'),
        Text('File exists: ${b['fileExists']==true?'YES':'NO'}'),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Close'))],
    ));
  }

  Future<void> issueReleaseCertificate()async{
    setState(()=>message='Issuing release certificate…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-certificate'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'RELEASE CERTIFICATE ISSUED ✓  ${b['certificate']?['certificateId']??''}'
      :'Certificate blocked: ${b['reason']??b['error']??''}');
  }

  Future<void> showReleaseAudit()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-audit'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Release audit unavailable.');return;}
    final b=jsonDecode(r.body) as Map<String,dynamic>;
    final stages=(b['stages'] as List).cast<Map<String,dynamic>>();
    showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        Text('Release Audit',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        Text(b['complete']==true?'All release stages complete':'Release stages still incomplete'),
        const SizedBox(height:8),
        ...stages.map((e)=>ListTile(
          leading:Icon(e['complete']==true?Icons.check_circle:Icons.error_outline),
          title:Text(e['name'].toString()),
        )),
      ],
    )));
  }
  Future<void> saveReleaseAudit()async{
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-audit/save'));
    if(!mounted)return;
    setState(()=>message=r.statusCode==200?'Release audit saved ✓':'Could not save release audit.');
  }

  Future<void> sealRelease()async{
    setState(()=>message='Sealing approved release…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-seal'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'RELEASE SEALED ✓  ${b['seal']?['sealId']??''}'
      :'Seal blocked: ${b['reason']??b['error']??''}');
  }

  Future<void> approveRelease()async{
    setState(()=>message='Checking readiness and approving release…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-approval'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'RELEASE APPROVED ✓  ${b['approval']?['approvalId']??''}'
      :'Approval blocked: ${(b['blockers'] as List?)?.join(', ')??b['error']??''}');
  }

  Future<void> checkReleaseReadiness()async{
    setState(()=>message='Checking final release readiness…');
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-readiness'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    if(r.statusCode==200){
      setState(()=>message='RELEASE READY ✓  All required checkpoints are complete.');
    }else{
      final blockers=(b['blockers'] as List?)?.join(', ')??'Unknown blocker';
      setState(()=>message='Release not ready: $blockers');
    }
  }

  Future<void> showReleaseCatalogue()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-catalogue'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Release catalogue unavailable.');return;}
    final b=jsonDecode(r.body) as Map<String,dynamic>;
    final stages=(b['stages'] as Map).cast<String,dynamic>();
    showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        Text(b['title']?.toString()??'Film Release',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        ...stages.entries.map((e)=>ListTile(
          leading:Icon(e.value==true?Icons.check_circle:Icons.radio_button_unchecked),
          title:Text(e.key),
          subtitle:Text(e.value==true?'Complete':'Not complete'),
        )),
        if(b['snapshot']!=null)SelectableText('Release SHA-256: ${b['snapshot']['sha256']}'),
      ],
    )));
  }

  Future<void> createReleaseSnapshot()async{
    setState(()=>message='Creating sealed release snapshot…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/release-snapshot'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'Release snapshot sealed ✓  ${b['snapshot']?['snapshotId']??''}'
      :'Snapshot blocked: ${b['reason']??b['error']??''}');
  }

  Future<void> lockDelivery()async{
    setState(()=>message='Verifying and locking delivery…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/delivery/lock'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'Delivery locked ✓  ${b['lock']?['lockId']??''}'
      :'Delivery lock blocked: ${b['reason']??b['error']??''}');
  }

  Future<void> verifyDelivery()async{
    setState(()=>message='Verifying delivery file…');
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/delivery/verify'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'Delivery verified ✓  SHA-256 and file size match.'
      :'Delivery verification failed: ${b['reason']??'file identity mismatch'}');
  }

  Future<void> prepareDelivery()async{
    setState(()=>message='Creating verified delivery record…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/delivery'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200
      ?'Delivery package ready: ${b['record']?['deliveryId']??''}'
      :'Delivery blocked: ${b['blockers']??b['error']??''}');
  }

  Future<void> preparePackage()async{
    setState(()=>message='Building verified export package…');
    final r=await http.post(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/package'));
    if(!mounted)return;
    if(r.statusCode==200){
      final b=jsonDecode(r.body);
      setState(()=>message='Verified export package ready: ${b['record']?['packageId']??''}');
      load();
    }else{
      final b=jsonDecode(r.body);
      setState(()=>message='Package blocked: ${b['blockers']??b['error']??''}');
    }
  }

  Future<void> verifyFilm()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/verify'));
    if(!mounted)return;
    if(r.statusCode==200){
      final b=jsonDecode(r.body);
      setState(()=>message=b['verified']==true?'Export integrity verified ✓':'Integrity check failed.');
    }else setState(()=>message='Could not verify the export.');
  }
  Future<void> showHistory()async{
    final r=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/history'));
    if(!mounted)return;
    if(r.statusCode!=200){setState(()=>message='Export history unavailable.');return;}
    final items=(jsonDecode(r.body)['history'] as List).cast<Map<String,dynamic>>();
    showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:ListView(
      padding:const EdgeInsets.all(16),
      children:[
        const Text('Export History',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        if(items.isEmpty) const Text('No exports yet.'),
        ...items.map((e)=>ListTile(
          leading:const Icon(Icons.movie),
          title:Text(e['filename']?.toString()??'film.mp4'),
          subtitle:Text('${e['bytes']??0} bytes\n${e['exportedAt']??''}'),
        )),
      ],
    )));
  }

  Future<void> shareFilm()async{
    try{
      setState(()=>message='Preparing the film for Android sharing…');
      final info=await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/share-info'));
      if(info.statusCode!=200){if(mounted)setState(()=>message='Film is not ready to share.');return;}
      final b=jsonDecode(info.body) as Map<String,dynamic>;
      final response=await http.get(Uri.parse('$filmExportApi${b['downloadPath']}'));
      if(response.statusCode!=200){if(mounted)setState(()=>message='Could not retrieve the finished MP4.');return;}
      final dir=await getTemporaryDirectory();
      final filename=(b['filename'] as String?)?.isNotEmpty==true?b['filename']:'mark_ai_film.mp4';
      final file=File('${dir.path}/$filename');
      await file.writeAsBytes(response.bodyBytes,flush:true);
      await Share.shareXFiles([XFile(file.path)],text:b['title'] as String? ?? "My film");
      if(mounted)setState(()=>message='Film shared from the actual MP4 file.');
    }catch(e){if(mounted)setState(()=>message='Sharing is unavailable: $e');}
  }
  Future<void> download()async{
    setState(()=>message='Use the Download action from the server/browser endpoint to save the MP4.');
    await http.get(Uri.parse('$filmExportApi/api/projects/${widget.projectId}/approved-film/export/download'));
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Export Film')),
    body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:const Icon(Icons.file_download),title:Text(export==null?'Export not prepared':'Export ready'),subtitle:Text('${export?['filename']??'Film MP4'}\n${export?['bytes']??0} bytes'))),
      FilledButton.icon(onPressed:create,icon:const Icon(Icons.inventory_2),label:const Text('Prepare Film Export')),
      if(export!=null)FilledButton.icon(onPressed:download,icon:const Icon(Icons.download),label:const Text('Download Film MP4')),
      if(export!=null)FilledButton.icon(onPressed:shareFilm,icon:const Icon(Icons.share),label:const Text('Share Film')), 
      if(export!=null)OutlinedButton.icon(onPressed:verifyFilm,icon:const Icon(Icons.verified),label:const Text('Verify Export Integrity')),
      OutlinedButton.icon(onPressed:showHistory,icon:const Icon(Icons.history),label:const Text('Export History')), 
      if(export?['sha256']!=null)SelectableText('SHA-256: ${export?['sha256']}'),
      if(message.isNotEmpty)Padding(padding:const EdgeInsets.all(12),child:Text(message)),
    ]));
}
