import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String realClipApi='http://10.0.2.2:3000';

class RealClipGenerationScreen extends StatefulWidget{
  final String projectId;
  final String? shotId;
  const RealClipGenerationScreen({super.key,required this.projectId,this.shotId});
  @override State<RealClipGenerationScreen> createState()=>_RealClipGenerationScreenState();
}
class _RealClipGenerationScreenState extends State<RealClipGenerationScreen>{
  final prompt=TextEditingController();
  final duration=TextEditingController(text:'5');
  String status='Ready'; bool busy=false;
  @override void dispose(){prompt.dispose();duration.dispose();super.dispose();}
  Future<void> generate()async{
    if(widget.shotId==null){setState(()=>status='Select a shot first.');return;}
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$realClipApi/api/projects/${widget.projectId}/clips/real/generate'),
        headers:{'Content-Type':'application/json'},
        body:jsonEncode({'shotId':widget.shotId,'prompt':prompt.text.trim(),'duration':double.tryParse(duration.text)||5}));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      setState(()=>status=r.statusCode==202?'Clip generation job queued.':'Blocked: ${(b['blockers']??[b['error']??'Unknown error']).join(', ')}');
    }catch(e){if(mounted)setState(()=>status='Connection error: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Generate Real Clip')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:const Icon(Icons.movie_creation),title:const Text('AI Video Clip'),subtitle:Text('Shot: ${widget.shotId??'none selected'}'))),
      TextField(controller:prompt,maxLines:5,decoration:const InputDecoration(labelText:'Video prompt',border:OutlineInputBorder())),
      const SizedBox(height:12),
      TextField(controller:duration,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Duration (seconds)',border:OutlineInputBorder())),
      const SizedBox(height:16),
      FilledButton.icon(onPressed:busy?null:generate,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.play_arrow),label:Text(busy?'Submitting…':'Generate Clip')),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(status))),
    ]));
}
