import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalRenderWorkerQueueScreen extends StatefulWidget{
  const FinalRenderWorkerQueueScreen({super.key});
  @override State<FinalRenderWorkerQueueScreen> createState()=>_FinalRenderWorkerQueueScreenState();
}
class _FinalRenderWorkerQueueScreenState extends State<FinalRenderWorkerQueueScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false;List<dynamic> queue=[],active=[];
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/final-render/queue'));
      if(r.statusCode<300){final d=Map<String,dynamic>.from(jsonDecode(r.body));
        setState(()=>queue=List<dynamic>.from(d['queue']??[]));
        setState(()=>active=List<dynamic>.from(d['active']??[]));}
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> claim()async{
    setState(()=>loading=true);
    try{await http.post(Uri.parse('$base/api/final-render/queue/claim'));await load();}
    catch(_){if(mounted)setState(()=>loading=false);}
  }
  @override void initState(){super.initState();load();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Final Render Queue')),
    body:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Icon(Icons.queue_play_next,size:70),const SizedBox(height:10),
      const Text('Final renders are automatically dispatched one at a time. Queued jobs start when the worker is free.',textAlign:TextAlign.center),
      const SizedBox(height:18),
      FilledButton.icon(onPressed:loading?null:claim,icon:const Icon(Icons.play_arrow),label:const Text('START NEXT QUEUED RENDER')),
      const SizedBox(height:18),
      Text('Active: ${active.length}  •  Queued: ${queue.where((j)=>j['status']=='queued').length}'),
      const SizedBox(height:8),
      Expanded(child:queue.isEmpty?const Center(child:Text('Render queue is empty.')):
        ListView.builder(itemCount:queue.length,itemBuilder:(c,i){
          final j=Map<String,dynamic>.from(queue[i]);
          return Card(child:ListTile(leading:const Icon(Icons.movie),title:Text(j['title']?.toString()??'Untitled Film'),
            subtitle:Text('${j['status']??''} • position ${j['queuePosition']??'-'}')));
        }))
    ])));
}
