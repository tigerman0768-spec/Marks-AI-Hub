import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String exportApi='http://10.0.2.2:3000';
class FinalMasterDeliveryExportScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterDeliveryExportScreen({super.key,required this.projectId});
  @override State<FinalMasterDeliveryExportScreen> createState()=>_FinalMasterDeliveryExportScreenState();
}
class _FinalMasterDeliveryExportScreenState extends State<FinalMasterDeliveryExportScreen>{
  Map<String,dynamic>? data;bool busy=false;
  Future<void> exportPackage()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$exportApi/api/projects/${widget.projectId}/final-render/delivery-export/write'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>data=b['export'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery export written.':'Delivery export blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=data?['exportable']==true;
    return Scaffold(appBar:AppBar(title:const Text('Delivery Export')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.file_present:Icons.lock),
        title:Text(ready?'DELIVERY EXPORT READY':'DELIVERY EXPORT BLOCKED'),
        subtitle:Text(ready?'Metadata package written':'Gate, receipt, manifest and lock are all required.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:SelectableText('Export: ${data?['file']??''}'))),
      FilledButton.icon(onPressed:busy?null:exportPackage,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.output),
        label:Text(busy?'Writing…':'Write Delivery Export'))
    ]));
  }
}
