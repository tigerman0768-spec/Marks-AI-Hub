import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'film_library_screen.dart';

class FinalMasterStatusScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterStatusScreen({super.key,required this.projectId});
  @override State<FinalMasterStatusScreen> createState()=>_FinalMasterStatusScreenState();
}
class _FinalMasterStatusScreenState extends State<FinalMasterStatusScreen>{
  static const base='http://10.0.2.2:3000';
  Timer? timer; Map<String,dynamic> data={}; String? error;
  @override void initState(){super.initState();_load();timer=Timer.periodic(const Duration(seconds:2),(_)=>_load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-master/status'));
      if(r.statusCode>=300)throw Exception('Final master status unavailable');
      data=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>{});
  }
  @override Widget build(BuildContext c){
    final progress=((data['progress']??0) as num).toDouble().clamp(0,100)/100;
    final ready=data['lifecycle']=='final_film_ready'||data['status']=='completed';
    return Scaffold(appBar:AppBar(title:const Text('Final Master')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text(data['title']?.toString()??'Final Master',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:12),Text('Status: ${data['status']??'loading'}'),
        const SizedBox(height:8),Text(data['stage']?.toString()??'Waiting for render'),
        const SizedBox(height:14),LinearProgressIndicator(value:progress),
        const SizedBox(height:8),Text('${(progress*100).round()}%'),
        if(data['error']!=null)Padding(padding:const EdgeInsets.only(top:14),child:Text('Error: ${data['error']}')),
        if(ready)...[
          const SizedBox(height:20),
          const Card(child:ListTile(leading:Icon(Icons.check_circle),title:Text('Film ready'),subtitle:Text('The finished film has been handed to the Film Library.'))),
          const SizedBox(height:10),
          FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FilmLibraryScreen())),
            icon:const Icon(Icons.video_library),label:const Text('OPEN FILM LIBRARY')),
        ],
        if(error!=null)Padding(padding:const EdgeInsets.only(top:14),child:Text(error!)),
      ]));
  }
}
