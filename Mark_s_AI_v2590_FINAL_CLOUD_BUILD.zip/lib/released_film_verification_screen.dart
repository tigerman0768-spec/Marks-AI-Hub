import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releaseVerifyApi='http://10.0.2.2:3000';
class ReleasedFilmVerificationScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmVerificationScreen({super.key,required this.projectId});
  @override State<ReleasedFilmVerificationScreen> createState()=>_ReleasedFilmVerificationScreenState();
}
class _ReleasedFilmVerificationScreenState extends State<ReleasedFilmVerificationScreen>{
  Map<String,dynamic>? verification;bool busy=false;
  Future<void> verify()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$releaseVerifyApi/api/projects/${widget.projectId}/final-render/library-release/verify'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>verification=b['verification'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Released film verified.':'Verification failed.')));
  }
  @override Widget build(BuildContext context){
    final ok=verification?['verified']==true;
    final blockers=(verification?['blockers'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Release Verification')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ok?Icons.verified:Icons.gpp_maybe),
        title:Text(ok?'RELEASE VERIFIED':'NOT VERIFIED'),
        subtitle:Text(verification==null?'Verify the released film file.':'Checked: ${verification?['verifiedAt']??''}'))),
      if(verification!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('File: ${verification?['filename']??''}'),
        Text('Size: ${verification?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${verification?['sha256']??''}'),
        if(blockers.isNotEmpty) ...[const SizedBox(height:12),Text('Blockers:'),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:verify,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.verified),
        label:Text(busy?'Verifying…':'Verify Released Film'))
    ]));
  }
}
