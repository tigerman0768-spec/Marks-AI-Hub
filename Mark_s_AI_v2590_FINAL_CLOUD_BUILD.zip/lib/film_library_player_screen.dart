import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class FilmLibraryPlayerScreen extends StatefulWidget{
 final String filmId,title;
 const FilmLibraryPlayerScreen({super.key,required this.filmId,this.title='My Film'});
 @override State<FilmLibraryPlayerScreen> createState()=>_FilmLibraryPlayerScreenState();
}
class _FilmLibraryPlayerScreenState extends State<FilmLibraryPlayerScreen>{
 static const base='http://10.0.2.2:3000';
 VideoPlayerController? controller;bool loading=true;String error='';
 @override void initState(){super.initState();_open();}
 Future<void> _open()async{
  try{
   final c=VideoPlayerController.networkUrl(Uri.parse('$base/api/film-library/${widget.filmId}/play'));
   await c.initialize();if(!mounted){c.dispose();return;}
   setState(()=>controller=c);await c.play();
  }catch(e){if(mounted)setState(()=>error=e.toString());}
  if(mounted)setState(()=>loading=false);
 }
 @override void dispose(){controller?.dispose();super.dispose();}
 @override Widget build(BuildContext context){
  final c=controller;
  return Scaffold(appBar:AppBar(title:Text(widget.title)),body:Center(
   child:error.isNotEmpty?Padding(padding:const EdgeInsets.all(20),child:Text(error,textAlign:TextAlign.center)):
   loading?const CircularProgressIndicator():
   c==null?const Text('Film unavailable'):
   Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c)),
    VideoProgressIndicator(c,allowScrubbing:true),
    IconButton(icon:Icon(c.value.isPlaying?Icons.pause:Icons.play_arrow),
      onPressed:()=>setState(()=>c.value.isPlaying?c.pause():c.play())),
   ])));
 }
}
