import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CharacterBibleScreen extends StatefulWidget{
  final String projectId;
  const CharacterBibleScreen({super.key,required this.projectId});
  @override State<CharacterBibleScreen> createState()=>_CharacterBibleScreenState();
}
class _CharacterBibleScreenState extends State<CharacterBibleScreen>{
  static const base='http://10.0.2.2:3000';
  List<Map<String,dynamic>> characters=[]; bool loading=true,generating=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}'));
      if(r.statusCode==200){
        final p=jsonDecode(r.body) as Map<String,dynamic>;
        characters=(p['characters'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e)).toList();
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> generate() async{
    setState(()=>generating=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/character-bible'));
      if(r.statusCode>=300)throw Exception(r.body);
      await load();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Character Bible generated')));
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Generation failed: $e')));
    }
    if(mounted)setState(()=>generating=false);
  }
  Widget field(String label,dynamic value)=>Padding(
    padding:const EdgeInsets.only(top:5),child:Text('$label: ${value?.toString().isEmpty??true?'TBD':value}'));
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('Character Bible')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Character Bible',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:8),
      const Text('Keep every character visually and emotionally consistent throughout the film.'),
      const SizedBox(height:16),
      FilledButton.icon(onPressed:generating?null:generate,
        icon:generating?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(generating?'GENERATING…':'GENERATE CHARACTER BIBLE')),
      const SizedBox(height:16),
      ...characters.map((c)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(c['name']?.toString()??'Character',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        field('Role',c['role']),field('Age',c['ageRange']),field('Appearance',c['appearance']),
        field('Personality',c['personality']),field('Motivation',c['motivation']),
        field('Wardrobe',c['wardrobe']),field('Voice',c['voiceDirection']),
        field('Continuity',c['continuityNotes']),
      ])))),
    ]));
  }
}
