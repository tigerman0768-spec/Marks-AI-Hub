import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'real_clip_player_screen.dart';

const String clipReviewApi='http://10.0.2.2:3000';

class RealClipReviewScreen extends StatefulWidget{
  final String projectId;
  const RealClipReviewScreen({super.key,required this.projectId});
  @override State<RealClipReviewScreen> createState()=>_RealClipReviewScreenState();
}
class _RealClipReviewScreenState extends State<RealClipReviewScreen>{
  List<dynamic> clips=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/clips/review'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>clips=jsonDecode(r.body)['clips'] as List<dynamic>);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> decide(Map<String,dynamic> clip,String decision)async{
    final id=clip['clipId'];
    if(decision=='regenerate'){
      final rr=await http.post(Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/clips/real/$id/regenerate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(!mounted)return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(rr.statusCode==202?'Regeneration submitted to Runway.':'Regeneration failed: ${rr.body}')));
      return;
    }
    final r=await http.post(Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/clips/review/$id'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'decision':decision}));
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Clip marked ${decision}.':'Unable to review clip.')));
    if(r.statusCode==200)load();
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Review Generated Clips'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),
    body:loading?const Center(child:CircularProgressIndicator()):
      clips.isEmpty?const Center(child:Text('No generated clips to review.')):
      ListView.builder(itemCount:clips.length,itemBuilder:(c,i){
        final x=clips[i] as Map<String,dynamic>; final decision=x['reviewDecision']??'unreviewed';
        return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('${x['provider']??'AI'} • ${decision.toString().toUpperCase()}',style:const TextStyle(fontWeight:FontWeight.bold)),
          Text('${x['clipId']??''}'),
          const SizedBox(height:8),
          Row(children:[
            Expanded(child:OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>RealClipPlayerScreen(projectId:widget.projectId))),icon:const Icon(Icons.play_arrow),label:const Text('Play'))),
            const SizedBox(width:6),
            Expanded(child:FilledButton.icon(onPressed:()=>decide(x,'keep'),icon:const Icon(Icons.check),label:const Text('Keep'))),
          ]),
          Row(children:[
            Expanded(child:OutlinedButton.icon(onPressed:()=>decide(x,'reject'),icon:const Icon(Icons.close),label:const Text('Reject'))),
            const SizedBox(width:6),
            Expanded(child:OutlinedButton.icon(onPressed:()=>decide(x,'regenerate'),icon:const Icon(Icons.refresh),label:const Text('Regenerate'))),
          ])
        ])));
      }));
}
