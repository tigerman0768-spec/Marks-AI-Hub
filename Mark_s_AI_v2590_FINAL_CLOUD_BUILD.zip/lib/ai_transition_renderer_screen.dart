import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiTransitionRendererScreen extends StatefulWidget{
  final String projectId;
  const AiTransitionRendererScreen({super.key,required this.projectId});
  @override State<AiTransitionRendererScreen> createState()=>_AiTransitionRendererScreenState();
}
class _AiTransitionRendererScreenState extends State<AiTransitionRendererScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? result;
  Future<void> render()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-transition-render'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Transitions rendered into final video')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final ts=(result?['transitions'] as List?)??[];
    return Scaffold(appBar:AppBar(title:const Text('AI Transition Renderer')),
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(16),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:loading?null:render,
            icon:const Icon(Icons.auto_awesome_motion),
            label:Text(loading?'RENDERING…':'RENDER TRANSITIONS')))),
        if(result!=null)Padding(padding:const EdgeInsets.all(12),
          child:Text('${result!['clipCount']??0} clips • ${ts.length} transition entries')),
        Expanded(child:ListView.builder(itemCount:ts.length,itemBuilder:(c,i){
          final x=Map<String,dynamic>.from(ts[i] as Map);
          return ListTile(leading:CircleAvatar(child:Text('${x['order']??i+1}')),
            title:Text('${x['type']??'cut'}'),
            subtitle:Text('${x['duration']??0}s'));
        }))
      ]));
  }
}
