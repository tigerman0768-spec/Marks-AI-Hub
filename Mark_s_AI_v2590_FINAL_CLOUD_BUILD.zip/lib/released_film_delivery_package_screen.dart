import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releasedPackageApi='http://10.0.2.2:3000';
class ReleasedFilmDeliveryPackageScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliveryPackageScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliveryPackageScreen> createState()=>_ReleasedFilmDeliveryPackageScreenState();
}
class _ReleasedFilmDeliveryPackageScreenState extends State<ReleasedFilmDeliveryPackageScreen>{
  Map<String,dynamic>? pkg;Map<String,dynamic>? manifest;bool busy=false;
  Future<void> createPackage()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$releasedPackageApi/api/projects/${widget.projectId}/final-render/library-release/delivery-package/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState((){
      pkg=b['package'] as Map<String,dynamic>?;
      manifest=b['manifest'] as Map<String,dynamic>?;
      busy=false;
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery package ready.':'Package creation blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=pkg?['status']=='ready';
    return Scaffold(appBar:AppBar(title:const Text('Released Film Package')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.inventory_2:Icons.lock),
        title:Text(ready?'DELIVERY PACKAGE READY':'PACKAGE NOT READY'),
        subtitle:Text(ready?'Package ID: ${pkg?['packageId']??''}':'Verify the released film first.'))),
      if(ready&&manifest!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Title: ${manifest?['title']??''}'),
        Text('File: ${manifest?['filename']??''}'),
        Text('Duration: ${manifest?['duration']??0}s'),
        Text('Size: ${manifest?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${manifest?['sha256']??''}'),
        const SizedBox(height:10),
        Text('Manifest: ${pkg?['manifestPath']??''}'),
        Text('Verification: ${pkg?['verificationPath']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:createPackage,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.inventory_2),
        label:Text(busy?'Creating…':'Create Delivery Package'))
    ]));
  }
}
