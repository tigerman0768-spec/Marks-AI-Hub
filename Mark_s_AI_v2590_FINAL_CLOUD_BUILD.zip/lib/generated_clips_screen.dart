import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class GeneratedClipsScreen extends StatefulWidget{
  final String projectId;
  const GeneratedClipsScreen({super.key,required this.projectId});
  @override State<GeneratedClipsScreen> createState()=>_GeneratedClipsScreenState();
}
class _GeneratedClipsScreenState extends State<GeneratedClipsScreen>{
  static const base='http://10.0.2.2:3000';
  List<Map<String,dynamic>> jobs=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/video-generation/latest/${widget.projectId}'));
      if(r.statusCode==200)jobs=(jsonDecode(r.body)['jobs'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Generated Clips')),
    body:loading?const Center(child:CircularProgressIndicator()):
      jobs.isEmpty?const Center(child:Text('No generated clips yet.')):
      ListView.builder(itemCount:jobs.length,itemBuilder:(context,i){
        final j=jobs[i];
        return Card(child:ListTile(leading:const Icon(Icons.video_library),title:Text('Shot ${j['shotNumber']??i+1}'),
          subtitle:Text('${j['sceneTitle']??''} • ${j['downloadStatus']??j['status']??''}')));
      }));
}
