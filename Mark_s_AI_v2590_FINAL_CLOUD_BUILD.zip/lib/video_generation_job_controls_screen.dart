import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String jobControlApi = 'http://10.0.2.2:3000';

class VideoGenerationJobControlsScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationJobControlsScreen({super.key, required this.projectId});
  @override
  State<VideoGenerationJobControlsScreen> createState() => _VideoGenerationJobControlsScreenState();
}

class _VideoGenerationJobControlsScreenState extends State<VideoGenerationJobControlsScreen> {
  List<Map<String,dynamic>> jobs=[];
  bool loading=true;

  @override void initState(){super.initState(); load();}
  Future<void> load() async {
    try {
      final r=await http.get(Uri.parse('$jobControlApi/api/projects/${widget.projectId}/video-generation/jobs'));
      if(r.statusCode==200 && mounted){
        final b=jsonDecode(r.body) as Map<String,dynamic>;
        setState((){jobs=List<Map<String,dynamic>>.from((b['jobs'] as List? ?? []).map((x)=>Map<String,dynamic>.from(x)));loading=false;});
      } else if(mounted){setState(()=>loading=false);}
    } catch(_){if(mounted)setState(()=>loading=false);}
  }

  Future<void> action(String jobId,String action) async {
    final r=await http.post(Uri.parse('$jobControlApi/api/projects/${widget.projectId}/video-generation/jobs/$jobId/$action'));
    if(r.statusCode>=200 && r.statusCode<300) await load();
    else if(mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Action failed: ${r.statusCode}')));
  }

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(
      appBar:AppBar(title:const Text('Job Controls'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
      body:ListView(
        padding:const EdgeInsets.all(16),
        children:jobs.map((j){
          final s='${j['status']??'queued'}';
          final canRetry=s=='failed'||s=='cancelled';
          final canCancel=s=='queued'||s=='running';
          return Card(child:Padding(
            padding:const EdgeInsets.all(8),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              ListTile(
                leading:Icon(s=='completed'?Icons.check_circle:s=='failed'?Icons.error_outline:Icons.movie),
                title:Text('Shot ${j['index']??'-'} • ${s.toUpperCase()}'),
                subtitle:Text('Progress ${j['progress']??0}%'),
              ),
              Row(children:[
                if(canRetry)TextButton.icon(onPressed:()=>action(j['id'],'retry'),icon:const Icon(Icons.replay),label:const Text('Retry')),
                if(canCancel)TextButton.icon(onPressed:()=>action(j['id'],'cancel'),icon:const Icon(Icons.stop),label:const Text('Cancel')),
              ])
            ])
          ));
        }).toList(),
      ),
    );
  }
}
