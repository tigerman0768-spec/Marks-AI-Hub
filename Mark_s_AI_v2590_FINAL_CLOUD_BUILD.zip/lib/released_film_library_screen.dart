import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releasedFilmApi='http://10.0.2.2:3000';

class ReleasedFilmLibraryScreen extends StatefulWidget{
  const ReleasedFilmLibraryScreen({super.key});
  @override State<ReleasedFilmLibraryScreen> createState()=>_ReleasedFilmLibraryScreenState();
}
class _ReleasedFilmLibraryScreenState extends State<ReleasedFilmLibraryScreen>{
  List<dynamic> films=[]; bool busy=false; final search=TextEditingController();
  Future<void> load()async{
    setState(()=>busy=true);
    final q=search.text.trim();
    final uri=Uri.parse('$releasedFilmApi/api/films/released${q.isEmpty?'':'?q=${Uri.encodeQueryComponent(q)}'}');
    try{
      final r=await http.get(uri);
      if(!mounted)return;
      if(r.statusCode==200) setState(()=>films=(jsonDecode(r.body)['films'] as List<dynamic>? ?? []));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override void initState(){super.initState();load();}
  @override void dispose(){search.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('Released Films'),actions:[
      IconButton(onPressed:busy?null:load,icon:const Icon(Icons.refresh))
    ]),body:Column(children:[
      Padding(padding:const EdgeInsets.all(12),child:TextField(controller:search,
        onSubmitted:(_)=>load(),decoration:InputDecoration(labelText:'Search released films',
        prefixIcon:const Icon(Icons.search),suffixIcon:IconButton(onPressed:load,icon:const Icon(Icons.search)),
        border:const OutlineInputBorder()))),
      Expanded(child:busy?const Center(child:CircularProgressIndicator()):
        films.isEmpty?const Center(child:Text('No released films found.')):
        ListView.builder(itemCount:films.length,itemBuilder:(c,i){
          final f=films[i] as Map<String,dynamic>;
          return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(
            leading:const CircleAvatar(child:Icon(Icons.movie)),
            title:Text('${f['title']??'Untitled Film'}'),
            subtitle:Text('${f['filename']??''}\n${f['duration']??0}s • ${f['bytes']??0} bytes'),
            isThreeLine:true,
            trailing:const Icon(Icons.verified),
          ));
        }))
    ]));
  }
}
