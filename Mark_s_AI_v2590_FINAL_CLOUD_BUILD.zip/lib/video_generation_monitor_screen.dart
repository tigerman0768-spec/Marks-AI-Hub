import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoGenerationMonitorScreen extends StatefulWidget{
  final String projectId;
  const VideoGenerationMonitorScreen({super.key,required this.projectId});
  @override State<VideoGenerationMonitorScreen> createState()=>_VideoGenerationMonitorScreenState();
}
class _VideoGenerationMonitorScreenState extends State<VideoGenerationMonitorScreen>{
  static const base='http://10.0.2.2:3000';
  Timer? timer; bool loading=true; Map<String,dynamic>? data;
  @override void initState(){super.initState();load();timer=Timer.periodic(const Duration(seconds:3),(_)=>load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/video-generation/monitor'));
      if(r.statusCode==200&&mounted)setState(()=>data=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> retry(String id)async{
    await http.post(Uri.parse('$base/api/projects/${widget.projectId}/video-generation/jobs/$id/retry'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({}));
    await load();
  }
  IconData iconFor(String status){
    if(status=='completed')return Icons.check_circle;
    if(status=='failed')return Icons.error;
    if(status=='generating')return Icons.movie;
    if(status=='retrying')return Icons.refresh;
    if(status=='waiting')return Icons.hourglass_top;
    return Icons.schedule;
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Video Generation Monitor')),
    body:loading&&data==null?const Center(child:CircularProgressIndicator()):RefreshIndicator(
      onRefresh:load,
      child:ListView(padding:const EdgeInsets.all(16),children:[
        if(data!=null)...[
          Text('${data!['progress']??0}% complete',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          LinearProgressIndicator(value:((data!['progress']??0) as num)/100),
          const SizedBox(height:12),
          Text('Status: ${data!['status']??'not_started'}'),
          const SizedBox(height:16),
          ...((data!['jobs'] as List?)??[]).map((j){
            final m=Map<String,dynamic>.from(j);
            final failed=m['status']=='failed';
            return Card(child:ListTile(
              leading:Icon(iconFor(m['status']??'')),
              title:Text('Scene ${m['sceneId']??''} • Shot ${m['shotNumber']??''}'),
              subtitle:Text('${m['status']??''} • attempts ${m['attempts']??0}${m['error']!=null?'\n${m['error']}':''}'),
              trailing:failed?IconButton(icon:const Icon(Icons.refresh),onPressed:()=>retry(m['id'].toString())):null,
              isThreeLine:failed,
            ));
          })
        ]
      ]),
    ),
  );
}
