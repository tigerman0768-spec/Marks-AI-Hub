import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'shot_cards_screen.dart';

class StoryboardScreen extends StatefulWidget{
  final String projectId;
  const StoryboardScreen({super.key,required this.projectId});
  @override State<StoryboardScreen> createState()=>_StoryboardScreenState();
}
class _StoryboardScreenState extends State<StoryboardScreen>{
  static const base='http://10.0.2.2:3000';
  List<Map<String,dynamic>> scenes=[]; bool loading=true,generating=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}'));
      if(r.statusCode==200){
        final p=jsonDecode(r.body) as Map<String,dynamic>;
        scenes=(p['scenes'] as List? ?? []).map((e)=>Map<String,dynamic>.from(e)).toList();
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> generate() async{
    setState(()=>generating=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/storyboard'));
      if(r.statusCode>=300)throw Exception(r.body);
      await load();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Storyboard generated')));
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Generation failed: $e')));
    }
    if(mounted)setState(()=>generating=false);
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('Storyboard')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Scene Breakdown & Storyboard',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:8),
      const Text('Plan each scene before video generation: location, characters, lighting, shots and camera movement.'),
      const SizedBox(height:16),
      FilledButton.icon(onPressed:generating?null:generate,
        icon:generating?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(generating?'BUILDING…':'BUILD STORYBOARD')),
      const SizedBox(height:16),
      OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(
        builder:(_)=>ShotCardsScreen(projectId:widget.projectId))),
        icon:const Icon(Icons.video_camera_back),label:const Text('VIEW SHOT CARDS')),
      const SizedBox(height:10),
      ...scenes.map((s)=>Card(child:ExpansionTile(
        leading:CircleAvatar(child:Text('${s['number']??''}')),
        title:Text(s['title']?.toString()??'Scene'),
        subtitle:Text('${s['location']??'TBD'} • ${s['time']??'TBD'}'),
        childrenPadding:const EdgeInsets.fromLTRB(16,0,16,16),
        children:[
          Align(alignment:Alignment.centerLeft,child:Text('Action: ${s['action']??'TBD'}')),
          Align(alignment:Alignment.centerLeft,child:Text('Characters: ${((s['characters'] as List?)??[]).join(', ')}')),
          Align(alignment:Alignment.centerLeft,child:Text('Emotion: ${s['emotion']??'natural'}')),
          Align(alignment:Alignment.centerLeft,child:Text('Lighting: ${s['lighting']??'cinematic'}')),
          Align(alignment:Alignment.centerLeft,child:Text('Wardrobe: ${s['wardrobe']??'consistent'}')),
          Align(alignment:Alignment.centerLeft,child:Text('Shots: ${s['shotCount']??4}')),
        ]))),
    ]));
  }
}
