import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String verificationApi='http://10.0.2.2:3000';
class FinalRenderVerificationScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderVerificationScreen({super.key,required this.projectId});
  @override State<FinalRenderVerificationScreen> createState()=>_FinalRenderVerificationScreenState();
}
class _FinalRenderVerificationScreenState extends State<FinalRenderVerificationScreen>{
  Map<String,dynamic>? result;bool busy=false;
  Future<void> verify()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$verificationApi/api/projects/${widget.projectId}/final-render/verify'));
    if(!mounted)return;
    setState(()=>result=jsonDecode(r.body));setState(()=>busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Final master verified.':'Verification failed.')));
  }
  @override Widget build(BuildContext context){
    final m=result?['metadata'] as Map<String,dynamic>?;
    return Scaffold(appBar:AppBar(title:const Text('Final Master Verification')),body:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('The final file is checked with media metadata before it can be treated as a finished master.'),
      const SizedBox(height:16),
      if(result!=null) Card(child:ListTile(
        leading:Icon(result!['verified']==true?Icons.verified:Icons.error),
        title:Text(result!['verified']==true?'Verified Master':'Not Verified'),
        subtitle:Text(m==null?'${result!['error']??'Unknown verification error'}':'${m['duration']??0}s • ${m['video']?['width']??0}×${m['video']?['height']??0} • ${m['video']?['codec']??''}'))),
      FilledButton.icon(onPressed:busy?null:verify,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.fact_check),
        label:Text(busy?'Verifying…':'Verify Final Master'))
    ]));
  }
}
