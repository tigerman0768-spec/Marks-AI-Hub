import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String executionApi='http://10.0.2.2:3000';
class FinalRenderExecutionScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderExecutionScreen({super.key,required this.projectId});
  @override State<FinalRenderExecutionScreen> createState()=>_FinalRenderExecutionScreenState();
}
class _FinalRenderExecutionScreenState extends State<FinalRenderExecutionScreen>{
  Map<String,dynamic> d={};bool loading=true,working=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final r=await http.get(Uri.parse('$executionApi/api/projects/${widget.projectId}/final-render/execution-status'));
    if(r.statusCode==200&&mounted)setState(()=>d=jsonDecode(r.body));
    if(mounted)setState(()=>loading=false);
  }
  Future<void> run(String action)async{
    setState(()=>working=true);
    final r=await http.post(Uri.parse('$executionApi/api/projects/${widget.projectId}$action'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode>=200&&r.statusCode<300?'Render action accepted.':'Render action could not be completed.')));
    setState(()=>working=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final s=d['status']??'not queued';
    return Scaffold(appBar:AppBar(title:const Text('Final Render Execution')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(d['outputExists']==true?Icons.check_circle:Icons.movie_creation),
        title:Text('Status: $s'),subtitle:Text('${d['stage']??'waiting'} • ${d['progress']??0}%'))),
      if(d['error']!=null)Card(child:ListTile(leading:const Icon(Icons.error),title:const Text('Render Error'),subtitle:Text('${d['error']}'))),
      if(['dispatched','running'].contains(s))
        FilledButton.icon(onPressed:working?null:()=>run('/final-render/execute'),
          icon:const Icon(Icons.play_arrow),label:const Text('Execute Render')),
      if(d['outputExists']==true)Card(child:ListTile(leading:const Icon(Icons.video_file),
        title:const Text('Final Master Ready'),subtitle:Text('${d['outputPath']}'))),
      if(s=='running'&&d['outputExists']!=true)
        const Padding(padding:EdgeInsets.all(16),child:LinearProgressIndicator())
    ]));
  }
}
