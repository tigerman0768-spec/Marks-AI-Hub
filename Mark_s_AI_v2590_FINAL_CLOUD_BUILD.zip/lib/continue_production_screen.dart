import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'production_workflow_screen.dart';

const String continueProductionApi = 'http://10.0.2.2:3000';

class ContinueProductionScreen extends StatefulWidget {
  final String projectId;
  const ContinueProductionScreen({super.key, required this.projectId});

  @override
  State<ContinueProductionScreen> createState() => _ContinueProductionScreenState();
}

class _ContinueProductionScreenState extends State<ContinueProductionScreen> {
  Map<String, dynamic>? data;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final r = await http.get(Uri.parse(
        '$continueProductionApi/api/projects/${widget.projectId}/next-action',
      ));
      if (r.statusCode != 200) throw Exception('Server returned ${r.statusCode}');
      setState(() {
        data = jsonDecode(r.body) as Map<String, dynamic>;
        loading = false;
      });
    } catch (e) {
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Continue Production')),
        body: Center(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(padding: const EdgeInsets.all(20), child: Text(error!, textAlign: TextAlign.center)),
            FilledButton(onPressed: load, child: const Text('Retry')),
          ],
        )),
      );
    }

    final p = data!;
    final finished = p['finished'] == true;
    final checks = Map<String, dynamic>.from(p['checks'] ?? {});
    final completed = p['completedStages'] ?? 0;
    final total = p['totalStages'] ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Continue Production'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p['title'] ?? 'Untitled Film',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('Production progress: ${p['progress']}%'),
              const SizedBox(height: 10),
              LinearProgressIndicator(value: (p['progress'] ?? 0) / 100),
              const SizedBox(height: 8),
              Text('$completed of $total production stages complete'),
            ]),
          )),
          const SizedBox(height: 16),
          Card(child: ListTile(
            leading: Icon(finished ? Icons.celebration : Icons.arrow_forward),
            title: Text(finished ? 'Film is ready' : (p['nextAction'] ?? 'Continue')),
            subtitle: Text(finished
                ? 'All tracked production stages are complete.'
                : 'Next stage: ${p['nextStage'] ?? 'unknown'}'),
          )),
          const SizedBox(height: 12),
          ...checks.entries.map((e) => ListTile(
            dense: true,
            leading: Icon(e.value == true
                ? Icons.check_circle
                : Icons.radio_button_unchecked),
            title: Text(_pretty(e.key)),
          )),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ProductionWorkflowScreen(projectId: widget.projectId),
            )),
            icon: const Icon(Icons.movie_creation),
            label: const Text('Continue in Production Studio'),
          ),
        ],
      ),
    );
  }

  String _pretty(String value) {
    if (value.isEmpty) return value;
    return value[0].toUpperCase() + value.substring(1);
  }
}
