import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String videoManifestApi = 'http://10.0.2.2:3000';

class VideoGenerationManifestScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationManifestScreen({super.key, required this.projectId});

  @override
  State<VideoGenerationManifestScreen> createState() => _VideoGenerationManifestScreenState();
}

class _VideoGenerationManifestScreenState extends State<VideoGenerationManifestScreen> {
  Map<String, dynamic>? manifest;
  bool loading = true;
  bool creating = false;
  String? message;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; message = null; });
    try {
      final r = await http.get(Uri.parse(
        '$videoManifestApi/api/projects/${widget.projectId}/video-generation-manifest',
      ));
      if (r.statusCode == 200) {
        setState(() {
          manifest = jsonDecode(r.body) as Map<String, dynamic>;
          loading = false;
        });
        return;
      }
      setState(() { loading = false; });
    } catch (e) {
      setState(() { loading = false; message = e.toString(); });
    }
  }

  Future<void> createManifest() async {
    setState(() { creating = true; message = null; });
    try {
      final r = await http.post(
        Uri.parse('$videoManifestApi/api/projects/${widget.projectId}/video-generation-manifest'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'provider': 'runway'}),
      );
      if (r.statusCode != 201) {
        throw Exception('Server returned ${r.statusCode}: ${r.body}');
      }
      setState(() {
        manifest = jsonDecode(r.body) as Map<String, dynamic>;
        creating = false;
        message = 'Generation manifest created. Review the shots before launching generation.';
      });
    } catch (e) {
      setState(() { creating = false; message = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final shots = List<Map<String, dynamic>>.from(
      (manifest?['shots'] as List? ?? []).map((x) => Map<String, dynamic>.from(x)),
    );
    final settings = Map<String, dynamic>.from(manifest?['settings'] ?? {});

    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Generation Manifest'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: const Icon(Icons.video_settings),
            title: Text('${settings['resolution'] ?? '1080p'} • ${settings['aspectRatio'] ?? '16:9'}'),
            subtitle: Text('${settings['fps'] ?? 24} fps • Provider: ${manifest?['provider'] ?? 'not set'}'),
          )),
          if (manifest == null)
            Card(child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                const Text('No generation manifest exists yet.'),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: creating ? null : createManifest,
                  icon: creating
                      ? const SizedBox(width: 18, height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.build),
                  label: Text(creating ? 'Creating…' : 'Create Generation Manifest'),
                ),
              ]),
            )),
          if (manifest != null) ...[
            Text('${shots.length} shots ready for generation',
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...shots.map((shot) => Card(child: ExpansionTile(
              leading: CircleAvatar(child: Text('${shot['index']}')),
              title: Text('Scene ${shot['scene'] ?? '-'} • ${shot['duration'] ?? 5}s'),
              subtitle: Text(shot['status'] ?? 'pending'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [Text(shot['prompt'] ?? '')],
            ))),
            const SizedBox(height: 12),
            const Card(child: Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'This screen prepares and reviews the provider request manifest. '
                'It does not claim that video has been generated until the provider job is actually submitted and tracked.',
              ),
            )),
          ],
          if (message != null) ...[
            const SizedBox(height: 12),
            Text(message!, textAlign: TextAlign.center),
          ],
        ],
      ),
    );
  }
}
