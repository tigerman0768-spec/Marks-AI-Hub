import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String deliverySnapshotApi='http://10.0.2.2:3000';

class ReleasedFilmDeliverySnapshotScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliverySnapshotScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliverySnapshotScreen> createState()=>_ReleasedFilmDeliverySnapshotScreenState();
}
class _ReleasedFilmDeliverySnapshotScreenState extends State<ReleasedFilmDeliverySnapshotScreen>{
  Map<String,dynamic>? snapshot;bool busy=false;
  Future<void> capture()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$deliverySnapshotApi/api/projects/${widget.projectId}/final-render/release-delivery-snapshot/create'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>snapshot=b['snapshot'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery snapshot captured.':'Snapshot blocked.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final ok=snapshot?['status']=='captured';
    final blockers=(snapshot?['blockers'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Snapshot')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ok?Icons.camera_alt:Icons.photo_camera_back),title:Text(ok?'SNAPSHOT CAPTURED':'SNAPSHOT NOT READY'),
        subtitle:Text(ok?'Snapshot ID: ${snapshot?['snapshotId']??''}':'Seal the final delivery first.'))),
      if(snapshot!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${snapshot?['title']??''}'),Text('Size: ${snapshot?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${snapshot?['sha256']??''}'),Text('Audit events: ${snapshot?['auditEventCount']??0}'),
        if(blockers.isNotEmpty)...[const SizedBox(height:10),const Text('Blockers:'),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:capture,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.camera_alt),
        label:Text(busy?'Capturing…':'Capture Delivery Snapshot'))
    ]));
  }
}
