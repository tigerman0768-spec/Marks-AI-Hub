import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalFilmQualityScreen extends StatefulWidget{
  final String projectId;
  const FinalFilmQualityScreen({super.key,required this.projectId});
  @override State<FinalFilmQualityScreen> createState()=>_FinalFilmQualityScreenState();
}
class _FinalFilmQualityScreenState extends State<FinalFilmQualityScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false;Map<String,dynamic>? report;
  Future<void> check()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/final-film-quality/check'));
      if(r.statusCode<300)setState(()=>report=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final r=report;
    return Scaffold(appBar:AppBar(title:const Text('Final Film Quality')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.verified,size:76),const SizedBox(height:16),
          const Text('Validate the finished MP4 before it is treated as ready.',
            textAlign:TextAlign.center),const SizedBox(height:20),
          FilledButton.icon(onPressed:loading?null:check,icon:const Icon(Icons.fact_check),
            label:Text(loading?'CHECKING…':'CHECK FINAL FILM')),
          if(r!=null)...[
            const SizedBox(height:24),
            Text('${r['status']??'unknown'} • score ${r['score']??0}',
              style:Theme.of(context).textTheme.titleLarge),
            Text('Duration: ${r['duration']??0}s'),
            Text('Resolution: ${r['width']??0} × ${r['height']??0}'),
            Text('Video: ${r['videoCodec']??'none'}'),
            Text('Audio: ${r['audioCodec']??'none'}'),
            if((r['issues'] as List?)?.isNotEmpty==true)
              Text('Issues: ${(r['issues'] as List).join(', ')}')
          ]
        ])));
  }
}
