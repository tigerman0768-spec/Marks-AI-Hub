import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String batchApi='http://10.0.2.2:3000';

class VideoGenerationBatchScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationBatchScreen({super.key, required this.projectId});
  @override State<VideoGenerationBatchScreen> createState()=>_VideoGenerationBatchScreenState();
}

class _VideoGenerationBatchScreenState extends State<VideoGenerationBatchScreen>{
  Map<String,dynamic>? data;
  bool loading=true;
  bool reconciling=false;

  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$batchApi/api/projects/${widget.projectId}/video-generation/batch-status'));
      if(r.statusCode==200&&mounted){
        setState((){data=jsonDecode(r.body) as Map<String,dynamic>;loading=false;});
      }else if(mounted){setState(()=>loading=false);}
    }catch(_){if(mounted)setState(()=>loading=false);}
  }

  Future<void> reconcile() async{
    setState(()=>reconciling=true);
    try{
      final r=await http.post(Uri.parse('$batchApi/api/projects/${widget.projectId}/video-generation/reconcile'));
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text(r.statusCode==200?'Generation jobs reconciled.':'Reconcile failed.')));
      }
      await load();
    }catch(_){}
    if(mounted)setState(()=>reconciling=false);
  }

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final d=data??{};
    final c=Map<String,dynamic>.from(d['counts']??{});
    return Scaffold(
      appBar:AppBar(title:const Text('Generation Batch')),
      body:ListView(
        padding:const EdgeInsets.all(16),
        children:[
          Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
            const Text('Overall generation progress',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            const SizedBox(height:10),
            LinearProgressIndicator(value:((d['progress']??0) as num)/100),
            const SizedBox(height:8),
            Text('${d['progress']??0}% • ${d['total']??0} shots'),
          ]))),
          ...['queued','running','completed','failed','cancelled'].map((s)=>ListTile(
            leading:Icon(_icon(s)),
            title:Text(s[0].toUpperCase()+s.substring(1)),
            trailing:Text('${c[s]??0}'),
          )),
          if(d['hasFailures']==true)
            const Card(child:Padding(padding:EdgeInsets.all(14),child:Text(
              'Some shots failed. Use the job controls to retry them after reviewing the error.'
            ))),
          const SizedBox(height:12),
          FilledButton.icon(
            onPressed:reconciling?null:reconcile,
            icon:reconciling?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.sync),
            label:Text(reconciling?'Reconciling…':'Reconcile Generation Jobs'),
          ),
        ],
      ),
    );
  }

  IconData _icon(String s){
    switch(s){
      case 'completed':return Icons.check_circle;
      case 'failed':return Icons.error;
      case 'running':return Icons.play_circle;
      case 'cancelled':return Icons.cancel;
      default:return Icons.schedule;
    }
  }
}
