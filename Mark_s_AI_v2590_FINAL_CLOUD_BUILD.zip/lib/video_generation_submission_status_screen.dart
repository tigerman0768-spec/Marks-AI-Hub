import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String submissionStatusApi = 'http://10.0.2.2:3000';

class VideoGenerationSubmissionStatusScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationSubmissionStatusScreen({super.key, required this.projectId});

  @override
  State<VideoGenerationSubmissionStatusScreen> createState() =>
      _VideoGenerationSubmissionStatusScreenState();
}

class _VideoGenerationSubmissionStatusScreenState
    extends State<VideoGenerationSubmissionStatusScreen> {
  Map<String, dynamic>? data;
  bool loading = true;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) => load());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final r = await http.get(Uri.parse(
        '$submissionStatusApi/api/projects/${widget.projectId}/video-generation/submission-status',
      ));
      if (r.statusCode == 200 && mounted) {
        setState(() {
          data = jsonDecode(r.body) as Map<String, dynamic>;
          loading = false;
        });
      } else if (mounted) {
        setState(() => loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final d = data ?? {};
    final jobs = List<Map<String, dynamic>>.from(
      (d['providerResults'] as List? ?? [])
          .map((x) => Map<String, dynamic>.from(x)),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Generation Status'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: Icon(_statusIcon('${d['status'] ?? 'not_started'}')),
            title: Text('${d['status'] ?? 'not_started'}'.toUpperCase()),
            subtitle: Text('${d['completedJobs'] ?? 0} of ${d['manifestShotCount'] ?? 0} shots completed'),
          )),
          if (d['launch'] != null)
            Card(child: ListTile(
              title: Text('Launch ${d['launch']['id'] ?? ''}'),
              subtitle: Text('Provider: ${d['launch']['provider'] ?? 'unknown'}'),
            )),
          if (d['submission'] != null)
            Card(child: ListTile(
              title: Text('Provider submission: ${d['submission']['status'] ?? ''}'),
              subtitle: Text('${d['submission']['submittedAt'] ?? ''}'),
            )),
          const SizedBox(height: 8),
          ...jobs.map((job) => ListTile(
            leading: const Icon(Icons.movie),
            title: Text(job['id']?.toString() ?? 'Video job'),
            subtitle: Text('Status: ${job['status'] ?? 'unknown'}'),
          )),
          if (d['status'] == 'not_started')
            const Card(child: Padding(
              padding: EdgeInsets.all(14),
              child: Text('No provider submission has been recorded yet.'),
            )),
        ],
      ),
    );
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'submitted':
        return Icons.cloud_upload;
      case 'failed':
        return Icons.error_outline;
      case 'queued':
        return Icons.schedule;
      default:
        return Icons.hourglass_empty;
    }
  }
}
