import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CinematicShotDirectorScreen extends StatefulWidget{
  final String projectId;
  const CinematicShotDirectorScreen({super.key,required this.projectId});
  @override State<CinematicShotDirectorScreen> createState()=>_CinematicShotDirectorScreenState();
}
class _CinematicShotDirectorScreenState extends State<CinematicShotDirectorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; List<dynamic> scenes=[];
  Future<void> generate()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/cinematic-shots/generate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300)setState(()=>scenes=(jsonDecode(r.body)['cinematicShotPlan'] as List));
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Cinematic Shot Director')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.camera,size:72),
      const SizedBox(height:12),
      const Text('Direct every shot with cinematic framing, lens feel, movement, lighting and composition.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('The plan uses scene emotion and the performance director to make the visual language support the acting.'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:generate,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(loading?'DIRECTING SHOTS...':'DIRECT CINEMATIC SHOTS')),
      const SizedBox(height:20),
      ...scenes.map((s){
        final m=Map<String,dynamic>.from(s as Map);
        final shots=(m['shots'] as List?)??[];
        return Card(child:ExpansionTile(
          title:Text(m['sceneTitle']??'Scene'),
          subtitle:Text('${shots.length} cinematic shots'),
          children:[for(final x in shots)
            ListTile(
              leading:const Icon(Icons.videocam),
              title:Text('${x['framing']??''} • ${x['lens']??''}'),
              subtitle:Text('${x['movement']??''} • ${x['lighting']??''}\n${x['composition']??''}'),
              isThreeLine:true,
            )],
        ));
      })
    ]),
  );
}
