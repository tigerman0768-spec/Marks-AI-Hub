import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiMasterFinishScreen extends StatefulWidget{
  final String projectId;
  const AiMasterFinishScreen({super.key,required this.projectId});
  @override State<AiMasterFinishScreen> createState()=>_AiMasterFinishScreenState();
}
class _AiMasterFinishScreenState extends State<AiMasterFinishScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? result;
  Future<void> master()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-master'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Master final MP4 created')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('AI Master Finish')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.high_quality,size:72),const SizedBox(height:16),
          const Text('Burn available subtitles and master the available audio tracks into the final film.',
            textAlign:TextAlign.center),const SizedBox(height:20),
          FilledButton.icon(onPressed:loading?null:master,icon:const Icon(Icons.auto_awesome),
            label:Text(loading?'MASTERING…':'MASTER FINAL FILM')),
          if(result!=null)...[
            const SizedBox(height:20),
            Text('Subtitles: ${result!['subtitlesBurned']==true?'burned':'not available'}'),
            Text('Audio mastered: ${result!['audioMastered']==true?'yes':'no'}'),
            const SizedBox(height:8),Text('${result!['outputPath']??''}',textAlign:TextAlign.center)
          ]
        ])));
  }
}
