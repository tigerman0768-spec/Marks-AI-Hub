import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class ProjectBackupScreen extends StatefulWidget{
  final String projectId; const ProjectBackupScreen({super.key,required this.projectId});
  @override State<ProjectBackupScreen> createState()=>_ProjectBackupScreenState();
}
class _ProjectBackupScreenState extends State<ProjectBackupScreen>{
  static const base='http://10.0.2.2:3000'; bool busy=false; Map<String,dynamic>? result;
  Future<void> _backup() async{
    setState(()=>busy=true);
    try{final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/backup'));
      if(r.statusCode>=300)throw Exception('Backup failed');
      if(mounted)setState(()=>result=jsonDecode(r.body));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
    if(mounted)setState(()=>busy=false);
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Project Backup')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Project Backup',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:8),
      const Text('Create a local JSON backup of the complete saved project state.'),
      const SizedBox(height:18),
      FilledButton.icon(onPressed:busy?null:_backup,icon:const Icon(Icons.backup),label:Text(busy?'CREATING BACKUP...':'CREATE BACKUP')),
      if(result!=null)Card(child:ListTile(leading:const Icon(Icons.check_circle),title:const Text('Backup created'),
        subtitle:Text('${result!['bytes']??0} bytes'))),
    ]));
}
