import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String catalogApi='http://10.0.2.2:3000';
class FinalMasterReleaseCatalogScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterReleaseCatalogScreen({super.key,required this.projectId});
  @override State<FinalMasterReleaseCatalogScreen> createState()=>_FinalMasterReleaseCatalogScreenState();
}
class _FinalMasterReleaseCatalogScreenState extends State<FinalMasterReleaseCatalogScreen>{
  Map<String,dynamic>? catalog;bool busy=false;
  Future<void> catalogue()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$catalogApi/api/projects/${widget.projectId}/final-render/release-catalog/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>catalog=b['catalog'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Film catalogued.':'Cataloguing blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=catalog?['status']=='catalogued';
    return Scaffold(appBar:AppBar(title:const Text('Release Catalogue')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.library_add_check:Icons.library_add),
        title:Text(ready?'FILM CATALOGUED':'NOT CATALOGUED'),
        subtitle:Text(ready?'Catalog ID: ${catalog?['catalogId']??''}':'Seal the release snapshot first.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Title: ${catalog?['title']??''}'),Text('File: ${catalog?['filename']??''}'),
        Text('Duration: ${catalog?['duration']??0}s'),Text('Size: ${catalog?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${catalog?['sha256']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:catalogue,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.library_add),
        label:Text(busy?'Cataloguing…':'Catalogue Film'))
    ]));
  }
}
