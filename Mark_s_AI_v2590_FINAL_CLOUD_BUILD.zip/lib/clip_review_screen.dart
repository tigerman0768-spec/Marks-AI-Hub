import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ClipReviewScreen extends StatefulWidget{
  final String projectId;
  const ClipReviewScreen({super.key,required this.projectId});
  @override State<ClipReviewScreen> createState()=>_ClipReviewScreenState();
}
class _ClipReviewScreenState extends State<ClipReviewScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; String? error; Map<String,dynamic> data={};
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clip-review-ui'));
      if(r.statusCode>=300)throw Exception('Clip review unavailable (${r.statusCode})');
      data=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> _decision(String jobId,String decision) async{
    try{
      final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/clip-review/$jobId'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'decision':decision}));
      if(r.statusCode>=300)throw Exception('Review failed (${r.statusCode})');
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  Future<void> _regenerate(String jobId) async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/clips/$jobId/regenerate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode>=300)throw Exception('Regeneration failed (${r.statusCode})');
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Regeneration queued')));
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Clip Review')),body:Center(child:Text(error!)));
    final jobs=(data['jobs'] as List?)??[];
    final reviews=(data['reviews'] as Map?)??{};
    return Scaffold(appBar:AppBar(title:const Text('Clip Review')),body:ListView(
      padding:const EdgeInsets.all(16),children:[
        Text(data['title']?.toString()??'Film',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:8),
        const Text('Review generated clips and accept the takes you want to keep.'),
        const SizedBox(height:18),
        ...jobs.map((j){
          final id=j['id'].toString(); final rev=reviews[id] as Map?;
          final decision=rev?['decision']?.toString()??'pending';
          return Card(child:ExpansionTile(
            title:Text('Shot ${j['shotNumber']??''}'),
            subtitle:Text('${j['status']??''} • Review: $decision'),
            children:[
              ListTile(title:const Text('Scene'),subtitle:Text('${j['sceneId']??''}')),
              ListTile(title:const Text('Quality'),subtitle:Text('${j['qualityStatus']??'not checked'}')),
              if(j['smartReview']!=null)ListTile(title:const Text('Smart Review'),subtitle:Text('${j['smartReview']['score']??''} / 100 • ${j['smartReview']['decision']??''}')),
              ButtonBar(children:[
                TextButton(onPressed:()=>_decision(id,'rejected'),child:const Text('REJECT')),
                FilledButton(onPressed:()=>_decision(id,'accepted'),child:const Text('ACCEPT')),
                OutlinedButton.icon(onPressed:()=>_regenerate(id),icon:const Icon(Icons.refresh),label:const Text('REGENERATE')),
              ])
            ],
          ));
        }),
      ],
    ));
  }
}
