import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SmartOneClickFinalRenderScreen extends StatefulWidget{
  final String projectId;
  const SmartOneClickFinalRenderScreen({super.key,required this.projectId});
  @override State<SmartOneClickFinalRenderScreen> createState()=>_SmartOneClickFinalRenderScreenState();
}
class _SmartOneClickFinalRenderScreenState extends State<SmartOneClickFinalRenderScreen>{
  static const base='http://10.0.2.2:3000';
  bool running=false;Map<String,dynamic>? result,progress;Timer? timer;
  Future<void> run()async{
    setState(()=>running=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/smart-one-click-final-render'));
      if(r.statusCode<300){
        final data=Map<String,dynamic>.from(jsonDecode(r.body));
        setState(()=>result=data);
        final id=data['progressId'];
        if(id!=null) _poll(id.toString());
      } else setState(()=>result={'status':'failed','error':r.body});
    }catch(e){setState(()=>result={'status':'failed','error':e.toString()});setState(()=>running=false);}
  }
  void _poll(String id){
    timer?.cancel();
    timer=Timer.periodic(const Duration(seconds:1),(t)async{
      try{
        final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/smart-one-click-final-render/progress/$id'));
        if(r.statusCode<300){
          final p=Map<String,dynamic>.from(jsonDecode(r.body));
          if(mounted)setState(()=>progress=p);
          if(p['status']!='running'){t.cancel();if(mounted)setState(()=>running=false);}
        }
      }catch(_){}
    });
  }
  @override void dispose(){timer?.cancel();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Smart One-Click Final Render')),
    body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Icon(Icons.movie_creation,size:80),const SizedBox(height:16),
      const Text('Render → quality check → auto-repair → final validation → Film Library.',textAlign:TextAlign.center),
      const SizedBox(height:24),
      FilledButton.icon(onPressed:running?null:run,icon:const Icon(Icons.play_circle),label:Text(running?'RUNNING…':'START SMART FINAL RENDER')),
      if(progress!=null)...[
        const SizedBox(height:24),
        Text(progress!['stage']?.toString()??'Working…'),
        const SizedBox(height:8),
        LinearProgressIndicator(value:(progress!['progress'] as num?)?.toDouble().clamp(0,100)/100),
        const SizedBox(height:8),
        Text('${progress!['progress']??0}%')
      ],
      if(result!=null)...[
        const SizedBox(height:20),
        Text('Status: ${progress?['status']??result!['status']??'unknown'}',style:Theme.of(context).textTheme.titleLarge),
        if(result!['outputPath']!=null)Text(result!['outputPath'].toString(),textAlign:TextAlign.center),
        if(result!['error']!=null)Text(result!['error'].toString())
      ]
    ])));
}
