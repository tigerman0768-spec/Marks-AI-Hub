import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String reconcileApi='http://10.0.2.2:3000';
class FinalRenderReconciliationScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderReconciliationScreen({super.key,required this.projectId});
  @override State<FinalRenderReconciliationScreen> createState()=>_FinalRenderReconciliationScreenState();
}
class _FinalRenderReconciliationScreenState extends State<FinalRenderReconciliationScreen>{
  Map<String,dynamic>? data; bool busy=false;
  Future<void> reconcile()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$reconcileApi/api/projects/${widget.projectId}/final-render/reconcile'));
    if(mounted){
      if(r.statusCode==200)setState(()=>data=jsonDecode(r.body));
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Render state reconciled.':'Reconciliation failed.')));
      setState(()=>busy=false);
    }
  }
  @override Widget build(BuildContext context){
    final q=data?['queue'] as Map<String,dynamic>?;
    return Scaffold(appBar:AppBar(title:const Text('Render Reconciliation')),body:Padding(
      padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('Checks worker state and the real output file before confirming completion.'),
        const SizedBox(height:16),
        if(q!=null) Card(child:ListTile(title:Text('Status: ${q['status']??'unknown'}'),
          subtitle:Text('${q['stage']??'waiting'} • ${q['progress']??0}% • output: ${q['outputExists']==true?'verified':'not found'}'))),
        FilledButton.icon(onPressed:busy?null:reconcile,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.sync),
          label:Text(busy?'Checking…':'Reconcile Render'))
      ])));
  }
}
