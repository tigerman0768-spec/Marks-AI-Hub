import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VisualContinuityScreen extends StatefulWidget{
  final String projectId;
  const VisualContinuityScreen({super.key,required this.projectId});
  @override State<VisualContinuityScreen> createState()=>_VisualContinuityScreenState();
}
class _VisualContinuityScreenState extends State<VisualContinuityScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? plan;
  Future<void> generate()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/visual-continuity/generate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300)setState(()=>plan=Map<String,dynamic>.from(jsonDecode(r.body)['visualContinuityPlan']));
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Visual Continuity Director')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.collections_bookmark,size:72),
      const SizedBox(height:12),
      const Text('Keep characters, wardrobe, props and locations consistent across generated shots.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('Creates a persistent visual continuity bible that can be passed into cinematic shot prompts.'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:generate,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(loading?'BUILDING...':'BUILD CONTINUITY BIBLE')),
      if(plan!=null)...[
        const SizedBox(height:20),
        Text('Characters: ${(plan!['characters'] as List?)?.length??0}',
          style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        ...((plan!['characters'] as List?)??[]).map((c){
          final m=Map<String,dynamic>.from(c);
          return ListTile(leading:const Icon(Icons.person),title:Text(m['name']??'Character'),
            subtitle:Text('${m['appearance']??''}\nWardrobe: ${m['wardrobe']??''}'),isThreeLine:true);
        }),
        const SizedBox(height:12),
        Text('Scenes: ${(plan!['scenes'] as List?)?.length??0}',
          style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        ...((plan!['scenes'] as List?)??[]).map((c){
          final m=Map<String,dynamic>.from(c);
          return Card(child:ListTile(title:Text(m['location']??'Scene'),
            subtitle:Text('Time: ${m['time']??''} • Lighting: ${m['lighting']??''}')));
        }),
      ]
    ]),
  );
}
