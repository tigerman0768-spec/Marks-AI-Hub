import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalRenderRecoveryScreen extends StatefulWidget{
  const FinalRenderRecoveryScreen({super.key});
  @override State<FinalRenderRecoveryScreen> createState()=>_FinalRenderRecoveryScreenState();
}
class _FinalRenderRecoveryScreenState extends State<FinalRenderRecoveryScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; List<dynamic> jobs=[]; int maxRetries=3;
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/final-render/recovery-candidates'));
      if(r.statusCode<300){
        final d=Map<String,dynamic>.from(jsonDecode(r.body));
        setState(()=>jobs=List<dynamic>.from(d['jobs']??[]));
        maxRetries=(d['maxRetries']??3) as int;
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> recover()async{
    setState(()=>loading=true);
    try{await http.post(Uri.parse('$base/api/final-render/recover'));await load();}
    catch(_){if(mounted)setState(()=>loading=false);}
  }
  @override void initState(){super.initState();load();}
  Color _statusColor(String s){
    if(s=='recovery_exhausted')return Colors.red;
    if(s=='recovering')return Colors.orange;
    return Colors.blue;
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Final Render Recovery')),
    body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Icon(Icons.restore,size:72),const SizedBox(height:12),
      const Text('Interrupted renders are safely restarted with a limited number of recovery attempts.',textAlign:TextAlign.center),
      const SizedBox(height:8),
      Text('Maximum automatic attempts: $maxRetries',textAlign:TextAlign.center),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:recover,icon:const Icon(Icons.restore),label:const Text('RECOVER RENDER JOBS')),
      const SizedBox(height:20),
      Expanded(child:jobs.isEmpty?const Center(child:Text('No recovery jobs found.')):
        ListView.builder(itemCount:jobs.length,itemBuilder:(c,i){
          final j=Map<String,dynamic>.from(jobs[i]);
          final status=j['status']?.toString()??'unknown';
          return Card(child:ListTile(
            leading:Icon(Icons.movie,color:_statusColor(status)),
            title:Text(j['projectId']?.toString()??'Unknown project'),
            subtitle:Text('$status • attempt ${j['recoveryAttempts']??0}/$maxRetries\n${j['recoveryMessage']??j['stage']??''}'),
          ));
        }))
    ])));
}
