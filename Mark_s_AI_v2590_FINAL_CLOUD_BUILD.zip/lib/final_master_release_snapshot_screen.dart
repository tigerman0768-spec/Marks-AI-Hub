import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String snapshotApi='http://10.0.2.2:3000';
class FinalMasterReleaseSnapshotScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterReleaseSnapshotScreen({super.key,required this.projectId});
  @override State<FinalMasterReleaseSnapshotScreen> createState()=>_FinalMasterReleaseSnapshotScreenState();
}
class _FinalMasterReleaseSnapshotScreenState extends State<FinalMasterReleaseSnapshotScreen>{
  Map<String,dynamic>? snapshot;bool busy=false;
  Future<void> seal()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$snapshotApi/api/projects/${widget.projectId}/final-render/release-snapshot/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>snapshot=b['snapshot'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Release snapshot sealed.':'Snapshot blocked.')));
  }
  @override Widget build(BuildContext context){
    final sealed=snapshot?['status']=='sealed';
    return Scaffold(appBar:AppBar(title:const Text('Release Snapshot')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(sealed?Icons.lock:Icons.photo_library),
        title:Text(sealed?'RELEASE SNAPSHOT SEALED':'SNAPSHOT NOT SEALED'),
        subtitle:Text(sealed?'Snapshot ID: ${snapshot?['snapshotId']??''}':'A verified release record is required.'))),
      if(sealed) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${snapshot?['title']??''}'),Text('File: ${snapshot?['filename']??''}'),
        Text('Size: ${snapshot?['bytes']??0} bytes'),Text('Sealed: ${snapshot?['createdAt']??''}'),
        SelectableText('SHA-256: ${snapshot?['sha256']??''}')
      ]))),
      FilledButton.icon(onPressed:busy||sealed?null:seal,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.lock),
        label:Text(busy?'Sealing…':'Seal Release Snapshot'))
    ]));
  }
}
