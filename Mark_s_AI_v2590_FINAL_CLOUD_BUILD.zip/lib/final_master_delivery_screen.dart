import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String deliveryApi='http://10.0.2.2:3000';
class FinalMasterDeliveryScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterDeliveryScreen({super.key,required this.projectId});
  @override State<FinalMasterDeliveryScreen> createState()=>_FinalMasterDeliveryScreenState();
}
class _FinalMasterDeliveryScreenState extends State<FinalMasterDeliveryScreen>{
  Map<String,dynamic>? pkg;bool busy=false;
  Future<void> buildPackage()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$deliveryApi/api/projects/${widget.projectId}/final-render/delivery-package/build'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>pkg=b['package'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery package ready.':'Delivery package blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=pkg?['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Final Master Delivery')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.inventory_2:Icons.lock),
        title:Text(ready?'DELIVERY PACKAGE READY':'DELIVERY PACKAGE NOT READY'),
        subtitle:Text(ready?'${pkg?['bytes']??0} bytes • ${pkg?['duration']??0}s':'Pass the Final Master Gate first.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${pkg?['title']??''}'),
        Text('Video: ${pkg?['video']?['width']??0} × ${pkg?['video']?['height']??0}'),
        Text('Codec: ${pkg?['video']?['codec']??'unknown'}'),
        Text('Audio: ${pkg?['audio']?['codec']??'none'}'),
      ]))),
      FilledButton.icon(onPressed:busy?null:buildPackage,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.inventory),
        label:Text(busy?'Building…':'Build Delivery Package'))
    ]));
  }
}
