import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releaseRecordApi='http://10.0.2.2:3000';
class FinalMasterReleaseRecordScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterReleaseRecordScreen({super.key,required this.projectId});
  @override State<FinalMasterReleaseRecordScreen> createState()=>_FinalMasterReleaseRecordScreenState();
}
class _FinalMasterReleaseRecordScreenState extends State<FinalMasterReleaseRecordScreen>{
  Map<String,dynamic>? record;bool busy=false;
  Future<void> release()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$releaseRecordApi/api/projects/${widget.projectId}/final-render/release-record/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>record=b['record'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Film release recorded.':'Release blocked.')));
  }
  @override Widget build(BuildContext context){
    final released=record?['status']=='released';
    return Scaffold(appBar:AppBar(title:const Text('Release Record')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(released?Icons.celebration:Icons.lock),
        title:Text(released?'FILM RELEASED':'RELEASE NOT RECORDED'),
        subtitle:Text(released?'Release ID: ${record?['releaseId']??''}':'Complete release readiness first.'))),
      if(released) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${record?['title']??''}'),Text('File: ${record?['filename']??''}'),
        Text('Size: ${record?['bytes']??0} bytes'),Text('Released: ${record?['releasedAt']??''}'),
        SelectableText('SHA-256: ${record?['sha256']??''}')
      ]))),
      FilledButton.icon(onPressed:busy||released?null:release,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rocket_launch),
        label:Text(busy?'Recording…':'Record Final Release'))
    ]));
  }
}
