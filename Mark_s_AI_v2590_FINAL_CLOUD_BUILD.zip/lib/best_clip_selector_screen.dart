import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class BestClipSelectorScreen extends StatefulWidget{
  final String projectId;
  const BestClipSelectorScreen({super.key,required this.projectId});
  @override State<BestClipSelectorScreen> createState()=>_BestClipSelectorScreenState();
}
class _BestClipSelectorScreenState extends State<BestClipSelectorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<dynamic> selections=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/best'));
      if(r.statusCode<300)setState(()=>selections=(jsonDecode(r.body)['selections'] as List));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> apply()async{
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/clips/best/apply'));
    if(mounted && r.statusCode<300){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Best clip selected for each shot')));
      load();
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Best Clip Selector'),actions:[
      IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):
      Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:selections.isEmpty?null:apply,
            icon:const Icon(Icons.auto_awesome),label:const Text('SELECT BEST CLIPS')))),
        Expanded(child:selections.isEmpty?const Center(child:Text('No versioned clips available.')):
          ListView.builder(padding:const EdgeInsets.all(12),itemCount:selections.length,
            itemBuilder:(context,i){
              final m=Map<String,dynamic>.from(selections[i] as Map);
              return Card(child:ListTile(
                leading:const Icon(Icons.star),
                title:Text('${m['shotKey']} — Version ${m['version']}'),
                subtitle:Text('Selection score: ${m['score']}'),
              ));
            }))
      ])
  );
}
