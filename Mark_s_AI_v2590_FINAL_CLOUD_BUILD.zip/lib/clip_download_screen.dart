import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ClipDownloadScreen extends StatefulWidget{
  final String projectId;
  const ClipDownloadScreen({super.key,required this.projectId});
  @override State<ClipDownloadScreen> createState()=>_ClipDownloadScreenState();
}
class _ClipDownloadScreenState extends State<ClipDownloadScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; List<dynamic> results=[];
  Future<void> download()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/video-generation/download-completed'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300)setState(()=>results=(jsonDecode(r.body)['downloadResults'] as List));
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Generated Clip Downloads')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.download_done,size:72),
      const SizedBox(height:12),
      const Text('Download completed AI video clips into the project.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('Completed provider outputs are saved locally and linked back to their scene and shot records.'),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:loading?null:download,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.download),
        label:Text(loading?'DOWNLOADING...':'DOWNLOAD COMPLETED CLIPS')),
      const SizedBox(height:16),
      ...results.map((r){
        final m=Map<String,dynamic>.from(r as Map);
        return ListTile(
          leading:Icon(m['status']=='downloaded'||m['status']=='already_downloaded'?Icons.check_circle:Icons.error),
          title:Text('Shot ${m['jobId']??''}'),
          subtitle:Text('${m['status']??''}${m['error']!=null?'\n${m['error']}':''}'),
          isThreeLine:m['error']!=null,
        );
      })
    ]),
  );
}
