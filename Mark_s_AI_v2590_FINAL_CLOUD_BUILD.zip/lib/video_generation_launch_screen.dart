import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String videoLaunchApi = 'http://10.0.2.2:3000';

class VideoGenerationLaunchScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationLaunchScreen({super.key, required this.projectId});

  @override
  State<VideoGenerationLaunchScreen> createState() => _VideoGenerationLaunchScreenState();
}

class _VideoGenerationLaunchScreenState extends State<VideoGenerationLaunchScreen> {
  Map<String, dynamic>? preflight;
  Map<String, dynamic>? launch;
  bool loading = true;
  bool launching = false;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final r = await http.get(Uri.parse(
        '$videoLaunchApi/api/projects/${widget.projectId}/video-generation-preflight',
      ));
      if (r.statusCode != 200) throw Exception('Server returned ${r.statusCode}');
      setState(() {
        preflight = jsonDecode(r.body) as Map<String, dynamic>;
        loading = false;
      });
    } catch (e) {
      setState(() { loading = false; error = e.toString(); });
    }
  }

  Future<void> launch() async {
    setState(() { launching = true; error = null; });
    try {
      final r = await http.post(
        Uri.parse('$videoLaunchApi/api/projects/${widget.projectId}/video-generation/launch'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'dryRun': preflight?['ready'] != true}),
      );
      if (r.statusCode != 202) {
        throw Exception('Server returned ${r.statusCode}: ${r.body}');
      }
      setState(() {
        launch = jsonDecode(r.body) as Map<String, dynamic>;
        launching = false;
      });
    } catch (e) {
      setState(() { launching = false; error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null && preflight == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Launch Video Generation')),
        body: Center(child: Text(error!, textAlign: TextAlign.center)),
      );
    }

    final checks = Map<String, dynamic>.from(preflight?['checks'] ?? {});
    final missing = List<String>.from(preflight?['missing'] ?? const []);
    final ready = preflight?['ready'] == true;

    return Scaffold(
      appBar: AppBar(title: const Text('Launch Video Generation')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: Icon(ready ? Icons.check_circle : Icons.info_outline),
            title: Text(ready ? 'Ready for provider launch' : 'Preflight incomplete'),
            subtitle: Text(ready
                ? 'All required inputs and provider configuration are present.'
                : 'The app will record a dry-run launch instead of claiming provider generation.'),
          )),
          const SizedBox(height: 8),
          ...checks.entries.map((e) => ListTile(
            leading: Icon(e.value == true
                ? Icons.check_circle : Icons.radio_button_unchecked),
            title: Text(_pretty(e.key)),
          )),
          if (missing.isNotEmpty)
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text('Missing: ${missing.map(_pretty).join(', ')}'),
            )),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: launching ? null : launch,
            icon: launching
                ? const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.rocket_launch),
            label: Text(launching ? 'Launching…' : 'Record Generation Launch'),
          ),
          if (launch != null) ...[
            const SizedBox(height: 16),
            Card(child: ListTile(
              leading: const Icon(Icons.task_alt),
              title: Text('Launch ${launch!['status']}'),
              subtitle: Text(
                '${launch!['shotCount']} shots • ${launch!['dryRun'] == true ? 'dry-run' : 'provider-ready'}',
              ),
            )),
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(launch!['message'] ?? ''),
            ),
          ],
          if (error != null) ...[
            const SizedBox(height: 12),
            Text(error!, textAlign: TextAlign.center),
          ],
        ],
      ),
    );
  }

  String _pretty(String value) {
    if (value.isEmpty) return value;
    return value[0].toUpperCase() + value.substring(1);
  }
}
