import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'film_library_player_screen.dart';

class FilmDetailsScreen extends StatefulWidget{
 final String filmId;
 const FilmDetailsScreen({super.key,required this.filmId});
 @override State<FilmDetailsScreen> createState()=>_FilmDetailsScreenState();
}
class _FilmDetailsScreenState extends State<FilmDetailsScreen>{
 static const base='http://10.0.2.2:3000';Map<String,dynamic>? film;bool loading=true;
 @override void initState(){super.initState();load();}
 Future<void> load()async{
  final r=await http.get(Uri.parse('$base/api/film-library/${widget.filmId}'));
  if(r.statusCode<300&&mounted)setState(()=>film=Map<String,dynamic>.from(jsonDecode(r.body)));
  if(mounted)setState(()=>loading=false);
 }
 @override Widget build(BuildContext context){
  final f=film;
  return Scaffold(appBar:AppBar(title:Text(f?['title']?.toString()??'Film Details')),
   body:loading?const Center(child:CircularProgressIndicator()):
   f==null?const Center(child:Text('Film not found')):
   ListView(padding:const EdgeInsets.all(18),children:[
    AspectRatio(aspectRatio:16/9,child:Image.network('$base/api/film-library/${widget.filmId}/thumbnail',
      fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Center(child:Icon(Icons.movie,size:70)))),
    const SizedBox(height:16),Text('${f['title']??'Untitled Film'}',style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:8),Text('${f['genre']??'Genre not set'} • ${f['style']??'Style not set'}'),
    const SizedBox(height:8),Text('Duration: ${f['duration']??0}  •  Resolution: ${f['resolution']??'—'}'),
    const SizedBox(height:18),FilledButton.icon(
      onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FilmLibraryPlayerScreen(
        filmId:widget.filmId,title:'${f['title']??'Film'}'))),
      icon:const Icon(Icons.play_circle_fill),label:const Text('PLAY FILM')),
   ]));
 }
}
