import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String renderPackageApi='http://10.0.2.2:3000';

class FinalRenderPackageScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderPackageScreen({super.key,required this.projectId});
  @override State<FinalRenderPackageScreen> createState()=>_FinalRenderPackageScreenState();
}
class _FinalRenderPackageScreenState extends State<FinalRenderPackageScreen>{
  Map<String,dynamic> data={};bool loading=true,validating=false;
  String resolution='1080p',ratio='16:9';int fps=24;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final a=await http.get(Uri.parse('$renderPackageApi/api/projects/${widget.projectId}/final-render/package'));
    final c=await http.get(Uri.parse('$renderPackageApi/api/projects/${widget.projectId}/final-render/config'));
    if(mounted)setState((){
      if(a.statusCode==200)data=jsonDecode(a.body);
      if(c.statusCode==200){final x=jsonDecode(c.body)['config'];resolution=x['resolution']??resolution;ratio=x['aspectRatio']??ratio;fps=x['fps']??fps;}
      loading=false;
    });
  }
  Future<void> validate()async{
    setState(()=>validating=true);
    final r=await http.post(Uri.parse('$renderPackageApi/api/projects/${widget.projectId}/final-render/package/validate'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200&&jsonDecode(r.body)['valid']==true?'Render package validated.':'Render package has issues.')));
    setState(()=>validating=false);load();
  }
  Future<void> saveConfig()async{
    await http.patch(Uri.parse('$renderPackageApi/api/projects/${widget.projectId}/final-render/config'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'resolution':resolution,'aspectRatio':ratio,'fps':fps,'format':'mp4'}));
    load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(appBar:AppBar(title:const Text('Final Render Package')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(title:Text('${data['clipCount']??0} render clips'),subtitle:Text('${data['availableFiles']??0}/${data['clipCount']??0} source files available'))),
      DropdownButtonFormField<String>(value:resolution,decoration:const InputDecoration(labelText:'Resolution'),items:['720p','1080p','4K'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>resolution=x!)),
      DropdownButtonFormField<String>(value:ratio,decoration:const InputDecoration(labelText:'Aspect Ratio'),items:['16:9','9:16','1:1'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>ratio=x!)),
      DropdownButtonFormField<int>(value:fps,decoration:const InputDecoration(labelText:'Frame Rate'),items:[24,25,30,60].map((x)=>DropdownMenuItem(value:x,child:Text('$x fps'))).toList(),onChanged:(x)=>setState(()=>fps=x!)),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:saveConfig,icon:const Icon(Icons.settings),label:const Text('Save Render Settings')),
      const SizedBox(height:8),
      FilledButton.icon(onPressed:validating?null:validate,icon:validating?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.verified),label:Text(validating?'Validating…':'Validate Render Package'))
    ]));
  }
}
