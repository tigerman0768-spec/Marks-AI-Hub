import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String clipInventoryApi='http://10.0.2.2:3000';

class VideoGenerationClipInventoryScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationClipInventoryScreen({super.key,required this.projectId});
  @override State<VideoGenerationClipInventoryScreen> createState()=>_VideoGenerationClipInventoryScreenState();
}

class _VideoGenerationClipInventoryScreenState extends State<VideoGenerationClipInventoryScreen>{
  Map<String,dynamic>? data;
  bool loading=true,syncing=false;

  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$clipInventoryApi/api/projects/${widget.projectId}/video-generation/clip-inventory'));
      if(r.statusCode==200&&mounted){
        setState((){data=jsonDecode(r.body) as Map<String,dynamic>;loading=false;});
      }else if(mounted)setState(()=>loading=false);
    }catch(_){if(mounted)setState(()=>loading=false);}
  }

  Future<void> sync() async{
    setState(()=>syncing=true);
    try{
      final r=await http.post(Uri.parse('$clipInventoryApi/api/projects/${widget.projectId}/video-generation/sync-clips'));
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text(r.statusCode==200?'Completed clips synced.':'Sync failed.')));
      await load();
    }catch(_){}
    if(mounted)setState(()=>syncing=false);
  }

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final clips=List<Map<String,dynamic>>.from((data?['inventory'] as List? ?? []).map((x)=>Map<String,dynamic>.from(x)));
    return Scaffold(
      appBar:AppBar(title:const Text('Generated Clips'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
      body:ListView(
        padding:const EdgeInsets.all(16),
        children:[
          Card(child:ListTile(
            leading:const Icon(Icons.video_library),
            title:Text('${data?['available']??0} of ${data?['total']??0} clips available'),
            subtitle:Text('${data?['missing']??0} clip files missing'),
          )),
          FilledButton.icon(
            onPressed:syncing?null:sync,
            icon:syncing?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.sync),
            label:Text(syncing?'Syncing…':'Sync Completed Clips'),
          ),
          const SizedBox(height:8),
          ...clips.map((c)=>Card(child:ListTile(
            leading:Icon(c['fileExists']==true?Icons.check_circle:Icons.error_outline),
            title:Text('Shot ${c['index']??'-'} • Scene ${c['scene']??'-'}'),
            subtitle:Text(c['status']??'unknown'),
            trailing:Text('${c['duration']??0}s'),
          )))
        ],
      ),
    );
  }
}
