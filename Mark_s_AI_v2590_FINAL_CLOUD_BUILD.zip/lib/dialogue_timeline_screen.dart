import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DialogueTimelineScreen extends StatefulWidget{
  final String projectId;
  const DialogueTimelineScreen({super.key,required this.projectId});
  @override State<DialogueTimelineScreen> createState()=>_DialogueTimelineScreenState();
}
class _DialogueTimelineScreenState extends State<DialogueTimelineScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> tracks=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/timeline/dialogue'));
      if(r.statusCode==200)tracks=(jsonDecode(r.body)['tracks'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> add() async{
    final character=TextEditingController(text:'Character');
    final text=TextEditingController();
    final audio=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:const Text('Add dialogue'),
      content:SingleChildScrollView(child:Column(children:[
        TextField(controller:character,decoration:const InputDecoration(labelText:'Character')),
        TextField(controller:text,decoration:const InputDecoration(labelText:'Dialogue')),
        TextField(controller:audio,decoration:const InputDecoration(labelText:'Voice audio path')),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('CANCEL')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('ADD'))],
    ));
    if(ok==true&&audio.text.trim().isNotEmpty){
      await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/dialogue'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'action':'add','track':{
          'character':character.text,'text':text.text,'audioPath':audio.text,'start':0,'duration':5,'volume':1,'duckMusic':true,'duckLevel':0.25
        }}));
      await load();
    }
  }
  Future<void> update(int i,Map<String,dynamic> patch) async{
    final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/dialogue'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'action':'update','index':i,'track':{...tracks[i],...patch}}));
    if(r.statusCode<300)await load();
  }
  Future<void> remove(int i) async{
    await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/dialogue'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'action':'remove','index':i}));
    await load();
  }
  
  Future<void> extractFromScreenplay() async{
    try{
      final r=await http.post(Uri.parse('http://10.0.2.2:3000/api/projects/$projectId/screenplay/extract-dialogue'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'replace':true}));
      if(r.statusCode<300){ await load(); }
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text(r.statusCode<300?'Dialogue extracted from screenplay.':r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
  }


  Future<void> generateActingDirection() async{
    try{
      final r=await http.post(Uri.parse('http://10.0.2.2:3000/api/projects/$projectId/dialogue/acting-direction'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300){await load();}
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:Text(r.statusCode<300?'AI acting direction generated.':r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
  }

@override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Dialogue Timeline'),actions:[IconButton(tooltip:'AI Acting Direction',icon:const Icon(Icons.psychology),onPressed:generateActingDirection)]),
    floatingActionButton:FloatingActionButton.extended(onPressed:add,icon:const Icon(Icons.record_voice_over),label:const Text('ADD DIALOGUE')),
    body:loading?const Center(child:CircularProgressIndicator()):
      tracks.isEmpty?const Center(child:Text('No dialogue tracks yet.')):
      ReorderableListView.builder(itemCount:tracks.length,padding:const EdgeInsets.all(12),
        onReorder:(a,b)async{
          if(b>a)b--;
          await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/dialogue'),
            headers:{'Content-Type':'application/json'},body:jsonEncode({'action':'reorder','from':a,'to':b}));
          await load();
        },
        itemBuilder:(context,i){
          final t=tracks[i]; final start=double.tryParse('${t['start']??0}')??0;
          final vol=double.tryParse('${t['volume']??1}')??1;
          final duck=t['duckMusic']??true;
          return Card(key:ValueKey(t['id']??i),child:ExpansionTile(
            leading:const Icon(Icons.record_voice_over),
            title:Text('${t['character']??'Speaker'}'),
            subtitle:Text('${t['text']??''} • ${start.toStringAsFixed(1)}s'),
            trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>remove(i)),
            children:[Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Column(children:[
              Text('Start: ${start.toStringAsFixed(1)}s'),
              Slider(min:0,max:120,value:start.clamp(0,120),onChanged:(v)=>update(i,{'start':v})),
              Text('Voice volume: ${(vol*100).round()}%'),
              Slider(min:0,max:2,value:vol.clamp(0,2),onChanged:(v)=>update(i,{'volume':v})),
              SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Duck music under speech'),
                value:duck,onChanged:(v)=>update(i,{'duckMusic':v})),
              if(duck)Text('Music duck level: ${(double.tryParse('${t['duckLevel']??0.25}')! * 100).round()}%'),
            ]))],
          ));
        });
}
