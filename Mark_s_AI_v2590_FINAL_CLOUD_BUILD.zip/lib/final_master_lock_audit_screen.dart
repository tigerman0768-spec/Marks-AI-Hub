import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String auditApi='http://10.0.2.2:3000';
class FinalMasterLockAuditScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterLockAuditScreen({super.key,required this.projectId});
  @override State<FinalMasterLockAuditScreen> createState()=>_FinalMasterLockAuditScreenState();
}
class _FinalMasterLockAuditScreenState extends State<FinalMasterLockAuditScreen>{
  List<dynamic> audit=[];bool busy=false;
  Future<void> load()async{
    final r=await http.get(Uri.parse('$auditApi/api/projects/${widget.projectId}/final-render/lock-audit'));
    if(r.statusCode==200&&mounted)setState(()=>audit=(jsonDecode(r.body)['audit'] as List?)??[]);
  }
  Future<void> addReview()async{
    setState(()=>busy=true);
    await http.post(Uri.parse('$auditApi/api/projects/${widget.projectId}/final-render/lock-audit'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'event':'manual_review','note':'Reviewed in Mark’s AI'}));
    await load();if(mounted)setState(()=>busy=false);
  }
  @override void initState(){super.initState();load();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Master Lock Audit')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      FilledButton.icon(onPressed:busy?null:addReview,icon:const Icon(Icons.fact_check),label:Text(busy?'Saving…':'Record Review')),
      const SizedBox(height:12),
      if(audit.isEmpty) const Card(child:ListTile(title:Text('No audit events yet.'))),
      ...audit.reversed.map((e)=>Card(child:ListTile(
        leading:const Icon(Icons.history),title:Text('${e['event']??'event'}'),
        subtitle:Text('${e['timestamp']??''}\n${e['details']?['note']??''}'))))
    ]));
}
