import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String finalReleaseRecordApi='http://10.0.2.2:3000';

class FinalReleaseRecordScreen extends StatefulWidget{
  final String projectId;
  const FinalReleaseRecordScreen({super.key,required this.projectId});
  @override State<FinalReleaseRecordScreen> createState()=>_FinalReleaseRecordScreenState();
}
class _FinalReleaseRecordScreenState extends State<FinalReleaseRecordScreen>{
  Map<String,dynamic>? release;bool busy=false;
  Future<void> createRelease()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$finalReleaseRecordApi/api/projects/${widget.projectId}/final-render/final-release-record/create'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>release=b['release'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Final release recorded.':'Release blocked.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final ok=release?['status']=='released';
    final blockers=(release?['blockers'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Final Release Record')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ok?Icons.rocket_launch:Icons.gpp_maybe),title:Text(ok?'FILM RELEASED':'RELEASE NOT READY'),
        subtitle:Text(ok?'Release ID: ${release?['releaseRecordId']??''}':'Complete the sealed delivery record first.'))),
      if(release!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${release?['title']??''}'),Text('Size: ${release?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${release?['sha256']??''}'),Text('Sealed record: ${release?['sealedDeliveryRecordId']??''}'),
        if(blockers.isNotEmpty)...[const SizedBox(height:10),const Text('Blockers:'),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:createRelease,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rocket_launch),
        label:Text(busy?'Releasing…':'Create Final Release Record'))
    ]));
  }
}
