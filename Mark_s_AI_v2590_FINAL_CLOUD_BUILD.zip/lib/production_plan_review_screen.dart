import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'video_generation_status_screen.dart';

class ProductionPlanReviewScreen extends StatefulWidget {
  final String projectId;
  const ProductionPlanReviewScreen({super.key, required this.projectId});

  @override
  State<ProductionPlanReviewScreen> createState() => _ProductionPlanReviewScreenState();
}

class _ProductionPlanReviewScreenState extends State<ProductionPlanReviewScreen> {
  static const base = 'http://10.0.2.2:3000';
  bool loading = true;
  String? error;
  Map<String,dynamic> data = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await http.get(Uri.parse('$base/api/projects/${widget.projectId}/production-plan'));
      if (r.statusCode < 300) {
        data = jsonDecode(r.body) as Map<String,dynamic>;
      } else {
        throw Exception('Production plan not found (${r.statusCode})');
      }
    } catch (e) {
      error = e.toString();
    }
    if (mounted) setState(() => loading = false);
  }

  List<dynamic> get characters =>
      ((data['characterBible'] as Map?)?['characters'] as List?) ?? [];
  List<dynamic> get scenes =>
      ((data['storyboard'] as Map?)?['scenes'] as List?) ?? [];
  List<dynamic> get shots => (data['shotCards'] as List?) ?? [];

  Future<void> _startVideoGeneration() async {
    try {
      final ready = await http.get(Uri.parse(
        '$base/api/projects/${widget.projectId}/video-generation/readiness'));
      if (ready.statusCode >= 300) throw Exception('Readiness check failed');
      final info = jsonDecode(ready.body) as Map<String,dynamic>;
      if (info['ready'] != true) throw Exception(info['message'] ?? 'Production plan is not ready');

      final configured = ((info['checks'] as Map?)?['runwayConfigured'] == true);
      final r = await http.post(
        Uri.parse('$base/api/projects/${widget.projectId}/video-generation/orchestrate'),
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({'dryRun': !configured}),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(r.statusCode < 300
          ? (configured ? 'Video generation started' : 'Video generation plan created (dry run)')
          : 'Video generation failed (${r.statusCode})')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Video generation failed: $e')));
      if (r.statusCode < 300 && mounted) {
        Navigator.push(context, MaterialPageRoute(builder: (_) => VideoGenerationStatusScreen(projectId: widget.projectId)));
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Production Plan')),
        body: Center(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(error!, textAlign: TextAlign.center),
        )),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Production Plan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(data['title']?.toString() ?? 'Untitled Film',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 6),
          Text('Review the production plan before video generation.'),
          const SizedBox(height: 20),
          _section('Characters', characters.length, Icons.people, [
            ...characters.map((c) => Card(
              child: ListTile(
                leading: const Icon(Icons.person),
                title: Text('${c['name'] ?? 'Character'}'),
                subtitle: Text(
                  '${c['role'] ?? ''}\nGoal: ${c['goal'] ?? c['motivation'] ?? 'TBD'}',
                ),
                isThreeLine: true,
              ),
            ))
          ]),
          _section('Scenes', scenes.length, Icons.movie, [
            ...scenes.map((s) => Card(
              child: ExpansionTile(
                title: Text('Scene ${s['number'] ?? ''}: ${s['title'] ?? 'Untitled'}'),
                subtitle: Text('${s['location'] ?? 'TBD'} • ${s['time'] ?? 'TBD'}'),
                children: [
                  ListTile(
                    title: const Text('Action'),
                    subtitle: Text('${s['action'] ?? 'TBD'}'),
                  ),
                  ListTile(
                    title: const Text('Characters'),
                    subtitle: Text(((s['characters'] as List?) ?? []).join(', ')),
                  ),
                ],
              ),
            ))
          ]),
          _section('Shot Cards', shots.length, Icons.camera_alt, [
            ...shots.map((s) => Card(
              child: ListTile(
                leading: const Icon(Icons.videocam),
                title: Text('Shot ${s['shotNumber'] ?? ''} • ${s['shotType'] ?? 'Shot'}'),
                subtitle: Text(
                  '${s['sceneTitle'] ?? ''}\n${s['cameraMovement'] ?? ''}\n${s['prompt'] ?? ''}',
                ),
                isThreeLine: true,
              ),
            ))
          ]),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _startVideoGeneration,
            icon: const Icon(Icons.video_settings),
            label: const Text('START VIDEO GENERATION'),
          ),
          const SizedBox(height: 8),
          const Text(
            'Video generation will be enabled after the production-plan review and provider workflow are fully connected.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _section(String title, int count, IconData icon, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Icon(icon),
          const SizedBox(width: 8),
          Text('$title ($count)',
              style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 8),
        ...children,
        const SizedBox(height: 18),
      ],
    );
  }
}
