import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoGenerationScreen extends StatefulWidget{
  final String projectId;
  const VideoGenerationScreen({super.key,required this.projectId});
  @override State<VideoGenerationScreen> createState()=>_VideoGenerationScreenState();
}
class _VideoGenerationScreenState extends State<VideoGenerationScreen>{
  static const base='http://10.0.2.2:3000';
  String? runId; Map<String,dynamic>? run; bool starting=false; Timer? timer;
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> start() async{
    setState(()=>starting=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/video-generation'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode>=300)throw Exception(r.body);
      final d=jsonDecode(r.body) as Map<String,dynamic>;
      runId=d['id']?.toString(); run=d;
      _poll();
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not start generation: $e')));
    }
    if(mounted)setState(()=>starting=false);
  }
  void _poll(){
    timer?.cancel();
    timer=Timer.periodic(const Duration(seconds:2),(_)=>load());
    load();
  }
  Future<void> load() async{
    if(runId==null)return;
    try{
      final r=await http.get(Uri.parse('$base/api/video-generation/$runId'));
      if(r.statusCode==200&&mounted)setState(()=>run=jsonDecode(r.body) as Map<String,dynamic>);
    }catch(_){}
  }
  @override Widget build(BuildContext context){
    final r=run; final total=(r?['total']??0) as num; final done=(r?['completed']??0) as num;
    return Scaffold(appBar:AppBar(title:const Text('AI Video Generation')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Generate Video Clips',style:Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height:8),
      const Text('Create one video-generation job for every planned shot. The provider runs asynchronously so progress can be tracked.'),
      const SizedBox(height:18),
      FilledButton.icon(onPressed:starting||runId!=null?null:start,icon:starting?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.movie_creation),
        label:Text(starting?'STARTING…':'GENERATE VIDEO CLIPS')),
      if(r!=null)...[
        const SizedBox(height:20),Text('Status: ${r['status']??'queued'}'),
        Text('Shots: ${done.toInt()} / ${total.toInt()}'),
        const SizedBox(height:8),LinearProgressIndicator(value:total>0?done/total:0),
        const SizedBox(height:16),
        ...(r['jobs'] as List? ?? []).map((j)=>ListTile(
          leading:Icon(j['status']=='completed'?Icons.check_circle:j['status']=='failed'?Icons.error_outline:Icons.hourglass_empty),
          title:Text('Shot ${j['shotNumber']??''}'),
          subtitle:Text(j['status']?.toString()??'queued'),
        )),
      ]
    ]));
  }
}
