import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String deliveryLockApi='http://10.0.2.2:3000';

class ReleasedFilmDeliveryLockScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliveryLockScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliveryLockScreen> createState()=>_ReleasedFilmDeliveryLockScreenState();
}
class _ReleasedFilmDeliveryLockScreenState extends State<ReleasedFilmDeliveryLockScreen>{
  Map<String,dynamic>? lock;bool busy=false;
  Future<void> createLock()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$deliveryLockApi/api/projects/${widget.projectId}/final-render/release-delivery-lock/create'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>lock=b['lock'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery locked.':'Lock blocked.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final locked=lock?['status']=='locked';
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Lock')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(locked?Icons.lock:Icons.lock_open),title:Text(locked?'DELIVERY LOCKED':'DELIVERY NOT LOCKED'),
        subtitle:Text(locked?'Lock ID: ${lock?['lockId']??''}':'Pass the final delivery gate first.'))),
      if(locked)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${lock?['title']??''}'),Text('Size: ${lock?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${lock?['sha256']??''}'),Text('Locked: ${lock?['lockedAt']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:createLock,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.lock),
        label:Text(busy?'Locking…':'Lock Final Delivery'))
    ]));
  }
}
