import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String aiDirectorApi = 'http://10.0.2.2:3000';

class AiDirectorScreen extends StatefulWidget {
  final String projectId;
  const AiDirectorScreen({super.key, required this.projectId});

  @override
  State<AiDirectorScreen> createState() => _AiDirectorScreenState();
}

class _AiDirectorScreenState extends State<AiDirectorScreen> {
  Map<String, dynamic>? readiness;
  bool loading = true;
  bool building = false;
  String? message;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; message = null; });
    try {
      final r = await http.get(Uri.parse(
        '$aiDirectorApi/api/projects/${widget.projectId}/ai-readiness',
      ));
      if (r.statusCode != 200) throw Exception('Server returned ${r.statusCode}');
      setState(() {
        readiness = jsonDecode(r.body) as Map<String, dynamic>;
        loading = false;
      });
    } catch (e) {
      setState(() { loading = false; message = e.toString(); });
    }
  }

  Future<void> buildPromptPack() async {
    setState(() { building = true; message = null; });
    try {
      final r = await http.post(Uri.parse(
        '$aiDirectorApi/api/projects/${widget.projectId}/ai-prompt-pack',
      ));
      if (r.statusCode != 200) throw Exception('Server returned ${r.statusCode}');
      final body = jsonDecode(r.body) as Map<String, dynamic>;
      setState(() {
        message = 'Prompt pack created: ${body['shotCount']} shots, '
            '${body['characterCount']} character references.';
        building = false;
      });
      await load();
    } catch (e) {
      setState(() { building = false; message = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final checks = Map<String, dynamic>.from(readiness?['checks'] ?? {});
    final missing = List<String>.from(readiness?['missing'] ?? const []);

    return Scaffold(
      appBar: AppBar(title: const Text('AI Director')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            leading: Icon(readiness?['readyForTextAI'] == true
                ? Icons.check_circle : Icons.warning),
            title: const Text('Story AI readiness'),
            subtitle: Text(readiness?['readyForTextAI'] == true
                ? 'Story data is available.'
                : 'Add an idea or screenplay first.'),
          )),
          Card(child: ListTile(
            leading: Icon(readiness?['readyForVideoProvider'] == true
                ? Icons.check_circle : Icons.info_outline),
            title: const Text('Video provider readiness'),
            subtitle: Text(readiness?['readyForVideoProvider'] == true
                ? 'All tracked requirements are present.'
                : 'Video provider configuration and/or production data is missing.'),
          )),
          const SizedBox(height: 12),
          const Text('Project AI inputs',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          ...checks.entries.map((e) => ListTile(
            dense: true,
            leading: Icon(e.value == true
                ? Icons.check_circle : Icons.radio_button_unchecked),
            title: Text(_pretty(e.key)),
          )),
          if (missing.isNotEmpty)
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text('Missing: ${missing.map(_pretty).join(', ')}'),
            )),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: building ? null : buildPromptPack,
            icon: building
                ? const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.auto_awesome),
            label: Text(building ? 'Building…' : 'Build AI Director Prompt Pack'),
          ),
          if (message != null) ...[
            const SizedBox(height: 12),
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(message!),
            )),
          ],
          const SizedBox(height: 12),
          const Text(
            'The prompt pack is provider-neutral: it prepares consistent shot and character instructions without pretending that a video provider has already generated anything.',
          ),
        ],
      ),
    );
  }

  String _pretty(String value) {
    if (value.isEmpty) return value;
    return value[0].toUpperCase() + value.substring(1);
  }
}
