import 'package:flutter/material.dart';
import 'ai_edit_review_screen.dart';
import 'production_plan_review_screen.dart';
import 'clip_review_screen.dart';
import 'final_cut_review_screen.dart';
import 'final_audio_screen.dart';
import 'final_finishing_screen.dart';
import 'production_health_screen.dart';
import 'production_summary_card.dart';
import 'project_settings_screen.dart';
import 'project_backup_screen.dart';
import 'project_validation_screen.dart';
import 'project_archive_screen.dart';
import 'project_lifecycle_screen.dart';
import 'project_resume_screen.dart';
import 'project_recovery_screen.dart';
import 'project_activity_screen.dart';
import 'project_health_screen.dart';
import 'project_readiness_screen.dart';
import 'project_dashboard_screen.dart';
import 'server_connection_screen.dart';
import 'app_config_screen.dart';
import 'project_search_screen.dart';
import 'project_stats_screen.dart';
import 'project_notes_screen.dart';
import 'project_tags_screen.dart';
import 'project_sort_screen.dart';
import 'favourite_films_screen.dart';
import 'recent_films_screen.dart';
import 'project_filter_screen.dart';
import 'film_export_screen.dart';

class ProductionWorkflowScreen extends StatelessWidget{
  final String projectId;
  const ProductionWorkflowScreen({super.key,required this.projectId});
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('Production Workflow')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text('Film Production',style:Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height:6),
        const Text('Move through the production stages in order.'),
        const SizedBox(height:22),        ProductionSummaryCard(projectId:projectId),
        const SizedBox(height:10),
        _tile(context,Icons.health_and_safety,'Production Health','See what is ready and what needs attention',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProductionHealthScreen(projectId:projectId)))),
        _tile(context,Icons.rate_review,'1. Review Clips','Accept, reject or regenerate generated footage',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ClipReviewScreen(projectId:projectId)))),
        _tile(context,Icons.auto_awesome_motion,'2. AI Edit','Review and apply the automatic edit',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AiEditReviewScreen(projectId:projectId)))),
        _tile(context,Icons.movie_filter,'3. Production Plan','Review the story, characters and shot plan',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProductionPlanReviewScreen(projectId:projectId)))),
        _tile(context,Icons.movie_creation,'4. Final Cut','Review the assembled footage before final rendering',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FinalCutReviewScreen(projectId:projectId)))),
        _tile(context,Icons.audiotrack,'5. Audio & Subtitles','Prepare dialogue, music, effects and subtitles',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FinalAudioScreen(projectId:projectId)))),
        _tile(context,Icons.tune,'6. Final Finishing','Prepare the final master and finishing stages',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FinalFinishingScreen(projectId:projectId)))),
        _tile(context,Icons.file_download,'7. Export','Check the final MP4 export details',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FilmExportScreen(projectId:projectId)))),
        _tile(context,Icons.settings,'Project Settings','Review the film format and production choices',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectSettingsScreen(projectId:projectId)))),
        _tile(context,Icons.backup,'Project Backup','Save a local backup of the complete project state',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectBackupScreen(projectId:projectId)))),
        _tile(context,Icons.fact_check,'Project Check','Validate the project before production',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectValidationScreen(projectId:projectId)))),
        _tile(context,Icons.archive,'Project Archive','Archive the current project state',
          ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectArchiveScreen(projectId:projectId)))),
        _tile(context,Icons.timeline,'Project Lifecycle','Set the current production state',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectLifecycleScreen(projectId:projectId)))),
        _tile(context,Icons.play_circle_outline,'Resume Film','Continue from the latest saved production stage',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectResumeScreen(projectId:projectId)))),
        _tile(context,Icons.restore,'Project Recovery','Restore a backup or archive',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectRecoveryScreen(projectId:projectId)))),
        _tile(context,Icons.history,'Project Activity','View the production timeline and saved milestones',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectActivityScreen(projectId:projectId)))),
        _tile(context,Icons.health_and_safety,'Project Health','Check production completeness and readiness',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectHealthScreen(projectId:projectId)))),
        _tile(context,Icons.rule,'Production Readiness','Check whether all major production gates are ready',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectReadinessScreen(projectId:projectId)))),
        _tile(context,Icons.video_library,'Film Projects','View all saved film projects',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProjectDashboardScreen()))),
        _tile(context,Icons.cloud,'Server Connection','Check the Mark’s AI backend connection',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ServerConnectionScreen()))),
        _tile(context,Icons.settings_applications,'App Configuration','View backend capabilities and API configuration',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AppConfigScreen()))),
        _tile(context,Icons.search,'Find a Film','Search saved projects by title, genre or status',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProjectSearchScreen()))),
        _tile(context,Icons.analytics,'Film Statistics','View project counts and production state',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectStatsScreen(projectId:projectId)))),
        _tile(context,Icons.notes,'Production Notes','Keep notes while developing and reviewing the film',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectNotesScreen(projectId:projectId)))),
        _tile(context,Icons.label,'Film Tags','Organise this film with searchable tags',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProjectTagsScreen(projectId:projectId)))),
        _tile(context,Icons.sort,'Sort Films','Sort saved films by update time, title or length',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProjectSortScreen()))),
        _tile(context,Icons.star,'Favourite Films','Open all films you have marked as favourites',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FavouriteFilmsScreen()))),
        _tile(context,Icons.update,'Recent Films','Open the films you worked on most recently',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RecentFilmsScreen()))),
        _tile(context,Icons.filter_list,'Filter Films','Filter saved films by production status',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProjectFilterScreen()))),
        const SizedBox(height:20),
        const Card(child:Padding(padding:EdgeInsets.all(14),
          child:Text('Final rendering, audio, subtitles and film-library delivery remain downstream stages of the production pipeline.'))),
      ]));
  }
  Widget _tile(BuildContext c,IconData icon,String title,String subtitle,VoidCallback onTap){
    return Card(child:ListTile(leading:Icon(icon),title:Text(title),subtitle:Text(subtitle),
      trailing:const Icon(Icons.chevron_right),onTap:onTap));
  }
}
