import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TimelineAudioEditorScreen extends StatefulWidget{
  final String projectId;
  const TimelineAudioEditorScreen({super.key,required this.projectId});
  @override State<TimelineAudioEditorScreen> createState()=>_TimelineAudioEditorScreenState();
}
class _TimelineAudioEditorScreenState extends State<TimelineAudioEditorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> tracks=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/timeline/audio'));
      if(r.statusCode==200)tracks=(jsonDecode(r.body)['tracks'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> updateTrack(int index,Map<String,dynamic> patch) async{
    final merged={...tracks[index],...patch};
    final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/audio'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'action':'update','index':index,'track':merged}));
    if(r.statusCode<300)await load();
  }
  Future<void> removeTrack(int index) async{
    final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/audio'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'action':'remove','index':index}));
    if(r.statusCode<300)await load();
  }
  Future<void> addTrack() async{
    final path=TextEditingController();
    final name=TextEditingController(text:'New Audio');
    final result=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:const Text('Add audio track'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:const InputDecoration(labelText:'Name')),
        TextField(controller:path,decoration:const InputDecoration(labelText:'Server audio file path')),
      ]),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('CANCEL')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('ADD')),
      ],
    ));
    if(result==true&&path.text.trim().isNotEmpty){
      await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/audio'),
        headers:{'Content-Type':'application/json'},
        body:jsonEncode({'action':'add','track':{'name':name.text,'path':path.text,'type':'music','start':0,'volume':0.35,'fadeIn':0,'fadeOut':0}}));
      await load();
    }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Timeline Audio')),
    floatingActionButton:FloatingActionButton.extended(onPressed:addTrack,icon:const Icon(Icons.add),label:const Text('ADD TRACK')),
    body:loading?const Center(child:CircularProgressIndicator()):
      tracks.isEmpty?const Center(child:Text('No audio tracks. Add music or SFX.')):
      ReorderableListView.builder(
        padding:const EdgeInsets.all(12),itemCount:tracks.length,
        onReorder:(a,b)async{
          if(b>a)b--;
          final r=await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/timeline/audio'),
            headers:{'Content-Type':'application/json'},body:jsonEncode({'action':'reorder','from':a,'to':b}));
          if(r.statusCode<300)await load();
        },
        itemBuilder:(context,i){
          final t=tracks[i];
          final volume=(double.tryParse('${t['volume']??0.35}')??0.35);
          final start=(double.tryParse('${t['start']??0}')??0);
          final fadeIn=(double.tryParse('${t['fadeIn']??0}')??0);
          final fadeOut=(double.tryParse('${t['fadeOut']??0}')??0);
          return Card(key:ValueKey(t['id']??i),child:ExpansionTile(
            leading:Icon(t['type']=='sfx'?Icons.graphic_eq:Icons.music_note),
            title:Text(t['name']??'Audio'),
            subtitle:Text('${t['type']??'music'} • starts ${start.toStringAsFixed(1)}s'),
            trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>removeTrack(i)),
            children:[Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Column(children:[
              Text('Start: ${start.toStringAsFixed(1)}s'),
              Slider(min:0,max:120,value:start.clamp(0,120),onChanged:(v)=>updateTrack(i,{'start':v})),
              Text('Volume: ${(volume*100).round()}%'),
              Slider(min:0,max:2,value:volume.clamp(0,2),onChanged:(v)=>updateTrack(i,{'volume':v})),
              Text('Fade in: ${fadeIn.toStringAsFixed(1)}s'),
              Slider(min:0,max:10,value:fadeIn.clamp(0,10),onChanged:(v)=>updateTrack(i,{'fadeIn':v})),
              Text('Fade out: ${fadeOut.toStringAsFixed(1)}s'),
              Slider(min:0,max:10,value:fadeOut.clamp(0,10),onChanged:(v)=>updateTrack(i,{'fadeOut':v})),
            ]))],
          ));
        },
      ),
  );
}
