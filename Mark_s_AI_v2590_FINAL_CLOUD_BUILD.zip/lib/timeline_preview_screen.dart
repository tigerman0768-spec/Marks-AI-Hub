import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class TimelinePreviewScreen extends StatefulWidget{
  final String projectId;
  const TimelinePreviewScreen({super.key,required this.projectId});
  @override State<TimelinePreviewScreen> createState()=>_TimelinePreviewScreenState();
}
class _TimelinePreviewScreenState extends State<TimelinePreviewScreen>{
  static const base='http://10.0.2.2:3000';
  VideoPlayerController? controller; bool loading=true; String? error; double clipVolume=1.0,musicVolume=0.35; bool musicEnabled=false;
  @override void initState(){super.initState();render();}
  Future<void> render() async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/timeline/preview'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'audioSettings':{'clipVolume':clipVolume,'musicVolume':musicVolume}}));
      if(r.statusCode>=300)throw Exception(r.body);
      final c=VideoPlayerController.networkUrl(Uri.parse('$base/api/projects/${widget.projectId}/timeline/preview.mp4'));
      await c.initialize(); await c.play();
      if(mounted)setState(()=>controller=c);
      else await c.dispose();
    }catch(e){if(mounted)setState(()=>error=e.toString());}
    if(mounted)setState(()=>loading=false);
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Timeline Preview')),
    body:loading?const Center(child:CircularProgressIndicator()):
      error!=null?Center(child:Padding(padding:const EdgeInsets.all(20),child:Text(error!))):
      controller==null?const Center(child:Text('No preview available.')):
      Column(children:[
        Padding(
          padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
          child:Row(children:[
            const Text('Clip volume'),
            Expanded(child:Slider(min:0,max:2,value:clipVolume,onChanged:(v){setState(()=>clipVolume=v);})),
            Text('${(clipVolume*100).round()}%'),
          ]),
        ),
        const SizedBox(height:8),
        AspectRatio(aspectRatio:controller!.value.aspectRatio,child:VideoPlayer(controller!)),
        VideoProgressIndicator(controller!,allowScrubbing:true),
        Row(mainAxisAlignment:MainAxisAlignment.center,children:[
          IconButton(icon:Icon(controller!.value.isPlaying?Icons.pause:Icons.play_arrow),
            onPressed:()=>setState(()=>controller!.value.isPlaying?controller!.pause():controller!.play())),
          IconButton(icon:const Icon(Icons.refresh),onPressed:render),
        ]),
      ]),
  );
}
