import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String deliveryGateApi='http://10.0.2.2:3000';

class ReleasedFilmDeliveryGateScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliveryGateScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliveryGateScreen> createState()=>_ReleasedFilmDeliveryGateScreenState();
}
class _ReleasedFilmDeliveryGateScreenState extends State<ReleasedFilmDeliveryGateScreen>{
  Map<String,dynamic>? gate;bool busy=false;
  Future<void> check()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$deliveryGateApi/api/projects/${widget.projectId}/final-render/release-delivery-gate/check'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>gate=b['gate'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Release delivery is ready.':'Release delivery has blockers.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final ready=gate?['ready']==true;
    final blockers=(gate?['blockers'] as List<dynamic>? ?? []);
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Gate')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.verified:Icons.gpp_maybe),title:Text(ready?'DELIVERY READY':'DELIVERY BLOCKED'),
        subtitle:Text(gate==null?'Run the final delivery checks.':'Checked: ${gate?['checkedAt']??''}'))),
      if(gate!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${gate?['title']??''}'),Text('Size: ${gate?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${gate?['sha256']??''}'),
        if(blockers.isNotEmpty)...[const SizedBox(height:10),const Text('Blockers:'),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:check,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.fact_check),label:Text(busy?'Checking…':'Run Final Delivery Check'))
    ]));
  }
}
