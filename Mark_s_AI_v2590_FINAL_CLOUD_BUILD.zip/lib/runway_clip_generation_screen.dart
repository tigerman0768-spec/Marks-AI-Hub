import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const String runwayClipApi='http://10.0.2.2:3000';

class RunwayClipGenerationScreen extends StatefulWidget{
  final String projectId;
  const RunwayClipGenerationScreen({super.key,required this.projectId});
  @override State<RunwayClipGenerationScreen> createState()=>_RunwayClipGenerationScreenState();
}
class _RunwayClipGenerationScreenState extends State<RunwayClipGenerationScreen>{
  final prompt=TextEditingController();
  String taskId=''; String status='Ready'; String? clipUrl; bool busy=false; Timer? timer; VideoPlayerController? player;
  Future<void> submit()async{
    if(prompt.text.trim().isEmpty){setState(()=>status='Enter a video prompt.');return;}
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$runwayClipApi/api/projects/${widget.projectId}/clips/provider/runway'),
        headers:{'Content-Type':'application/json'},
        body:jsonEncode({'prompt':prompt.text.trim(),'duration':5,'aspectRatio':'16:9','model':'gen4.5'}));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      if(r.statusCode==202){
        setState((){taskId='${b['taskId']??''}';status='Generating…';});
        timer?.cancel(); timer=Timer.periodic(const Duration(seconds:6),(_)=>check());
      }else setState(()=>status='Provider error: ${b['error']??(b['blockers']??['Unknown']).join(', ')}');
    }catch(e){if(mounted)setState(()=>status='Connection error: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> check()async{
    if(taskId.isEmpty)return;
    try{
      final r=await http.get(Uri.parse('$runwayClipApi/api/projects/${widget.projectId}/clips/provider/runway/$taskId'));
      if(!mounted)return;
      final b=jsonDecode(r.body); final t=b['task'] as Map<String,dynamic>? ?? {};
      final s='${t['status']??'unknown'}';
      if(s=='SUCCEEDED'&&b['localClip']!=null){
        timer?.cancel(); setState(()=>status='Clip downloaded and ready.');
        // Local Android access requires the server to expose the file; the backend
        // record is authoritative and the existing film-library media bridge can be used next.
      }else if(s=='FAILED'||s=='CANCELED'){
        timer?.cancel(); setState(()=>status='Generation $s: ${t['failureCode']??''}');
      }else setState(()=>status='Runway status: $s');
    }catch(e){if(mounted)setState(()=>status='Status check error: $e');}
  }
  @override void dispose(){timer?.cancel();player?.dispose();prompt.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Runway Clip Generator')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      TextField(controller:prompt,maxLines:6,decoration:const InputDecoration(labelText:'Video prompt',hintText:'A cinematic shot of...',border:OutlineInputBorder())),
      const SizedBox(height:16),
      FilledButton.icon(onPressed:busy?null:submit,icon:const Icon(Icons.movie),label:Text(busy?'Submitting…':'Generate 5s Clip')),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:taskId.isEmpty?null:check,icon:const Icon(Icons.refresh),label:const Text('Check Generation Status')),
      const SizedBox(height:16),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:SelectableText(status))),
    ]));
}
