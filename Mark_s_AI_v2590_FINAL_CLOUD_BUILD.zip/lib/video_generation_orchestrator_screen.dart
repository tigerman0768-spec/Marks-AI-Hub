import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VideoGenerationOrchestratorScreen extends StatefulWidget{
  final String projectId;
  const VideoGenerationOrchestratorScreen({super.key,required this.projectId});
  @override State<VideoGenerationOrchestratorScreen> createState()=>_VideoGenerationOrchestratorScreenState();
}
class _VideoGenerationOrchestratorScreenState extends State<VideoGenerationOrchestratorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? run; String message='';
  Future<void> start({bool dryRun=false})async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/video-generation/orchestrate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'dryRun':dryRun}));
      final data=jsonDecode(r.body);
      if(data is Map) setState(()=>run=data['run']);
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text(r.statusCode<300?'Video generation run created.':data['error']?.toString()??r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Video Generation Orchestrator')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.movie_creation,size:72),
      const SizedBox(height:12),
      const Text('Send directed shots into the video-generation pipeline.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('The orchestrator combines the saved shot prompts with the existing provider runner and Runway adapter.'),
      const SizedBox(height:20),
      OutlinedButton.icon(onPressed:loading?null:()=>start(dryRun:true),
        icon:const Icon(Icons.preview),label:const Text('PREVIEW GENERATION JOBS')),
      const SizedBox(height:10),
      FilledButton.icon(onPressed:loading?null:start,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.play_arrow),
        label:Text(loading?'STARTING...':'START AI VIDEO GENERATION')),
      if(run!=null)...[
        const SizedBox(height:20),
        Card(child:ListTile(
          title:Text('Status: ${run!['status']??'unknown'}'),
          subtitle:Text('${run!['total']??0} jobs • ${run!['completed']??0} completed • ${run!['failed']??0} failed'),
        )),
        ...((run!['jobs'] as List?)??[]).map((j){
          final m=Map<String,dynamic>.from(j);
          return ListTile(
            leading:Icon(m['status']=='completed'?Icons.check_circle:Icons.movie),
            title:Text('Scene ${m['sceneId']??''} • Shot ${m['shotNumber']??''}'),
            subtitle:Text('${m['status']??''}\n${m['prompt']??''}',maxLines:3,overflow:TextOverflow.ellipsis),
            isThreeLine:true,
          );
        })
      ]
    ]),
  );
}
