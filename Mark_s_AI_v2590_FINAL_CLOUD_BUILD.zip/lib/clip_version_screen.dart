import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ClipVersionScreen extends StatefulWidget{
  final String projectId;
  const ClipVersionScreen({super.key,required this.projectId});
  @override State<ClipVersionScreen> createState()=>_ClipVersionScreenState();
}
class _ClipVersionScreenState extends State<ClipVersionScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<dynamic> groups=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/versions'));
      if(r.statusCode<300)setState(()=>groups=(jsonDecode(r.body)['groups'] as List));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Clip Versions'),actions:[
      IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):
      groups.isEmpty?const Center(child:Text('No clip versions recorded yet.')):
      ListView.builder(padding:const EdgeInsets.all(12),itemCount:groups.length,
        itemBuilder:(context,i){
          final versions=(groups[i] as List).cast<dynamic>();
          final shot=versions.first['shotKey']??'Shot';
          return Card(child:ExpansionTile(
            title:Text(shot.toString()),
            subtitle:Text('${versions.length} version(s)'),
            children:versions.map((v){
              final m=Map<String,dynamic>.from(v as Map);
              final score=m['smartReview']?['score'];
              return ListTile(
                leading:CircleAvatar(child:Text('v${m['version']}')),
                title:Text('Version ${m['version']}'),
                subtitle:Text('Quality: ${m['qualityStatus']??'unknown'}${score!=null?' • Score $score':''}'),
                trailing:m['smartReview']?['decision']=='recommended'
                  ?const Icon(Icons.star):const Icon(Icons.video_library),
              );
            }).toList(),
          ));
        })
  );
}
