import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'release_package_viewer_screen.dart';

class ReleasePackageDashboardScreen extends StatefulWidget {
  final String projectId;
  final String apiBase;
  const ReleasePackageDashboardScreen({super.key,required this.projectId,this.apiBase='http://10.0.2.2:3000'});
  @override State<ReleasePackageDashboardScreen> createState()=>_ReleasePackageDashboardScreenState();
}
class _ReleasePackageDashboardScreenState extends State<ReleasePackageDashboardScreen>{
  Map<String,dynamic>? data; bool loading=true;
  Future<void> load() async {
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('${widget.apiBase}/api/projects/${widget.projectId}/final-render/release-package-dashboard'));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      setState(()=>data=r.statusCode==200?Map<String,dynamic>.from(b):{'error':b['error']??'Unable to load'});
    }catch(_){if(mounted)setState(()=>data={'error':'Release package dashboard unavailable'});}
    if(mounted)setState(()=>loading=false);
  }
  @override void initState(){super.initState();load();}
  Widget row(String label,String value,{bool good=false})=>ListTile(dense:true,contentPadding=EdgeInsets.zero,title:Text(label),trailing:Row(mainAxisSize:MainAxisSize.min,children:[if(good) const Icon(Icons.check_circle,size:18),const SizedBox(width:6),SizedBox(width:150,child:Text(value,textAlign:TextAlign.right,overflow:TextOverflow.ellipsis))]));
  @override Widget build(BuildContext context){
    final d=data;
    return Scaffold(appBar:AppBar(title:const Text('Release Package Dashboard'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):d==null?const SizedBox():d['error']!=null?Center(child:Text(d['error'])):ListView(padding:const EdgeInsets.all(16),children:[
      SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>ReleasePackageViewerScreen(projectId:widget.projectId,apiBase:widget.apiBase,data:d))),icon:const Icon(Icons.movie),label:const Text('Open Final Release Viewer'))),
      const SizedBox(height:12),
      Text(d['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Final release',style:Theme.of(context).textTheme.titleLarge),row('Status','${d['finalRelease']?['status']??'unknown'}',good:d['finalRelease']?['status']=='released'),row('Release record','${d['finalRelease']?['releaseRecordId']??'—'}')]))),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Film file',style:Theme.of(context).textTheme.titleLarge),row('File','${d['film']?['file']?['name']??'Missing'}',good:d['film']?['file']?['exists']==true),row('Size','${d['film']?['file']?['bytes']??'—'} bytes'),row('SHA-256','${d['film']?['file']?['sha256']??'—'}')]))),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Release documents',style:Theme.of(context).textTheme.titleLarge),row('Certificate','${d['certificate']?['id']??'Not issued'}',good:d['certificate']?['issued']==true),row('Manifest','${d['manifest']?['path']??'Not saved'}',good:d['manifest']?['saved']==true)]))),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Verification',style:Theme.of(context).textTheme.titleLarge),row('Final film present',d['verification']?['filePresent']==true?'PASS':'FAIL',good:d['verification']?['filePresent']==true),row('Hash matches',d['verification']?['hashMatches']==true?'PASS':'FAIL',good:d['verification']?['hashMatches']==true),row('Size matches',d['verification']?['sizeMatches']==true?'PASS':'FAIL',good:d['verification']?['sizeMatches']==true),row('Certificate',d['verification']?['certificate']==true?'PASS':'FAIL',good:d['verification']?['certificate']==true),row('Manifest',d['verification']?['manifest']==true?'PASS':'FAIL',good:d['verification']?['manifest']==true),const SizedBox(height:8),Container(width:double.infinity,padding:const EdgeInsets.all(12),decoration:BoxDecoration(borderRadius:BorderRadius.circular(10),color:d['verification']?['verified']==true?Theme.of(context).colorScheme.primaryContainer:Theme.of(context).colorScheme.errorContainer),child:Text(d['verification']?['verified']==true?'RELEASE PACKAGE VERIFIED':'RELEASE PACKAGE NEEDS ATTENTION',style:const TextStyle(fontWeight:FontWeight.bold)))]))),
      if((d['blockers'] as List?)?.isNotEmpty==true) Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Blockers',style:Theme.of(context).textTheme.titleLarge),for(final b in (d['blockers'] as List)) ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.warning),title:Text('$b'))]))),
    ]);
  }
}
