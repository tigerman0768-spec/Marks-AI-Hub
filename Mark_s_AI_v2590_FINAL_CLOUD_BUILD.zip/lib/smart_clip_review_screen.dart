import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SmartClipReviewScreen extends StatefulWidget{
  final String projectId;
  const SmartClipReviewScreen({super.key,required this.projectId});
  @override State<SmartClipReviewScreen> createState()=>_SmartClipReviewScreenState();
}
class _SmartClipReviewScreenState extends State<SmartClipReviewScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<dynamic> results=[];
  @override void initState(){super.initState();check();}
  Future<void> regenerate()async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/clips/auto-regenerate'));
      if(r.statusCode<300 && mounted){
        final n=jsonDecode(r.body)['queuedCount']??0;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$n clip(s) queued for regeneration')));
        check();
      }
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
  }
  Future<void> runQueue()async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/clips/regeneration/run'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300 && mounted){
        final body=jsonDecode(r.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Regeneration: ${body['status']}')));
        check();
      } else if(mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
      }
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
  }
  Future<void> check()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/clips/smart-review'));
      if(r.statusCode<300)setState(()=>results=(jsonDecode(r.body)['results'] as List));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Smart Clip Review'),actions:[
      IconButton(onPressed:loading?null:check,icon:const Icon(Icons.refresh))
    ]),
    body:loading?const Center(child:CircularProgressIndicator()):results.isEmpty
      ?const Center(child:Text('No downloaded clips to review.'))
      :Column(children:[
          Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
            child:FilledButton.icon(onPressed:runQueue,icon:const Icon(Icons.play_arrow),
              label:const Text('RUN REGENERATION QUEUE')))),
          Expanded(child:ListView.builder(
        padding:const EdgeInsets.all(12),itemCount:results.length,
        itemBuilder:(context,i){
          final m=Map<String,dynamic>.from(results[i] as Map);
          final score=(m['score']??0).toString();
          final decision=(m['decision']??'review').toString();
          final regenerate=decision=='regenerate';
          return Card(child:ListTile(
            leading:CircleAvatar(child:Text(score)),
            title:Text('Shot ${m['shotNumber']??''}'),
            subtitle:Text('${decision.toUpperCase()}${(m['issues'] as List?)?.isNotEmpty==true?'\n${(m['issues'] as List).join(', ')}':''}'),
            trailing:regenerate?const Icon(Icons.refresh):const Icon(Icons.check_circle),
            isThreeLine:(m['issues'] as List?)?.isNotEmpty==true,
          ));
        }))
  );
}
