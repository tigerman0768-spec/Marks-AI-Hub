import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class ProjectValidationScreen extends StatefulWidget{
  final String projectId; const ProjectValidationScreen({super.key,required this.projectId});
  @override State<ProjectValidationScreen> createState()=>_ProjectValidationScreenState();
}
class _ProjectValidationScreenState extends State<ProjectValidationScreen>{
  static const base='http://10.0.2.2:3000'; bool loading=true; Map<String,dynamic> d={};
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{try{final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/validate'));
    if(r.statusCode==200)d=jsonDecode(r.body);}catch(_){}if(mounted)setState(()=>loading=false);}
  @override Widget build(BuildContext c){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final valid=d['valid']==true; final issues=(d['issues'] as List?)??[];
    return Scaffold(appBar:AppBar(title:const Text('Project Check')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Project Check',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:16),
      Card(child:ListTile(leading:Icon(valid?Icons.verified:Icons.warning),
        title:Text(valid?'Project is valid':'Project needs attention'),
        subtitle:Text(valid?'Core production information is present.':'Missing: ${issues.join(', ')}'))),
      const SizedBox(height:12),FilledButton.icon(onPressed:_load,icon:const Icon(Icons.refresh),label:const Text('RUN CHECK AGAIN'))
    ]));}
}
