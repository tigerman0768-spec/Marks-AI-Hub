import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String finalCutApi='http://10.0.2.2:3000';

class FinalCutPreparationScreen extends StatefulWidget{
  final String projectId;
  const FinalCutPreparationScreen({super.key,required this.projectId});
  @override State<FinalCutPreparationScreen> createState()=>_FinalCutPreparationScreenState();
}
class _FinalCutPreparationScreenState extends State<FinalCutPreparationScreen>{
  Map<String,dynamic> readiness={}; Map<String,dynamic>? plan; bool loading=true,preparing=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final a=await http.get(Uri.parse('$finalCutApi/api/projects/${widget.projectId}/final-cut/readiness'));
    final b=await http.get(Uri.parse('$finalCutApi/api/projects/${widget.projectId}/final-cut/plan'));
    if(mounted)setState((){
      if(a.statusCode==200)readiness=jsonDecode(a.body);
      if(b.statusCode==200)plan=jsonDecode(b.body)['plan'];
      loading=false;
    });
  }
  Future<void> prepare()async{
    setState(()=>preparing=true);
    final r=await http.post(Uri.parse('$finalCutApi/api/projects/${widget.projectId}/final-cut/prepare'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode==201?'Final Cut plan prepared.':'Final Cut is not ready yet.')));
    setState(()=>preparing=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final ready=readiness['ready']==true;
    final clips=List.from(plan?['clips']??[]);
    return Scaffold(appBar:AppBar(title:const Text('Final Cut Preparation')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(
          leading:Icon(ready?Icons.check_circle:Icons.warning),
          title:Text(ready?'Ready for Final Cut':'Final Cut readiness'),
          subtitle:Text('${readiness['availableFiles']??0}/${readiness['itemCount']??0} source files available'),
        )),
        if(plan!=null)Card(child:ListTile(
          title:Text('${clips.length} clips in Final Cut plan'),
          subtitle:const Text('Canonical reviewed timeline is now the Final Cut source.'),
        )),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:ready&&!preparing?prepare:null,
          icon:preparing?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.movie),
          label:Text(preparing?'Preparing…':'Prepare Final Cut'))
      ]));
  }
}
