import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class OneClickFinalFilmScreen extends StatefulWidget{
  final String projectId;
  const OneClickFinalFilmScreen({super.key,required this.projectId});
  @override State<OneClickFinalFilmScreen> createState()=>_OneClickFinalFilmScreenState();
}
class _OneClickFinalFilmScreenState extends State<OneClickFinalFilmScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false;Map<String,dynamic>? result;
  Future<void> run()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/one-click-final'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content:Text('Final film created')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('One-Click Final Film')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.movie,size:80),const SizedBox(height:16),
          const Text('Render transitions, apply professional audio ducking and create the final MP4.',
            textAlign:TextAlign.center),const SizedBox(height:24),
          FilledButton.icon(onPressed:loading?null:run,icon:const Icon(Icons.auto_awesome),
            label:Text(loading?'CREATING FINAL FILM…':'CREATE FINAL FILM')),
          if(result!=null)...[
            const SizedBox(height:24),const Text('FINAL FILM READY',textAlign:TextAlign.center),
            const SizedBox(height:8),
            Text('${result!['final']?['outputPath']??''}',textAlign:TextAlign.center)
          ]
        ])));
  }
}
