import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'final_film_player_screen.dart';

class QueueRenderJob {
  final String id, title, status;
  final int progress;
  final String stage;
  final int queuePosition;
  QueueRenderJob({
    required this.id, required this.title, required this.status,
    required this.progress, required this.stage, required this.queuePosition,
  });
  factory QueueRenderJob.fromJson(Map<String,dynamic> j) => QueueRenderJob(
    id: '${j['id'] ?? ''}',
    title: '${j['title'] ?? 'Untitled Film'}',
    status: '${j['status'] ?? 'unknown'}',
    progress: int.tryParse('${j['progress'] ?? 0}') ?? 0,
    stage: '${j['stage'] ?? j['message'] ?? ''}',
    queuePosition: int.tryParse('${j['queuePosition'] ?? 0}') ?? 0,
  );
}

class FinalRenderQueueAwareScreen extends StatefulWidget {
  final String projectId;
  final String title;
  const FinalRenderQueueAwareScreen({
    super.key, required this.projectId, this.title='Final Render',
  });
  @override State<FinalRenderQueueAwareScreen> createState()=>_FinalRenderQueueAwareScreenState();
}

class _FinalRenderQueueAwareScreenState extends State<FinalRenderQueueAwareScreen> {
  static const base='http://10.0.2.2:3000';
  Timer? timer;
  QueueRenderJob? job;
  bool loading=false;
  String error='';
  bool openedDetails=false;

  @override void initState(){super.initState(); _load(); timer=Timer.periodic(const Duration(seconds:2),(_)=>_load());}
  @override void dispose(){timer?.cancel();super.dispose();}

  Future<void> _load() async {
    try {
      if(job?.id!=null){
        final r=await http.get(Uri.parse('$base/api/final-render/jobs/${job!.id}/status'));
        if(r.statusCode<300){
          final next=QueueRenderJob.fromJson(Map<String,dynamic>.from(jsonDecode(r.body)));
          if(mounted)setState(()=>job=next);
          if(next.status=='completed' && !openedDetails) _openDetails();
          return;
        }
      }
      final r=await http.get(Uri.parse('$base/api/final-render/queue'));
      if(r.statusCode>=300) return;
      final d=Map<String,dynamic>.from(jsonDecode(r.body));
      final all=List<dynamic>.from(d['queue']??[]);
      final found=all.cast<dynamic>().where((x)=>'${x['projectId']??''}'==widget.projectId).toList();
      if(found.isNotEmpty){
        final next=QueueRenderJob.fromJson(Map<String,dynamic>.from(found.first));
        if(mounted)setState(()=>job=next);
        if(next.status=='completed' && !openedDetails) _openDetails();
      }
    } catch(_){}
  }

  Future<void> startRender() async {
    setState(()=>loading=true);
    try {
      final r=await http.post(
        Uri.parse('$base/api/projects/${widget.projectId}/smart-one-click-final-render'),
        headers:{'Content-Type':'application/json'},
        body:jsonEncode({'title':widget.title}),
      );
      if(r.statusCode>=300) throw Exception('Unable to queue final render');
      final d=Map<String,dynamic>.from(jsonDecode(r.body));
      final j=Map<String,dynamic>.from(d['job']??{});
      if(j.isNotEmpty && mounted)setState(()=>job=QueueRenderJob.fromJson(j));
    } catch(e) {
      if(mounted)setState(()=>error=e.toString());
    } finally {if(mounted)setState(()=>loading=false);}
  }

  Future<void> cancel() async {
    final id=job?.id;if(id==null)return;
    await http.post(Uri.parse('$base/api/final-render/queue/$id/cancel'));
    await _load();
  }

  void _openDetails() {
    if(openedDetails || job==null)return;
    openedDetails=true;
    Navigator.push(context,MaterialPageRoute(
      builder:(_)=>FinalRenderQueueJobDetailsScreen(jobId:job!.id,title:job!.title)
    )).then((_){openedDetails=false;});
  }

  @override Widget build(BuildContext context) {
    final j=job;
    final active=j!=null && (j.status=='claimed'||j.status=='running'||j.status=='recovering');
    final done=j!=null && (j.status=='completed'||j.status=='failed');
    return Scaffold(
      appBar:AppBar(title:Text(widget.title)),
      body:Padding(padding:const EdgeInsets.all(18),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.movie_filter,size:72),
          const SizedBox(height:12),
          Text(j==null?'Ready to render':j.title,textAlign:TextAlign.center,
            style=Theme.of(context).textTheme.titleLarge),
          const SizedBox(height:20),
          if(j==null) FilledButton.icon(
            onPressed:loading?null:startRender,icon:const Icon(Icons.movie_creation),
            label:Text(loading?'QUEUING…':'START FINAL RENDER'))
          else ...[
            Text(j.status.toUpperCase(),textAlign:TextAlign.center,
              style=Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height:12),
            if(j.status=='queued') ...[
              LinearProgressIndicator(value:null),
              const SizedBox(height:10),
              Text('Waiting in queue${j.queuePosition>0?' — position ${j.queuePosition}':''}',
                textAlign:TextAlign.center),
            ] else ...[
              LinearProgressIndicator(value:(j.progress.clamp(0,100))/100),
              const SizedBox(height:10),
              Text('${j.progress}%${j.stage.isNotEmpty?' — ${j.stage}':''}',
                textAlign:TextAlign.center),
            ],
            const SizedBox(height:16),
            if(active) OutlinedButton.icon(
              onPressed:cancel,icon:const Icon(Icons.cancel),label:const Text('CANCEL QUEUED RENDER')),
            if(done) FilledButton.icon(
              onPressed:_openDetails,icon:const Icon(Icons.receipt_long),
              label:const Text('VIEW RENDER DETAILS')),
          ],
          if(error.isNotEmpty) Padding(padding:const EdgeInsets.only(top:12),
            child:Text(error,textAlign:TextAlign.center)),
          const Spacer(),
          if(j!=null) Text('Job ID: ${j.id}',textAlign:TextAlign.center,
            style:Theme.of(context).textTheme.bodySmall),
        ],
      )),
    );
  }
}

class FinalRenderQueueJobDetailsScreen extends StatefulWidget {
  final String jobId,title;
  const FinalRenderQueueJobDetailsScreen({super.key,required this.jobId,required this.title});
  @override State<FinalRenderQueueJobDetailsScreen> createState()=>_FinalRenderQueueJobDetailsScreenState();
}
class _FinalRenderQueueJobDetailsScreenState extends State<FinalRenderQueueJobDetailsScreen>{
  static const base='http://10.0.2.2:3000';
  Map<String,dynamic>? job;Timer? timer;
  @override void initState(){super.initState();_load();timer=Timer.periodic(const Duration(seconds:2),(_)=>_load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _load()async{
    try{
      final r=await http.get(Uri.parse('$base/api/final-render/jobs/${widget.jobId}/status'));
      if(r.statusCode<300 && mounted)setState(()=>job=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
  }
  @override Widget build(BuildContext context){
    final j=job??{};
    return Scaffold(appBar:AppBar(title:Text(widget.title)),body:ListView(padding:const EdgeInsets.all(18),children:[
      const Icon(Icons.assignment_turned_in,size:64),
      const SizedBox(height:12),
      _row('Status','${j['status']??'Loading…'}'),
      _row('Progress','${j['progress']??0}%'),
      _row('Stage','${j['stage']??j['message']??'—'}'),
      _row('Queue position','${j['queuePosition']??'—'}'),
      _row('Job ID','${j['id']??widget.jobId}'),
      _row('Library ID','${j['libraryId']??'Pending handoff'}'),
      const SizedBox(height:12),
      if('${j['status']??''}'=='completed')
        FilledButton.icon(
          onPressed: () async {
            final r=await http.get(Uri.parse('$base/api/final-render/jobs/${widget.jobId}/result'));
            if(!context.mounted)return;
            final d=Map<String,dynamic>.from(jsonDecode(r.body));
            showDialog(context:context,builder:(_)=>AlertDialog(
              title:const Text('Final Film Ready'),
              content:Text('Output: ${d['outputPath'] ?? 'Unavailable'}'),
              actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))],
            ));
          },
          icon:const Icon(Icons.play_circle),label:const Text('VIEW FINAL FILM'),
        const SizedBox(height:8),
        FilledButton.icon(
          onPressed:()=>Navigator.push(context,MaterialPageRoute(
            builder:(_)=>FinalFilmPlayerScreen(jobId:widget.jobId,title:widget.title))),
          icon:const Icon(Icons.play_circle_fill),label:const Text('PLAY FINAL FILM'),
        ),
        ),
    ]));
  }
  Widget _row(String a,String b)=>Card(child:ListTile(title:Text(a),subtitle:Text(b)));
}
