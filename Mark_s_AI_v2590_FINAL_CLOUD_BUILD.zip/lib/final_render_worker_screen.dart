import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String workerApi='http://10.0.2.2:3000';
class FinalRenderWorkerScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderWorkerScreen({super.key,required this.projectId});
  @override State<FinalRenderWorkerScreen> createState()=>_FinalRenderWorkerScreenState();
}
class _FinalRenderWorkerScreenState extends State<FinalRenderWorkerScreen>{
  Map<String,dynamic> q={};bool loading=true,working=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final r=await http.get(Uri.parse('$workerApi/api/projects/${widget.projectId}/final-render/queue'));
    if(r.statusCode==200&&mounted)setState(()=>q=jsonDecode(r.body)['queue']??{});
    if(mounted)setState(()=>loading=false);
  }
  Future<void> action(String path)async{
    setState(()=>working=true);
    final r=await http.post(Uri.parse('$workerApi/api/projects/${widget.projectId}$path'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode>=200&&r.statusCode<300?'Worker action completed.':'Worker action could not be completed.')));
    setState(()=>working=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final status=q['status']??'not queued';
    return Scaffold(appBar:AppBar(title:const Text('Render Worker')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(title:Text('Status: $status'),
          subtitle:Text('Stage: ${q['stage']??'waiting'} • Progress: ${q['progress']??0}%'))),
        if(q['workerJobId']==null)FilledButton.icon(onPressed:working?null:()=>action('/final-render/dispatch'),
          icon:const Icon(Icons.send),label:const Text('Dispatch to Render Worker')),
        if(status=='dispatched')FilledButton.icon(onPressed:working?null:()=>action('/final-render/claim'),
          icon:const Icon(Icons.play_arrow),label:const Text('Claim Worker Job')),
        if(q['outputPath']!=null)Card(child:ListTile(leading:Icon(q['outputExists']==true?Icons.video_file:Icons.warning),
          title:const Text('Render Output'),subtitle:Text('${q['outputPath']}')))
      ]));
  }
}
