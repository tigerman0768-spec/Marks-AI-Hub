import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProductionHealthScreen extends StatefulWidget{
  final String projectId;
  const ProductionHealthScreen({super.key,required this.projectId});
  @override State<ProductionHealthScreen> createState()=>_ProductionHealthScreenState();
}
class _ProductionHealthScreenState extends State<ProductionHealthScreen>{
  static const base='http://10.0.2.2:3000';
  Timer? timer; Map<String,dynamic> data={}; String? error;
  @override void initState(){super.initState();_load();timer=Timer.periodic(const Duration(seconds:5),(_)=>_load());}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/production-health'));
      if(r.statusCode>=300)throw Exception('Production health unavailable');
      data=jsonDecode(r.body) as Map<String,dynamic>; error=null;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>{});
  }
  @override Widget build(BuildContext c){
    final checks=(data['checks'] as Map?)?.cast<String,dynamic>()??{};
    final pct=(data['completion'] as num?)?.toInt()??0;
    return Scaffold(appBar:AppBar(title:const Text('Production Health')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text('Production Health',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:6),Text('Overall readiness: $pct%'),
        const SizedBox(height:10),LinearProgressIndicator(value:pct/100),
        const SizedBox(height:18),
        ...checks.entries.map((e)=>Card(child:ListTile(
          leading:Icon(e.value==true?Icons.check_circle:Icons.radio_button_unchecked),
          title:Text(_title(e.key)),subtitle:Text(e.value==true?'Ready':'Not ready')))),
        const SizedBox(height:12),
        Text('Next: ${_title(data['next']?.toString()??'final-master')}',style:const TextStyle(fontWeight:FontWeight.bold)),
        if(error!=null)Padding(padding:const EdgeInsets.only(top:12),child:Text(error!)),
      ]));
  }
  String _title(String x)=>x.split(RegExp(r'(?=[A-Z])|-')).map((v)=>v.isEmpty?v:'${v[0].toUpperCase()}${v.substring(1)}').join(' ');
}
