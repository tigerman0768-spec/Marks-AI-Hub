import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String canonicalReviewApi='http://10.0.2.2:3000';

class CanonicalTimelineReviewScreen extends StatefulWidget{
  final String projectId;
  const CanonicalTimelineReviewScreen({super.key,required this.projectId});
  @override State<CanonicalTimelineReviewScreen> createState()=>_CanonicalTimelineReviewScreenState();
}
class _CanonicalTimelineReviewScreenState extends State<CanonicalTimelineReviewScreen>{
  Map<String,dynamic> data={}; bool loading=true,working=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final r=await http.get(Uri.parse('$canonicalReviewApi/api/projects/${widget.projectId}/timeline-review'));
    if(r.statusCode==200&&mounted)setState(()=>data=jsonDecode(r.body));
    if(mounted)setState(()=>loading=false);
  }
  Future<void> start()async{
    await http.post(Uri.parse('$canonicalReviewApi/api/projects/${widget.projectId}/timeline-review/start'));
    load();
  }
  Future<void> decide(String id,String status)async{
    await http.patch(Uri.parse('$canonicalReviewApi/api/projects/${widget.projectId}/timeline-review/$id'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({'status':status}));
    load();
  }
  Future<void> finalize()async{
    setState(()=>working=true);
    final r=await http.post(Uri.parse('$canonicalReviewApi/api/projects/${widget.projectId}/timeline-review/finalize'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Timeline review finalized.':'Finish all review decisions first.')));
    setState(()=>working=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final t=List<Map<String,dynamic>>.from((data['timeline'] as List???[]).map((x)=>Map<String,dynamic>.from(x)));
    final rev=Map<String,dynamic>.from((data['review'] as Map???{}));
    final ds=List<Map<String,dynamic>>.from((rev['itemDecisions'] as List???[]).map((x)=>Map<String,dynamic>.from(x)));
    final finalized=rev['status']=='finalized';
    return Scaffold(appBar:AppBar(title:const Text('Final Timeline Review')),body:ListView(padding:const EdgeInsets.all(12),children:[
      Card(child:ListTile(title:Text('${t.length} timeline items'),subtitle:Text(finalized?'Review finalized':'Review every item before final cut'))),
      if(rev.isEmpty)FilledButton.icon(onPressed:start,icon:const Icon(Icons.playlist_add_check),label:const Text('Start Timeline Review')),
      ...t.asMap().entries.map((e){
        final x=e.value; final d=ds.where((z)=>z['timelineId']==x['id']).isNotEmpty?ds.firstWhere((z)=>z['timelineId']==x['id']):{};
        return Card(child:ListTile(
          title:Text('${e.key+1}. Scene ${x['scene']??'-'} • Shot ${x['shotId']??'-'}'),
          subtitle:Text('Decision: ${d['status']??'pending'}'),
          trailing:PopupMenuButton<String>(onSelected:(s)=>decide(x['id'],s),itemBuilder:(_)=>const[
            PopupMenuItem(value:'keep',child:Text('Keep')),PopupMenuItem(value:'remove',child:Text('Remove')),
            PopupMenuItem(value:'needs_trim',child:Text('Needs Trim'))
          ]),
        ));
      }),
      const SizedBox(height:8),
      FilledButton.icon(onPressed:ds.isEmpty||finalized||working?null:finalize,
        icon:working?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.done_all),
        label:Text(working?'Finalizing…':'Finalize Timeline Review'))
    ]));
  }
}
