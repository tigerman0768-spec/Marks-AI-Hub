import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const String libraryPlayerApi='http://10.0.2.2:3000';

class ApprovedFilmLibraryPlayerScreen extends StatefulWidget{
  final String projectId;
  const ApprovedFilmLibraryPlayerScreen({super.key,required this.projectId});
  @override State<ApprovedFilmLibraryPlayerScreen> createState()=>_ApprovedFilmLibraryPlayerScreenState();
}
class _ApprovedFilmLibraryPlayerScreenState extends State<ApprovedFilmLibraryPlayerScreen>{
  Map<String,dynamic>? film; VideoPlayerController? controller; String? error; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$libraryPlayerApi/api/projects/${widget.projectId}/approved-film/library'));
      if(r.statusCode!=200)throw Exception('Film is not in the library');
      final f=jsonDecode(r.body)['film'] as Map<String,dynamic>?;
      if(f==null)throw Exception('No library film found');
      final c=VideoPlayerController.networkUrl(Uri.parse('$libraryPlayerApi/api/projects/${widget.projectId}/approved-film/library/media'));
      await c.initialize();
      if(!mounted){c.dispose();return;}
      setState((){film=f;controller=c;loading=false;});
    }catch(e){if(mounted)setState((){error='$e';loading=false;});}
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final c=controller;
    return Scaffold(appBar:AppBar(title:Text(film?['title']??'Film Player')),
      body:loading?const Center(child:CircularProgressIndicator()):
      error!=null?Center(child:Padding(padding:const EdgeInsets.all(20),child:Text(error!))):
      c==null?const Center(child:Text('No video available.')):
      Column(children:[
        Expanded(child:Center(child:AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c)))),
        Text('${film?['clipCount']??0} clips • ${film?['bytes']??0} bytes'),
        const SizedBox(height:8),
        Row(mainAxisAlignment:MainAxisAlignment.center,children:[
          IconButton(icon:Icon(c.value.isPlaying?Icons.pause_circle:Icons.play_circle,size:58),onPressed:(){setState(()=>c.value.isPlaying?c.pause():c.play());}),
          IconButton(icon:const Icon(Icons.replay_10),onPressed:()=>c.seekTo(c.value.position-const Duration(seconds:10))),
          IconButton(icon:const Icon(Icons.forward_10),onPressed:()=>c.seekTo(c.value.position+const Duration(seconds:10))),
        ]),
        const SizedBox(height:16),
      ]));
  }
}
