import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

class ReleaseBuildCenterScreen extends StatefulWidget {
  final String apiBase;
  const ReleaseBuildCenterScreen({super.key,this.apiBase='http://10.0.2.2:3000'});
  @override State<ReleaseBuildCenterScreen> createState()=>_ReleaseBuildCenterScreenState();
}

class _ReleaseBuildCenterScreenState extends State<ReleaseBuildCenterScreen>{
  Map<String,dynamic>? data,monitor;
  bool loading=true,dispatching=false,monitorLoading=false;
  String? message,error;

  Future<void> load() async {
    if(mounted)setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('${widget.apiBase}/api/release-build'));
      if(r.statusCode>=400)throw Exception('Release Build Center unavailable');
      if(!mounted)return;
      setState(()=>data=Map<String,dynamic>.from(jsonDecode(r.body)));
      await refreshMonitor(silent:true);
    }catch(e){if(mounted)setState(()=>error=e.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted)setState(()=>loading=false);}
  }

  Future<void> refreshMonitor({bool silent=false}) async {
    if(!silent&&mounted)setState(()=>monitorLoading=true);
    try{
      final r=await http.get(Uri.parse('${widget.apiBase}/api/release-build/monitor'));
      final body=Map<String,dynamic>.from(jsonDecode(r.body));
      if(r.statusCode>=400)throw Exception(body['message']??'Build monitor unavailable');
      if(mounted)setState(()=>monitor=body);
    }catch(e){if(mounted&&!silent)setState(()=>message=e.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted&&!silent)setState(()=>monitorLoading=false);}
  }

  Future<void> dispatch() async {
    if(mounted)setState(()=>dispatching=true);
    try{
      final r=await http.post(Uri.parse('${widget.apiBase}/api/release-build/dispatch'),headers:{'Content-Type':'application/json'},body:jsonEncode({'releaseVersion':data?['version']??'v2570'}));
      final body=Map<String,dynamic>.from(jsonDecode(r.body));
      if(r.statusCode>=400)throw Exception(body['error']??'Build dispatch failed');
      if(!mounted)return;
      setState(()=>message='Build dispatched. Refresh the Build Monitor to see GitHub Actions progress.');
      await Future.delayed(const Duration(seconds:2));
      await refreshMonitor();
    }catch(e){if(mounted)setState(()=>message=e.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted)setState(()=>dispatching=false);}
  }

  String _statusLabel(){
    final s=monitor?['status'];
    if(s=='success')return 'Build succeeded';
    if(s=='failure')return 'Build failed';
    if(s=='queued')return 'Build queued';
    if(s=='in_progress')return 'Build running';
    if(s=='not_configured')return 'Monitor not configured';
    if(s=='no_runs')return 'No build runs yet';
    if(s=='error')return 'Monitor error';
    return 'Waiting for build status';
  }
  IconData _statusIcon(){final s=monitor?['status']; if(s=='success')return Icons.check_circle; if(s=='failure')return Icons.error; if(s=='queued')return Icons.schedule; if(s=='in_progress')return Icons.sync; return Icons.info_outline;}

  String _artifactSize(dynamic bytes){
    final n=(bytes is num)?bytes.toDouble():double.tryParse('$bytes');
    if(n==null)return 'Size unavailable';
    if(n>=1024*1024)return '${(n/(1024*1024)).toStringAsFixed(1)} MB';
    if(n>=1024)return '${(n/1024).toStringAsFixed(1)} KB';
    return '${n.toStringAsFixed(0)} bytes';
  }

  Future<void> _openArtifact(Map<String,dynamic> a) async {
    final raw=a['downloadUrl'];
    if(raw==null)return;
    final value=raw.toString();
    final uri=Uri.parse(value.startsWith('http')?value:'${widget.apiBase}$value');
    if(!await launchUrl(uri,mode:LaunchMode.externalApplication)){
      if(mounted)setState(()=>message='Could not open the artifact download link.');
    }
  }

  @override void initState(){super.initState();load();}

  @override Widget build(BuildContext context){
    final d=data; final m=monitor; final run=m?['run'] as Map<String,dynamic>?; final artifacts=(m?['artifacts'] as List?)??const [];
    return Scaffold(appBar:AppBar(title:const Text('Release Build Center'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),body:
      loading?const Center(child:CircularProgressIndicator()):error!=null?Center(child:Text(error!)):ListView(padding:const EdgeInsets.all(16),children:[
        Text('Build the real Android release',style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:8),
        const Text('Dispatches the real GitHub Actions Android build and then monitors its status and produced artifacts.'),
        const SizedBox(height:16),
        Card(child:ListTile(leading:Icon(d?['configured']==true?Icons.cloud_done:Icons.cloud_off),title:Text(d?['configured']==true?'GitHub Actions configured':'GitHub Actions not configured'),subtitle:Text(d?['message']??'':'—'))),
        Card(child:ListTile(leading:const Icon(Icons.tag),title:const Text('Release version'),subtitle:Text(d?['version']??'v2570'))),
        Card(child:const ListTile(leading:Icon(Icons.android),title:Text('APK artifact'),subtitle:Text('marks-ai-android-apk'))),
        Card(child:const ListTile(leading:Icon(Icons.shop),title:Text('AAB artifact'),subtitle:Text('marks-ai-android-aab'))),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:d?['configured']==true&&!dispatching?dispatch:null,icon:dispatching?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rocket_launch),label:Text(dispatching?'Starting build…':'Build Android APK + AAB')),
        const SizedBox(height:18),
        Row(children:[Expanded(child:Text('Build Monitor',style:Theme.of(context).textTheme.titleLarge)),IconButton(onPressed:monitorLoading?null:()=>refreshMonitor(),icon:monitorLoading?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.refresh))]),
        Card(child:ListTile(leading:Icon(_statusIcon()),title:Text(_statusLabel()),subtitle:Text(m?['message']??'Checking GitHub Actions…'))),
        if(run!=null)Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Run #${run['runNumber']??'—'}',style:Theme.of(context).textTheme.titleMedium),
          const SizedBox(height:6),Text('${run['status']??'—'}${run['conclusion']!=null?' • ${run['conclusion']}':''}'),
          if(run['branch']!=null)Text('Branch: ${run['branch']}'),
          if(run['createdAt']!=null)Text('Started: ${run['createdAt']}'),
          if(run['htmlUrl']!=null)Padding(padding:const EdgeInsets.only(top:8),child:OutlinedButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:run['htmlUrl']));if(mounted)setState(()=>message='Build run link copied.');},icon:const Icon(Icons.copy),label:const Text('Copy build run link')))
        ]))),
        if(artifacts.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('Produced artifacts',style:Theme.of(context).textTheme.titleMedium),
          const SizedBox(height:8),
          ...artifacts.map((raw){
            final a=Map<String,dynamic>.from(raw as Map);
            return ListTile(contentPadding:EdgeInsets.zero,leading:Icon(a['name']=='marks-ai-android-aab'?Icons.shop:Icons.android),title:Text(a['name']??'Artifact'),subtitle:Text('${_artifactSize(a['sizeBytes'])} • Updated ${a['updatedAt']??a['createdAt']??'—'}'),trailing:IconButton(tooltip:'Download artifact',onPressed:()=>_openArtifact(a),icon:const Icon(Icons.download)));
          })
        ]))),
        const SizedBox(height:8),
        if((d?['workflowUrl']??'')!='')OutlinedButton.icon(onPressed:()async{await Clipboard.setData(ClipboardData(text:d!['workflowUrl']));if(mounted)setState(()=>message='GitHub Actions link copied.');},icon:const Icon(Icons.copy),label:const Text('Copy GitHub Actions link')),
        if(message!=null)Padding(padding:const EdgeInsets.only(top:14),child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Text(message!)))),
        const SizedBox(height:10),
        const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('The monitor only reports artifacts after GitHub Actions actually produces them.'))),
      ]);
  }
}
