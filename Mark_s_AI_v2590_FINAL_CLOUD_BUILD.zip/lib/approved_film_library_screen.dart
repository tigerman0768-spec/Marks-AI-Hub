import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'approved_film_library_player_screen.dart';

const String approvedLibraryApi='http://10.0.2.2:3000';

class ApprovedFilmLibraryScreen extends StatefulWidget{
  final String projectId;
  const ApprovedFilmLibraryScreen({super.key,required this.projectId});
  @override State<ApprovedFilmLibraryScreen> createState()=>_ApprovedFilmLibraryScreenState();
}
class _ApprovedFilmLibraryScreenState extends State<ApprovedFilmLibraryScreen>{
  Map<String,dynamic>? film; bool loading=true; String message='';
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$approvedLibraryApi/api/projects/${widget.projectId}/approved-film/library'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>film=jsonDecode(r.body)['film'] as Map<String,dynamic>?);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> handoff()async{
    final r=await http.post(Uri.parse('$approvedLibraryApi/api/projects/${widget.projectId}/approved-film/library/handoff'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState(()=>message=r.statusCode==200?'Film added to Film Library.':'Blocked: ${b['blockers']??b['error']??''}');
    if(r.statusCode==200)load();
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Film Library')),
    body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:const Icon(Icons.video_library),title:Text(film?['title']??'Not in library'),subtitle:Text(film==null?'Render the film first.':'${film?['clipCount']??0} clips • ${film?['bytes']??0} bytes'))),
      FilledButton.icon(onPressed:handoff,icon:const Icon(Icons.library_add),label:const Text('Add Rendered Film to Library')),
      if(film!=null)FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ApprovedFilmLibraryPlayerScreen(projectId:widget.projectId))),icon:const Icon(Icons.play_circle),label:const Text('Play Film')),
      if(film?['outputPath']!=null)Card(child:Padding(padding:const EdgeInsets.all(12),child:SelectableText('Film file: ${film?['outputPath']}'))),
      if(film?['sha256']!=null)SelectableText('SHA-256: ${film?['sha256']}'),
      if(message.isNotEmpty)Padding(padding:const EdgeInsets.all(12),child:Text(message)),
    ]));
}
