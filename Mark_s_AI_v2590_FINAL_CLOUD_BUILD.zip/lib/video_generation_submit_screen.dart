import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String videoSubmitApi = 'http://10.0.2.2:3000';

class VideoGenerationSubmitScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationSubmitScreen({super.key, required this.projectId});

  @override
  State<VideoGenerationSubmitScreen> createState() => _VideoGenerationSubmitScreenState();
}

class _VideoGenerationSubmitScreenState extends State<VideoGenerationSubmitScreen> {
  bool submitting = false;
  Map<String, dynamic>? result;
  String? error;

  Future<void> submit() async {
    setState(() { submitting = true; error = null; });
    try {
      final r = await http.post(Uri.parse(
        '$videoSubmitApi/api/projects/${widget.projectId}/video-generation/submit',
      ));
      final body = jsonDecode(r.body) as Map<String, dynamic>;
      if (r.statusCode != 202) {
        throw Exception(body['error'] ?? 'Submission failed');
      }
      setState(() {
        result = body;
        submitting = false;
      });
    } catch (e) {
      setState(() { submitting = false; error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Submit Video Generation')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'This is the final submission step after preflight and launch preparation. '
              'A provider must be configured. The app records the orchestrator response and does not invent generated clips.',
            ),
          )),
          FilledButton.icon(
            onPressed: submitting ? null : submit,
            icon: submitting
                ? const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.cloud_upload),
            label: Text(submitting ? 'Submitting…' : 'Submit to Video Provider'),
          ),
          if (result != null) ...[
            const SizedBox(height: 16),
            Card(child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Submitted successfully.\n'
                'Launch: ${result!['launchId']}\n'
                'Provider: ${result!['provider']}\n'
                'Status: ${result!['status']}',
              ),
            )),
            if (result!['result'] != null)
              Card(child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(const JsonEncoder.withIndent('  ').convert(result!['result'])),
              )),
          ],
          if (error != null) ...[
            const SizedBox(height: 12),
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(error!),
            )),
          ],
        ],
      ),
    );
  }
}
