import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String videoJobsApi = 'http://10.0.2.2:3000';

class VideoGenerationJobsScreen extends StatefulWidget {
  final String projectId;
  const VideoGenerationJobsScreen({super.key, required this.projectId});

  @override
  State<VideoGenerationJobsScreen> createState() => _VideoGenerationJobsScreenState();
}

class _VideoGenerationJobsScreenState extends State<VideoGenerationJobsScreen> {
  List<Map<String, dynamic>> jobs = [];
  bool loading = true;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 3), (_) => load());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final r = await http.get(Uri.parse(
        '$videoJobsApi/api/projects/${widget.projectId}/video-generation/jobs',
      ));
      if (r.statusCode == 200 && mounted) {
        final body = jsonDecode(r.body) as Map<String, dynamic>;
        setState(() {
          jobs = List<Map<String, dynamic>>.from(
            (body['jobs'] as List? ?? [])
                .map((x) => Map<String, dynamic>.from(x)),
          );
          loading = false;
        });
      } else if (mounted) {
        setState(() => loading = false);
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final done = jobs.where((j) =>
      ['completed', 'complete', 'succeeded', 'success'].contains(
        '${j['status']}'.toLowerCase(),
      )).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Video Generation Jobs'),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : jobs.isEmpty
              ? const Center(child: Text('No video jobs recorded yet.'))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Card(child: ListTile(
                      leading: const Icon(Icons.video_library),
                      title: Text('$done of ${jobs.length} shots complete'),
                      subtitle: const Text('Jobs are stored per shot for review and recovery.'),
                    )),
                    const SizedBox(height: 8),
                    ...jobs.map((job) {
                      final progress = ((job['progress'] ?? 0) as num).toDouble() / 100;
                      return Card(child: ListTile(
                        leading: CircularProgressIndicator(value: progress.clamp(0, 1)),
                        title: Text('Shot ${job['index'] ?? '-'} • Scene ${job['scene'] ?? '-'}'),
                        subtitle: Text('${job['status'] ?? 'queued'} • ${job['provider'] ?? ''}'),
                        trailing: Text('${job['progress'] ?? 0}%'),
                      ));
                    }),
                  ],
                ),
    );
  }
}
