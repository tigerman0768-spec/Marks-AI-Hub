import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiAudioDuckingScreen extends StatefulWidget{
  final String projectId;
  const AiAudioDuckingScreen({super.key,required this.projectId});
  @override State<AiAudioDuckingScreen> createState()=>_AiAudioDuckingScreenState();
}
class _AiAudioDuckingScreenState extends State<AiAudioDuckingScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? result;
  Future<void> run()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-duck-master'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content:Text('Dialogue ducking applied to music')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('AI Audio Ducking')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.volume_down,size:72),const SizedBox(height:16),
          const Text('Automatically lower background music while dialogue is playing.',
            textAlign:TextAlign.center),const SizedBox(height:20),
          FilledButton.icon(onPressed:loading?null:run,icon:const Icon(Icons.auto_awesome),
            label:Text(loading?'MASTERING…':'APPLY AUDIO DUCKING')),
          if(result!=null)...[
            const SizedBox(height:20),
            Text('Ducking: ${result!['duckingApplied']==true?'applied':'not applied'}'),
            Text('Dialogue windows: ${result!['duckWindows']??0}'),
            const SizedBox(height:8),
            Text('${result!['outputPath']??''}',textAlign:TextAlign.center)
          ]
        ])));
  }
}
