import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'final_master_status_screen.dart';

class FinalFinishingScreen extends StatefulWidget{
  final String projectId;
  const FinalFinishingScreen({super.key,required this.projectId});
  @override State<FinalFinishingScreen> createState()=>_FinalFinishingScreenState();
}
class _FinalFinishingScreenState extends State<FinalFinishingScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; String? error; Map<String,dynamic> data={}; Map<String,dynamic> readiness={};
  @override void initState(){super.initState();_load();}
  Future<void> _checkReadiness() async {
    try {
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-master/readiness'));
      if(r.statusCode>=300)throw Exception('Readiness check failed');
      readiness=jsonDecode(r.body) as Map<String,dynamic>;
    } catch (_) {}
  }

  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-finishing-plan'));
      if(r.statusCode>=300)throw Exception('Final finishing unavailable');
      data=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    await _checkReadiness();
    if(mounted)setState(()=>loading=false);
  }
  Future<void> _prepare() async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/final-finishing/prepare'),
        headers:{'Content-Type':'application/json'});
      if(r.statusCode>=300)throw Exception('Preparation failed (${r.statusCode})');
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Final finishing prepared')));
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  Future<void> _queueMaster() async {
    await _checkReadiness();
    if(readiness['ready']!=true){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Final master is not ready yet')));
      return;
    }
    try {
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/final-master/queue'),
        headers:{'Content-Type':'application/json'});
      if(r.statusCode>=300)throw Exception('Final master queue failed (${r.statusCode})');
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Final master queued')));
      if(mounted)Navigator.push(context,MaterialPageRoute(builder:(_)=>FinalMasterStatusScreen(projectId:widget.projectId)));
    } catch(e) {
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));
    }
  }

  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Final Finishing')),body:Center(child:Text(error!)));
    final st=(data['stages'] as Map?)??{};
    return Scaffold(appBar:AppBar(title:const Text('Final Finishing')),body:ListView(
      padding:const EdgeInsets.all(16),children:[
        Text('Final Finishing',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:8),const Text('Prepare the final master with audio, ducking and subtitles.'),
        const SizedBox(height:18),
        _stage('Audio Mix',st['audioMix']==true),
        _stage('Dialogue Ducking',st['ducking']==true),
        _stage('Subtitles',st['subtitles']==true),
        _stage('Final Render',st['finalRender']==true),
        const SizedBox(height:18),
        FilledButton.icon(onPressed:_prepare,icon:const Icon(Icons.check_circle),label:const Text('PREPARE FINAL MASTER')),
        const SizedBox(height:10),
        OutlinedButton.icon(onPressed:_queueMaster,icon:const Icon(Icons.queue_play_next),label:const Text('QUEUE FINAL MASTER')),
      ]));
  }
  Widget _stage(String name,bool ok)=>Card(child:ListTile(
    leading:Icon(ok?Icons.check_circle:Icons.radio_button_unchecked),
    title:Text(name),subtitle:Text(ok?'Ready':'Needs input')));
}
