import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String clipReviewApi='http://10.0.2.2:3000';

class GeneratedClipReviewScreen extends StatefulWidget {
  final String projectId;
  const GeneratedClipReviewScreen({super.key,required this.projectId});
  @override State<GeneratedClipReviewScreen> createState()=>_GeneratedClipReviewScreenState();
}

class _GeneratedClipReviewScreenState extends State<GeneratedClipReviewScreen>{
  Map<String,dynamic>? reviewSet;
  bool loading=true,creating=false;

  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/generated-clips/review-set'));
      if(r.statusCode==200&&mounted){
        setState((){reviewSet=jsonDecode(r.body) as Map<String,dynamic>;loading=false;});
      }else if(mounted){setState(()=>loading=false);}
    }catch(_){if(mounted)setState(()=>loading=false);}
  }

  Future<void> createSet() async{
    setState(()=>creating=true);
    final r=await http.post(Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/generated-clips/review-set'));
    if(r.statusCode==201&&mounted)setState(()=>reviewSet=jsonDecode(r.body) as Map<String,dynamic>);
    if(mounted)setState(()=>creating=false);
  }

  Future<void> decide(String clipId,String status) async{
    final r=await http.patch(
      Uri.parse('$clipReviewApi/api/projects/${widget.projectId}/generated-clips/review-set/$clipId'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'reviewStatus':status}),
    );
    if(r.statusCode>=200&&r.statusCode<300) await load();
  }

  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final clips=List<Map<String,dynamic>>.from((reviewSet?['clips'] as List? ?? []).map((x)=>Map<String,dynamic>.from(x)));
    final accepted=clips.where((c)=>c['reviewStatus']=='accepted').length;
    return Scaffold(
      appBar:AppBar(title:const Text('Clip Review')),
      body:ListView(
        padding:const EdgeInsets.all(16),
        children:[
          if(reviewSet==null)Card(child:Padding(
            padding:const EdgeInsets.all(16),
            child:Column(children:[
              const Text('No review set exists yet.'),
              const SizedBox(height:12),
              FilledButton.icon(onPressed:creating?null:createSet,
                icon:creating?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.rate_review),
                label:Text(creating?'Creating…':'Create Review Set'))
            ])
          )),
          if(reviewSet!=null)...[
            Card(child:ListTile(
              title:Text('${clips.length} clips • $accepted accepted'),
              subtitle:const Text('Review each generated clip before editing.'),
            )),
            ...clips.map((c)=>Card(child:Padding(
              padding:const EdgeInsets.all(8),
              child:Column(children:[
                ListTile(
                  title:Text('Shot ${c['index']??'-'} • Scene ${c['scene']??'-'}'),
                  subtitle:Text('${c['reviewStatus']??'pending'} • ${c['duration']??0}s'),
                ),
                Row(children:[
                  TextButton.icon(onPressed:()=>decide(c['id'],'accepted'),icon:const Icon(Icons.check),label:const Text('Accept')),
                  TextButton.icon(onPressed:()=>decide(c['id'],'rejected'),icon:const Icon(Icons.close),label:const Text('Reject')),
                  TextButton.icon(onPressed:()=>decide(c['id'],'needs_regeneration'),icon:const Icon(Icons.replay),label:const Text('Regenerate')),
                ])
              ])
            )))
          ]
        ],
      ),
    );
  }
}
