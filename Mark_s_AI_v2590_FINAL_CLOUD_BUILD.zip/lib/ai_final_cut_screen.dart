import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiFinalCutScreen extends StatefulWidget{
  final String projectId;
  const AiFinalCutScreen({super.key,required this.projectId});
  @override State<AiFinalCutScreen> createState()=>_AiFinalCutScreenState();
}
class _AiFinalCutScreenState extends State<AiFinalCutScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? plan;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-cut-plan'));
      if(r.statusCode<300)setState(()=>plan=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final p=plan;
    return Scaffold(
      appBar:AppBar(title:const Text('AI Final Cut Planner'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
      p==null?const Center(child:Text('Unable to build final cut plan.')):
      ListView(padding:const EdgeInsets.all(12),children:[
        Card(child:ListTile(
          leading:const Icon(Icons.movie_creation),
          title:Text('${p['shotCount']??0} shots'),
          subtitle:Text('Estimated duration: ${NumberHelper.seconds(p['totalDuration'])} • ${p['readyToRender']==true?'READY TO RENDER':'NEEDS REVIEW'}'),
        )),
        ...((p['notes'] as List?)??[]).map((n)=>ListTile(
          leading:const Icon(Icons.info_outline),title:Text(n.toString()))),
        ...((p['items'] as List?)??[]).map((x){
          final m=Map<String,dynamic>.from(x as Map);
          return ListTile(
            leading:CircleAvatar(child:Text('${m['order']}')),
            title:Text('Shot ${m['shotNumber']??''}'),
            subtitle:Text('${m['editReason']} • ${NumberHelper.seconds(m['duration'])}'),
            trailing:const Icon(Icons.cut),
          );
        })
      ])
    );
  }
}
class NumberHelper{
  static String seconds(dynamic v){
    final d=double.tryParse('$v')??0;
    return '${d.toStringAsFixed(1)}s';
  }
}
