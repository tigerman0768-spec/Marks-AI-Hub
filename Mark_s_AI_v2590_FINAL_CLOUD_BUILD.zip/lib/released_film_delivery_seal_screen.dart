import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
const String deliverySealApi='http://10.0.2.2:3000';

class ReleasedFilmDeliverySealScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliverySealScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliverySealScreen> createState()=>_ReleasedFilmDeliverySealScreenState();
}
class _ReleasedFilmDeliverySealScreenState extends State<ReleasedFilmDeliverySealScreen>{
  Map<String,dynamic>? seal;bool busy=false;
  Future<void> sealDelivery()async{
    setState(()=>busy=true);
    try{
      final r=await http.post(Uri.parse('$deliverySealApi/api/projects/${widget.projectId}/final-render/release-delivery-seal/create'));
      if(!mounted)return;
      final b=jsonDecode(r.body);
      setState(()=>seal=b['seal'] as Map<String,dynamic>?);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery sealed.':'Seal blocked.')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final sealed=seal?['status']=='sealed';
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Seal')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(sealed?Icons.verified_user:Icons.lock_outline),
        title:Text(sealed?'DELIVERY SEALED':'DELIVERY NOT SEALED'),
        subtitle:Text(sealed?'Seal ID: ${seal?['sealId']??''}':'Pass the gate and lock the final delivery first.'))),
      if(sealed)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Film: ${seal?['title']??''}'),Text('Size: ${seal?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${seal?['sha256']??''}'),Text('Sealed: ${seal?['sealedAt']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:sealDelivery,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.verified_user),
        label:Text(busy?'Sealing…':'Seal Final Delivery'))
    ]));
  }
}
