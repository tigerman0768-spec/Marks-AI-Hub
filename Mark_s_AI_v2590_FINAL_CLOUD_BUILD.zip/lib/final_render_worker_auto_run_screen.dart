import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String autoRunApi='http://10.0.2.2:3000';
class FinalRenderWorkerAutoRunScreen extends StatefulWidget{
  final String projectId;
  const FinalRenderWorkerAutoRunScreen({super.key,required this.projectId});
  @override State<FinalRenderWorkerAutoRunScreen> createState()=>_FinalRenderWorkerAutoRunScreenState();
}
class _FinalRenderWorkerAutoRunScreenState extends State<FinalRenderWorkerAutoRunScreen>{
  Map<String,dynamic> q={},out={};bool loading=true,running=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final a=await http.get(Uri.parse('$autoRunApi/api/projects/${widget.projectId}/final-render/queue'));
    final b=await http.get(Uri.parse('$autoRunApi/api/projects/${widget.projectId}/final-render/output-inspection'));
    if(mounted)setState((){
      if(a.statusCode==200)q=jsonDecode(a.body)['queue']??{};
      if(b.statusCode==200)out=jsonDecode(b.body);
      loading=false;
    });
  }
  Future<void> run()async{
    setState(()=>running=true);
    final r=await http.post(Uri.parse('$autoRunApi/api/projects/${widget.projectId}/final-render/worker-run'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode==202?'Worker run requested.':'Worker run could not be started.')));
    setState(()=>running=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final s=q['status']??'not queued',ready=out['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Render Worker Run')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(title:Text('Queue: $s'),subtitle:Text('${q['stage']??'waiting'} • ${q['progress']??0}%'))),
      Card(child:ListTile(leading:Icon(ready?Icons.check_circle:Icons.pending),
        title:Text(ready?'Output verified':'Waiting for output'),
        subtitle:Text('${out['bytes']??0} bytes'))),
      FilledButton.icon(onPressed:['dispatched','running'].contains(s)&&!running?run:null,
        icon:running?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.play_circle),
        label:Text(running?'Starting…':'Run Worker'))
    ]));
  }
}
