import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class CharacterVoiceProfilesScreen extends StatefulWidget{
  final String projectId;
  const CharacterVoiceProfilesScreen({super.key,required this.projectId});
  @override State<CharacterVoiceProfilesScreen> createState()=>_CharacterVoiceProfilesScreenState();
}
class _CharacterVoiceProfilesScreenState extends State<CharacterVoiceProfilesScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; List<Map<String,dynamic>> profiles=[];
  final voices=['alloy','ash','ballad','coral','echo','fable','nova','onyx','sage','shimmer'];
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/voice-profiles'));
      if(r.statusCode==200)profiles=(jsonDecode(r.body)['profiles'] as List).map((e)=>Map<String,dynamic>.from(e)).toList();
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> edit(Map<String,dynamic> p) async{
    final instructions=TextEditingController(text:p['instructions']??'');
    double speed=double.tryParse('${p['speed']??1}')??1;
    String voice=p['voice']??'alloy';
    await showDialog(context:context,builder:(_)=>StatefulBuilder(builder:(context,setDialog)=>AlertDialog(
      title:Text('${p['character']??'Character'} Voice'),
      content:SingleChildScrollView(child:Column(children:[
        DropdownButtonFormField<String>(initialValue:voices.contains(voice)?voice:voices.first,
          decoration:const InputDecoration(labelText:'Voice'),items:voices.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
          onChanged:(v){if(v!=null)setDialog(()=>voice=v);}),
        const SizedBox(height:12),
        Text('Speed: ${speed.toStringAsFixed(2)}'),
        Slider(min:.5,max:2,divisions:15,value:speed,onChanged:(v)=>setDialog(()=>speed=v)),
        TextField(controller:instructions,maxLines:4,decoration:const InputDecoration(
          labelText:'Character voice instructions',hintText:'Tone, emotion, delivery and speaking style')),
      ])),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(context),child:const Text('CANCEL')),
        FilledButton(onPressed:()async{
          await http.patch(Uri.parse('$base/api/projects/${widget.projectId}/voice-profiles'),
            headers:{'Content-Type':'application/json'},body:jsonEncode({...p,'voice':voice,'speed':speed,'instructions':instructions.text}));
          if(context.mounted)Navigator.pop(context);
        },child:const Text('SAVE')),
      ],
    )));
    await load();
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Character Voice Profiles')),
    body:loading?const Center(child:CircularProgressIndicator()):
      profiles.isEmpty?const Center(child:Text('No character voice profiles yet.')):
      ListView.builder(itemCount:profiles.length,padding:const EdgeInsets.all(12),
        itemBuilder:(context,i){final p=profiles[i];return Card(child:ListTile(
          leading:const Icon(Icons.record_voice_over),title:Text(p['character']??'Character'),
          subtitle:Text('${p['voice']??'alloy'} • ${p['style']??'cinematic'} • speed ${p['speed']??1}'),
          trailing:IconButton(icon:const Icon(Icons.edit),onPressed:()=>edit(p)),
        ));}),
  );
}
