import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String manifestApi='http://10.0.2.2:3000';
class FinalMasterDeliveryManifestScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterDeliveryManifestScreen({super.key,required this.projectId});
  @override State<FinalMasterDeliveryManifestScreen> createState()=>_FinalMasterDeliveryManifestScreenState();
}
class _FinalMasterDeliveryManifestScreenState extends State<FinalMasterDeliveryManifestScreen>{
  Map<String,dynamic>? manifest;bool busy=false;
  Future<void> buildManifest()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$manifestApi/api/projects/${widget.projectId}/final-render/delivery-manifest/build'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>manifest=b['manifest'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Delivery manifest ready.':'Manifest blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=manifest?['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Delivery Manifest')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.verified:Icons.lock),
        title:Text(ready?'MANIFEST READY':'MANIFEST NOT READY'),
        subtitle:Text(ready?'SHA-256 recorded':'Build after the delivery package is ready.'))),
      if(ready) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('File: ${manifest?['filename']??''}'),
        Text('Size: ${manifest?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${manifest?['sha256']??''}'),
        Text('Duration: ${manifest?['duration']??0}s'),
      ]))),
      FilledButton.icon(onPressed:busy?null:buildManifest,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.fingerprint),
        label:Text(busy?'Building…':'Build Delivery Manifest'))
    ]));
  }
}
