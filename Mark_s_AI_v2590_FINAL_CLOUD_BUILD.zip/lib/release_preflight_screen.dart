import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ReleasePreflightScreen extends StatefulWidget {
  final String apiBase;
  const ReleasePreflightScreen({super.key,this.apiBase='http://10.0.2.2:3000'});
  @override State<ReleasePreflightScreen> createState()=>_ReleasePreflightScreenState();
}

class _ReleasePreflightScreenState extends State<ReleasePreflightScreen>{
  Map<String,dynamic>? data;
  bool loading=true;
  String? error;

  Future<void> run() async {
    if(mounted)setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('${widget.apiBase}/api/release-preflight'));
      final b=jsonDecode(r.body);
      if(!mounted)return;
      setState(()=>data=Map<String,dynamic>.from(b));
    }catch(e){
      if(mounted)setState(()=>error='Release preflight unavailable');
    }finally{
      if(mounted)setState(()=>loading=false);
    }
  }

  @override void initState(){super.initState();run();}

  Widget checkRow(Map<String,dynamic> c){
    final ok=c['ok']==true;
    return Card(child:ListTile(
      leading:Icon(ok?Icons.check_circle:Icons.error_outline),
      title:Text('${c['name']??'Check'}'),
      subtitle:Text('${c['detail']??''}'),
      trailing:Text(ok?'PASS':'BLOCKED',style:TextStyle(fontWeight:FontWeight.bold,color:ok?Theme.of(context).colorScheme.primary:Theme.of(context).colorScheme.error)),
    ));
  }

  @override Widget build(BuildContext context){
    final d=data;
    final checks=(d?['checks'] as List?)?.whereType<Map>().map((x)=>Map<String,dynamic>.from(x)).toList()??const <Map<String,dynamic>>[];
    final ready=d?['readyForSourceRelease']==true;
    return Scaffold(
      appBar:AppBar(title:const Text('Release Preflight'),actions:[IconButton(onPressed:loading?null:run,icon:const Icon(Icons.refresh))]),
      body:loading?const Center(child:CircularProgressIndicator()):error!=null?Center(child:Text(error!)):ListView(padding:const EdgeInsets.all(16),children:[
        Text('Final release environment check',style:Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height:8),
        Text('This check reports the real build state. Missing APK/AAB files are never treated as ready.'),
        const SizedBox(height:16),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[
          Icon(ready?Icons.verified:Icons.warning_amber_rounded,size:34),const SizedBox(width:12),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(ready?'READY FOR SOURCE RELEASE':'NOT READY FOR SOURCE RELEASE',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
            const SizedBox(height:4),
            Text('Preflight version ${d?['version']??'—'}'),
          ])),
        ]))),
        const SizedBox(height:8),
        for(final c in checks) checkRow(c),
        const SizedBox(height:8),
        Card(child:ListTile(leading:const Icon(Icons.android),title:const Text('APK available'),trailing:Text(d?['apkAvailable']==true?'YES':'NO'))),
        Card(child:ListTile(leading:const Icon(Icons.shop),title:const Text('AAB available'),trailing:Text(d?['aabAvailable']==true?'YES':'NO'))),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:loading?null:run,icon:const Icon(Icons.fact_check),label:const Text('Run Preflight Again')),
      ]),
    );
  }
}
