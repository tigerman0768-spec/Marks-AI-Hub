import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiTimelineBuilderScreen extends StatefulWidget{
  final String projectId;
  const AiTimelineBuilderScreen({super.key,required this.projectId});
  @override State<AiTimelineBuilderScreen> createState()=>_AiTimelineBuilderScreenState();
}
class _AiTimelineBuilderScreenState extends State<AiTimelineBuilderScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? timeline;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/ai-timeline'));
      if(r.statusCode<300)setState(()=>timeline=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> buildTimeline()async{
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-timeline/build'));
    if(mounted&&r.statusCode<300){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('AI timeline built')));
      load();
    }
  }
  @override Widget build(BuildContext context){
    final t=timeline;
    return Scaffold(
      appBar:AppBar(title:const Text('AI Timeline Builder'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
      t==null?const Center(child:Text('Unable to build AI timeline.')):
      Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:buildTimeline,icon:const Icon(Icons.timeline),
            label:const Text('BUILD AI TIMELINE')))),
        Expanded(child:ListView.builder(
          padding:const EdgeInsets.all(12),itemCount:((t['items'] as List?)??[]).length,
          itemBuilder:(context,i){
            final m=Map<String,dynamic>.from(((t['items'] as List)[i]) as Map);
            return ListTile(
              leading:CircleAvatar(child:Text('${m['order']}')),
              title:Text('Shot ${m['shotNumber']??''}'),
              subtitle:Text('${m['transition']??'cut'} • ${NumberHelper.seconds(m['duration'])}'),
              trailing:const Icon(Icons.movie),
            );
          }))
      ])
    );
  }
}
class NumberHelper{
  static String seconds(dynamic v){
    final d=double.tryParse('$v')??0;
    return '${d.toStringAsFixed(1)}s';
  }
}
