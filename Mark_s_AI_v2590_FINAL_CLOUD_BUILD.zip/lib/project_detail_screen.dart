import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'production_workflow_screen.dart';

const String projectDetailApi = 'http://10.0.2.2:3000';

class ProjectDetailScreen extends StatefulWidget {
  final String projectId;
  const ProjectDetailScreen({super.key, required this.projectId});
  @override State<ProjectDetailScreen> createState() => _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends State<ProjectDetailScreen> {
  Map<String,dynamic>? data; bool loading=true; String? error;
  @override void initState(){super.initState(); load();}
  Future<void> load() async {
    setState((){loading=true;error=null;});
    try {
      final r=await http.get(Uri.parse('$projectDetailApi/api/projects/${widget.projectId}/overview'));
      if(r.statusCode!=200) throw Exception('Server returned ${r.statusCode}');
      setState((){data=jsonDecode(r.body) as Map<String,dynamic>;loading=false;});
    } catch(e){setState((){error=e.toString();loading=false;});}
  }
  Widget stat(String label,dynamic value)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Text('$value',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:4),Text(label)]))));
  Widget stage(String name,bool done)=>ListTile(dense:true,leading:Icon(done?Icons.check_circle:Icons.radio_button_unchecked),title:Text(name),trailing:Text(done?'Ready':'Not ready'));
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Project')),body:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Text(error!),const SizedBox(height:12),FilledButton(onPressed:load,child:const Text('Retry'))]));
    final p=data!; final c=Map<String,dynamic>.from(p['counts']??{}); final s=Map<String,dynamic>.from(p['stages']??{}); final tags=List<String>.from(p['tags']??const[]);
    return Scaffold(appBar:AppBar(title:Text(p['title']??'Project'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(16),children:[
      Text(p['title']??'Untitled Film',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:6),Text('${p['genre']} • ${p['style']} • ${p['length']} min'),const SizedBox(height:14),
      LinearProgressIndicator(value:(p['progress']??0)/100),const SizedBox(height:6),Text('Production progress: ${p['progress']}%'),const SizedBox(height:12),
      Row(children:[stat('Scenes',c['scenes']??0),stat('Characters',c['characters']??0),stat('Shot cards',c['shotCards']??0)]),
      Card(child:Column(children:[ListTile(title:const Text('Film status'),trailing:Text('${p['status']}')),ListTile(title:const Text('Format'),trailing:Text('${p['aspectRatio']} • ${p['resolution']}')),ListTile(title:const Text('Frame rate'),trailing:Text('${p['fps']} fps'))])),
      if(tags.isNotEmpty)Card(child:Padding(padding:const EdgeInsets.all(12),child:Wrap(spacing:8,children:tags.map((t)=>Chip(label:Text(t))).toList()))),
      Card(child:Column(children:[const ListTile(title:Text('Production stages')),stage('Story',s['story']==true),stage('Production plan',s['production']==true),stage('Video generation',s['video']==true),stage('AI edit',s['edit']==true),stage('Final finishing',s['finishing']==true),stage('Film Library',s['library']==true)])),
      const SizedBox(height:12),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProductionWorkflowScreen(projectId:widget.projectId))),icon:const Icon(Icons.movie_creation),label:const Text('Open Production Studio')),
    ])));
  }
}
