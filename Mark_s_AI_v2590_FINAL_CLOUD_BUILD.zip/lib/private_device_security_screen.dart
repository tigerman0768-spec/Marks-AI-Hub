import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PrivateDeviceSecurityScreen extends StatefulWidget {
  const PrivateDeviceSecurityScreen({super.key});
  @override State<PrivateDeviceSecurityScreen> createState() => _PrivateDeviceSecurityScreenState();
}

class _PrivateDeviceSecurityScreenState extends State<PrivateDeviceSecurityScreen> {
  static const base = 'http://10.0.2.2:3000';
  Map<String, dynamic>? data;
  bool loading = true;
  String? error;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final r = await http.get(Uri.parse('$base/api/private-device-security'));
      if (r.statusCode >= 300) throw Exception('Private security status unavailable');
      if (mounted) setState(() => data = jsonDecode(r.body) as Map<String, dynamic>);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Private Device & Security')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Private Device & Security', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          const Text('Mark’s AI is configured as a personal, private film studio. Secret values are never displayed here.'),
          const SizedBox(height: 18),
          if (loading) const Center(child: CircularProgressIndicator()),
          if (error != null) Card(child: ListTile(leading: const Icon(Icons.error_outline), title: const Text('Status unavailable'), subtitle: Text(error!))),
          if (data != null) ...[
            Card(child: ListTile(leading: const Icon(Icons.lock), title: const Text('Private mode'), subtitle: Text(data!['privateMode'] == true ? 'Enabled — personal use' : 'Not enabled'))),
            Card(child: ListTile(leading: const Icon(Icons.visibility_off), title: const Text('Secret protection'), subtitle: Text(data!['secretsExposed'] == false ? 'Protected — secret values are not returned' : 'Review configuration'))),
            const SizedBox(height: 8),
            Text('AI service configuration', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            _keyTile('OpenAI API', data!['apiKeysConfigured']?['openai'] == true),
            _keyTile('Runway API', data!['apiKeysConfigured']?['runway'] == true),
            _keyTile('GitHub access', data!['apiKeysConfigured']?['github'] == true),
            const SizedBox(height: 12),
            Card(child: ListTile(leading: const Icon(Icons.phone_android), title: const Text('Device runtime'), subtitle: Text('${data!['platform'] ?? 'Unknown'} • ${data!['nodeVersion'] ?? ''}'))),
          ],
          const SizedBox(height: 12),
          Card(child: ListTile(leading: const Icon(Icons.info_outline), title: const Text('Privacy rule'), subtitle: const Text('No API key, token, password or secret is shown in the app status response.'))),
        ]),
      ),
    );
  }

  Widget _keyTile(String name, bool configured) => Card(child: ListTile(
    leading: Icon(configured ? Icons.check_circle : Icons.radio_button_unchecked),
    title: Text(name),
    subtitle: Text(configured ? 'Configured' : 'Not configured'),
  ));
}
