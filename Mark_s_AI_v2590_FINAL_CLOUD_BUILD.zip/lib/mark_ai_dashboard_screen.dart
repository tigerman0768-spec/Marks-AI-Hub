import 'package:flutter/material.dart';
import 'film_library_screen.dart';
import 'film_projects_screen.dart';
import 'film_creator_screen.dart';
import 'final_render_worker_queue_screen.dart';
import 'app_completion_screen.dart';
import 'release_preflight_screen.dart';
import 'release_build_center_screen.dart';
import 'private_device_security_screen.dart';

class MarkAiDashboardScreen extends StatelessWidget{
 const MarkAiDashboardScreen({super.key});

 @override Widget build(BuildContext context){
  return Scaffold(
   appBar:AppBar(title:const Text("Mark's AI")),
   body:ListView(padding:const EdgeInsets.all(18),children:[
    Text("AI Filmmaking Studio",style:Theme.of(context).textTheme.headlineMedium),
    const SizedBox(height:6),
    Text("Create, render and manage your films from one place.",
      style:Theme.of(context).textTheme.bodyLarge),
    const SizedBox(height:24),
    _tile(context,Icons.movie_creation,"Create Film","Start a new film project",()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FilmCreatorScreen()))),
    _tile(context,Icons.folder_copy,"Projects","Manage your film projects",()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FilmProjectsScreen()))),
    _tile(context,Icons.queue_play_next,"Render Queue","View queued and active renders",
      ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FinalRenderWorkerQueueScreen()))),
    _tile(context,Icons.video_library,"Film Library","Watch and manage finished films",
      ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const FilmLibraryScreen()))),
    _tile(context,Icons.verified,"App Completion","Final readiness and launch centre",
      ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AppCompletionScreen()))),
    _tile(context,Icons.rocket_launch,"Release Build","Build and monitor the real Android APK + AAB",()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ReleaseBuildCenterScreen()))),
    _tile(context,Icons.security,"Private Device & Security","Personal-use privacy and secret protection status",()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PrivateDeviceSecurityScreen()))),
   ]),
  );
 }
 Widget _tile(BuildContext c,IconData icon,String title,String subtitle,VoidCallback onTap){
  return Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(title),
   subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_right),onTap:onTap));
 }
}
