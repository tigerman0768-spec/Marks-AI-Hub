import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FilmLevelDirectorScreen extends StatefulWidget{
  final String projectId;
  const FilmLevelDirectorScreen({super.key,required this.projectId});
  @override State<FilmLevelDirectorScreen> createState()=>_FilmLevelDirectorScreenState();
}
class _FilmLevelDirectorScreenState extends State<FilmLevelDirectorScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? report;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/director-pass'));
      if(r.statusCode<300)setState(()=>report=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final r=report;
    return Scaffold(
      appBar:AppBar(title:const Text('Film-Level AI Director'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
      r==null?const Center(child:Text('Unable to run director pass.')):
      ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(
          leading:CircleAvatar(child:Text('${r['overallScore']??0}')),
          title:Text('Director Score: ${r['overallScore']??0}/100'),
          subtitle:Text('Grade ${r['grade']??'—'} • ${r['readyForEdit']==true?'READY FOR EDIT':'NEEDS REVIEW'}'),
        )),
        const SizedBox(height:8),
        ...((r['notes'] as List?)??[]).map((n)=>ListTile(
          leading:const Icon(Icons.lightbulb_outline),title:Text(n.toString()))),
        const SizedBox(height:8),
        Text('Regeneration Candidates',style:Theme.of(context).textTheme.titleLarge),
        ...((r['regenerationCandidates'] as List?)??[]).map((x){
          final m=Map<String,dynamic>.from(x as Map);
          return ListTile(
            leading:const Icon(Icons.refresh),
            title:Text('Shot ${m['shotNumber']??''}'),
            subtitle:Text((m['reason'] as List?)?.join(', ')??'Needs review'),
          );
        })
      ])
    );
  }
}
