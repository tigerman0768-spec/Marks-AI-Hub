import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiEditingEngineScreen extends StatefulWidget{
  final String projectId;
  const AiEditingEngineScreen({super.key,required this.projectId});
  @override State<AiEditingEngineScreen> createState()=>_AiEditingEngineScreenState();
}
class _AiEditingEngineScreenState extends State<AiEditingEngineScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? edit;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/ai-edit'));
      if(r.statusCode<300)setState(()=>edit=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> apply()async{
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-edit/apply'));
    if(mounted&&r.statusCode<300){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('AI edit applied to timeline')));
      load();
    }
  }
  @override Widget build(BuildContext context){
    final e=edit;
    return Scaffold(
      appBar:AppBar(title:const Text('AI Automatic Editing'),actions:[
        IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))
      ]),
      body:loading?const Center(child:CircularProgressIndicator()):
      e==null?const Center(child:Text('Unable to build automatic edit.')):
      Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:apply,icon:const Icon(Icons.auto_awesome),
            label:const Text('APPLY AI EDIT')))),
        Padding(padding:const EdgeInsets.symmetric(horizontal:12),
          child:Align(alignment:Alignment.centerLeft,
            child:Text('${e['cutCount']??0} cuts • ${e['transitionCount']??0} transitions',
              style:Theme.of(context).textTheme.titleMedium))),
        Expanded(child:ListView.builder(
          padding:const EdgeInsets.all(12),itemCount:((e['items'] as List?)??[]).length,
          itemBuilder:(context,i){
            final m=Map<String,dynamic>.from(((e['items'] as List)[i]) as Map);
            return ListTile(
              leading:CircleAvatar(child:Text('${m['order']??i+1}')),
              title:Text('Shot ${m['shotNumber']??''} • ${m['pacing']??'normal'}'),
              subtitle:Text('${m['transition']??'cut'} ${m['transitionDuration']??0}s • ${m['transitionReason']??''}'),
            );
          }))
      ])
    );
  }
}
