import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String archiveVerifyApi='http://10.0.2.2:3000';
class FinalMasterArchiveVerifyScreen extends StatefulWidget{
  final String projectId;
  const FinalMasterArchiveVerifyScreen({super.key,required this.projectId});
  @override State<FinalMasterArchiveVerifyScreen> createState()=>_FinalMasterArchiveVerifyScreenState();
}
class _FinalMasterArchiveVerifyScreenState extends State<FinalMasterArchiveVerifyScreen>{
  Map<String,dynamic>? verification;bool busy=false;
  Future<void> check()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$archiveVerifyApi/api/projects/${widget.projectId}/final-render/archive-verification/check'));
    if(!mounted)return;
    final b=jsonDecode(r.body);setState(()=>verification=b['verification'] as Map<String,dynamic>?;busy=false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Archive verified.':'Archive verification failed.')));
  }
  @override Widget build(BuildContext context){
    final ok=verification?['verified']==true;
    final blockers=(verification?['blockers'] as List?)?.map((e)=>e.toString()).toList()??[];
    return Scaffold(appBar:AppBar(title:const Text('Archive Verification')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ok?Icons.verified:Icons.warning),
        title:Text(ok?'ARCHIVE VERIFIED':'ARCHIVE NOT VERIFIED'),
        subtitle:Text(ok?'The archived evidence matches the current source file.':'Run a live integrity check.'))),
      if(verification!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Archive: ${verification?['archiveId']??''}'),
        Text('Bytes: ${verification?['currentBytes']??0}'),
        SelectableText('SHA-256: ${verification?['currentSha256']??''}'),
        if(blockers.isNotEmpty)...[const SizedBox(height:10),...blockers.map((x)=>Text('• $x'))]
      ]))),
      FilledButton.icon(onPressed:busy?null:check,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.security),
        label:Text(busy?'Checking…':'Verify Archive'))
    ]));
  }
}
