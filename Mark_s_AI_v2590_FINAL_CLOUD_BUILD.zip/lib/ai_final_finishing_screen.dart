import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiFinalFinishingScreen extends StatefulWidget{
  final String projectId;
  const AiFinalFinishingScreen({super.key,required this.projectId});
  @override State<AiFinalFinishingScreen> createState()=>_AiFinalFinishingScreenState();
}
class _AiFinalFinishingScreenState extends State<AiFinalFinishingScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; Map<String,dynamic>? result;
  Future<void> finish()async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-finish'));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Final film finished')));
      }
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context){
    final a=Map<String,dynamic>.from(result?['audioTracks'] as Map? ?? {});
    return Scaffold(appBar:AppBar(title:const Text('AI Final Finishing')),
      body:Padding(padding:const EdgeInsets.all(20),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const Icon(Icons.movie_filter,size:72),
          const SizedBox(height:16),
          const Text('Combine the transitioned film with available audio and prepare the final MP4.',
            textAlign:TextAlign.center),
          const SizedBox(height:20),
          FilledButton.icon(onPressed:loading?null:finish,icon:const Icon(Icons.done_all),
            label:Text(loading?'FINISHING…':'FINISH FINAL FILM')),
          if(result!=null)...[
            const SizedBox(height:20),
            Text('Music: ${a['music']==true?'yes':'no'} • Dialogue: ${a['dialogue']==true?'yes':'no'} • SFX: ${a['sfx']==true?'yes':'no'}'),
            const SizedBox(height:8),
            Text('${result!['outputPath']??''}',textAlign:TextAlign.center)
          ]
        ])));
  }
}
