import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class FinalFilmPlayerScreen extends StatefulWidget{
 final String jobId,title;
 const FinalFilmPlayerScreen({super.key,required this.jobId,this.title='Final Film'});
 @override State<FinalFilmPlayerScreen> createState()=>_FinalFilmPlayerScreenState();
}
class _FinalFilmPlayerScreenState extends State<FinalFilmPlayerScreen>{
 static const base='http://10.0.2.2:3000';
 VideoPlayerController? controller;
 bool loading=true;String error='';
 @override void initState(){super.initState();_open();}
 Future<void> _open()async{
  try{
   final c=VideoPlayerController.networkUrl(Uri.parse('$base/api/final-render/jobs/${widget.jobId}/play'));
   await c.initialize(); if(!mounted){await c.dispose();return;}
   setState(()=>controller=c); await c.play();
  }catch(e){if(mounted)setState(()=>error=e.toString());}
  if(mounted)setState(()=>loading=false);
 }
 @override void dispose(){controller?.dispose();super.dispose();}
 @override Widget build(BuildContext context){
  final c=controller;
  return Scaffold(appBar:AppBar(title:Text(widget.title)),body:Center(
   child:error.isNotEmpty?Padding(padding:const EdgeInsets.all(20),child:Text(error,textAlign:TextAlign.center)):
   loading?const CircularProgressIndicator():
   c==null?const Text('Film unavailable'):
   Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c)),
    VideoProgressIndicator(c,allowScrubbing:true),
    Row(mainAxisAlignment:MainAxisAlignment.center,children:[
     IconButton(icon:Icon(c.value.isPlaying?Icons.pause:Icons.play_arrow),onPressed:()=>setState(()=>c.value.isPlaying?c.pause():c.play())),
    ]),
   ])));
 }
}
