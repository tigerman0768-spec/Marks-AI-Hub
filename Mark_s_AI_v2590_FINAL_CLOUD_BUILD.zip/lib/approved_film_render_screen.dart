import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String approvedRenderApi='http://10.0.2.2:3000';

class ApprovedFilmRenderScreen extends StatefulWidget{
  final String projectId;
  const ApprovedFilmRenderScreen({super.key,required this.projectId});
  @override State<ApprovedFilmRenderScreen> createState()=>_ApprovedFilmRenderScreenState();
}
class _ApprovedFilmRenderScreenState extends State<ApprovedFilmRenderScreen>{
  Map<String,dynamic>? job; bool loading=true; Timer? timer;
  @override void initState(){super.initState();load();timer=Timer.periodic(const Duration(seconds:3),(_)=>load());}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$approvedRenderApi/api/projects/${widget.projectId}/approved-film-render/status'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>job=jsonDecode(r.body)['job'] as Map<String,dynamic>?);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> start()async{
    final r=await http.post(Uri.parse('$approvedRenderApi/api/projects/${widget.projectId}/approved-film-render/start'),
      headers:{'Content-Type':'application/json'},body:jsonEncode({}));
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==202?'Film render started.':'Render could not start.')));
    load();
  }
  @override void dispose(){timer?.cancel();super.dispose();}
  @override Widget build(BuildContext context){
    final s=job?['status']??'not started';
    return Scaffold(appBar:AppBar(title:const Text('Render Approved Film')),
      body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(leading:Icon(s=='completed'?Icons.check_circle:s=='failed'?Icons.error:Icons.movie),
          title:Text('Render: $s'),subtitle:Text('${job?['clipCount']??0} clips'))),
        FilledButton.icon(onPressed:s=='running'?null:start,icon:const Icon(Icons.movie_creation),label:Text(s=='running'?'Rendering…':'Render Film')),
        if(job?['outputPath']!=null)Card(child:Padding(padding:const EdgeInsets.all(12),child:SelectableText('Output: ${job?['outputPath']}'))),
        if(job?['bytes']!=null)Text('Size: ${job?['bytes']} bytes'),
        if(job?['error']!=null)Text('Error: ${job?['error']}'),
      ]));
  }
}
