import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class FinalAudioScreen extends StatefulWidget{
  final String projectId;
  const FinalAudioScreen({super.key,required this.projectId});
  @override State<FinalAudioScreen> createState()=>_FinalAudioScreenState();
}
class _FinalAudioScreenState extends State<FinalAudioScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; String? error; Map<String,dynamic> data={};
  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/final-audio-status'));
      if(r.statusCode>=300)throw Exception('Audio status unavailable');
      data=jsonDecode(r.body) as Map<String,dynamic>;
    }catch(e){error=e.toString();}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> _subtitles() async{
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/subtitles/build'),
        headers:{'Content-Type':'application/json'});
      if(r.statusCode>=300)throw Exception('Subtitle generation failed (${r.statusCode})');
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Subtitles prepared')));
      await _load();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    if(error!=null)return Scaffold(appBar:AppBar(title:const Text('Final Audio')),body:Center(child:Text(error!)));
    return Scaffold(appBar:AppBar(title:const Text('Audio & Subtitles')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text('Final Audio & Subtitles',style:Theme.of(c).textTheme.headlineMedium),
        const SizedBox(height:18),
        _status(Icons.record_voice_over,'Dialogue','${data['dialogueTracks']??0} dialogue tracks'),
        _status(Icons.music_note,'Music',data['musicConfigured']==true?'Configured':'Not configured'),
        _status(Icons.graphic_eq,'Sound Effects',data['sfxConfigured']==true?'Configured':'Not configured'),
        _status(Icons.subtitles,'Subtitles',data['subtitlesConfigured']==true?'Prepared':'Not prepared'),
        const SizedBox(height:18),
        FilledButton.icon(onPressed:_subtitles,icon:const Icon(Icons.subtitles),label:const Text('BUILD SUBTITLES')),
      ]));
  }
  Widget _status(IconData icon,String title,String value)=>Card(child:ListTile(
    leading:Icon(icon),title:Text(title),subtitle:Text(value)));
}
