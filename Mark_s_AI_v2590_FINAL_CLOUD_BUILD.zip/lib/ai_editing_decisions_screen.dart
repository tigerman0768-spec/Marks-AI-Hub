import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AiEditingDecisionsScreen extends StatefulWidget{
  final String projectId;
  const AiEditingDecisionsScreen({super.key,required this.projectId});
  @override State<AiEditingDecisionsScreen> createState()=>_AiEditingDecisionsScreenState();
}
class _AiEditingDecisionsScreenState extends State<AiEditingDecisionsScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=true; Map<String,dynamic>? data;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    setState(()=>loading=true);
    try{
      final r=await http.get(Uri.parse('$base/api/projects/${widget.projectId}/editing-decisions'));
      if(r.statusCode<300)setState(()=>data=Map<String,dynamic>.from(jsonDecode(r.body)));
    }catch(_){}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> apply()async{
    final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/editing-decisions/apply'));
    if(mounted&&r.statusCode<300){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('AI editing decisions saved')));
      load();
    }
  }
  @override Widget build(BuildContext context){
    final items=(data?['items'] as List?)??[];
    return Scaffold(
      appBar:AppBar(title:const Text('AI Editing Decisions')),
      body:loading?const Center(child:CircularProgressIndicator()):
      Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,
          child:FilledButton.icon(onPressed:apply,icon:const Icon(Icons.movie_edit),
            label:const Text('APPLY DECISIONS')))),
        Expanded(child:ListView.builder(
          itemCount:items.length,itemBuilder:(c,i){
            final x=Map<String,dynamic>.from(items[i] as Map);
            return ListTile(
              leading:CircleAvatar(child:Text('${x['order']??i+1}')),
              title:Text('${x['pacingBeat']??'general'} • ${x['targetDuration']??0}s'),
              subtitle:Text('${x['reason']??''}'),
            );
          }))
      ])
    );
  }
}
