import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String releaseExportApi='http://10.0.2.2:3000';
class ReleasedFilmDeliveryExportScreen extends StatefulWidget{
  final String projectId;
  const ReleasedFilmDeliveryExportScreen({super.key,required this.projectId});
  @override State<ReleasedFilmDeliveryExportScreen> createState()=>_ReleasedFilmDeliveryExportScreenState();
}
class _ReleasedFilmDeliveryExportScreenState extends State<ReleasedFilmDeliveryExportScreen>{
  Map<String,dynamic>? exportRecord;Map<String,dynamic>? manifest;bool busy=false;
  Future<void> createExport()async{
    setState(()=>busy=true);
    final r=await http.post(Uri.parse('$releaseExportApi/api/projects/${widget.projectId}/final-render/library-release/delivery-export/create'));
    if(!mounted)return;
    final b=jsonDecode(r.body);
    setState((){
      exportRecord=b['export'] as Map<String,dynamic>?;
      manifest=b['manifest'] as Map<String,dynamic>?;
      busy=false;
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Release export is ready.':'Release export blocked.')));
  }
  @override Widget build(BuildContext context){
    final ready=exportRecord?['status']=='export_ready';
    return Scaffold(appBar:AppBar(title:const Text('Release Delivery Export')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(leading:Icon(ready?Icons.outbox:Icons.lock),
        title:Text(ready?'EXPORT READY':'EXPORT NOT READY'),
        subtitle:Text(ready?'Export ID: ${exportRecord?['exportId']??''}':'Create and verify the delivery package first.'))),
      if(ready&&manifest!=null) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Title: ${manifest?['title']??''}'),
        Text('Film file: ${manifest?['sourcePath']??''}'),
        Text('Size: ${manifest?['bytes']??0} bytes'),
        SelectableText('SHA-256: ${manifest?['sha256']??''}'),
        const SizedBox(height:10),
        Text('Manifest: ${exportRecord?['manifestPath']??''}')
      ]))),
      FilledButton.icon(onPressed:busy?null:createExport,
        icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.outbox),
        label:Text(busy?'Preparing…':'Prepare Release Export'))
    ]));
  }
}
