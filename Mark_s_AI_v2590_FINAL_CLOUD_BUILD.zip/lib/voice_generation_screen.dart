import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class VoiceGenerationScreen extends StatefulWidget{
  final String projectId;
  const VoiceGenerationScreen({super.key,required this.projectId});
  @override State<VoiceGenerationScreen> createState()=>_VoiceGenerationScreenState();
}
class _VoiceGenerationScreenState extends State<VoiceGenerationScreen>{
  static const base='http://10.0.2.2:3000';
  bool loading=false; bool extracting=false; bool generatingDialogue=false; Map<String,dynamic>? result;


  Future<void> generateAIDialogue() async{
    setState(()=>generatingDialogue=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/ai-dialogue/generate'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'replace':true}));
      if(r.statusCode<300 && mounted){
        final data=Map<String,dynamic>.from(jsonDecode(r.body));
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('${data['created']??0} AI dialogue lines generated')));
      }else if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>generatingDialogue=false);
  }

  Future<void> extractDialogue() async{
    setState(()=>extracting=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/screenplay/extract-dialogue'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({'replace':true}));
      if(r.statusCode<300 && mounted){
        final data=Map<String,dynamic>.from(jsonDecode(r.body));
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content:Text('${data['created']??0} dialogue lines added to the timeline')));
      }else if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    if(mounted)setState(()=>extracting=false);
  }

  Future<void> generate() async{
    setState(()=>loading=true);
    try{
      final r=await http.post(Uri.parse('$base/api/projects/${widget.projectId}/voice-generation'),
        headers:{'Content-Type':'application/json'},body:jsonEncode({}));
      if(r.statusCode<300){
        setState(()=>result=Map<String,dynamic>.from(jsonDecode(r.body)));
      }else if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.body)));
      }
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));
    }
    if(mounted)setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('AI Voice Generation')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Icon(Icons.record_voice_over,size:72),
      const SizedBox(height:12),
      const Text('Generate character voices from your dialogue tracks.',
        style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      const Text('The server uses the configured OpenAI text-to-speech provider. Each dialogue line is generated as an individual audio asset.'),
      const SizedBox(height:20),
      FilledButton.icon(
        onPressed:generatingDialogue?null:generateAIDialogue,
        icon:generatingDialogue?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
        label:Text(generatingDialogue?'GENERATING...':'GENERATE AI DIALOGUE'),
      ),
      const SizedBox(height:10),
      OutlinedButton.icon(
        onPressed:extracting?null:extractDialogue,
        icon:extracting?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_stories),
        label:Text(extracting?'EXTRACTING...':'EXTRACT DIALOGUE FROM SCREENPLAY'),
      ),
      const SizedBox(height:10),
      FilledButton.icon(
        onPressed:loading?null:generate,
        icon:loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.auto_awesome),
        label:Text(loading?'GENERATING...':'GENERATE VOICES'),
      ),
      if(result!=null)...[
        const SizedBox(height:20),
        Card(child:ListTile(
          title:Text('${result!['completed']??0} voices generated'),
          subtitle:Text('${result!['failed']??0} failed'),
        )),
        ...((result!['jobs'] as List?)??[]).map((e){
          final j=Map<String,dynamic>.from(e);
          return ListTile(
            leading:Icon(j['status']=='completed'?Icons.check_circle:Icons.error),
            title:Text(j['character']??'Speaker'),
            subtitle:Text(j['text']??''),
          );
        }),
      ]
    ]),
  );
}
