import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String renderBridgeApi='http://10.0.2.2:3000';

class FinalCutRenderBridgeScreen extends StatefulWidget{
  final String projectId;
  const FinalCutRenderBridgeScreen({super.key,required this.projectId});
  @override State<FinalCutRenderBridgeScreen> createState()=>_FinalCutRenderBridgeScreenState();
}
class _FinalCutRenderBridgeScreenState extends State<FinalCutRenderBridgeScreen>{
  Map<String,dynamic> readiness={};Map<String,dynamic> input={};bool loading=true,preparing=false;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    final a=await http.get(Uri.parse('$renderBridgeApi/api/projects/${widget.projectId}/final-cut/render-readiness'));
    final b=await http.get(Uri.parse('$renderBridgeApi/api/projects/${widget.projectId}/final-render-input'));
    if(mounted)setState((){
      if(a.statusCode==200)readiness=jsonDecode(a.body);
      if(b.statusCode==200)input=jsonDecode(b.body);
      loading=false;
    });
  }
  Future<void> prepare()async{
    setState(()=>preparing=true);
    final r=await http.post(Uri.parse('$renderBridgeApi/api/projects/${widget.projectId}/final-cut/render-input'));
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
      r.statusCode==201?'Final render input prepared.':'Final render input is not ready.')));
    setState(()=>preparing=false);load();
  }
  @override Widget build(BuildContext context){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final ready=readiness['ready']==true, done=input['ready']==true;
    return Scaffold(appBar:AppBar(title:const Text('Final Cut → Render')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(leading:Icon(ready?Icons.check_circle:Icons.warning),
          title:Text(ready?'Ready for render':'Render readiness'),
          subtitle:Text('${readiness['availableFiles']??0}/${readiness['clipCount']??0} source files available'))),
        Card(child:ListTile(leading:Icon(done?Icons.done_all:Icons.pending),
          title:Text(done?'Render input prepared':'Prepare render input'),
          subtitle:const Text('Use the final reviewed sequence as the render source.'))),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:ready&&!done&&!preparing?prepare:null,
          icon:preparing?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.movie_creation),
          label:Text(preparing?'Preparing…':'Prepare Render Input'))
      ]));
  }
}
