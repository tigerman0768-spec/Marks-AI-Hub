import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'project_delete_screen.dart';
import 'project_duplicate_screen.dart';
import 'project_export_screen.dart';
import 'project_import_screen.dart';
import 'project_favourite_screen.dart';
import 'new_project_template_screen.dart';

class ProjectDashboardScreen extends StatefulWidget{
 const ProjectDashboardScreen({super.key});
 @override State<ProjectDashboardScreen> createState()=>_ProjectDashboardScreenState();
}
class _ProjectDashboardScreenState extends State<ProjectDashboardScreen>{
 static const base='http://10.0.2.2:3000';bool loading=true;Map<String,dynamic> data={};
 Future<void> load()async{setState(()=>loading=true);try{
  final r=await http.get(Uri.parse('$base/api/projects/dashboard'));
  if(r.statusCode>=300)throw Exception('Dashboard load failed');
  setState(()=>data=jsonDecode(r.body));
 }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
 if(mounted)setState(()=>loading=false);}
 @override void initState(){super.initState();load();}
 @override Widget build(BuildContext c){
  final s=Map<String,dynamic>.from(data['summary']??{});
  final ps=List<Map<String,dynamic>>.from((data['projects']??[]).map((x)=>Map<String,dynamic>.from(x)));
  return Scaffold(appBar:AppBar(title:const Text('Film Projects'),actions:[IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const NewProjectTemplateScreen())).then((_){load();}),icon:const Icon(Icons.movie_creation)),IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const ProjectImportScreen())).then((_){load();}),icon:const Icon(Icons.upload)),IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
   body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
    Text('Project Dashboard',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:12),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Wrap(spacing:18,runSpacing:12,children:[
      Text('Total ${s['total']??0}'),Text('Producing ${s['producing']??0}'),Text('Review ${s['review']??0}'),Text('Complete ${s['complete']??0}')
    ]))),const SizedBox(height:12),
    if(ps.isEmpty)const Card(child:ListTile(title:Text('No film projects yet'),subtitle:Text('Create your first film from the main dashboard.'))),
    ...ps.map((p)=>Card(child:ListTile(leading:const Icon(Icons.movie),title:Text(p['title']??'Untitled Film'),
      subtitle:Text('${p['status']??'draft'} • ${p['genre']??'Drama'} • ${p['length']??5} min'),
      trailing:Wrap(spacing:0,children:[IconButton(icon:const Icon(Icons.star_border),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ProjectFavouriteScreen(projectId:p['id'],title:p['title']??'Untitled Film')))),IconButton(icon:const Icon(Icons.download),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ProjectExportScreen(projectId:p['id'],title:p['title']??'Untitled Film')))),IconButton(icon:const Icon(Icons.copy),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ProjectDuplicateScreen(projectId:p['id'],title:p['title']??'Untitled Film')))),IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>showDialog(context:c,builder:(d)=>AlertDialog(title:const Text('Delete project?'),content:Text(p['title']??'Untitled Film'),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('CANCEL')),FilledButton(onPressed:()async{Navigator.pop(d);final changed=await Navigator.push<bool>(c,MaterialPageRoute(builder:(_)=>ProjectDeleteScreen(projectId:p['id'],title:p['title']??'Untitled Film')));if(changed==true)load();},child:const Text('CONTINUE'))]))))
   ]));
 }
}
