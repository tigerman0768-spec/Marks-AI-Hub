import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String approvedTimelineApi='http://10.0.2.2:3000';

class ApprovedClipsTimelineScreen extends StatefulWidget{
  final String projectId;
  const ApprovedClipsTimelineScreen({super.key,required this.projectId});
  @override State<ApprovedClipsTimelineScreen> createState()=>_ApprovedClipsTimelineScreenState();
}
class _ApprovedClipsTimelineScreenState extends State<ApprovedClipsTimelineScreen>{
  List<dynamic> clips=[]; List<dynamic> regenerations=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load()async{
    try{
      final r=await http.get(Uri.parse('$approvedTimelineApi/api/projects/${widget.projectId}/clips/review'));
      final g=await http.get(Uri.parse('$approvedTimelineApi/api/projects/${widget.projectId}/clips/regenerations'));
      if(!mounted)return;
      if(r.statusCode==200)setState(()=>clips=jsonDecode(r.body)['approvedGeneratedClips'] as List<dynamic>? ?? []);
      if(g.statusCode==200)setState(()=>regenerations=jsonDecode(g.body)['regenerations'] as List<dynamic>? ?? []);
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Future<void> checkRegen(String id)async{
    final r=await http.post(Uri.parse('$approvedTimelineApi/api/projects/${widget.projectId}/clips/regenerations/$id/check'));
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(r.statusCode==200?'Regeneration checked.':'Check failed.')));
    load();
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Approved Clips Timeline'),actions:[IconButton(onPressed:loading?null:load,icon:const Icon(Icons.refresh))]),
    body:loading?const Center(child:CircularProgressIndicator()):
      ListView(padding:const EdgeInsets.all(12),children:[
        if(regenerations.isNotEmpty) ...[
          const Text('Regenerations',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
          ...regenerations.map((x){
            final m=x as Map<String,dynamic>;
            return Card(child:ListTile(title:Text('Shot ${m['sourceClipId']??''}'),subtitle:Text('${m['status']??'submitted'} • ${m['taskId']??''}'),
              trailing:IconButton(icon:const Icon(Icons.sync),onPressed:()=>checkRegen('${m['regenerationId']}'))));
          }),
          const Divider()
        ],
        const Text('Approved clips',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        if(clips.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('Keep some clips to build your film timeline.')),
        ...List.generate(clips.length,(i){
          final x=clips[i] as Map<String,dynamic>;
          return Card(child:ListTile(leading:CircleAvatar(child:Text('${i+1}')),title:Text('Shot ${x['shotId']??x['clipId']??''}'),subtitle:Text('${x['provider']??'AI'} • ${x['bytes']??0} bytes'),trailing:const Icon(Icons.drag_handle)));
        })
      ]));
}
