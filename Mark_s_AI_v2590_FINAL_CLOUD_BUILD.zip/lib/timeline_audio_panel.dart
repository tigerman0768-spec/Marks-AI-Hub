import 'package:flutter/material.dart';

class TimelineAudioPanel extends StatelessWidget{
  final double clipVolume,musicVolume; final bool musicEnabled;
  final ValueChanged<Map<String,dynamic>> onChanged;
  const TimelineAudioPanel({super.key,required this.clipVolume,required this.musicVolume,
    required this.musicEnabled,required this.onChanged});
  @override Widget build(BuildContext context)=>Card(
    child:Padding(padding:const EdgeInsets.all(16),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Timeline Audio',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        Row(children:[const Expanded(child:Text('Original clip audio')),
          Text('${(clipVolume*100).round()}%')]),
        Slider(min:0,max:2,value:clipVolume,onChanged:(v)=>onChanged({'clipVolume':v,'musicVolume':musicVolume,'musicEnabled':musicEnabled})),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Background music'),
          value:musicEnabled,onChanged:(v)=>onChanged({'clipVolume':clipVolume,'musicVolume':musicVolume,'musicEnabled':v})),
        if(musicEnabled)...[
          Row(children:[const Expanded(child:Text('Music volume')),Text('${(musicVolume*100).round()}%')]),
          Slider(min:0,max:1,value:musicVolume,onChanged:(v)=>onChanged({'clipVolume':clipVolume,'musicVolume':v,'musicEnabled':musicEnabled})),
          const Text('Music file is configured by the render request/server project settings.')
        ],
      ]));
}
