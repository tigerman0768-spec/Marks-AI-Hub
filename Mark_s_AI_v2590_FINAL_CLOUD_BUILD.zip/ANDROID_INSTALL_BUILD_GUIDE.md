# Mark's AI — installable Android build

This milestone adds the Android release scaffold and reproducible build scripts.

On a machine with Flutter installed:

1. Open the Mark's AI project directory.
2. Run `flutter create .` if the Android host has not yet been generated.
3. Run `flutter pub get`.
4. Run `flutter build apk --release`.
5. Install `build/app/outputs/flutter-apk/app-release.apk` on an Android phone.
6. For Google Play, run `flutter build appbundle --release` and upload the AAB.

This package is intentionally not labelled as an APK: no APK was compiled in the
current environment.
