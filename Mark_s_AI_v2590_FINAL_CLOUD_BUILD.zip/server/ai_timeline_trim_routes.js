const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {renderAiEditedTimeline}=require("./ai_timeline_trim_renderer");
function registerAiTimelineTrimRoutes(app){
  app.post("/api/projects/:id/ai-edit/render",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await renderAiEditedTimeline(project);
      saveProject(dir,{...project,renderedAiEdit:result,status:"ai_edit_rendered"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-edit/render", (req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.renderedAiEdit||{renderedCount:0,items:[]});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiTimelineTrimRoutes};
