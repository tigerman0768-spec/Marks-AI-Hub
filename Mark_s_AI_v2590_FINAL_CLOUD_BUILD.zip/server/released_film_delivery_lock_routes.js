const path=require("path");
const {getProject}=require("./film_projects");
const {lockReleasedFilmDelivery}=require("./released_film_delivery_lock");
function registerReleasedFilmDeliveryLockRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-lock",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,lock:p.finalMasterReleasedFilmDeliveryLock||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-lock/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=lockReleasedFilmDelivery(p);
    res.status(result.locked?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliveryLockRoutes};
