const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function registerApprovedFilmLibraryMediaRoutes(app){
  app.get("/api/projects/:id/approved-film/library/media",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const film=p.approvedFilmLibraryFilm;
    if(!film?.outputPath)return res.status(404).json({error:"film not in library"});
    if(!fs.existsSync(film.outputPath))return res.status(404).json({error:"film file missing"});
    res.sendFile(path.resolve(film.outputPath));
  });
}
module.exports={registerApprovedFilmLibraryMediaRoutes};
