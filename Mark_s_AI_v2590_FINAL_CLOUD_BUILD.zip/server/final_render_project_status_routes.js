const {getFinalRenderProjectStatus}=require("./final_render_project_status");
function registerFinalRenderProjectStatusRoutes(app){
  app.get("/api/projects/:id/final-render-status",(req,res)=>{
    const status=getFinalRenderProjectStatus(req.params.id);
    if(!status)return res.status(404).json({error:"project not found"});
    res.json(status);
  });
}
module.exports={registerFinalRenderProjectStatusRoutes};
