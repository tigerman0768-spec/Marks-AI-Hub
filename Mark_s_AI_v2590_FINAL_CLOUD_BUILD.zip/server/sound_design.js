const MOODS = {
  action:{music:"tense cinematic pulse",sfx:["impact","footsteps","whoosh"],intensity:.9},
  horror:{music:"dark atmospheric drone",sfx:["distant creak","low hit","room tone"],intensity:.8},
  romance:{music:"warm emotional piano",sfx:["soft ambience"],intensity:.45},
  comedy:{music:"light playful rhythm",sfx:["comic accent"],intensity:.4},
  drama:{music:"emotional cinematic underscore",sfx:["room tone"],intensity:.55},
  suspense:{music:"slow tension build",sfx:["subtle riser","ambient room tone"],intensity:.7},
  fantasy:{music:"magical cinematic orchestra",sfx:["wind","sparkle ambience"],intensity:.65},
  neutral:{music:"subtle cinematic underscore",sfx:["room tone"],intensity:.35}
};
function detectMood(scene={}) {
  const text=`${scene.genre||""} ${scene.mood||""} ${scene.emotion||""}`.toLowerCase();
  return Object.keys(MOODS).find(k=>text.includes(k))||"neutral";
}
function buildSoundDesign(scene={}) {
  const mood=detectMood(scene), preset=MOODS[mood], duration=Number(scene.duration||5);
  return {
    mood,
    music:{description:preset.music,start:0,duration,volume:preset.intensity*.35,
      fadeIn:Math.min(1.5,duration/3),fadeOut:Math.min(1.5,duration/3)},
    sfx:preset.sfx.map((description,i)=>({
      description,
      start:i===0?.2:Math.min(duration-.2,(duration/(preset.sfx.length+1))*(i+1)),
      duration:Math.min(2,duration),volume:preset.intensity*.8
    }))
  };
}
function buildFilmSoundPlan(scenes=[]) {
  let offset=0;
  const scenePlans=scenes.map(scene=>{
    const plan=buildSoundDesign(scene);
    const result={sceneId:scene.id||"",offset,...plan,
      music:{...plan.music,filmStart:offset},
      sfx:plan.sfx.map(x=>({...x,filmStart:offset+x.start}))};
    offset+=Number(scene.duration||5);
    return result;
  });
  return {duration:offset,scenes:scenePlans};
}
module.exports={detectMood,buildSoundDesign,buildFilmSoundPlan};
