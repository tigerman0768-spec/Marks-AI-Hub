const fs = require("fs");
const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerVideoGenerationLaunchRoutes(app) {
  app.post("/api/projects/:id/video-generation/launch", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const manifest = p.videoGenerationManifest;
    if (!manifest?.shots?.length) {
      return res.status(409).json({ error: "video generation manifest required" });
    }

    const providerConfigured = Boolean(
      process.env.RUNWAY_API_KEY || process.env.VIDEO_API_KEY
    );
    const dryRun = req.body?.dryRun === true || !providerConfigured;

    const launch = {
      id: `launch-${p.id}-${Date.now()}`,
      projectId: p.id,
      manifestId: manifest.id,
      provider: manifest.provider || "runway",
      dryRun,
      status: "queued",
      createdAt: new Date().toISOString(),
      shots: manifest.shots.map(s => ({
        id: s.id,
        scene: s.scene,
        status: "pending"
      }))
    };

    p.videoGenerationLaunch = launch;
    p.videoGenerationLaunchHistory = Array.isArray(p.videoGenerationLaunchHistory)
      ? p.videoGenerationLaunchHistory.concat([launch])
      : [launch];
    saveProject(dir, p);

    // This endpoint records an auditable launch request. The existing provider
    // orchestrator remains responsible for submitting actual provider jobs.
    res.status(202).json({
      projectId: p.id,
      launchId: launch.id,
      provider: launch.provider,
      dryRun,
      status: launch.status,
      shotCount: launch.shots.length,
      message: dryRun
        ? "Launch recorded in dry-run mode; no provider job was submitted."
        : "Launch recorded; provider submission is handled by the generation orchestrator."
    });
  });
}

module.exports = { registerVideoGenerationLaunchRoutes };
