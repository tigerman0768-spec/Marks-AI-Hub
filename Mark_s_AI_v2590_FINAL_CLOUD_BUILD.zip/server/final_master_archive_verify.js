const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function verifyArchive(project){
  const a=project.finalMasterDeliveryArchive;
  if(!a?.archiveId)return {verified:false,blockers:["delivery archive does not exist"]};
  const output=a.sourcePath||project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))return {verified:false,blockers:["archived source file is missing"]};
  const stat=fs.statSync(output);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  const blockers=[];
  if(sha!==a.sha256)blockers.push("source hash differs from archived hash");
  if(Number(stat.size)!==Number(a.bytes))blockers.push("source size differs from archived size");
  const verified=blockers.length===0;
  project.finalMasterArchiveVerification={
    verified,archiveId:a.archiveId,checkedAt:new Date().toISOString(),
    currentBytes:stat.size,currentSha256:sha,blockers
  };
  saveProject(path.join(process.cwd(),"projects"),project);
  return project.finalMasterArchiveVerification;
}
module.exports={verifyArchive};
