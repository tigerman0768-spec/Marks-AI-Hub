const path=require("path");
const {getProject}=require("./film_projects");
const {getRecoveryCandidates}=require("./final_render_recovery");

function getFinalRenderProjectStatus(projectId){
  const project=getProject(path.join(process.cwd(),"projects"),projectId);
  if(!project)return null;
  const jobs=getRecoveryCandidates().filter(j=>String(j.projectId)===String(projectId));
  const latest=jobs.sort((a,b)=>Date.parse(b.updatedAt||0)-Date.parse(a.updatedAt||0))[0]||null;
  const result=project.smartOneClickFinalRender||null;
  return {
    projectId,
    status:project.status||"draft",
    finalRenderStatus:result?.status||null,
    progressId:result?.progressId||latest?.id||null,
    recoveryStatus:latest?.status||null,
    recoveryAttempts:Number(latest?.recoveryAttempts||0),
    recoveryMessage:latest?.recoveryMessage||null,
    outputPath:result?.outputPath||latest?.outputPath||null,
    updatedAt:project.updatedAt||latest?.updatedAt||null
  };
}
module.exports={getFinalRenderProjectStatus};
