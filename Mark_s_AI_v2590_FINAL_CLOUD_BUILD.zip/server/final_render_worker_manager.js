const path=require("path");
const {getCandidates,recoverFinalRenderJobs}=require("./final_render_recovery");
const {getProcessState}=require("./final_render_process_registry");
const DIR=path.join(process.cwd(),"final-render-jobs");

function classify(job){
  const state=getProcessState(job.id);
  if(state?.status==="running"&&state.pid)return "owned_running";
  if(job.status==="running"||job.status==="recoverable"||job.status==="recovering")return "restartable";
  if(job.status==="recovery_exhausted")return "blocked";
  return "inactive";
}
function inspectWorkers(){
  return getCandidates().map(job=>({...job,workerState:classify(job),process:getProcessState(job.id)}));
}
async function takeOverInterruptedJobs(options={}){
  const workers=inspectWorkers();
  const restartable=workers.filter(x=>x.workerState==="restartable");
  const results=[];
  for(const job of restartable){
    results.push(...await recoverFinalRenderJobs({
      outputDir:options.outputDir,
      onlyJobId:job.id
    }));
  }
  return results;
}
module.exports={inspectWorkers,takeOverInterruptedJobs};
