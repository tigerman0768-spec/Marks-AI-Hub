const path=require("path");
const {getProject}=require("./film_projects");
const {lockFinalMaster}=require("./final_master_delivery_lock");
function registerFinalMasterDeliveryLockRoutes(app){
  app.get("/api/projects/:id/final-render/lock",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,lock:p.finalMasterLock||null});
  });
  app.post("/api/projects/:id/final-render/lock",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=lockFinalMaster(p);
    res.status(result.locked?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterDeliveryLockRoutes};
