const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {finishFilm}=require("./ai_final_finishing");
function registerAiFinalFinishingRoutes(app){
  app.post("/api/projects/:id/ai-finish",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await finishFilm(project);
      saveProject(dir,{...project,aiFinalFinish:result,status:"ai_final_finished"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-finish",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.aiFinalFinish||{outputPath:null});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiFinalFinishingRoutes};
