const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function versionFile(dir,projectId){return path.join(dir,`${projectId}.json`);}
function loadVersions(dir,projectId){
  const f=versionFile(dir,projectId);
  if(!fs.existsSync(f))return {projectId,versions:[],updatedAt:null};
  try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch{return {projectId,versions:[],updatedAt:null};}
}
function saveVersions(dir,projectId,versions){
  fs.mkdirSync(dir,{recursive:true});
  const record={projectId,versions,updatedAt:new Date().toISOString()};
  fs.writeFileSync(versionFile(dir,projectId),JSON.stringify(record,null,2));
  return record;
}
function snapshotClip(dir,projectId,job){
  const versionsDir=path.join(dir,projectId);
  fs.mkdirSync(versionsDir,{recursive:true});
  const versions=loadVersions(dir,projectId).versions;
  const number=versions.filter(v=>v.sourceJobId===job.id||v.shotKey===`${job.sceneId}:${job.shotNumber}`).length+1;
  const version={
    id:crypto.randomUUID(),projectId,sourceJobId:job.id,
    regenerationOf:job.regenerationOf||null,shotKey:`${job.sceneId}:${job.shotNumber}`,
    version:number,clipPath:job.clipPath||null,downloadStatus:job.downloadStatus||"pending",
    qualityStatus:job.qualityStatus||null,qualityReport:job.qualityReport||null,
    smartReview:job.smartReview||null,createdAt:new Date().toISOString()
  };
  versions.push(version); saveVersions(dir,projectId,versions); return version;
}
function groupByShot(record){
  const groups={};
  for(const v of record.versions||[]){
    (groups[v.shotKey] ||= []).push(v);
  }
  return Object.values(groups).map(items=>items.sort((a,b)=>a.version-b.version));
}
function chooseVersion(record,shotKey,version){
  const items=(record.versions||[]).filter(v=>v.shotKey===shotKey);
  return items.find(v=>Number(v.version)===Number(version))||null;
}
module.exports={loadVersions,saveVersions,snapshotClip,groupByShot,chooseVersion};
