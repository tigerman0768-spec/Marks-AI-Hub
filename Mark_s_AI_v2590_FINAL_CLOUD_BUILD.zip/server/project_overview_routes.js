const path = require('path');
const { getProject } = require('./film_projects');

function registerProjectOverviewRoutes(app) {
  app.get('/api/projects/:id/overview', (req, res) => {
    const p = getProject(path.join(process.cwd(), 'projects'), req.params.id);
    if (!p) return res.status(404).json({ error: 'project not found' });
    const scenes = Array.isArray(p.scenes) ? p.scenes : [];
    const shotCards = Array.isArray(p.shotCards) ? p.shotCards : [];
    const characters = Array.isArray(p.characters) ? p.characters : [];
    const tags = Array.isArray(p.tags) ? p.tags : [];
    const stages = {
      story: Boolean(p.idea || p.screenplay),
      production: Boolean(p.characterBible || p.storyboard || shotCards.length),
      video: Boolean(p.videoGeneration || p.videoGenerationStatus || p.generationJobs),
      edit: Boolean(p.timeline || p.finalTimeline || p.aiEditPlan),
      finishing: Boolean(p.finalFinishingPlan),
      library: Boolean(p.libraryId || p.finalFilm || p.finalMaster)
    };
    const complete = Object.values(stages).filter(Boolean).length;
    res.json({
      projectId: p.id, title: p.title || 'Untitled Film', idea: p.idea || '',
      genre: p.genre || 'Drama', style: p.style || 'Cinematic', length: Number(p.length || 0),
      aspectRatio: p.aspectRatio || '16:9', resolution: p.resolution || '1080p',
      fps: Number(p.fps || 24), exportFormat: p.exportFormat || 'mp4',
      status: p.status || 'draft', favourite: Boolean(p.favourite), tags,
      counts: { scenes: scenes.length, characters: characters.length, shotCards: shotCards.length },
      stages, progress: Math.round((complete / Object.keys(stages).length) * 100),
      updatedAt: p.updatedAt || null, createdAt: p.createdAt || null
    });
  });
}
module.exports = { registerProjectOverviewRoutes };
