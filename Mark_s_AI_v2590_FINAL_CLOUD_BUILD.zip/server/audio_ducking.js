const fs=require("fs");
const {spawn}=require("child_process");

function buildDuckingWindows(plan={}){
  const windows=[];
  for(const scene of (plan.scenes||[])){
    for(const voice of (scene.voiceAssets||[])){
      if(!voice.localPath) continue;
      const start=Number(voice.filmStart??scene.offset??0);
      const duration=Math.max(.2,Number(voice.duration||3));
      windows.push({start,end:start+duration,amount:.28});
    }
  }
  return windows.sort((a,b)=>a.start-b.start);
}

function mergeWindows(windows=[]){
  const out=[];
  for(const w of windows){
    const last=out[out.length-1];
    if(last && w.start<=last.end) last.end=Math.max(last.end,w.end);
    else out.push({...w});
  }
  return out;
}

function buildDuckedMixArgs(videoPath,tracks,duckWindows,outputPath,ffmpeg){
  if(!videoPath||!fs.existsSync(videoPath)) throw new Error("video file unavailable");
  const bin=ffmpeg||process.env.FFMPEG_BIN||"ffmpeg";
  const args=["-y","-i",videoPath];
  tracks.forEach(t=>args.push("-i",t.path));
  if(!tracks.length) return {ffmpeg:bin,args:[...args,"-c","copy","-movflags","+faststart",outputPath]};
  const windows=mergeWindows(duckWindows);
  const filters=tracks.map((t,i)=>{
    const delay=Math.max(0,Math.round(t.start*1000));
    let chain=`[${i+1}:a]adelay=${delay}|${delay},volume=${t.volume}`;
    if(t.type!=="dialogue" && windows.length){
      const expr=windows.map(w=>`between(t\\,${w.start}\\,${w.end})`).join("+");
      chain+=`,volume=eval=frame:volume='if(${expr}\\,0.28\\,1)'`;
    }
    return `${chain}[a${i}]`;
  }).join(";");
  const labels=tracks.map((_,i)=>`[a${i}]`).join("");
  const filter=`${filters};${labels}amix=inputs=${tracks.length}:duration=longest:dropout_transition=2:normalize=0[aout]`;
  return {ffmpeg:bin,args:[...args,"-filter_complex",filter,"-map","0:v:0","-map","[aout]",
    "-c:v","copy","-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath]};
}

async function mixWithDucking({videoPath,plan,tracks,outputPath,ffmpeg}){
  const all=tracks||[];
  for(const t of all){
    if(!fs.existsSync(t.path)||!fs.statSync(t.path).size) throw new Error(`audio asset unavailable: ${t.path}`);
  }
  const windows=buildDuckingWindows(plan||{});
  const cmd=buildDuckedMixArgs(videoPath,all,windows,outputPath,ffmpeg);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]});
    let err=""; child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`ducked mix failed (${code}): ${err.slice(-1800)}`));
      if(!fs.existsSync(outputPath)||!fs.statSync(outputPath).size)
        return reject(new Error("ducked mix output is empty"));
      resolve({outputPath,bytes:fs.statSync(outputPath).size,duckWindows:windows.length,tracks:all.length});
    });
  });
}
module.exports={buildDuckingWindows,mergeWindows,buildDuckedMixArgs,mixWithDucking};
