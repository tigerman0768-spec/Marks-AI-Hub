const path=require("path");
const {getProject}=require("./film_projects");
const {verifyReleasedFilmDeliverySnapshot}=require("./released_film_delivery_snapshot_verify");
function registerReleasedFilmDeliverySnapshotVerifyRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-snapshot/verification",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,verification:p.finalMasterReleasedFilmDeliverySnapshotVerification||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-snapshot/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=verifyReleasedFilmDeliverySnapshot(p);
    res.status(result.verified?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliverySnapshotVerifyRoutes};
