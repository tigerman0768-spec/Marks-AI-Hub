const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function registerApprovedFilmShareRoutes(app){
  app.get("/api/projects/:id/approved-film/share-info",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    const f=p?.approvedFilmLibraryFilm;
    if(!p)return res.status(404).json({error:"project not found"});
    if(!f?.outputPath||!fs.existsSync(f.outputPath))
      return res.status(409).json({error:"completed Film Library film is required"});
    res.json({
      projectId:p.id,
      title:p.title||"Untitled Film",
      filename:path.basename(f.outputPath),
      bytes:f.bytes||fs.statSync(f.outputPath).size,
      sha256:f.sha256||null,
      mediaPath:`/api/projects/${p.id}/approved-film/library/media`,
      downloadPath:`/api/projects/${p.id}/approved-film/export/download`,
      shareReady:true
    });
  });
}
module.exports={registerApprovedFilmShareRoutes};
