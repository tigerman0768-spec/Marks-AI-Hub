const fs=require("fs");
const path=require("path");
const {execFile}=require("child_process");
const {promisify}=require("util");
const execFileAsync=promisify(execFile);

async function inspectClip(clipPath,options={}){
  const minDuration=Number(options.minDuration||0.5);
  const maxDuration=Number(options.maxDuration||3600);
  if(!clipPath||!fs.existsSync(clipPath)) return {status:"failed",valid:false,error:"clip file not found"};
  const stat=fs.statSync(clipPath);
  if(stat.size<=0) return {status:"failed",valid:false,error:"clip file is empty",size:stat.size};
  try{
    const {stdout}=await execFileAsync("ffprobe",[
      "-v","error","-show_entries",
      "format=duration:stream=index,codec_type,codec_name,width,height,r_frame_rate",
      "-of","json",clipPath
    ]);
    const meta=JSON.parse(stdout||"{}");
    const streams=Array.isArray(meta.streams)?meta.streams:[];
    const video=streams.find(s=>s.codec_type==="video");
    const duration=Number(meta.format?.duration||0);
    const issues=[];
    if(!video) issues.push("no video stream");
    if(duration<minDuration) issues.push("clip is too short");
    if(duration>maxDuration) issues.push("clip is longer than allowed");
    if(video&&(!Number(video.width)||!Number(video.height))) issues.push("invalid video dimensions");
    return {
      status:issues.length?"warning":"passed",
      valid:issues.length===0,
      playable:!!video&&duration>0,
      size:stat.size,
      duration,
      width:Number(video?.width||0),
      height:Number(video?.height||0),
      codec:video?.codec_name||null,
      frameRate:video?.r_frame_rate||null,
      issues
    };
  }catch(e){
    return {status:"failed",valid:false,error:`ffprobe failed: ${e.message}`,size:stat.size};
  }
}
async function inspectProjectClips(project={}){
  const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
  const results=[];
  for(const job of jobs){
    if(job.downloadStatus!=="downloaded"||!job.clipPath) continue;
    const quality=await inspectClip(job.clipPath);
    job.qualityStatus=quality.status;
    job.qualityReport=quality;
    job.qualityCheckedAt=new Date().toISOString();
    results.push({jobId:job.id,shotNumber:job.shotNumber,...quality});
  }
  return results;
}
module.exports={inspectClip,inspectProjectClips};
