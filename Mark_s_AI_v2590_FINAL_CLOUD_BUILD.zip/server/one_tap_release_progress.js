const crypto=require('crypto');
const jobs=new Map();
function createJob(projectId){const id=crypto.randomBytes(8).toString('hex');const job={jobId:id,projectId,status:'queued',currentStep:null,completedSteps:[],steps:[],error:null,updatedAt:new Date().toISOString()};jobs.set(id,job);return job;}
function updateJob(id,patch){const j=jobs.get(id);if(!j)return null;Object.assign(j,patch,{updatedAt:new Date().toISOString()});return j;}
function getJob(id){return jobs.get(id)||null;}
module.exports={createJob,updateJob,getJob};
