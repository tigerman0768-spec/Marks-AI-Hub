function buildDialoguePrompt(project,scene,characters=[]){
  const cast=(characters||[]).map(c=>`${c.name||"Character"}: ${c.personality||"natural"}; goal: ${c.motivation||"advance the story"}`).join("\n");
  return `Write cinematic spoken dialogue for this film scene.
Film: ${project.title||"Untitled"}
Genre: ${project.genre||"Drama"}
Scene: ${scene.title||"Scene"}
Location: ${scene.location||"unspecified"}
Action: ${scene.action||scene.description||""}
Emotion: ${scene.emotion||"natural"}
Characters:
${cast}
Return only JSON with a dialogue array. Each item must contain character and text.
Keep dialogue natural, purposeful, character-specific, and avoid narration.`;
}
function validateDialogue(items,allowed=[]){
  const names=new Set(allowed.map(c=>String(c.name||"")));
  return (Array.isArray(items)?items:[]).filter(x=>{
    const character=String(x?.character||"").trim(),text=String(x?.text||"").trim();
    return character&&text&&(!names.size||names.has(character));
  }).map(x=>({character:String(x.character).trim(),text:String(x.text).trim()}));
}
module.exports={buildDialoguePrompt,validateDialogue};
