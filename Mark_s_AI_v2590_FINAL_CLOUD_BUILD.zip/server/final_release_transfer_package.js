const fs=require('fs');
const crypto=require('crypto');
const path=require('path');
const {spawn}=require('child_process');

function packageCandidates(project){
  return [
    project?.finalMasterFinalReleaseRecord?.outputPath,
    project?.approvedFilmLibraryFilm?.outputPath,
    project?.approvedFilmExport?.sourcePath,
    project?.approvedFilmReleaseManifest?.manifestPath,
    project?.approvedFilmReleaseCertificate?.certificatePath
  ].filter(Boolean).map(p=>path.resolve(p)).filter((p,i,a)=>fs.existsSync(p)&&a.indexOf(p)===i);
}

function buildTransferPackage(project, outputDir){
  const files=packageCandidates(project);
  if(!files.length) return {available:false,reason:'No release files are available'};
  fs.mkdirSync(outputDir,{recursive:true});
  const packageName=`marks_ai_${project?.id||'film'}_release_package.zip`;
  const outputPath=path.resolve(outputDir,packageName);
  const stage=path.join(outputDir,`.package_${project?.id||'film'}_${Date.now()}`);
  fs.mkdirSync(stage,{recursive:true});
  const copied=[];
  try{
    for(const source of files){
      const target=path.join(stage,path.basename(source));
      fs.copyFileSync(source,target);
      const stat=fs.statSync(target);
      const sha256=crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
      copied.push({name:path.basename(target),bytes:stat.size,sha256});
    }
    const manifest={projectId:project?.id||null,title:project?.title||'Untitled Film',generatedAt:new Date().toISOString(),files:copied};
    fs.writeFileSync(path.join(stage,'MARKS_AI_RELEASE_PACKAGE.json'),JSON.stringify(manifest,null,2));
    const child=spawn('zip',['-q','-r','-FS',outputPath,'.'],{cwd:stage});
    return new Promise(resolve=>{
      let error=''; child.stderr.on('data',d=>error+=d.toString());
      child.on('close',code=>{
        fs.rmSync(stage,{recursive:true,force:true});
        if(code!==0){resolve({available:false,reason:error.trim()||'Unable to create release package'});return;}
        const stat=fs.statSync(outputPath);
        resolve({available:true,name:packageName,path:outputPath,bytes:stat.size,fileCount:copied.length,files:copied});
      });
    });
  }catch(e){fs.rmSync(stage,{recursive:true,force:true});return Promise.resolve({available:false,reason:e.message});}
}
module.exports={buildTransferPackage};
