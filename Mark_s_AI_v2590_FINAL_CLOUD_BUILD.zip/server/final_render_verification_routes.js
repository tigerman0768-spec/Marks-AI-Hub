const path=require("path");
const {getProject}=require("./film_projects");
const {verifyFinalRenderProject}=require("./final_render_verification");
function registerFinalRenderVerificationRoutes(app){
  app.post("/api/projects/:id/final-render/verify",async(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=await verifyFinalRenderProject(p,String(req.body?.ffprobe||"ffprobe"));
    require("./film_projects").saveProject(dir,p);
    res.status(result.verified?200:409).json({projectId:p.id,...result,finalRenderReady:p.finalRenderReady===true});
  });
}
module.exports={registerFinalRenderVerificationRoutes};
