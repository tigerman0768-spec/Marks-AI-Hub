const crypto=require("crypto");
function buildExportManifest(project,exportRecord){
  return {
    manifestVersion:"1.0",
    exportId:exportRecord?.exportId||null,
    projectId:project?.id||null,
    title:project?.title||"Untitled Film",
    filename:exportRecord?.filename||"film.mp4",
    bytes:Number(exportRecord?.bytes||0),
    sha256:exportRecord?.sha256||null,
    clipCount:Number(exportRecord?.clipCount||0),
    exportedAt:exportRecord?.exportedAt||null,
    integrity:exportRecord?.sha256?"sha256":"unverified"
  };
}
function manifestHash(manifest){
  return crypto.createHash("sha256").update(JSON.stringify(manifest)).digest("hex");
}
module.exports={buildExportManifest,manifestHash};
