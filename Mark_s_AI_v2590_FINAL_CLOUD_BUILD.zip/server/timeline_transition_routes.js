const path=require("path");
const {getProject}=require("./film_projects");
const {editTimeline}=require("./film_timeline_editor");
function registerTimelineTransitionRoutes(app){
  app.patch("/api/projects/:id/timeline/:index/transition",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=editTimeline(path.join(process.cwd(),"timelines"),project.id,"transition",{
        index:Number(req.params.index),transition:req.body?.transition
      });
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerTimelineTransitionRoutes};
