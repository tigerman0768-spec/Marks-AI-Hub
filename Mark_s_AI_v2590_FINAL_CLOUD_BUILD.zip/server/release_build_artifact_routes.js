const { Readable } = require('stream');

function config(){
  const owner=process.env.GITHUB_OWNER||'';
  const repo=process.env.GITHUB_REPO||'';
  const workflow=process.env.GITHUB_RELEASE_WORKFLOW||'android-release.yml';
  return {owner,repo,workflow,configured:Boolean(owner&&repo&&process.env.GITHUB_TOKEN)};
}

async function github(path, options={}){
  const r=await fetch(`https://api.github.com${path}`,{
    ...options,
    headers:{
      'Accept':'application/vnd.github+json',
      'Authorization':`Bearer ${process.env.GITHUB_TOKEN}`,
      'X-GitHub-Api-Version':'2022-11-28',
      'User-Agent':"Mark's-AI-Artifact-Center",
      ...(options.headers||{})
    }
  });
  const text=await r.text();
  let body={}; try{body=JSON.parse(text);}catch{body={message:text.slice(0,500)};}
  if(!r.ok){const e=new Error(body.message||`GitHub API ${r.status}`);e.status=r.status;throw e;}
  return body;
}

function registerReleaseBuildArtifactRoutes(app){
  app.get('/api/release-build/artifacts',async(req,res)=>{
    const c=config();
    if(!c.configured)return res.status(200).json({configured:false,status:'not_configured',artifacts:[],message:'Configure GITHUB_OWNER, GITHUB_REPO and GITHUB_TOKEN to access release artifacts.'});
    try{
      const runs=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/workflows/${encodeURIComponent(c.workflow)}/runs?per_page=10`);
      const run=runs.workflow_runs?.[0]||null;
      if(!run)return res.json({configured:true,status:'no_runs',run:null,artifacts:[],message:'No Android release build has been run yet.'});
      const result=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/runs/${run.id}/artifacts?per_page=50`);
      const artifacts=(result.artifacts||[]).filter(a=>!a.expired&&['marks-ai-android-apk','marks-ai-android-aab'].includes(a.name)).map(a=>({
        id:a.id,name:a.name,sizeBytes:a.size_in_bytes,expired:a.expired,createdAt:a.created_at,updatedAt:a.updated_at,
        downloadUrl:`/api/release-build/artifacts/${encodeURIComponent(String(a.id))}/download`
      }));
      res.json({configured:true,status:run.status==='completed'?(run.conclusion||'completed'):run.status,run:{id:run.id,runNumber:run.run_number,branch:run.head_branch,htmlUrl:run.html_url},artifacts,message:`Found ${artifacts.length} non-expired release artifact${artifacts.length===1?'':'s'}.`});
    }catch(e){res.status(e.status===401||e.status===403?502:500).json({configured:true,status:'error',message:'Unable to read GitHub release artifacts.',detail:e.message});}
  });

  app.get('/api/release-build/artifacts/:artifactId/download',async(req,res)=>{
    const c=config();
    if(!c.configured)return res.status(503).json({error:'GitHub release artifacts are not configured'});
    const artifactId=String(req.params.artifactId||'');
    if(!/^\d+$/.test(artifactId))return res.status(400).json({error:'Invalid artifact id'});
    try{
      const runs=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/workflows/${encodeURIComponent(c.workflow)}/runs?per_page=10`);
      const run=runs.workflow_runs?.[0]||null;
      if(!run)return res.status(404).json({error:'No release build run found'});
      const result=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/runs/${run.id}/artifacts?per_page=50`);
      const artifact=(result.artifacts||[]).find(a=>String(a.id)===artifactId&&['marks-ai-android-apk','marks-ai-android-aab'].includes(a.name)&&!a.expired);
      if(!artifact)return res.status(404).json({error:'Release artifact not found or expired'});

      const upstream=await fetch(artifact.archive_download_url,{headers:{
        'Accept':'application/vnd.github+json',
        'Authorization':`Bearer ${process.env.GITHUB_TOKEN}`,
        'X-GitHub-Api-Version':'2022-11-28',
        'User-Agent':"Mark's-AI-Artifact-Download"
      }});
      if(!upstream.ok)return res.status(upstream.status).json({error:'GitHub artifact download failed'});
      res.status(200);
      res.setHeader('Content-Type','application/zip');
      res.setHeader('Content-Disposition',`attachment; filename="${artifact.name}.zip"`);
      if(upstream.headers.get('content-length'))res.setHeader('Content-Length',upstream.headers.get('content-length'));
      Readable.fromWeb(upstream.body).pipe(res);
    }catch(e){res.status(e.status||502).json({error:'Unable to download release artifact',detail:e.message});}
  });
}

module.exports={registerReleaseBuildArtifactRoutes};
