const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function reviewClip(project,clipId,decision,notes=""){
  const clips=[...(project.generatedRealClips||[])];
  const i=clips.findIndex(c=>String(c.clipId)===String(clipId));
  if(i<0)return {ready:false,blockers:["generated clip not found"]};
  if(!["keep","reject","regenerate"].includes(decision))return {ready:false,blockers:["decision must be keep, reject or regenerate"]};
  const clip=clips[i];
  if(!clip.outputPath||!fs.existsSync(clip.outputPath))return {ready:false,blockers:["clip file is missing"]};
  const stat=fs.statSync(clip.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(clip.outputPath)).digest("hex");
  if(clip.sha256&&sha!==clip.sha256)return {ready:false,blockers:["clip integrity check failed"]};
  clips[i]={...clip,reviewDecision:decision,reviewNotes:String(notes||""),reviewedAt:new Date().toISOString(),status:decision==="keep"?"approved":decision};
  project.generatedRealClips=clips;
  project.approvedGeneratedClips=clips.filter(c=>c.reviewDecision==="keep");
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,clip:clips[i],approvedGeneratedClips:project.approvedGeneratedClips};
}
function getReviewSet(project){
  return (project.generatedRealClips||[]).map(c=>({...c,exists:!!c.outputPath&&fs.existsSync(c.outputPath)}));
}
module.exports={reviewClip,getReviewSet};
