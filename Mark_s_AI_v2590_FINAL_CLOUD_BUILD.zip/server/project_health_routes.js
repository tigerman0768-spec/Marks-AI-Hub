const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectHealthRoutes(app){
 app.get("/api/projects/:id/health",(req,res)=>{
  const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const checks=[
   ["identity",!!(p.id&&p.title)],["story",!!(p.idea||p.screenplay)],["scenes",(p.scenes||[]).length>0],
   ["productionPlan",!!(p.characterBible||p.storyboard||p.shotCards)],["shotCards",(p.shotCards||[]).length>0],
   ["timeline",!!(p.finalTimeline||p.timeline)],["finishing",!!p.finalFinishingPlan]
  ];
  const passed=checks.filter(x=>x[1]).length;
  res.json({projectId:p.id,title:p.title,score:Math.round(passed/checks.length*100),healthy:passed===checks.length,checks:Object.fromEntries(checks)});
 });
}
module.exports={registerProjectHealthRoutes};
