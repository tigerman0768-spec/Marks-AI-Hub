function buildCharacterBiblePrompt(project){
  return [
    "Create a production-ready Character Bible from this film project.",
    `Title: ${project.title||"Untitled Film"}`,
    `Genre: ${project.genre||"Drama"}`,
    `Story idea: ${project.idea||""}`,
    `Screenplay: ${JSON.stringify(project.screenplay||"")}`,
    "For every important character provide: name, role, age range, appearance, personality, motivation, relationships, wardrobe, voice direction and continuity notes.",
    "Keep character details consistent with the screenplay and genre."
  ].join("\n");
}
function createCharacterBibleDraft(project){
  if(!project)throw new Error("project required");
  const existing=Array.isArray(project.characters)?project.characters:[];
  const characters=existing.length?existing.map((c,i)=>({
    id:c.id||`character-${i+1}`,name:c.name||`Character ${i+1}`,role:c.role||"Supporting",
    ageRange:c.ageRange||"Adult",appearance:c.appearance||"TBD",
    personality:c.personality||"TBD",motivation:c.motivation||"TBD",
    relationships:c.relationships||[],wardrobe:c.wardrobe||"Consistent with story",
    voiceDirection:c.voiceDirection||"Natural, genre-appropriate",
    continuityNotes:c.continuityNotes||"Keep appearance and wardrobe consistent."
  })):[
    {id:"character-1",name:"Protagonist",role:"Lead",ageRange:"Adult",appearance:"TBD",
      personality:"TBD",motivation:"TBD",relationships:[],wardrobe:"TBD",
      voiceDirection:"Natural, genre-appropriate",continuityNotes:"Keep appearance and wardrobe consistent."},
    {id:"character-2",name:"Antagonist",role:"Antagonist",ageRange:"Adult",appearance:"TBD",
      personality:"TBD",motivation:"TBD",relationships:[],wardrobe:"TBD",
      voiceDirection:"Natural, genre-appropriate",continuityNotes:"Keep appearance and wardrobe consistent."}
  ];
  return {status:"draft",prompt:buildCharacterBiblePrompt(project),characters};
}
module.exports={buildCharacterBiblePrompt,createCharacterBibleDraft};
