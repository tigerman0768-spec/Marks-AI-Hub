const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");
const {buildTransitionGraph}=require("./timeline_renderer_video");
const {buildAudioGraph,normaliseAudioSettings}=require("./timeline_audio");
const {buildTrackFilters}=require("./timeline_audio_tracks");
const {buildDialogueFilters,buildDuckWindows}=require("./dialogue_audio_mixer");

function renderTimeline({items,outputPath,ffmpeg="ffmpeg",audioSettings={}}){
  if(!Array.isArray(items)||!items.length)throw new Error("timeline has no items");
  for(const item of items){
    if(!item.clipPath||!fs.existsSync(item.clipPath))throw new Error(`missing clip: ${item.jobId||item.id}`);
  }
  const settings=normaliseAudioSettings(audioSettings);
  if(settings.musicPath&&!fs.existsSync(settings.musicPath))throw new Error("background music file not found");
  fs.mkdirSync(path.dirname(outputPath),{recursive:true});

  const video=buildTransitionGraph(items);
  const audio=buildAudioGraph(items,settings);
  const filters=[...video.filters,...audio.filters];
  const args=["-y"];
  for(const item of items)args.push("-i",item.clipPath);
  let musicIndex=-1;
  if(settings.musicPath){
    musicIndex=items.length;
    args.push("-stream_loop",settings.loopMusic?"-1":"0","-i",settings.musicPath);
    filters.push(`[${musicIndex}:a]aresample=48000,volume=${settings.musicVolume}[music]`);
  }
  const tracks=Array.isArray(settings.audioTracks)?settings.audioTracks:[];
  const dialogue=Array.isArray(settings.dialogueTracks)?settings.dialogueTracks:[];
  const trackStart=items.length+(settings.musicPath?1:0);
  for(const track of tracks)args.push("-i",track.path);
  const dialogueStart=trackStart+tracks.length;
  for(const track of dialogue)args.push("-i",track.audioPath);
  if(tracks.length){
    const trackFilters=buildTrackFilters(tracks);
    filters.push(...trackFilters.map((f,idx)=>f.replace(`$[${idx}:a]`,`[${trackStart+idx}:a]`).replace(`[${idx}:a]`,`[${trackStart+idx}:a]`)));
  }
  const mixInputs=[audio.audio];
  if(settings.musicPath)mixInputs.push("[music]");
  for(let i=0;i<tracks.length;i++)mixInputs.push(`[track${i}]`);
  if(dialogue.length){
    const df=buildDialogueFilters(dialogue);
    filters.push(...df.map((f,i)=>f.replace(`[${i}:a]`,`[${dialogueStart+i}:a]`)));
    for(let i=0;i<dialogue.length;i++)mixInputs.push(`[dialogue${i}]`);
  }
  if(mixInputs.length>1)filters.push(`${mixInputs.join("")}amix=inputs=${mixInputs.length}:duration=first:dropout_transition=2[aout]`);
  const finalAudio=mixInputs.length>1?"[aout]":audio.audio;
  args.push("-filter_complex",filters.join(";"),
    "-map",video.video,"-map",finalAudio,
    "-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p",
    "-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath);
  return new Promise((resolve,reject)=>{
    const child=spawn(ffmpeg,args,{stdio:["ignore","pipe","pipe"]});
    let stderr="";
    child.stderr.on("data",d=>stderr+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`FFmpeg audio/video render failed (${code}): ${stderr.slice(-1800)}`));
      if(!fs.existsSync(outputPath)||!fs.statSync(outputPath).size)return reject(new Error("preview output is empty"));
      resolve({outputPath,bytes:fs.statSync(outputPath).size,audioRendered:true,musicMixed:Boolean(settings.musicPath)});
    });
  });
}
module.exports={renderTimeline};
