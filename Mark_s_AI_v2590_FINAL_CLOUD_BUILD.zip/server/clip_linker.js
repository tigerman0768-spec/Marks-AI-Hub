function linkGeneratedClips(project,run){
  const shots=Array.isArray(project?.directorPlan)?project.directorPlan.flatMap(x=>x.shots||[]):[];
  const byId=new Map(shots.map(s=>[s.id,s]));
  return (run?.jobs||[]).map(job=>{
    const shot=byId.get(job.id);
    return {...job,sceneTitle:shot?.sceneTitle||job.sceneTitle||"",
      shotType:shot?.shotType||job.shotType||"",clipPath:job.clipPath||null};
  });
}
module.exports={linkGeneratedClips};
