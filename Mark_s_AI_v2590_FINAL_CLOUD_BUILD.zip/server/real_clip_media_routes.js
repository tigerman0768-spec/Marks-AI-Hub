const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function registerRealClipMediaRoutes(app){
  app.get("/api/projects/:id/clips/real/:clipId/media",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const clip=(p.generatedRealClips||[]).find(c=>String(c.clipId)===String(req.params.clipId));
    if(!clip||!clip.outputPath)return res.status(404).json({error:"clip not found"});
    if(!fs.existsSync(clip.outputPath))return res.status(404).json({error:"clip file missing"});
    res.sendFile(path.resolve(clip.outputPath));
  });
  app.get("/api/projects/:id/clips/real/media-list",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const clips=(p.generatedRealClips||[]).filter(c=>c.outputPath&&fs.existsSync(c.outputPath));
    res.json({projectId:p.id,clips:clips.map(c=>({...c,mediaUrl:`/api/projects/${p.id}/clips/real/${c.clipId}/media`}))});
  });
}
module.exports={registerRealClipMediaRoutes};
