const path = require("path");
const { getProject, saveProject } = require("./film_projects");

const transitions = {
  queued: ["running", "cancelled", "failed"],
  running: ["completed", "failed", "cancelled"],
  completed: [],
  failed: ["queued"],
  cancelled: ["queued"],
};

function registerVideoGenerationJobControlRoutes(app) {
  app.post("/api/projects/:id/video-generation/jobs/:jobId/claim", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const i = jobs.findIndex(j => j.id === req.params.jobId);
    if (i < 0) return res.status(404).json({ error: "job not found" });
    const job = jobs[i];
    if (job.status !== "queued") {
      return res.status(409).json({ error: "job is not queued", status: job.status });
    }
    job.status = "running";
    job.progress = Math.max(Number(job.progress || 0), 1);
    job.workerId = String(req.body?.workerId || "local-worker");
    job.startedAt = new Date().toISOString();
    job.updatedAt = job.startedAt;
    saveProject(dir, p);
    res.json(job);
  });

  app.post("/api/projects/:id/video-generation/jobs/:jobId/complete", (req, res) => {
    updateJob(req, res, "completed", {
      progress: 100,
      clipPath: req.body?.clipPath ?? null,
      providerJobId: req.body?.providerJobId ?? null
    });
  });

  app.post("/api/projects/:id/video-generation/jobs/:jobId/fail", (req, res) => {
    updateJob(req, res, "failed", {
      error: String(req.body?.error || "generation failed")
    });
  });

  app.post("/api/projects/:id/video-generation/jobs/:jobId/cancel", (req, res) => {
    updateJob(req, res, "cancelled", {});
  });

  function updateJob(req, res, nextStatus, patch) {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const i = jobs.findIndex(j => j.id === req.params.jobId);
    if (i < 0) return res.status(404).json({ error: "job not found" });
    const job = jobs[i];
    const allowed = transitions[job.status] || [];
    if (!allowed.includes(nextStatus)) {
      return res.status(409).json({
        error: "invalid job state transition",
        from: job.status,
        to: nextStatus
      });
    }
    Object.assign(job, patch);
    job.status = nextStatus;
    job.updatedAt = new Date().toISOString();
    if (nextStatus === "completed" || nextStatus === "failed" || nextStatus === "cancelled") {
      job.finishedAt = job.updatedAt;
    }
    saveProject(dir, p);
    res.json(job);
  }
}

module.exports = { registerVideoGenerationJobControlRoutes };
