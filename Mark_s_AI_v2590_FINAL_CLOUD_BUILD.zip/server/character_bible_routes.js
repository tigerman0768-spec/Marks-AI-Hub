const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {createCharacterBibleDraft}=require("./character_bible");
function registerCharacterBibleRoutes(app){
  app.post("/api/projects/:id/character-bible",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const bible=createCharacterBibleDraft(project);
      const saved=saveProject(dir,{...project,characters:bible.characters,status:"characters_ready"});
      res.status(201).json({project:saved,characterBible:bible});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerCharacterBibleRoutes};
