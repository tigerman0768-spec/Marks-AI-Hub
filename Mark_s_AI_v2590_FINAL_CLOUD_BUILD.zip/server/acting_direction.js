const crypto=require("crypto");

const emotions=["neutral","happy","sad","angry","afraid","excited","tender","sarcastic","determined","shocked"];
const intensities=["low","medium","high","extreme"];
const deliveries=["natural","whispered","soft","warm","firm","urgent","shouting","breathy","deadpan"];

function normalizeLine(line={}){
  return {
    id:line.id||crypto.randomUUID(),
    character:String(line.character||"Speaker"),
    text:String(line.text||""),
    emotion:emotions.includes(line.emotion)?line.emotion:"neutral",
    intensity:intensities.includes(line.intensity)?line.intensity:"medium",
    delivery:deliveries.includes(line.delivery)?line.delivery:"natural",
    pauseBefore:Math.max(0,Number(line.pauseBefore||0)),
    pauseAfter:Math.max(0,Number(line.pauseAfter||0)),
    emphasis:String(line.emphasis||""),
    actingNotes:String(line.actingNotes||"")
  };
}
function buildActingPrompt(scene,lines=[]){
  return `Add acting direction to the following dialogue for a cinematic film scene.
Scene emotion: ${scene?.emotion||"natural"}
Scene action: ${scene?.action||scene?.description||""}
Return JSON only. For every line return the original character and text plus:
emotion (one of ${emotions.join(", ")}), intensity (one of ${intensities.join(", ")}),
delivery (one of ${deliveries.join(", ")}), pauseBefore (seconds), pauseAfter (seconds),
emphasis and actingNotes.
Dialogue:
${lines.map((x,i)=>`${i+1}. ${x.character}: ${x.text}`).join("\n")}`;
}
module.exports={emotions,intensities,deliveries,normalizeLine,buildActingPrompt};
