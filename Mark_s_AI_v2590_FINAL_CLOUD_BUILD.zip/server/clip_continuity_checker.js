function norm(v){return String(v??"").trim().toLowerCase();}
function compare(a,b,field){
  const x=norm(a?.[field]),y=norm(b?.[field]);
  if(!x||!y)return {field,status:"unknown",match:true};
  return {field,status:x===y?"match":"mismatch",match:x===y,from:x,to:y};
}
function checkPair(a,b){
  const checks=[
    compare(a,b,"sceneId"),
    compare(a,b,"location"),
    compare(a,b,"time"),
    compare(a,b,"lighting"),
    compare(a,b,"wardrobe"),
    compare(a,b,"shotType"),
  ];
  const mismatches=checks.filter(x=>x.status==="mismatch");
  return {fromJobId:a?.id,toJobId:b?.id,match:mismatches.length===0,
    score:Math.max(0,100-mismatches.length*16),checks,mismatches};
}
function checkProjectContinuity(project={}){
  const jobs=(project.videoJobs||[]).filter(j=>j.downloadStatus==="downloaded");
  const ordered=[...jobs].sort((a,b)=>
    String(a.sceneId).localeCompare(String(b.sceneId))||Number(a.shotNumber||0)-Number(b.shotNumber||0));
  const pairs=[];
  for(let i=1;i<ordered.length;i++)pairs.push(checkPair(ordered[i-1],ordered[i]));
  const mismatches=pairs.filter(p=>!p.match);
  const score=pairs.length?Math.round(pairs.reduce((n,p)=>n+p.score,0)/pairs.length):100;
  return {projectId:project.id,score,pairs,mismatches,consistent:mismatches.length===0};
}
module.exports={checkPair,checkProjectContinuity};
