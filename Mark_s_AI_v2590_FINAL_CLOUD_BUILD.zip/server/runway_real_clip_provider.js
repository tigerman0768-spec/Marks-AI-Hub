const fs=require("fs");
const path=require("path");

async function runwayRequest(url,options={}){
  const r=await fetch(url,options);
  const text=await r.text();
  let data; try{data=JSON.parse(text);}catch{data={raw:text};}
  if(!r.ok)throw new Error(data?.error?.message||data?.message||`Runway HTTP ${r.status}`);
  return data;
}
function ratioFor(aspect){
  if(aspect==="9:16")return "720:1280";
  if(aspect==="1:1")return "960:960";
  return "1280:720";
}
async function submitRunwayClip({prompt,duration=5,aspectRatio="16:9",model="gen4.5"}){
  const key=process.env.RUNWAYML_API_SECRET||process.env.RUNWAY_API_KEY;
  if(!key)return {ready:false,provider:"runway",blockers:["RUNWAYML_API_SECRET is not configured"]};
  const payload={model,promptText:String(prompt),ratio:ratioFor(aspectRatio),duration:Number(duration)};
  const task=await runwayRequest("https://api.dev.runwayml.com/v1/image_to_video",{
    method:"POST",
    headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`,"X-Runway-Version":"2024-11-06"},
    body:JSON.stringify(payload)
  });
  return {ready:true,provider:"runway",taskId:task.id||task.taskId||null,raw:task};
}
async function getRunwayTask(taskId){
  const key=process.env.RUNWAYML_API_SECRET||process.env.RUNWAY_API_KEY;
  if(!key)return {ready:false,blockers:["RUNWAYML_API_SECRET is not configured"]};
  return {ready:true,provider:"runway",task:await runwayRequest(`https://api.dev.runwayml.com/v1/tasks/${encodeURIComponent(taskId)}`,{
    headers:{"Authorization":`Bearer ${key}`,"X-Runway-Version":"2024-11-06"}
  })};
}
async function downloadRunwayOutput(url,destination){
  const r=await fetch(url);
  if(!r.ok)throw new Error(`Runway output download failed: HTTP ${r.status}`);
  await new Promise((resolve,reject)=>{
    const out=fs.createWriteStream(destination);
    r.body.pipeTo(new WritableStream({
      write(chunk){out.write(Buffer.from(chunk));},
      close(){out.end();resolve();},
      abort(err){out.destroy(err);reject(err);}
    })).catch(reject);
  });
  return destination;
}
module.exports={submitRunwayClip,getRunwayTask,downloadRunwayOutput,ratioFor};
