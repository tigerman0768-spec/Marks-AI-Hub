const fs=require("fs"),path=require("path");
function registerProjectFilterRoutes(app){
 app.get("/api/projects/filter",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});const status=String(req.query.status||"").toLowerCase();
  const projects=fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"))}catch{return null}}).filter(Boolean).filter(p=>!status||String(p.status||"draft").toLowerCase()===status);
  res.json({status,count:projects.length,projects:projects.map(p=>({id:p.id,title:p.title||"Untitled Film",status:p.status||"draft",genre:p.genre||"Drama",length:p.length||5}))});
 });
}
module.exports={registerProjectFilterRoutes};
