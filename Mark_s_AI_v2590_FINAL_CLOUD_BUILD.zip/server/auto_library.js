const path=require("path");
const {saveFilmRecord,updateFilmRecord}=require("./film_library");
const {generateThumbnail}=require("./film_thumbnail");

async function registerFinishedFilm(config,result,options={}){
  if(!result||!result.outputPath) throw new Error("finished outputPath required");
  const dir=options.dir||path.join(process.cwd(),"films");
  const id=config.filmId||undefined;
  const record=saveFilmRecord(dir,{
    id,
    title:config.title||config.filmTitle||"Untitled Film",
    outputPath:result.outputPath,
    thumbnailPath:result.thumbnailPath||config.thumbnailPath||'',
    duration:result.duration||config.duration||0,
    status:"completed"
  });
  if(!record.thumbnailPath){
    const thumb=path.join(dir,"thumbnails",`${record.id}.jpg`);
    try{
      const made=await generateThumbnail({videoPath:record.outputPath,outputPath:thumb,ffmpeg:options.ffmpeg});
      return updateFilmRecord(dir,record.id,{thumbnailPath:made.outputPath,thumbnailUrl:`/api/films/${record.id}/thumbnail`});
    }catch(error){
      return updateFilmRecord(dir,record.id,{thumbnailPath:"",thumbnailError:error.message});
    }
  }
  return record;
}
module.exports={registerFinishedFilm};
