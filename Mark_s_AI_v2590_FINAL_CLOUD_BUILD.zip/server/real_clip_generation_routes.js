const path=require("path");
const {getProject}=require("./film_projects");
const {buildRealClipRequest,createRealClipJob,getRealClipJobs}=require("./real_clip_generation_bridge");

function registerRealClipGenerationRoutes(app){
  app.get("/api/projects/:id/clips/real",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,jobs:getRealClipJobs(p)});
  });
  app.post("/api/projects/:id/clips/real/prepare",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const shotId=req.body?.shotId;
    const result=buildRealClipRequest(p,shotId,req.body||{});
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
  app.post("/api/projects/:id/clips/real/generate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const shotId=req.body?.shotId;
    const result=createRealClipJob(p,shotId,req.body||{});
    res.status(result.ready?202:409).json({projectId:p.id,...result});
  });
}
module.exports={registerRealClipGenerationRoutes};
