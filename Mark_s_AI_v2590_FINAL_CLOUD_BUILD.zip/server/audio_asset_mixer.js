const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function validateAudioFile(p){
  if(!p||!fs.existsSync(p)||!fs.statSync(p).isFile()||fs.statSync(p).size===0)
    throw new Error(`audio asset unavailable: ${p||"missing"}`);
  return p;
}
function buildTimedAudioTracks(plan={}){
  const tracks=[];
  for(const scene of (plan.scenes||[])){
    if(scene.music?.path) tracks.push({type:"music",path:validateAudioFile(scene.music.path),
      start:Number(scene.music.filmStart||0),duration:Number(scene.music.duration||scene.duration||5),
      volume:Number(scene.music.volume??.35)});
    for(const s of (scene.sfx||[])){
      if(s.path) tracks.push({type:"sfx",path:validateAudioFile(s.path),
        start:Number(s.filmStart||0),duration:Number(s.duration||1),volume:Number(s.volume??.8)});
    }
  }
  return tracks;
}
function buildMixArguments(videoPath,tracks,outputPath,ffmpeg){
  if(!videoPath||!fs.existsSync(videoPath)) throw new Error("video file unavailable");
  if(!outputPath) throw new Error("outputPath required");
  const args=["-y","-i",videoPath];
  tracks.forEach(t=>args.push("-i",t.path));
  if(!tracks.length) return {ffmpeg:ffmpeg||process.env.FFMPEG_BIN||"ffmpeg",
    args:args.concat(["-c:v","copy","-c:a","aac","-b:a","192k","-movflags","+faststart",outputPath])};
  const filters=tracks.map((t,i)=>`[${i+1}:a]adelay=${Math.round(t.start*1000)}|${Math.round(t.start*1000)},volume=${t.volume}[a${i}]`).join(";");
  const inputs=tracks.map((_,i)=>`[a${i}]`).join("");
  const filter=`${filters};${inputs}amix=inputs=${tracks.length}:duration=longest:dropout_transition=2[aout]`;
  return {ffmpeg:ffmpeg||process.env.FFMPEG_BIN||"ffmpeg",
    args:args.concat(["-filter_complex",filter,"-map","0:v:0","-map","[aout]",
      "-c:v","copy","-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath])};
}
function mixTimedAudio(config){
  const tracks=buildTimedAudioTracks(config.plan||{});
  const cmd=buildMixArguments(config.videoPath,tracks,config.outputPath,config.ffmpeg);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]}); let err="";
    child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`audio asset mix failed (${code}): ${err.slice(-1800)}`));
      if(!fs.existsSync(config.outputPath)||!fs.statSync(config.outputPath).size)
        return reject(new Error("mixed output is empty"));
      resolve({outputPath:config.outputPath,bytes:fs.statSync(config.outputPath).size,tracks:tracks.length});
    });
  });
}
module.exports={validateAudioFile,buildTimedAudioTracks,buildMixArguments,mixTimedAudio};
