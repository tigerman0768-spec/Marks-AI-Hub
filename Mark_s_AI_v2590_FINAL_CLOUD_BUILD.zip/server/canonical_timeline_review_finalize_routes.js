const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerCanonicalTimelineReviewFinalizeRoutes(app){
  app.post("/api/projects/:id/timeline-review/finalize",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const r=p.timelineReview, decisions=Array.isArray(r?.itemDecisions)?r.itemDecisions:[];
    if(!decisions.length)return res.status(409).json({error:"timeline review not started"});
    const pending=decisions.filter(x=>x.status==="pending");
    if(pending.length)return res.status(409).json({error:"timeline review has pending items",pending:pending.length});

    const remove=new Set(decisions.filter(x=>x.status==="remove").map(x=>x.timelineId));
    p.timeline=p.timeline.filter(x=>!remove.has(x.id)).map((x,i)=>({...x,order:i}));
    p.editTimeline=p.timeline;
    p.timelineReview={...r,status:"finalized",finalizedAt:new Date().toISOString(),
      kept:p.timeline.length,removed:remove.size};
    p.timelineReviewReady=true;
    saveProject(dir,p);
    res.json({projectId:p.id,finalized:true,kept:p.timeline.length,removed:remove.size,timeline:p.timeline});
  });
}
module.exports={registerCanonicalTimelineReviewFinalizeRoutes};
