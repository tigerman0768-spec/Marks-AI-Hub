const path = require("path");
const fs = require("fs");
const { getProject, saveProject } = require("./film_projects");

function registerApprovedClipTimelineRoutes(app) {
  app.get("/api/projects/:id/edit-input-timeline", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    res.json({
      projectId: p.id,
      source: p.editInputSource || null,
      preparedAt: p.editInputPreparedAt || null,
      timeline: Array.isArray(p.approvedClipEditTimeline) ? p.approvedClipEditTimeline : []
    });
  });

  app.patch("/api/projects/:id/edit-input-timeline/:itemId", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const timeline = Array.isArray(p.approvedClipEditTimeline) ? p.approvedClipEditTimeline : [];
    const item = timeline.find(x => x.id === req.params.itemId);
    if (!item) return res.status(404).json({ error: "timeline item not found" });

    if (req.body?.order !== undefined) item.order = Math.max(0, Number(req.body.order) || 0);
    if (req.body?.start !== undefined) item.start = Math.max(0, Number(req.body.start) || 0);
    if (req.body?.end !== undefined && req.body.end !== null) item.end = Math.max(item.start, Number(req.body.end) || item.start);
    if (req.body?.transition !== undefined) {
      const t = String(req.body.transition);
      if (!["cut","dissolve","fade","dip-to-black"].includes(t)) {
        return res.status(400).json({ error: "invalid transition" });
      }
      item.transition = t;
    }
    p.approvedClipEditTimeline = timeline.sort((a,b)=>(a.order||0)-(b.order||0));
    p.editInputUpdatedAt = new Date().toISOString();
    saveProject(dir, p);
    res.json(item);
  });

  app.post("/api/projects/:id/edit-input-timeline/validate", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const timeline = Array.isArray(p.approvedClipEditTimeline) ? p.approvedClipEditTimeline : [];
    const issues = [];
    const seen = new Set();
    timeline.forEach((x,i) => {
      if (!x.sourcePath || !fs.existsSync(x.sourcePath)) issues.push(`missing:${x.id}`);
      if (seen.has(x.clipId)) issues.push(`duplicate:${x.clipId}`);
      seen.add(x.clipId);
      if (Number(x.end) > 0 && Number(x.end) < Number(x.start || 0)) issues.push(`range:${x.id}`);
      if (Number(x.order) !== i) issues.push(`order:${x.id}`);
    });
    res.json({ projectId:p.id, valid:issues.length===0 && timeline.length>0, issues, count:timeline.length });
  });
}
module.exports = { registerApprovedClipTimelineRoutes };
