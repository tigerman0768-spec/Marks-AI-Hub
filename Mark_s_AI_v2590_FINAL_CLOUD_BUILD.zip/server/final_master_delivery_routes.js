const path=require("path");
const {getProject}=require("./film_projects");
const {saveDeliveryPackage}=require("./final_master_delivery_package");
function registerFinalMasterDeliveryRoutes(app){
  app.get("/api/projects/:id/final-render/delivery-package",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,package:p.finalMasterDeliveryPackage||null});
  });
  app.post("/api/projects/:id/final-render/delivery-package/build",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const pkg=saveDeliveryPackage(p);
    res.status(pkg.ready?200:409).json({projectId:p.id,package:pkg});
  });
}
module.exports={registerFinalMasterDeliveryRoutes};
