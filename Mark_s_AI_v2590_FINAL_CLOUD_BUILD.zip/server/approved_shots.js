function getApprovedShots(project){
  const jobs=Array.isArray(project?.videoJobs)?project.videoJobs:[];
  const reviews=project?.clipReviews||{};
  return jobs.filter(job=>{
    const decision=reviews[job.id]?.decision||job.reviewStatus||"pending";
    return decision==="accepted" && job.downloadStatus==="downloaded" && job.clipPath;
  });
}
function buildApprovalSummary(project){
  const jobs=Array.isArray(project?.videoJobs)?project.videoJobs:[];
  const approved=getApprovedShots(project);
  return {
    total:jobs.length,
    approved:approved.length,
    pending:jobs.filter(j=>(project?.clipReviews?.[j.id]?.decision||j.reviewStatus||"pending")==="pending").length,
    rejected:jobs.filter(j=>(project?.clipReviews?.[j.id]?.decision||j.reviewStatus||"pending")==="rejected").length,
    ready:approved.length>0 && approved.length===jobs.filter(j=>j.downloadStatus==="downloaded").length
  };
}
module.exports={getApprovedShots,buildApprovalSummary};
