const path=require("path");
const crypto=require("crypto");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function lockFinalMaster(project){
  const receipt=project.finalMasterDeliveryReceipt;
  if(!receipt||receipt.status!=="verified")return {locked:false,blockers:["verified delivery receipt is required"]};
  if(!receipt.sha256||!receipt.filename)return {locked:false,blockers:["delivery receipt is incomplete"]};
  if(!receipt.projectId||receipt.projectId!==project.id)return {locked:false,blockers:["receipt project mismatch"]};
  const file=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!file||!fs.existsSync(file))return {locked:false,blockers:["final output file is missing"]};
  const sha=crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
  if(sha!==receipt.sha256)return {locked:false,blockers:["final output hash does not match the verified receipt"]};
  project.finalMasterLock={
    locked:true,projectId:project.id,filename:receipt.filename,sha256:receipt.sha256,
    lockedAt:new Date().toISOString(),immutableSource:file
  };
  saveProject(path.join(process.cwd(),"projects"),project);
  return {locked:true,lock:project.finalMasterLock};
}
function isFinalMasterLocked(project){return project.finalMasterLock?.locked===true;}
module.exports={lockFinalMaster,isFinalMasterLocked};
