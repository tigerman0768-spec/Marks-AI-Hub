const path=require("path");
const {getProject,saveProject}=require("./film_projects");

function registerFinalCutPrepareRoutes(app){
  app.post("/api/projects/:id/final-cut/prepare",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const timeline=Array.isArray(p.timeline)?p.timeline:[];
    if(!p.timelineReviewReady||!timeline.length)
      return res.status(409).json({error:"timeline review is not finalized"});
    p.finalCutPlan={
      id:`final-cut-${p.id}-${Date.now()}`,
      source:"canonical-timeline",
      createdAt:new Date().toISOString(),
      clips:timeline.map((x,i)=>({
        id:x.id,clipId:x.clipId,shotId:x.shotId,scene:x.scene,
        sourcePath:x.sourcePath,start:x.start||0,end:x.end,
        order:i,transition:x.transition||"cut"
      }))
    };
    p.finalCutPreparedAt=new Date().toISOString();
    p.status="review";
    saveProject(dir,p);
    res.status(201).json({projectId:p.id,ready:true,plan:p.finalCutPlan});
  });
}
module.exports={registerFinalCutPrepareRoutes};
