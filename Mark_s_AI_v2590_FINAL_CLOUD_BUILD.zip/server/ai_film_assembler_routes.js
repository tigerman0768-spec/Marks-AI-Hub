const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {assembleAiFilm}=require("./ai_film_assembler");
function registerAiFilmAssemblerRoutes(app){
  app.post("/api/projects/:id/ai-assemble",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await assembleAiFilm(project);
      saveProject(dir,{...project,aiFilmAssembly:result,status:"ai_film_assembled"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-assemble",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.aiFilmAssembly||{clipCount:0});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiFilmAssemblerRoutes};
