const {listFilms,getFilm,updateFilm,deleteFilm}=require("./film_library");
const path=require("path");
const DIR=path.join(process.cwd(),"films");
function registerFilmLibraryUiRoutes(app){
 app.get("/api/film-library",(req,res)=>{
  try{res.json({films:listFilms(DIR)});}catch(e){res.status(500).json({error:e.message});}
 });
 app.get("/api/film-library/:id",(req,res)=>{
  try{const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});res.json(f);}
  catch(e){res.status(500).json({error:e.message});}
 });
 app.post("/api/film-library/:id/favourite",(req,res)=>{
  try{const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});
   res.json(updateFilm(DIR,req.params.id,{favourite:!f.favourite}));}
  catch(e){res.status(500).json({error:e.message});}
 });
 app.delete("/api/film-library/:id",(req,res)=>{
  try{const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});
   res.json({deleted:deleteFilm(DIR,req.params.id),id:req.params.id});}
  catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFilmLibraryUiRoutes};
