const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {runRegenerationQueue}=require("./regeneration_worker");

function registerRegenerationWorkerRoutes(app){
  app.post("/api/projects/:id/clips/regeneration/run",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await runRegenerationQueue(project,{apiKey:req.body?.apiKey,maxRetries:req.body?.maxRetries});
      const jobs=result.run?.jobs||project.videoJobs||[];
      const originalJobs=(project.videoJobs||[]).filter(j=>!result.run?.jobs?.some(r=>r.id===j.id));
      const merged=[...originalJobs,...jobs];
      saveProject(dir,{...project,videoJobs:merged,status:result.status==="completed"?"regeneration_completed":"regeneration_failed"});
      res.json({projectId:project.id,...result});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerRegenerationWorkerRoutes};
