const path=require("path");
const {getProject}=require("./film_projects");
const {handoffApprovedFilm}=require("./approved_film_library_handoff");
function registerApprovedFilmLibraryHandoffRoutes(app){
  app.get("/api/projects/:id/approved-film/library",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,film:p.approvedFilmLibraryFilm||null});
  });
  app.post("/api/projects/:id/approved-film/library/handoff",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=handoffApprovedFilm(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerApprovedFilmLibraryHandoffRoutes};
