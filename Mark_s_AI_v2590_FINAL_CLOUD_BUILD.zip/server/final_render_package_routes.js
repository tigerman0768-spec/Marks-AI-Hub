const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function registerFinalRenderPackageRoutes(app){
  app.get("/api/projects/:id/final-render/package",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const input=p.finalRenderInput;
    const clips=Array.isArray(input?.clips)?input.clips:[];
    const available=clips.filter(c=>c.sourcePath&&fs.existsSync(c.sourcePath)).length;
    res.json({projectId:p.id,ready:Boolean(p.finalRenderInputReady),
      packageId:input?.id||null,createdAt:input?.createdAt||null,
      clipCount:clips.length,availableFiles:available,clips});
  });

  app.post("/api/projects/:id/final-render/package/validate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const input=p.finalRenderInput,clips=Array.isArray(input?.clips)?input.clips:[];
    const issues=[];
    if(!p.finalRenderInputReady)issues.push("render_input_not_ready");
    if(!clips.length)issues.push("no_clips");
    const orders=new Set();
    clips.forEach((c,i)=>{
      if(!c.sourcePath||!fs.existsSync(c.sourcePath))issues.push(`missing:${c.id}`);
      if(orders.has(c.order))issues.push(`duplicate_order:${c.id}`);
      orders.add(c.order);
      if((c.end!==null&&c.end!==undefined)&&Number(c.end)<Number(c.start||0))issues.push(`range:${c.id}`);
      if(Number(c.order)!==i)issues.push(`order:${c.id}`);
    });
    const valid=issues.length===0;
    if(valid){p.finalRenderPackageValidatedAt=new Date().toISOString();saveProject(path.join(process.cwd(),"projects"),p);}
    res.json({projectId:p.id,valid,issues,clipCount:clips.length});
  });
}
module.exports={registerFinalRenderPackageRoutes};
