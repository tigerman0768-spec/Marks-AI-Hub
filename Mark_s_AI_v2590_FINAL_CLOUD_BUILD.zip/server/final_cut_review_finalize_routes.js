const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
function registerFinalCutReviewFinalizeRoutes(app){
  app.post("/api/projects/:id/final-cut/review/finalize",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const r=p.finalCutReview,ds=Array.isArray(r?.decisions)?r.decisions:[];
    if(!ds.length)return res.status(409).json({error:"final cut review not started"});
    const pending=ds.filter(x=>x.status==="pending");
    if(pending.length)return res.status(409).json({error:"review has pending items",pending:pending.length});
    const remove=new Set(ds.filter(x=>x.status==="remove").map(x=>x.timelineId));
    const clips=(p.finalCutPlan.clips||[]).filter(x=>!remove.has(x.id));
    const missing=clips.filter(x=>!x.sourcePath||!fs.existsSync(x.sourcePath));
    if(missing.length)return res.status(409).json({error:"final cut contains missing source files",missing:missing.length});
    p.finalCutPlan={...p.finalCutPlan,clips:clips.map((x,i)=>({...x,order:i}))};
    p.finalCutReview={...r,status:"finalized",finalizedAt:new Date().toISOString(),kept:clips.length,removed:remove.size};
    p.finalCutReviewReady=true;
    saveProject(dir,p);
    res.json({projectId:p.id,finalized:true,kept:clips.length,removed:remove.size,plan:p.finalCutPlan});
  });
}
module.exports={registerFinalCutReviewFinalizeRoutes};
