const path=require("path");
const {getProject}=require("./film_projects");
const {loadEditableTimeline}=require("./film_timeline_editor");
const {renderTimeline}=require("./timeline_renderer");
const {loadProjectAudio}=require("./timeline_audio_editor");
const {loadDialogue}=require("./dialogue_timeline");

function registerTimelinePreviewRoutes(app){
  app.post("/api/projects/:id/timeline/preview",async(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const timeline=loadEditableTimeline(path.join(process.cwd(),"timelines"),project.id);
      if(!timeline?.items?.length)return res.status(400).json({error:"timeline is empty"});
      const output=path.join(process.cwd(),"previews",`${project.id}-timeline-preview.mp4`);
      const result=await renderTimeline({items:timeline.items,outputPath:output,ffmpeg:req.body?.ffmpeg||"ffmpeg",audioSettings:{...(req.body?.audioSettings||{}),audioTracks:loadProjectAudio(path.join(process.cwd(),"timeline-audio"),project.id).tracks,dialogueTracks:loadDialogue(path.join(process.cwd(),"dialogue"),project.id).tracks}});
      res.json({projectId:project.id,outputPath:result.outputPath,bytes:result.bytes,transitionsRendered:true,audioRendered:Boolean(result.audioRendered),musicMixed:Boolean(result.musicMixed),
        url:`/api/projects/${project.id}/timeline/preview.mp4`});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/timeline/preview.mp4",(req,res)=>{
    const file=path.join(process.cwd(),"previews",`${req.params.id}-timeline-preview.mp4`);
    if(!require("fs").existsSync(file))return res.status(404).json({error:"preview not rendered"});
    res.sendFile(file);
  });
}
module.exports={registerTimelinePreviewRoutes};
