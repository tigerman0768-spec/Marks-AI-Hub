const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadDialogue,saveDialogue}=require("./dialogue_timeline");
const {buildActingPrompt,normalizeLine}=require("./acting_direction");

function registerActingDirectionRoutes(app){
  app.post("/api/projects/:id/dialogue/acting-direction",async(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"OPENAI_API_KEY is not configured"});
      const OpenAI=require("openai"); const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
      const record=loadDialogue(path.join(process.cwd(),"dialogue"),project.id);
      let tracks=[...(record.tracks||[])];
      if(!tracks.length)return res.status(400).json({error:"no dialogue tracks available"});
      const scenes=project.scenes||[];
      const result=[];
      for(const scene of scenes){
        const group=tracks.filter(t=>t.sceneId===scene.id);
        if(!group.length)continue;
        const response=await client.responses.create({
          model:process.env.OPENAI_DIALOGUE_MODEL||"gpt-5.6-luna",
          input:buildActingPrompt(scene,group),
          text:{format:{type:"json_schema",name:"acting_direction",strict:true,schema:{
            type:"object",properties:{lines:{type:"array",items:{type:"object",properties:{
              character:{type:"string"},text:{type:"string"},emotion:{type:"string"},
              intensity:{type:"string"},delivery:{type:"string"},pauseBefore:{type:"number"},
              pauseAfter:{type:"number"},emphasis:{type:"string"},actingNotes:{type:"string"}
            },required:["character","text","emotion","intensity","delivery","pauseBefore","pauseAfter","emphasis","actingNotes"],additionalProperties:false}}},
            required:["lines"],additionalProperties:false
          }}}
        });
        const parsed=JSON.parse(response.output_text||'{"lines":[]}');
        for(const line of parsed.lines||[]){
          const match=tracks.find(t=>t.sceneId===scene.id&&t.character===line.character&&t.text===line.text);
          if(match)Object.assign(match,normalizeLine({...match,...line}));
        }
        result.push({sceneId:scene.id,lines:parsed.lines?.length||0});
      }
      const saved=saveDialogue(path.join(process.cwd(),"dialogue"),project.id,tracks);
      saveProject(path.join(process.cwd(),"projects"),{...project,dialogueTracks:saved.tracks,status:"acting_direction_ready"});
      res.json({projectId:project.id,tracks:saved.tracks,scenes:result});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerActingDirectionRoutes};
