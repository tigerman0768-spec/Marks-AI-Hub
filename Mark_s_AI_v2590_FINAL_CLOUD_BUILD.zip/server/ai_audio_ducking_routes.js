const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {masterWithDucking}=require("./ai_audio_ducking_master");
function registerAiAudioDuckingRoutes(app){
  app.post("/api/projects/:id/ai-duck-master",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await masterWithDucking(project);
      saveProject(dir,{...project,aiDuckedMaster:result,status:"ai_ducked_mastered"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-duck-master",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.aiDuckedMaster||{outputPath:null,duckingApplied:false});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiAudioDuckingRoutes};
