const path=require("path");
const {getProject}=require("./film_projects");

function registerFinalCutPlanRoutes(app){
  app.get("/api/projects/:id/final-cut/plan",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,preparedAt:p.finalCutPreparedAt||null,
      plan:p.finalCutPlan||null});
  });
}
module.exports={registerFinalCutPlanRoutes};
