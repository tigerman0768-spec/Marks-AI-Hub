const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {execFile}=require('child_process');
const {promisify}=require('util');
const exec=promisify(execFile);

async function listZipEntries(zipPath){
  const {stdout}=await exec('unzip',['-Z1',zipPath]);
  return stdout.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
}

async function readZipEntry(zipPath,name){
  const {stdout}=await exec('unzip',['-p',zipPath,name],{encoding:'buffer',maxBuffer:64*1024*1024});
  return Buffer.isBuffer(stdout)?stdout:Buffer.from(stdout);
}

async function verifyReleasePackage(zipPath){
  if(!zipPath||!fs.existsSync(zipPath)) return {verified:false,available:false,reason:'Release package does not exist'};
  const stat=fs.statSync(zipPath);
  const packageSha256=crypto.createHash('sha256').update(fs.readFileSync(zipPath)).digest('hex');
  try{
    const entries=await listZipEntries(zipPath);
    const manifestName='MARKS_AI_RELEASE_PACKAGE.json';
    if(!entries.includes(manifestName)) return {verified:false,available:true,reason:'Package manifest is missing',package:{name:path.basename(zipPath),bytes:stat.size,sha256:packageSha256}};
    const manifest=JSON.parse((await readZipEntry(zipPath,manifestName)).toString('utf8'));
    const results=[];
    for(const expected of Array.isArray(manifest.files)?manifest.files:[]){
      const exists=entries.includes(expected.name);
      if(!exists){results.push({name:expected.name,exists:false,hashMatches:false,sizeMatches:false});continue;}
      const buf=await readZipEntry(zipPath,expected.name);
      const sha256=crypto.createHash('sha256').update(buf).digest('hex');
      results.push({name:expected.name,exists:true,bytes:buf.length,sha256,hashMatches:!expected.sha256||expected.sha256===sha256,sizeMatches:expected.bytes==null||Number(expected.bytes)===buf.length});
    }
    const verified=results.length>0 && results.every(x=>x.exists&&x.hashMatches&&x.sizeMatches);
    return {verified,available:true,package:{name:path.basename(zipPath),bytes:stat.size,sha256:packageSha256},manifest:{projectId:manifest.projectId||null,title:manifest.title||'Untitled Film',generatedAt:manifest.generatedAt||null,fileCount:results.length},files:results,checkedAt:new Date().toISOString(),reason:verified?null:'One or more package files failed verification'};
  }catch(e){return {verified:false,available:true,reason:e.message,package:{name:path.basename(zipPath),bytes:stat.size,sha256:packageSha256}};}
}
module.exports={verifyReleasePackage};
