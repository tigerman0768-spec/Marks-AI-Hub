const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function registerFinalCutRenderBridgeRoutes(app){
  app.get("/api/projects/:id/final-cut/render-readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const clips=Array.isArray(p.finalCutPlan?.clips)?p.finalCutPlan.clips:[];
    const available=clips.filter(c=>c.sourcePath&&fs.existsSync(c.sourcePath)).length;
    const checks={
      reviewFinalized:p.finalCutReview?.status==="finalized",
      reviewReady:p.finalCutReviewReady===true,
      clips:clips.length>0,
      sourceFiles:available===clips.length
    };
    res.json({projectId:p.id,ready:Object.values(checks).every(Boolean),checks,
      clipCount:clips.length,availableFiles:available});
  });

  app.post("/api/projects/:id/final-cut/render-input",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const clips=Array.isArray(p.finalCutPlan?.clips)?p.finalCutPlan.clips:[];
    if(p.finalCutReview?.status!=="finalized"||!p.finalCutReviewReady)
      return res.status(409).json({error:"final cut review is not finalized"});
    const missing=clips.filter(c=>!c.sourcePath||!fs.existsSync(c.sourcePath));
    if(!clips.length||missing.length)return res.status(409).json({error:"final cut render input is incomplete",missing:missing.length});
    p.finalRenderInput={
      id:`final-render-input-${p.id}-${Date.now()}`,
      source:"finalCutPlan",
      createdAt:new Date().toISOString(),
      clips:clips.map((c,i)=>({...c,order:i}))
    };
    p.finalRenderInputReady=true;
    p.finalRenderInputPreparedAt=new Date().toISOString();
    saveProject(dir,p);
    res.status(201).json({projectId:p.id,ready:true,input:p.finalRenderInput});
  });
}
module.exports={registerFinalCutRenderBridgeRoutes};
