const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {renderAiTransitions}=require("./ai_transition_renderer");
function registerAiTransitionRoutes(app){
  app.post("/api/projects/:id/ai-transition-render",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await renderAiTransitions(project);
      saveProject(dir,{...project,aiTransitionRender:result,status:"ai_transition_rendered"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-transition-render",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.aiTransitionRender||{clipCount:0,transitions:[]});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiTransitionRoutes};
