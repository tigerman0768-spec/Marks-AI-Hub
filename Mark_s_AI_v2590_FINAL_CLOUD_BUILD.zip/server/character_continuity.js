function normaliseCharacter(character = {}) {
  return {
    id: character.id || character.name || `character-${Math.random().toString(36).slice(2,8)}`,
    name: character.name || "Character",
    appearance: character.appearance || "",
    wardrobe: character.wardrobe || "",
    hair: character.hair || "",
    ageRange: character.ageRange || "",
    personality: character.personality || "",
    referenceImage: character.referenceImage || null
  };
}

function buildCharacterBible(characters = []) {
  const bible = {};
  for (const c of characters) {
    const n = normaliseCharacter(c);
    bible[n.id] = n;
  }
  return bible;
}

function buildContinuityPrompt(scene, bible = {}) {
  const names = scene.characters || [];
  const refs = names.map(name => {
    const c = Object.values(bible).find(x => x.name === name || x.id === name);
    if (!c) return `character ${name}: maintain continuity`;
    return [
      `${c.name}`,
      c.appearance && `appearance ${c.appearance}`,
      c.wardrobe && `wardrobe ${c.wardrobe}`,
      c.hair && `hair ${c.hair}`,
      c.ageRange && `age ${c.ageRange}`,
      c.referenceImage && `use reference image ${c.referenceImage}`
    ].filter(Boolean).join(", ");
  });
  return refs.join(". ");
}

function applyCharacterContinuity(jobs = [], scenes = [], characters = []) {
  const bible = buildCharacterBible(characters);
  const sceneMap = new Map(scenes.map(s => [s.id, s]));
  return jobs.map(job => {
    const scene = sceneMap.get(job.sceneId) || {};
    const continuity = buildContinuityPrompt(scene, bible);
    return {
      ...job,
      continuity,
      prompt: continuity
        ? `${job.prompt}. ${continuity}. Preserve identity, wardrobe and physical appearance between shots.`
        : `${job.prompt}. Preserve character identity and visual continuity between shots.`
    };
  });
}

module.exports = { buildCharacterBible, buildContinuityPrompt, applyCharacterContinuity };
