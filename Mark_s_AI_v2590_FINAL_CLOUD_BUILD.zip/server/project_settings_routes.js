const path=require("path");
const {getProject,saveProject}=require("./film_projects");
function registerProjectSettingsRoutes(app){
  app.get("/api/projects/:id/settings",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,title:p.title,genre:p.genre,length:p.length,style:p.style,
      aspectRatio:p.aspectRatio,resolution:p.resolution||"1080p",fps:p.fps||24,
      exportFormat:p.exportFormat||"mp4",updatedAt:p.updatedAt});
  });
  app.patch("/api/projects/:id/settings",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const allowed=["title","genre","length","style","aspectRatio","resolution","fps","exportFormat"];
    const changes={}; for(const k of allowed)if(req.body?.[k]!==undefined)changes[k]=req.body[k];
    const saved=saveProject(dir,{...p,...changes});
    res.json({projectId:saved.id,settings:changes,updatedAt:saved.updatedAt});
  });
}
module.exports={registerProjectSettingsRoutes};
