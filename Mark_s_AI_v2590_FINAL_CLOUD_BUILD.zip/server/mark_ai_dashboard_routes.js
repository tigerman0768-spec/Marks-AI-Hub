function registerMarkAiDashboardRoutes(app){
 app.get("/api/dashboard",(_req,res)=>res.json({
  app:"Mark's AI",version:"136",
  areas:[
   {id:"create",title:"Create Film"},
   {id:"projects",title:"Projects"},
   {id:"render-queue",title:"Render Queue"},
   {id:"library",title:"Film Library"}
  ]
 }));
}
module.exports={registerMarkAiDashboardRoutes};
