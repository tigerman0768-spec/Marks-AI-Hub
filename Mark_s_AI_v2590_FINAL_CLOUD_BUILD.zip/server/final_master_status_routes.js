const path=require("path");
const {getProject}=require("./film_projects");
const {getJob}=require("./final_render_job_store");
function registerFinalMasterStatusRoutes(app){
  app.get("/api/projects/:id/final-master/status",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const progress=p.smartOneClickFinalRender||{};
    const jobId=progress.progressId||p.finalRenderJobId||null;
    const job=jobId?getJob(path.join(process.cwd(),"final-render-jobs"),jobId):null;
    res.json({projectId:p.id,title:p.title,status:job?.status||progress.status||"not_started",
      progress:job?.progress??progress.progress??0,stage:job?.stage||progress.stage||null,
      outputPath:job?.outputPath||job?.result?.outputPath||null,
      libraryId:job?.libraryId||job?.result?.libraryId||null,
      lifecycle:job?.lifecycle||null,error:job?.error||progress.error||null});
  });
}
module.exports={registerFinalMasterStatusRoutes};
