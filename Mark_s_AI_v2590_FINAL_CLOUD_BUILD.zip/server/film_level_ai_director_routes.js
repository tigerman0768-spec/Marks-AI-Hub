const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildDirectorPass}=require("./film_level_ai_director");

function registerFilmLevelDirectorRoutes(app){
  app.get("/api/projects/:id/director-pass",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const report=buildDirectorPass(project);
      saveProject(dir,{...project,directorPass:report});
      res.json(report);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFilmLevelDirectorRoutes};
