function durationOf(job){
  return Math.max(0,Number(job?.duration||job?.qualityReport?.duration||0));
}
function buildFinalCutPlan(project={}){
  const jobs=(project.videoJobs||[]).filter(j=>j.downloadStatus==="downloaded");
  const selected=jobs.filter(j=>j.selectedVersionId||j.bestVersion||j.selectedClipPath);
  const source=selected.length?selected:jobs;
  const ordered=[...source].sort((a,b)=>
    String(a.sceneId).localeCompare(String(b.sceneId))||Number(a.shotNumber||0)-Number(b.shotNumber||0));
  const items=ordered.map((j,i)=>({
    order:i+1,jobId:j.id,sceneId:j.sceneId,shotNumber:j.shotNumber,
    clipPath:j.selectedClipPath||j.clipPath||null,
    duration:durationOf(j),
    editReason:j.smartReview?.decision==="recommended"?"strong_take":"selected_take",
    transition:i===0?"cut":(j.transition||"cut")
  }));
  const totalDuration=items.reduce((n,x)=>n+x.duration,0);
  const notes=[];
  if(!items.length)notes.push("No approved/downloaded clips are available for a final cut.");
  if(items.some(x=>x.duration<=0))notes.push("Some clips have unknown duration; verify timing before rendering.");
  return {projectId:project.id,createdAt:new Date().toISOString(),items,
    totalDuration,shotCount:items.length,notes,readyToRender:items.length>0&&items.every(x=>x.clipPath)};
}
module.exports={buildFinalCutPlan};
