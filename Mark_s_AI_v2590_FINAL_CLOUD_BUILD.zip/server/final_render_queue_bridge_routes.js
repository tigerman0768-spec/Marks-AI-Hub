const path=require("path");
const {getProject,saveProject}=require("./film_projects");

function registerFinalRenderQueueBridgeRoutes(app){
  app.get("/api/projects/:id/final-render/queue-readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const checks={
      package:Boolean(p.finalRenderPackageValidatedAt),
      config:Boolean(p.finalRenderConfig),
      input:Boolean(p.finalRenderInputReady),
      finalCut:Boolean(p.finalCutReviewReady)
    };
    res.json({projectId:p.id,ready:Object.values(checks).every(Boolean),checks});
  });

  app.post("/api/projects/:id/final-render/queue",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    if(!p.finalRenderPackageValidatedAt)
      return res.status(409).json({error:"render package must be validated"});
    if(!p.finalRenderConfig)
      return res.status(409).json({error:"render configuration is missing"});
    const queueRecord={
      id:`final-render-${p.id}-${Date.now()}`,
      projectId:p.id,
      status:"queued",
      createdAt:new Date().toISOString(),
      config:p.finalRenderConfig,
      packageId:p.finalRenderInput?.id||null,
      clipCount:Array.isArray(p.finalRenderInput?.clips)?p.finalRenderInput.clips.length:0
    };
    p.finalRenderQueueRecord=queueRecord;
    p.status="producing";
    saveProject(dir,p);
    res.status(202).json(queueRecord);
  });

  app.get("/api/projects/:id/final-render/queue",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,queue:p.finalRenderQueueRecord||null});
  });
}
module.exports={registerFinalRenderQueueBridgeRoutes};
