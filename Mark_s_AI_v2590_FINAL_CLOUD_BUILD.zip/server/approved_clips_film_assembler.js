const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function buildApprovedFilmTimeline(project){
  const clips=(project.approvedGeneratedClips||[]).filter(c=>c.outputPath&&fs.existsSync(c.outputPath));
  if(!clips.length)return {ready:false,blockers:["no approved clips with existing files"]};
  const timeline=clips.map((c,i)=>({
    timelineId:`approved_timeline_${i+1}`,
    order:i+1,clipId:c.clipId,shotId:c.shotId||null,
    sourcePath:c.outputPath,duration:Number(c.request?.duration||5),
    transition:i===0?"cut":"cut",status:"ready"
  }));
  const totalDuration=timeline.reduce((n,c)=>n+c.duration,0);
  const record={
    filmTimelineId:`film_timeline_${Date.now()}`,
    projectId:project.id,title:project.title||"Untitled Film",
    clips:timeline,totalDuration,clipCount:timeline.length,
    createdAt:new Date().toISOString(),status:"ready"
  };
  project.approvedFilmTimeline=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,timeline:record};
}
function getApprovedFilmTimeline(project){return project?.approvedFilmTimeline||null;}
module.exports={buildApprovedFilmTimeline,getApprovedFilmTimeline};
