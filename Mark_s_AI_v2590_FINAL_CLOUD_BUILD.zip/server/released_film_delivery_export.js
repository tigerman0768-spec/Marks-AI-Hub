const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function exportReleasedFilmDelivery(project){
  const pkg=project?.finalMasterReleasedFilmDeliveryPackage;
  const verification=project?.finalMasterLibraryReleaseVerification;
  if(!pkg?.packageId)return {ready:false,blockers:["delivery package is missing"]};
  if(!verification?.verified)return {ready:false,blockers:["release verification is required"]};
  const source=pkg.outputPath;
  if(!source||!fs.existsSync(source))return {ready:false,blockers:["final film file is missing"]};

  const exportId=`release_export_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_export");
  fs.mkdirSync(dir,{recursive:true});
  const manifest={
    exportId,packageId:pkg.packageId,projectId:project.id,
    title:project.title||"Untitled Film",sourcePath:source,
    bytes:fs.statSync(source).size,
    sha256:crypto.createHash("sha256").update(fs.readFileSync(source)).digest("hex"),
    deliveryManifestPath:pkg.manifestPath,
    verificationPath:pkg.verificationPath,
    exportedAt:new Date().toISOString(),status:"export_ready"
  };
  fs.writeFileSync(path.join(dir,"export_manifest.json"),JSON.stringify(manifest,null,2));
  const exportRecord={
    exportId,packageId:pkg.packageId,manifestPath:path.join(dir,"export_manifest.json"),
    outputPath:source,status:"export_ready",createdAt:manifest.exportedAt
  };
  project.finalMasterReleasedFilmDeliveryExport=exportRecord;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,export:exportRecord,manifest};
}
module.exports={exportReleasedFilmDelivery};
