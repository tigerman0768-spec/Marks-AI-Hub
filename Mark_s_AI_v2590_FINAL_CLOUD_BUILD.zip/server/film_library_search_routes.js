const {searchFilms}=require("./film_library_search");
function registerFilmLibrarySearchRoutes(app){
 app.get("/api/film-library/search",(req,res)=>{
  try{res.json({films:searchFilms({q:req.query.q,sort:req.query.sort,favourite:req.query.favourite==="true"})});}
  catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFilmLibrarySearchRoutes};
