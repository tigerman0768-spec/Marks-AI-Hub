const path=require("path");
const {getProject}=require("./film_projects");
const {createReleasedFilmDeliverySnapshot}=require("./released_film_delivery_snapshot");
function registerReleasedFilmDeliverySnapshotRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-snapshot",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,snapshot:p.finalMasterReleasedFilmDeliverySnapshot||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-snapshot/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleasedFilmDeliverySnapshot(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliverySnapshotRoutes};
