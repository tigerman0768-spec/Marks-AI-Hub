const fs=require("fs");
const path=require("path");

function dialogueFile(dir,id){return path.join(dir,`${id}.json`);}
function loadDialogue(dir,projectId){
  const f=dialogueFile(dir,projectId);
  if(!fs.existsSync(f))return {projectId,tracks:[],updatedAt:null};
  try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch{return {projectId,tracks:[],updatedAt:null}};
}
function saveDialogue(dir,projectId,tracks){
  fs.mkdirSync(dir,{recursive:true});
  const clean=tracks.map((t,i)=>({
    id:String(t.id||`dialogue-${Date.now()}-${i}`),
    character:String(t.character||"Speaker"),
    text:String(t.text||""),
    audioPath:String(t.audioPath||""),
    start:Math.max(0,Number(t.start||0)),
    duration:Math.max(0,Number(t.duration||0)),
    volume:Math.max(0,Math.min(2,Number(t.volume??1))),
    duckMusic:Boolean(t.duckMusic??true),
    duckLevel:Math.max(0,Math.min(1,Number(t.duckLevel??0.25))),
    order:i
  }));
  const record={projectId,updatedAt:new Date().toISOString(),tracks:clean};
  fs.writeFileSync(dialogueFile(dir,projectId),JSON.stringify(record,null,2));
  return record;
}
function editDialogue(dir,projectId,action,payload={}){
  const current=loadDialogue(dir,projectId);
  let tracks=[...(current.tracks||[])];
  if(action==="add")tracks.push(payload.track||{});
  else if(action==="update"){
    const i=Number(payload.index);
    if(i<0||i>=tracks.length)throw new Error("invalid dialogue track");
    tracks[i]={...tracks[i],...(payload.track||{})};
  }else if(action==="remove"){
    const i=Number(payload.index);
    if(i<0||i>=tracks.length)throw new Error("invalid dialogue track");
    tracks.splice(i,1);
  }else if(action==="reorder"){
    const a=Number(payload.from),b=Number(payload.to);
    if(a<0||b<0||a>=tracks.length||b>=tracks.length)throw new Error("invalid dialogue positions");
    const [x]=tracks.splice(a,1);tracks.splice(b,0,x);
  }else throw new Error("unsupported dialogue action");
  return saveDialogue(dir,projectId,tracks);
}
module.exports={loadDialogue,saveDialogue,editDialogue};
