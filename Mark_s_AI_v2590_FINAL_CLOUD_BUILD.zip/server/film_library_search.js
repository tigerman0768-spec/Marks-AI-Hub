const path=require("path");
const {listFilms}=require("./film_library");
const DIR=path.join(process.cwd(),"films");
function searchFilms(options={}){
 const q=String(options.q||"").trim().toLowerCase();
 const favourite=options.favourite===true;
 let films=listFilms(DIR);
 if(q)films=films.filter(f=>[f.title,f.genre,f.style,f.description].some(v=>String(v||"").toLowerCase().includes(q)));
 if(favourite)films=films.filter(f=>f.favourite===true);
 const sort=String(options.sort||"newest");
 films.sort((a,b)=>{
  if(sort==="oldest")return Date.parse(a.createdAt||0)-Date.parse(b.createdAt||0);
  if(sort==="title")return String(a.title||"").localeCompare(String(b.title||""));
  if(sort==="duration")return Number(b.duration||0)-Number(a.duration||0);
  return Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0);
 });
 return films;
}
module.exports={searchFilms};
