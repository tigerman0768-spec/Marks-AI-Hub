const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function verifyReleasedFilm(project){
  const release=project?.finalMasterLibraryRelease;
  if(!release?.libraryReleaseId) return {verified:false,blockers:["library release is missing"]};
  const output=release.outputPath;
  if(!output||!fs.existsSync(output)) return {verified:false,blockers:["released film file is missing"]};
  const stat=fs.statSync(output);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  const blockers=[];
  if(sha!==release.sha256) blockers.push("SHA-256 mismatch");
  if(stat.size!==Number(release.bytes)) blockers.push("file size mismatch");
  const verification={
    verificationId:`release_verify_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    libraryReleaseId:release.libraryReleaseId,
    projectId:project.id,
    filename:path.basename(output),
    bytes:stat.size,
    sha256:sha,
    expectedSha256:release.sha256,
    verified:blockers.length===0,
    blockers,
    verifiedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"verification.json"),JSON.stringify(verification,null,2));
  project.finalMasterLibraryReleaseVerification=verification;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {verified:verification.verified,verification};
}
module.exports={verifyReleasedFilm};
