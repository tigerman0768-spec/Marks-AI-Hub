function normaliseAudioSettings(settings={}){
  return {
    clipVolume:Math.max(0,Math.min(2,Number(settings.clipVolume??1))),
    musicVolume:Math.max(0,Math.min(2,Number(settings.musicVolume??0.35))),
    musicPath:settings.musicPath||"",
    loopMusic:Boolean(settings.loopMusic??true),
  };
}
function buildAudioGraph(items,settings={}){
  const s=normaliseAudioSettings(settings);
  const filters=[];
  items.forEach((item,i)=>{
    filters.push(`[${i}:a]aresample=48000,volume=${s.clipVolume}[a${i}]`);
  });
  if(items.length===1)return {filters,audio:"[a0]"};
  let current="[a0]";
  for(let i=1;i<items.length;i++){
    const prev=items[i-1];
    const tr=typeof prev.transition==="string"?{type:prev.transition,duration:0}:(prev.transition||{});
    const d=Math.max(0,Math.min(5,Number(tr.duration||0)));
    if(d>0){
      filters.push(`${current}[a${i}]acrossfade=d=${d}:c1=tri:c2=tri[aX${i}]`);
      current=`[aX${i}]`;
    }else{
      filters.push(`${current}[a${i}]concat=n=2:v=0:a=1[aC${i}]`);
      current=`[aC${i}]`;
    }
  }
  return {filters,audio:current};
}
module.exports={normaliseAudioSettings,buildAudioGraph};
