function buildDialogueFilters(tracks=[]){
  return tracks.map((t,i)=>{
    const delay=Math.round(Math.max(0,Number(t.start||0))*1000);
    const volume=Math.max(0,Math.min(2,Number(t.volume??1)));
    return `[${i}:a]aresample=48000,volume=${volume},adelay=${delay}|${delay}[dialogue${i}]`;
  });
}
function buildDuckWindows(tracks=[]){
  return tracks.filter(t=>t.duckMusic!==false).map(t=>({
    start:Math.max(0,Number(t.start||0)),
    end:Math.max(Number(t.start||0),Number(t.start||0)+Number(t.duration||0)),
    level:Math.max(0,Math.min(1,Number(t.duckLevel??0.25)))
  }));
}
module.exports={buildDialogueFilters,buildDuckWindows};
