const path=require("path");
const {getProject}=require("./film_projects");
const {exportReleasedFilmDelivery}=require("./released_film_delivery_export");
function registerReleasedFilmDeliveryExportRoutes(app){
  app.get("/api/projects/:id/final-render/library-release/delivery-export",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,export:p.finalMasterReleasedFilmDeliveryExport||null});
  });
  app.post("/api/projects/:id/final-render/library-release/delivery-export/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=exportReleasedFilmDelivery(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliveryExportRoutes};
