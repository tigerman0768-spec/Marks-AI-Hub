const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createReleasedFilmDeliverySnapshot(project){
  const seal=project?.finalMasterReleasedFilmDeliverySeal;
  const audit=project?.finalMasterReleasedFilmDeliveryAudit;
  if(seal?.status!=="sealed")return {ready:false,blockers:["final delivery must be sealed"]};
  if(!seal.outputPath||!fs.existsSync(seal.outputPath))return {ready:false,blockers:["sealed final film file is missing"]};
  const stat=fs.statSync(seal.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(seal.outputPath)).digest("hex");
  const blockers=[];
  if(sha!==seal.sha256)blockers.push("sealed film hash mismatch");
  if(stat.size!==Number(seal.bytes))blockers.push("sealed film size mismatch");
  const snapshot={
    snapshotId:`delivery_snapshot_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    outputPath:seal.outputPath,bytes:stat.size,sha256:sha,
    sealId:seal.sealId,auditEventCount:Array.isArray(audit)?audit.length:0,
    capturedAt:new Date().toISOString(),status:blockers.length?"blocked":"captured",blockers
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_snapshot");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"delivery_snapshot.json"),JSON.stringify(snapshot,null,2));
  project.finalMasterReleasedFilmDeliverySnapshot=snapshot;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:blockers.length===0,snapshot};
}
module.exports={createReleasedFilmDeliverySnapshot};
