const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function run(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]}); let err="";
    p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-5000))));
  });
}
function file(v){return typeof v==="string"&&fs.existsSync(v)?v:null;}
function normaliseWindows(project={}){
  const raw=project.dialogueWindows||project.dialogueDuckWindows||
    project.dialogueTimeline?.windows||project.audioTiming?.dialogueWindows||[];
  return raw.map(w=>({start:Math.max(0,Number(w.start||0)),end:Math.max(0,Number(w.end||0))}))
    .filter(w=>w.end>w.start);
}
function duckExpression(windows,amount=0.28){
  if(!windows.length)return null;
  const terms=windows.map(w=>`between(t\\,${w.start}\\,${w.end})`).join("+");
  return `volume=if(gt(${terms}\\,0)\\,${amount}\\,1)`;
}
async function masterWithDucking(project={},options={}){
  const source=project.aiFinalFinish?.outputPath||project.aiTransitionRender?.outputPath||project.aiFilmAssembly?.outputPath;
  if(!source||!fs.existsSync(source))throw new Error("no final video available");
  const music=file(project.musicPath)||file(project.backgroundMusicPath);
  const dialogue=file(project.dialoguePath);
  const sfx=file(project.sfxPath);
  const windows=normaliseWindows(project);
  const dir=options.outputDir||path.join(process.cwd(),"output");fs.mkdirSync(dir,{recursive:true});
  const out=options.outputPath||path.join(dir,`${project.id}-ducked-master.mp4`);
  const inputs=[source],tracks=[];
  for(const p of [music,dialogue,sfx])if(p){inputs.push(p);tracks.push(inputs.length-1);}
  const args=["-y"];inputs.forEach(x=>args.push("-i",x));
  const filters=[];
  if(music&&dialogue){
    filters.push(`[1:a]${duckExpression(windows,0.28)||"anull"}[musicduck]`);
    filters.push(`[musicduck][2:a]amix=inputs=2:duration=first:dropout_transition=2[mix]`);
    if(sfx)filters.push(`[mix][3:a]amix=inputs=2:duration=first:dropout_transition=2[aout]`);
    else filters.push(`[mix]alimiter=limit=0.95[aout]`);
  }else if(tracks.length){
    const labels=tracks.map(i=>`[${i}:a]`).join("");
    filters.push(`${labels}amix=inputs=${tracks.length}:duration=first:dropout_transition=2,alimiter=limit=0.95[aout]`);
  }
  if(filters.length)args.push("-filter_complex",filters.join(";"));
  args.push("-map","0:v:0","-map",filters.length?"[aout]":"0:a:0?",
    "-c:v","libx264","-preset","veryfast","-crf","18","-c:a","aac","-b:a","192k",
    "-movflags","+faststart",out);
  await run(args);
  return {projectId:project.id,outputPath:out,duckingApplied:!!(music&&dialogue&&windows.length),
    duckWindows:windows.length,duckAmount:0.28,audioTracks:{music:!!music,dialogue:!!dialogue,sfx:!!sfx},
    createdAt:new Date().toISOString(),engine:"ai-audio-ducking-master"};
}
module.exports={masterWithDucking,normaliseWindows,duckExpression};
