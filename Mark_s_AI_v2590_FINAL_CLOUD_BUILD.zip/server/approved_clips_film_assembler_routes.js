const path=require("path");
const {getProject}=require("./film_projects");
const {buildApprovedFilmTimeline,getApprovedFilmTimeline}=require("./approved_clips_film_assembler");

function registerApprovedFilmAssemblerRoutes(app){
  app.get("/api/projects/:id/approved-film-timeline",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,timeline:getApprovedFilmTimeline(p)});
  });
  app.post("/api/projects/:id/approved-film-timeline/build",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=buildApprovedFilmTimeline(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerApprovedFilmAssemblerRoutes};
