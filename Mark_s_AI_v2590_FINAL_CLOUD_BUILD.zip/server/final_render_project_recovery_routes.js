const path=require("path");
const {restartProjectFinalRender}=require("./final_render_project_recovery");
function registerFinalRenderProjectRecoveryRoutes(app){
  app.post("/api/projects/:id/final-render-restart",async(req,res)=>{
    try{
      const result=await restartProjectFinalRender(req.params.id,{outputDir:path.join(process.cwd(),"output")});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalRenderProjectRecoveryRoutes};
