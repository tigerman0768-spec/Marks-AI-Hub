const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerAiPromptPackRoutes(app) {
  app.post("/api/projects/:id/ai-prompt-pack", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const scenes = Array.isArray(p.scenes) ? p.scenes : [];
    const characters = Array.isArray(p.characters) ? p.characters : [];
    const shotCards = Array.isArray(p.shotCards) ? p.shotCards : [];

    const pack = {
      projectId: p.id,
      title: p.title || "Untitled Film",
      style: p.style || "Cinematic",
      aspectRatio: p.aspectRatio || "16:9",
      resolution: p.resolution || "1080p",
      globalDirection:
        `Create a ${p.style || "Cinematic"} film in ${p.aspectRatio || "16:9"}. ` +
        `Maintain visual continuity, character identity, wardrobe, lighting, geography and tone across every shot.`,
      characterReferences: characters.map((c, i) => ({
        id: c.id || `character-${i + 1}`,
        name: c.name || c.character || `Character ${i + 1}`,
        description: c.description || c.appearance || ""
      })),
      shots: (shotCards.length ? shotCards : scenes).map((s, i) => ({
        id: s.id || `shot-${i + 1}`,
        scene: s.sceneNumber || s.scene || i + 1,
        prompt: [
          p.style || "Cinematic",
          s.visualDirection || s.visual || s.description || s.action || "",
          s.camera || s.cameraMovement || "",
          s.lighting || "",
          s.mood || s.emotionalBeat || "",
          "Maintain continuity with previous and following shots."
        ].filter(Boolean).join(". "),
        duration: Number(s.duration || s.targetDuration || 5)
      }))
    };

    p.aiPromptPack = pack;
    p.aiPromptPackCreatedAt = new Date().toISOString();
    saveProject(path.join(process.cwd(), "projects"), p);

    res.json({
      projectId: p.id,
      shotCount: pack.shots.length,
      characterCount: pack.characterReferences.length,
      promptPack: pack
    });
  });

  app.get("/api/projects/:id/ai-prompt-pack", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    if (!p.aiPromptPack) return res.status(404).json({ error: "prompt pack not created" });
    res.json(p.aiPromptPack);
  });
}

module.exports = { registerAiPromptPackRoutes };
