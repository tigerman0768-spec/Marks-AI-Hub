const fs=require("fs"),crypto=require("crypto");
function verifyReleaseManifest(m){
  if(!m?.manifestPath||!fs.existsSync(m.manifestPath))return {verified:false,reason:"manifest file is missing"};
  const stored=JSON.parse(fs.readFileSync(m.manifestPath,"utf8"));
  const copy={...stored}; delete copy.manifestSha256;
  const actual=crypto.createHash("sha256").update(JSON.stringify(copy)).digest("hex");
  return {verified:actual===stored.manifestSha256,expectedSha256:stored.manifestSha256,actualSha256:actual};
}
module.exports={verifyReleaseManifest};
