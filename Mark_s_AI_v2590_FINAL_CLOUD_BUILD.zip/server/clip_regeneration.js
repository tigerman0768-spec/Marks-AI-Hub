const crypto=require("crypto");
function createRegenerationJob(shot,options={}){
  if(!shot)throw new Error("shot required");
  return {
    id:crypto.randomUUID(),sceneId:shot.sceneId,shotNumber:shot.shotNumber,
    provider:options.provider||"runway",duration:Number(options.duration||5),
    aspectRatio:options.aspectRatio||"16:9",
    prompt:options.prompt||shot.prompt||"",status:"queued",attempts:0,
    replacesJobId:shot.id||null,output:null,error:null
  };
}
module.exports={createRegenerationJob};
