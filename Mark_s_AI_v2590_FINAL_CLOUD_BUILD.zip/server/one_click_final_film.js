const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {renderAiTransitions}=require("./ai_transition_renderer");
const {professionalDuck}=require("./professional_audio_ducking");

async function createOneClickFinalFilm(project,options={}){
  const transition=await renderAiTransitions(project,{outputPath:path.join(process.cwd(),"output",`${project.id}-oneclick-video.mp4`)});
  const staged={...project,aiTransitionRender:transition};
  const finish=await professionalDuck(staged,{outputPath:path.join(process.cwd(),"output",`${project.id}-FINAL.mp4`)});
  return {projectId:project.id,video:transition,final:finish,status:"one_click_complete",
    createdAt:new Date().toISOString()};
}
function registerOneClickFinalFilmRoutes(app){
  app.post("/api/projects/:id/one-click-final",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await createOneClickFinalFilm(project);
      saveProject(dir,{...project,oneClickFinalFilm:result,status:"final_film_ready"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={createOneClickFinalFilm,registerOneClickFinalFilmRoutes};
