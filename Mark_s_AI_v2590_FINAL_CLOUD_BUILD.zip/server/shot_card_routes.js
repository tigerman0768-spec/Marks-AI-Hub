const path=require("path");
const {getProject}=require("./film_projects");
const {buildShotCards}=require("./shot_cards");
function registerShotCardRoutes(app){
  app.get("/api/projects/:id/shot-cards",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,shots:buildShotCards(p)});
  });
}
module.exports={registerShotCardRoutes};
