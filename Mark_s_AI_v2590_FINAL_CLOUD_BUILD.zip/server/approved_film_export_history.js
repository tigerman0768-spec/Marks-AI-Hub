const fs=require("fs");
const path=require("path");
function historyPath(projectId){
  return path.join(process.cwd(),"projects",String(projectId),"film_library","exports","history.json");
}
function appendExportHistory(project,record){
  const p=historyPath(project.id);
  fs.mkdirSync(path.dirname(p),{recursive:true});
  let items=[];
  if(fs.existsSync(p)){try{items=JSON.parse(fs.readFileSync(p,"utf8"))||[]}catch{}}
  items=Array.isArray(items)?items:[];
  items.unshift({...record,projectId:project.id});
  fs.writeFileSync(p,JSON.stringify(items.slice(0,50),null,2));
  return items[0];
}
function getExportHistory(projectId){
  const p=historyPath(projectId);
  if(!fs.existsSync(p))return [];
  try{
    const x=JSON.parse(fs.readFileSync(p,"utf8"));
    return Array.isArray(x)?x:[];
  }catch{return []}
}
module.exports={appendExportHistory,getExportHistory};
