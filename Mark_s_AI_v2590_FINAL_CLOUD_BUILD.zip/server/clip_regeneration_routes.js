const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildShotCards}=require("./shot_cards");
const {createRegenerationJob}=require("./clip_regeneration");
function registerClipRegenerationRoutes(app){
  app.post("/api/projects/:id/clips/:jobId/regenerate",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const shot=buildShotCards(project).find(x=>x.id===req.params.jobId);
      if(!shot)return res.status(404).json({error:"shot not found"});
      const job=createRegenerationJob(shot,{provider:project.videoProvider,duration:project.shotDuration,aspectRatio:project.aspectRatio,prompt:req.body?.prompt});
      const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
      saveProject(dir,{...project,videoJobs:[...jobs,job],status:"video_regeneration_queued"});
      res.status(202).json(job);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerClipRegenerationRoutes};
