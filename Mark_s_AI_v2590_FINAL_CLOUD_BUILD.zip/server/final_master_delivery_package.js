const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function buildDeliveryPackage(project){
  const gate=project.finalMasterGate||{};
  const q=project.finalRenderQueueRecord||{};
  const output=q.outputPath||project.finalRenderOutput||null;
  const exists=Boolean(output&&fs.existsSync(output));
  if(!gate.ready||!exists) return {ready:false,blockers:[...(gate.blockers||[]),...(exists?[]:["final output file is missing"])].filter(Boolean)};
  const stat=fs.statSync(output);
  const meta=q.mediaMetadata||{};
  return {
    ready:true,
    projectId:project.id,title:project.title||"Untitled Film",
    outputPath:output,bytes:stat.size,
    duration:Number(meta.duration||0),
    video:meta.video||null,audio:meta.audio||null,
    createdAt:new Date().toISOString()
  };
}
function saveDeliveryPackage(project){
  const pkg=buildDeliveryPackage(project);
  project.finalMasterDeliveryPackage=pkg;
  saveProject(path.join(process.cwd(),"projects"),project);
  return pkg;
}
module.exports={buildDeliveryPackage,saveDeliveryPackage};
