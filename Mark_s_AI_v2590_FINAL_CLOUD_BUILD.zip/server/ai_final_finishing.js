const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function runFfmpeg(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});
    let err="";p.stderr.on("data",d=>err+=d);
    p.on("close",code=>code===0?resolve():reject(new Error(err.slice(-4000))));
  });
}
function existingAudio(project,key){
  const v=project[key];
  return v&&typeof v==="string"&&fs.existsSync(v)?v:null;
}
async function finishFilm(project={},options={}){
  const video=existingAudio(project,"aiTransitionRender")?null:null;
  const source=project.aiTransitionRender?.outputPath||project.aiFilmAssembly?.outputPath;
  if(!source||!fs.existsSync(source))throw new Error("no assembled video available");
  const dir=options.outputDir||path.join(process.cwd(),"output");
  fs.mkdirSync(dir,{recursive:true});
  const outputPath=options.outputPath||path.join(dir,`${project.id}-finished.mp4`);
  const inputs=[source], audio=[];
  const music=existingAudio(project,"musicPath")||existingAudio(project,"backgroundMusicPath");
  const dialogue=existingAudio(project,"dialoguePath");
  const sfx=existingAudio(project,"sfxPath");
  if(music){inputs.push(music);audio.push(1);}
  if(dialogue){inputs.push(dialogue);audio.push(inputs.length-1);}
  if(sfx){inputs.push(sfx);audio.push(inputs.length-1);}
  const args=["-y"];
  inputs.forEach(x=>args.push("-i",x));
  if(!audio.length){
    args.push("-map","0:v:0","-map","0:a:0?","-c:v","libx264","-preset","veryfast","-crf","18","-c:a","aac","-movflags","+faststart",outputPath);
  }else{
    const labels=audio.map((_,i)=>`[${i+1}:a]`).join("");
    args.push("-filter_complex",`${labels}amix=inputs=${audio.length}:duration=first:dropout_transition=2[aout]`,
      "-map","0:v:0","-map","[aout]","-c:v","libx264","-preset","veryfast","-crf","18",
      "-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath);
  }
  await runFfmpeg(args);
  return {projectId:project.id,outputPath,videoSource:source,
    audioTracks:{music:!!music,dialogue:!!dialogue,sfx:!!sfx},
    subtitlesAvailable:!!project.subtitles||!!project.subtitleFile,
    createdAt:new Date().toISOString(),engine:"ai-final-finishing"};
}
module.exports={finishFilm};
