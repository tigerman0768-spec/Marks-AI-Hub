const path=require("path");
const {getProject}=require("./film_projects");
const {recordReleaseDeliveryAudit,getReleaseDeliveryAudit}=require("./released_film_delivery_audit");
function registerReleasedFilmDeliveryAuditRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-audit",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,audit:getReleaseDeliveryAudit(p)});
  });
  app.post("/api/projects/:id/final-render/release-delivery-audit",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const event=String(req.body?.event||"manual_review");
    const entry=recordReleaseDeliveryAudit(p,event,req.body?.details||{});
    res.status(201).json({projectId:p.id,entry,audit:getReleaseDeliveryAudit(p)});
  });
}
module.exports={registerReleasedFilmDeliveryAuditRoutes};
