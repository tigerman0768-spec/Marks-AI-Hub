const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function verifyReleasedFilmDeliveryExport(project){
  const exp=project?.finalMasterReleasedFilmDeliveryExport;
  if(!exp?.exportId)return {verified:false,blockers:["release export is missing"]};
  if(!exp.manifestPath||!fs.existsSync(exp.manifestPath))return {verified:false,blockers:["export manifest is missing"]};
  let manifest;
  try{manifest=JSON.parse(fs.readFileSync(exp.manifestPath,"utf8"));}catch(e){return {verified:false,blockers:["export manifest is invalid"]};}
  const output=manifest.sourcePath||exp.outputPath;
  if(!output||!fs.existsSync(output))return {verified:false,blockers:["final film file is missing"]};
  const stat=fs.statSync(output);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  const blockers=[];
  if(sha!==manifest.sha256)blockers.push("export manifest SHA-256 mismatch");
  if(stat.size!==Number(manifest.bytes))blockers.push("export manifest file size mismatch");
  const verification={
    verificationId:`export_verify_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    exportId:exp.exportId,packageId:manifest.packageId,projectId:project.id,
    bytes:stat.size,sha256:sha,expectedSha256:manifest.sha256,
    verified:blockers.length===0,blockers,verifiedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_export");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"export_verification.json"),JSON.stringify(verification,null,2));
  project.finalMasterReleasedFilmDeliveryExportVerification=verification;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {verified:verification.verified,verification};
}
module.exports={verifyReleasedFilmDeliveryExport};
