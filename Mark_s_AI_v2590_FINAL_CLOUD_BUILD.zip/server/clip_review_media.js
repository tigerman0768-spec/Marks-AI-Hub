function buildClipMedia(projectId,job){
  if(!job)return null;
  return {
    jobId:job.id,
    clipUrl:`/api/projects/${projectId}/clips/${job.id}`,
    available:Boolean(job.clipPath && job.downloadStatus==="downloaded"),
    bytes:Number(job.clipBytes||0)
  };
}
module.exports={buildClipMedia};
