const path = require("path");
const { getProject } = require("./film_projects");

function registerProjectCommandsRoutes(app) {
  app.get("/api/projects/:id/command-center", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const has = (...keys) => keys.some(k => {
      const v = p[k];
      return Array.isArray(v) ? v.length > 0 : Boolean(v);
    });

    const commands = [
      { id: "screenplay", label: "Screenplay", ready: has("screenplay", "scenes") },
      { id: "production", label: "Production Plan", ready: has("characterBible", "storyboard", "shotCards") },
      { id: "video", label: "Video Generation", ready: has("videoGeneration", "videoGenerationStatus", "generationJobs") },
      { id: "edit", label: "AI Edit", ready: has("timeline", "finalTimeline", "aiEditPlan") },
      { id: "finishing", label: "Final Finishing", ready: has("finalFinishingPlan") },
      { id: "master", label: "Final Master", ready: has("finalMaster", "finalFilm", "libraryId") }
    ];

    res.json({
      projectId: p.id,
      title: p.title || "Untitled Film",
      status: p.status || "draft",
      favourite: Boolean(p.favourite),
      commands,
      canResume: commands.some(c => !c.ready),
      next: commands.find(c => !c.ready)?.id || "library"
    });
  });
}

module.exports = { registerProjectCommandsRoutes };
