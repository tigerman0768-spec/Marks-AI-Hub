const path=require('path');
const {getProject}=require('./film_projects');
const {releaseReadiness}=require('./approved_film_release_readiness');
const {approveRelease}=require('./approved_film_release_approval');
const {sealRelease}=require('./approved_film_release_seal');
const {createReleaseCertificate}=require('./approved_film_release_certificate');
const {saveReleaseManifest}=require('./approved_film_release_manifest');
const {saveProject}=require('./film_projects');

function executeOneTapRelease(project, onProgress=()=>{}){
  const steps=[];
  let current=project;
  onProgress({step:'readiness',status:'running'});
  const readiness=releaseReadiness(current);
  steps.push({step:'readiness',ok:readiness.ready,result:readiness});
  onProgress({step:'readiness',status:readiness.ready?'complete':'blocked',result:readiness});
  if(!readiness.ready)return {complete:false,steps,nextStep:'readiness'};

  if(!current.approvedFilmReleaseApproval?.approved){
    onProgress({step:'approval',status:'running'});
    const result=approveRelease(current); steps.push({step:'approval',ok:result.approved,result});
    onProgress({step:'approval',status:result.approved?'complete':'blocked',result});
    if(!result.approved)return {complete:false,steps,nextStep:'approval'};
    current=getProject(path.join(process.cwd(),'projects'),String(project.id))||current;
  } else { steps.push({step:'approval',ok:true,result:{approved:true,alreadyComplete:true}}); onProgress({step:'approval',status:'complete',result:{approved:true,alreadyComplete:true}}); }

  if(!current.approvedFilmReleaseSeal?.sealed){
    onProgress({step:'seal',status:'running'});
    const result=sealRelease(current); steps.push({step:'seal',ok:result.sealed,result});
    onProgress({step:'seal',status:result.sealed?'complete':'blocked',result});
    if(!result.sealed)return {complete:false,steps,nextStep:'seal'};
    current=getProject(path.join(process.cwd(),'projects'),String(project.id))||current;
  } else { steps.push({step:'seal',ok:true,result:{sealed:true,alreadyComplete:true}}); onProgress({step:'seal',status:'complete',result:{sealed:true,alreadyComplete:true}}); }

  if(!(current.approvedFilmReleaseCertificate?.certificateId||current.approvedFilmReleaseCertificate?.id)){
    onProgress({step:'certificate',status:'running'});
    const result=createReleaseCertificate(current); steps.push({step:'certificate',ok:result.issued,result});
    onProgress({step:'certificate',status:result.issued?'complete':'blocked',result});
    if(!result.issued)return {complete:false,steps,nextStep:'certificate'};
    current=getProject(path.join(process.cwd(),'projects'),String(project.id))||current;
  } else { steps.push({step:'certificate',ok:true,result:{issued:true,alreadyComplete:true}}); onProgress({step:'certificate',status:'complete',result:{issued:true,alreadyComplete:true}}); }

  if(!current.approvedFilmReleaseManifest?.manifestPath){
    onProgress({step:'manifest',status:'running'});
    const manifest=saveReleaseManifest(current);
    current.approvedFilmReleaseManifest=manifest;
    saveProject(path.join(process.cwd(),'projects'),current);
    steps.push({step:'manifest',ok:true,result:manifest});
    onProgress({step:'manifest',status:'complete',result:manifest});
  } else { steps.push({step:'manifest',ok:true,result:{saved:true,alreadyComplete:true}}); onProgress({step:'manifest',status:'complete',result:{saved:true,alreadyComplete:true}}); }

  return {complete:true,steps,nextStep:null,projectId:current.id};
}

module.exports={executeOneTapRelease};
