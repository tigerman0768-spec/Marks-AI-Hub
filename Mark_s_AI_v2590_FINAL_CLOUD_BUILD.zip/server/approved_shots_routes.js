const path=require("path");
const {getProject}=require("./film_projects");
const {getClipReview}=require("./clip_review");
const {getApprovedShots,buildApprovalSummary}=require("./approved_shots");

function registerApprovedShotsRoutes(app){
  app.get("/api/projects/:id/approved-shots",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const reviews=getClipReview(path.join(process.cwd(),"reviews"),project.id);
    const merged={...project,clipReviews:reviews};
    res.json({
      projectId:project.id,
      summary:buildApprovalSummary(merged),
      shots:getApprovedShots(merged)
    });
  });
}
module.exports={registerApprovedShotsRoutes};
