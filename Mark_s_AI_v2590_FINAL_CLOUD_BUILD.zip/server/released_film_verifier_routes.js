const path=require("path");
const {getProject}=require("./film_projects");
const {verifyReleasedFilm}=require("./released_film_verifier");
function registerReleasedFilmVerifierRoutes(app){
  app.get("/api/projects/:id/final-render/library-release/verification",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,verification:p.finalMasterLibraryReleaseVerification||null});
  });
  app.post("/api/projects/:id/final-render/library-release/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=verifyReleasedFilm(p);
    res.status(result.verified?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmVerifierRoutes};
