const fs=require("fs"),path=require("path");
function registerProjectCloneTemplateRoutes(app){
 app.post("/api/projects/template",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});
  const id=`template-${Date.now()}`,now=new Date().toISOString();
  const p={id,title:String(req.body?.title||"New Film"),idea:"",genre:String(req.body?.genre||"Drama"),length:Number(req.body?.length||5),style:String(req.body?.style||"Cinematic"),aspectRatio:String(req.body?.aspectRatio||"16:9"),status:"draft",screenplay:"",characters:[],scenes:[],createdAt:now,updatedAt:now};
  fs.writeFileSync(path.join(dir,`${id}.json`),JSON.stringify(p,null,2));res.status(201).json({projectId:id,title:p.title});
 });
}
module.exports={registerProjectCloneTemplateRoutes};
