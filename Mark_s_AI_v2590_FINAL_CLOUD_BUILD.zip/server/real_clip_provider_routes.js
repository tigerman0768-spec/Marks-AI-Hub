const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");
const {submitRunwayClip,getRunwayTask,downloadRunwayOutput}=require("./runway_real_clip_provider");

function registerRealClipProviderRoutes(app){
  app.post("/api/projects/:id/clips/provider/runway",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    (async()=>{
      try{
        const result=await submitRunwayClip({
          prompt:req.body?.prompt,duration:req.body?.duration||5,
          aspectRatio:req.body?.aspectRatio||p.aspectRatio||"16:9",
          model:req.body?.model||"gen4.5"
        });
        if(!result.ready)return res.status(409).json({projectId:p.id,...result});
        const record={provider:"runway",taskId:result.taskId,status:"submitted",createdAt:new Date().toISOString(),request:req.body||{}};
        p.realClipProviderJobs=[...(p.realClipProviderJobs||[]),record];
        saveProject(path.join(process.cwd(),"projects"),p);
        res.status(202).json({projectId:p.id,...record});
      }catch(e){res.status(502).json({error:e.message,provider:"runway"});}
    })();
  });

  app.get("/api/projects/:id/clips/provider/runway/:taskId",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    (async()=>{
      try{
        const result=await getRunwayTask(req.params.taskId);
        if(!result.ready)return res.status(409).json(result);
        const task=result.task||{};
        const jobs=[...(p.realClipProviderJobs||[])];
        const i=jobs.findIndex(j=>String(j.taskId)===String(req.params.taskId));
        if(i>=0){jobs[i]={...jobs[i],status:String(task.status||"unknown").toLowerCase(),lastCheckedAt:new Date().toISOString(),failureCode:task.failureCode||null};p.realClipProviderJobs=jobs;}
        if(i>=0&&String(task.status)==="SUCCEEDED"&&Array.isArray(task.output)&&task.output[0]){
          const dir=path.join(process.cwd(),"projects",String(p.id),"video_generation","real_clips");
          fs.mkdirSync(dir,{recursive:true});
          const file=path.join(dir,`runway_${req.params.taskId}.mp4`);
          await downloadRunwayOutput(task.output[0],file);
          const stat=fs.statSync(file);
          const sha=crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
          jobs[i]={...jobs[i],status:"downloaded",outputPath:file,bytes:stat.size,sha256:sha,downloadedAt:new Date().toISOString()};
          p.realClipProviderJobs=jobs;
          p.generatedRealClips=[...(p.generatedRealClips||[]),{
            clipId:`real_clip_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`,
            taskId:req.params.taskId,provider:"runway",outputPath:file,bytes:stat.size,sha256:sha,
            createdAt:new Date().toISOString(),status:"ready"
          }];
        }
        saveProject(path.join(process.cwd(),"projects"),p);
        res.json({projectId:p.id,...result,localClip:jobs[i]?.outputPath||null});
      }catch(e){res.status(502).json({error:e.message,provider:"runway"});}
    })();
  });
}
module.exports={registerRealClipProviderRoutes};
