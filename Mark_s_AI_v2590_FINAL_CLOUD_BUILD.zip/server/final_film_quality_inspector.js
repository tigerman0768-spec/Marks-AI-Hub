const fs=require("fs");
const {spawn}=require("child_process");

function probe(file){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffprobe",["-v","error","-print_format","json","-show_format","-show_streams",file]);
    let out="",err="";p.stdout.on("data",d=>out+=d);p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve(JSON.parse(out)):reject(new Error(err.slice(-3000))));
  });
}
async function inspectFinalFilm(filePath={}){
  const file=typeof filePath==="string"?filePath:filePath.outputPath;
  if(!file||!fs.existsSync(file))return {status:"failed",playable:false,error:"final film not found"};
  const stat=fs.statSync(file);
  if(stat.size<1000)return {status:"failed",playable:false,error:"final film is empty or too small"};
  try{
    const meta=await probe(file),format=meta.format||{};
    const streams=meta.streams||[],video=streams.find(s=>s.codec_type==="video"),audio=streams.find(s=>s.codec_type==="audio");
    const duration=Number(format.duration||video?.duration||0);
    const issues=[];
    if(duration<=0)issues.push("invalid duration");
    if(!video)issues.push("missing video stream");
    if(video&&(!video.width||!video.height))issues.push("missing video dimensions");
    if(video&&!video.codec_name)issues.push("missing video codec");
    if(!audio)issues.push("no audio stream");
    if(format.format_name&&!format.format_name.includes("mp4")&&!format.format_name.includes("mov"))issues.push("unexpected container");
    const score=Math.max(0,100-issues.length*18);
    return {status:issues.length===0?"passed":score>=60?"warning":"failed",playable:!!video&&duration>0,
      score,duration,width:video?.width||0,height:video?.height||0,
      videoCodec:video?.codec_name||null,audioCodec:audio?.codec_name||null,
      hasAudio:!!audio,fileSize:stat.size,issues,checkedAt:new Date().toISOString()};
  }catch(e){return {status:"failed",playable:false,error:e.message};}
}
module.exports={inspectFinalFilm};
