const path = require("path");
const { getProject } = require("./film_projects");

function registerProjectNextActionRoutes(app) {
  app.get("/api/projects/:id/next-action", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const scenes = Array.isArray(p.scenes) ? p.scenes : [];
    const shotCards = Array.isArray(p.shotCards) ? p.shotCards : [];

    const checks = [
      ["screenplay", Boolean(p.screenplay || scenes.length), "Create Screenplay"],
      ["production", Boolean(p.characterBible || p.storyboard || shotCards.length), "Build Production Plan"],
      ["video", Boolean(p.videoGeneration || p.videoGenerationStatus || p.generationJobs), "Generate Video Clips"],
      ["review", Boolean(p.clipReview || p.approvedShots || p.bestClips), "Review Generated Clips"],
      ["edit", Boolean(p.timeline || p.finalTimeline || p.aiEditPlan), "Build AI Edit"],
      ["audio", Boolean(p.finalAudioPlan || p.audioPlan || p.dialogueTimeline), "Prepare Audio & Dialogue"],
      ["finishing", Boolean(p.finalFinishingPlan), "Prepare Final Finishing"],
      ["master", Boolean(p.finalMaster || p.finalFilm || p.libraryId), "Render Final Master"],
    ];

    const firstMissing = checks.find(c => !c[1]);
    const completed = checks.filter(c => c[1]).length;

    res.json({
      projectId: p.id,
      title: p.title || "Untitled Film",
      status: p.status || "draft",
      completedStages: completed,
      totalStages: checks.length,
      progress: Math.round((completed / checks.length) * 100),
      nextStage: firstMissing ? firstMissing[0] : "library",
      nextAction: firstMissing ? firstMissing[2] : "Open Film Library",
      finished: !firstMissing,
      checks: Object.fromEntries(checks.map(c => [c[0], c[1]]))
    });
  });
}

module.exports = { registerProjectNextActionRoutes };
