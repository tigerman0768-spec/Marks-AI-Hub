const fs=require("fs");
const path=require("path");

function stateFile(dir,projectId){return path.join(dir,`${projectId}.json`);}
function getClipReview(dir,projectId){
  const p=stateFile(dir,projectId);
  if(!fs.existsSync(p))return {};
  try{return JSON.parse(fs.readFileSync(p,"utf8"));}catch{return {};}
}
function setClipReview(dir,projectId,jobId,changes={}){
  fs.mkdirSync(dir,{recursive:true});
  const all=getClipReview(dir,projectId);
  const current=all[jobId]||{decision:"pending",notes:"",updatedAt:null};
  all[jobId]={...current,...changes,updatedAt:new Date().toISOString()};
  fs.writeFileSync(stateFile(dir,projectId),JSON.stringify(all,null,2));
  return all[jobId];
}
module.exports={getClipReview,setClipReview};
