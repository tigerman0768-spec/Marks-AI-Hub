const {getFinalFilmResult}=require("./final_render_lifecycle");
function registerFinalRenderLifecycleRoutes(app){
 app.get("/api/final-render/jobs/:id/result",(req,res)=>{
  try{const x=getFinalFilmResult(req.params.id);if(!x)return res.status(404).json({error:"final render job not found"});
   if(x.status==="completed"&&!x.ready)return res.status(409).json({...x,error:"completed without usable final film output"});
   res.json(x);
  }catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFinalRenderLifecycleRoutes};
