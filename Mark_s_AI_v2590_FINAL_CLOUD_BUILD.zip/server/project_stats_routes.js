const fs=require("fs"),path=require("path");
function registerProjectStatsRoutes(app){
 app.get("/api/projects/:id/stats",(req,res)=>{
  const file=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(file))return res.status(404).json({error:"project not found"});
  const p=JSON.parse(fs.readFileSync(file,"utf8"));const scenes=p.scenes||[],chars=p.characters||[],shots=p.shotCards||[];
  res.json({projectId:p.id,title:p.title,counts:{characters:chars.length,scenes:scenes.length,shots:shots.length},storyLength:String(p.screenplay||"").length,hasProductionPlan:!!(p.characterBible||p.storyboard||shots.length),hasEdit:!!(p.aiEditPlan||p.finalTimeline),hasFinishing:!!p.finalFinishingPlan});
 });
}
module.exports={registerProjectStatsRoutes};
