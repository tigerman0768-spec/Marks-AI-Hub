const path=require('path');
const {getProject}=require('./film_projects');
const {saveReleaseCenter}=require('./released_film_release_center');
const {buildOneTapReleasePlan}=require('./one_tap_release');
const {executeOneTapRelease}=require('./one_tap_release_executor');
const {createJob,updateJob,getJob}=require('./one_tap_release_progress');

function registerReleaseCenterRoutes(app){
  app.get('/api/projects/:id/final-render/release-center',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    res.json(saveReleaseCenter(p));
  });
  app.get('/api/projects/:id/final-render/release-center/one-tap-plan',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    res.json(buildOneTapReleasePlan(p));
  });
  app.post('/api/projects/:id/final-render/release-center/one-tap-execute',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    const job=createJob(String(p.id));
    setImmediate(()=>{
      try{
        updateJob(job.jobId,{status:'running'});
        const result=executeOneTapRelease(p,progress=>{
          const j=getJob(job.jobId); if(!j)return;
          const completed=j.completedSteps.slice();
          if(progress.status==='running') updateJob(job.jobId,{currentStep:progress.step,steps:completed});
          else if(progress.status==='complete'){
            if(!completed.includes(progress.step))completed.push(progress.step);
            updateJob(job.jobId,{currentStep:null,completedSteps:completed,steps:completed});
          } else updateJob(job.jobId,{status:'blocked',currentStep:progress.step,steps:completed,error:progress.result?.reason||null});
        });
        updateJob(job.jobId,{status:result.complete?'complete':'blocked',currentStep:result.nextStep||null,steps:result.steps,completedSteps:result.steps.filter(s=>s.ok).map(s=>s.step),result});
      }catch(e){updateJob(job.jobId,{status:'failed',error:e.message});}
    });
    res.status(202).json({jobId:job.jobId,status:job.status});
  });
  app.get('/api/projects/:id/final-render/release-center/one-tap-execute/:jobId',(req,res)=>{
    const job=getJob(req.params.jobId);
    if(!job||String(job.projectId)!==String(req.params.id))return res.status(404).json({error:'release job not found'});
    res.json(job);
  });
}
module.exports={registerReleaseCenterRoutes};
