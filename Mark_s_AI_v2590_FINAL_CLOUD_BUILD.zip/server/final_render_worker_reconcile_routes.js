const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {reconcileFinalRenderProject,reconcileAllFinalRenders}=require("./final_render_worker_reconcile");

function registerFinalRenderWorkerReconcileRoutes(app){
  app.post("/api/projects/:id/final-render/reconcile",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=reconcileFinalRenderProject(p);saveProject(dir,p);
    res.json({projectId:p.id,queue:q,finalRenderReady:p.finalRenderReady===true});
  });
  app.post("/api/final-render/reconcile-all",(req,res)=>{
    res.json({reconciled:reconcileAllFinalRenders()});
  });
}
module.exports={registerFinalRenderWorkerReconcileRoutes};
