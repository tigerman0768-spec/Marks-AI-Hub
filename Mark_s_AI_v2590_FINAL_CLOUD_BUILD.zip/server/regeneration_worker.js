const {executeProductionRun}=require("./provider_runner");
const {createRunwayVideoProvider}=require("./runway_video_provider");
const {downloadCompletedClips}=require("./auto_clip_download");
const {inspectProjectClips}=require("./clip_quality_inspector");
const {reviewProjectClips}=require("./smart_clip_review");
const {snapshotClip}=require("./clip_version_manager");

async function runRegenerationQueue(project,options={}){
  const queued=(project.videoJobs||[]).filter(j=>j.status==="queued"&&j.regenerationOf);
  if(!queued.length)return {status:"nothing_to_do",jobs:[],results:[]};
  const provider=options.provider||createRunwayVideoProvider({
    apiKey:options.apiKey||(process.env.RUNWAY_API_KEY||process.env.RUNWAYML_API_SECRET)
  });
  const run={id:require("crypto").randomUUID(),projectId:project.id,mode:"automatic-regeneration",
    status:"queued",createdAt:new Date().toISOString(),total:queued.length,completed:0,failed:0,jobs:queued};
  const completed=await executeProductionRun(run,provider,{maxRetries:Number(options.maxRetries??2)});
  let finalRun=completed,downloads=[];
  if(completed.status==="completed"){
    const d=await downloadCompletedClips(project,completed,{});
    finalRun={...completed,jobs:d.jobs};downloads=d.results;
    await inspectProjectClips({...project,videoJobs:finalRun.jobs});
    const reviews=reviewProjectClips({...project,videoJobs:finalRun.jobs});
    for(const r of reviews){
      const j=finalRun.jobs.find(x=>x.id===r.jobId);
      if(j){j.smartReview={score:r.score,decision:r.decision,issues:r.issues,qualityStatus:r.qualityStatus};j.smartReviewAt=new Date().toISOString();}
    }
    const versionDir=require("path").join(process.cwd(),"clip-versions");
    for(const j of finalRun.jobs) if(j.downloadStatus==="downloaded"){
      snapshotClip(versionDir,project.id,j);
    }
  }
  return {status:finalRun.status,run:finalRun,downloads};
}
module.exports={runRegenerationQueue};
