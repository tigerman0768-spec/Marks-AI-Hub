const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerVideoGenerationReconciliationRoutes(app) {
  app.post("/api/projects/:id/video-generation/reconcile", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const providerJobs = Array.isArray(p.generationJobs) ? p.generationJobs : [];

    let matched = 0;
    let changed = 0;

    const byId = new Map(providerJobs.map(j => [
      String(j.id || j.jobId || j.providerJobId || ""),
      j
    ]));

    for (const job of jobs) {
      const candidates = [
        job.providerJobId,
        job.id,
        job.shotId
      ].filter(Boolean).map(String);

      const provider = candidates.map(id => byId.get(id)).find(Boolean);
      if (!provider) continue;

      matched++;
      const providerStatus = String(provider.status || "").toLowerCase();
      const next = {
        providerJobId: provider.providerJobId || provider.jobId || job.providerJobId || null,
        clipPath: provider.clipPath || provider.outputPath || job.clipPath || null,
        progress: Number.isFinite(Number(provider.progress))
          ? Number(provider.progress)
          : job.progress
      };

      if (["completed","complete","succeeded","success"].includes(providerStatus)) {
        next.status = "completed";
        next.progress = 100;
      } else if (["failed","error"].includes(providerStatus)) {
        next.status = "failed";
        next.error = provider.error || provider.message || job.error || "provider job failed";
      } else if (["running","processing","in_progress"].includes(providerStatus)) {
        next.status = "running";
      }

      for (const [k,v] of Object.entries(next)) {
        if (v !== undefined && job[k] !== v) {
          job[k] = v;
          changed++;
        }
      }
      job.updatedAt = new Date().toISOString();
    }

    p.videoGenerationJobs = jobs;
    p.videoGenerationReconciledAt = new Date().toISOString();
    saveProject(dir, p);

    res.json({
      projectId: p.id,
      matched,
      changed,
      jobCount: jobs.length,
      reconciledAt: p.videoGenerationReconciledAt
    });
  });
}

module.exports = { registerVideoGenerationReconciliationRoutes };
