const path = require("path");
const fs = require("fs");
const { getProject, saveProject } = require("./film_projects");

function registerGeneratedClipReviewFinalizeRoutes(app) {
  app.post("/api/projects/:id/generated-clips/review-set/finalize", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const set = p.clipReviewSet;
    const clips = Array.isArray(set?.clips) ? set.clips : [];
    if (!clips.length) return res.status(400).json({ error: "no review clips" });

    const missing = clips.filter(c => !c.path || !fs.existsSync(c.path));
    const pending = clips.filter(c => !["accepted","rejected","needs_regeneration"].includes(c.reviewStatus));
    const accepted = clips.filter(c => c.reviewStatus === "accepted" && c.path && fs.existsSync(c.path));

    if (missing.length || pending.length || !accepted.length) {
      return res.status(409).json({
        error: "review set is not ready to finalize",
        missing: missing.length,
        pending: pending.length,
        accepted: accepted.length
      });
    }

    p.approvedGeneratedClips = accepted.map((c, i) => ({
      id: c.id, shotId: c.shotId, scene: c.scene, index: c.index || i + 1,
      path: c.path, duration: c.duration || 0, approvedAt: new Date().toISOString()
    }));
    p.generatedClipReviewFinalizedAt = new Date().toISOString();
    saveProject(dir, p);
    res.json({
      projectId: p.id,
      finalized: true,
      acceptedCount: accepted.length,
      approvedGeneratedClips: p.approvedGeneratedClips
    });
  });
}
module.exports = { registerGeneratedClipReviewFinalizeRoutes };
