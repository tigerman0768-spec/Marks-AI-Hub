const {getQueue,activeJobs,queuedJobs,enqueue,dispatch,cancelQueued,MAX_ACTIVE}=require("./final_render_worker_queue");
function registerFinalRenderWorkerQueueRoutes(app){
  app.get("/api/final-render/queue",(_req,res)=>{
    try{res.json({maxActive:MAX_ACTIVE,active:activeJobs(),queued:queuedJobs(),queue:getQueue()});}
    catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/final-render/queue/dispatch",(_req,res)=>{
    dispatch(_req.body?.outputDir).then(()=>res.json({ok:true,queue:getQueue()})).catch(e=>res.status(500).json({error:e.message}));
  });
  app.post("/api/final-render/queue/:id/cancel",(_req,res)=>{
    try{
      const job=cancelQueued(_req.params.id);
      if(!job)return res.status(404).json({error:"queue job not found"});
      res.json({job});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/final-render/queue/enqueue",(_req,res)=>{
    try{
      const project=_req.body?.project||_req.body;
      if(!project?.id)return res.status(400).json({error:"project.id required"});
      const job=enqueue(project,{outputDir:_req.body?.outputDir});
      res.status(202).json({status:"queued",job});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalRenderWorkerQueueRoutes};
