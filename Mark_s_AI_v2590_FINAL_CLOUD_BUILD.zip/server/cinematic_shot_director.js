const crypto=require("crypto");

const framings=["extreme-wide","wide","medium-wide","medium","medium-close","close-up","extreme-close-up","over-the-shoulder","point-of-view"];
const lenses=["18mm","24mm","35mm","50mm","85mm","100mm-macro"];
const movements=["locked-off","slow push-in","slow pull-out","gentle tracking","handheld","orbit","pan","tilt","crane"];
const lighting=["natural cinematic","soft key","high contrast","low key","backlit","neon","warm practicals","cool moonlight"];

function chooseVisualStyle(scene={},performance={},shot={},index=0){
  const emotion=String(performance?.emotionalArc||scene?.emotion||"natural").toLowerCase();
  const intense=["angry","afraid","shocked","urgent"].some(x=>emotion.includes(x));
  const intimate=["sad","tender","romance","emotional"].some(x=>emotion.includes(x));
  const framing=intimate?["close-up","medium-close","over-the-shoulder"][index%3]:
    intense?["medium","close-up","handheld"][index%3]:framings[index%framings.length];
  const lens=intimate?["85mm","50mm"][index%2]:intense?"35mm":lenses[index%lenses.length];
  const movement=shot?.cameraMovement||movements[index%movements.length];
  return {
    id:crypto.randomUUID(),
    shotId:shot.id||`shot-${index+1}`,
    framing,
    lens,
    movement,
    lighting:scene?.lighting||lighting[index%lighting.length],
    composition:intimate?"focus on eyes and subtle facial reaction":intense?"dynamic subject separation and strong foreground depth":"clear cinematic subject/background separation",
    depthOfField:intimate||intense?"shallow":"moderate",
    visualPurpose:shot?.purpose||"advance the scene visually",
    promptAddendum:`${framing} framing, ${lens} lens feel, ${movement}, ${scene?.lighting||lighting[index%lighting.length]}, ${intimate?"intimate emotional performance":intense?"high-energy dramatic performance":"cinematic natural performance"}, ${intimate||intense?"shallow":"moderate"} depth of field`
  };
}
function directShots(project={},scene={},performance={},shots=[]){
  return shots.map((shot,i)=>chooseVisualStyle(scene,performance,shot,i));
}
function buildCinematicShotPlan(project={},performancePlan=[],directorPlan=[]){
  return (project.scenes||[]).map(scene=>{
    const perf=performancePlan.find(x=>x.sceneId===scene.id)||{};
    const shots=(directorPlan.find(x=>x.sceneId===scene.id)||{}).shots||[];
    const continuity=(project.visualContinuityPlan?.scenes||[]).find(x=>x.sceneId===scene.id)||{};
    return {sceneId:scene.id,sceneTitle:scene.title||`Scene`,continuity,shots:directShots(project,scene,perf,shots).map(x=>({
      ...x,continuityPrompt:require("./visual_continuity_director").buildShotContinuityPrompt(continuity,x)
    }))};
  });
}
module.exports={framings,lenses,movements,lighting,chooseVisualStyle,directShots,buildCinematicShotPlan};
