const {recoverFinalRenderJobs,getRecoveryCandidates,MAX_RETRIES,STALE_MS}=require("./final_render_recovery");
function registerFinalRenderRecoveryRoutes(app){
  app.post("/api/final-render/recover",async(req,res)=>{
    try{res.json({status:"ok",maxRetries:MAX_RETRIES,jobs:await recoverFinalRenderJobs({outputDir:require("path").join(process.cwd(),"output")})});}
    catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/final-render/recovery-candidates",(_req,res)=>{
    try{res.json({maxRetries:MAX_RETRIES,staleAfterMs:STALE_MS,jobs:getRecoveryCandidates()});}
    catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalRenderRecoveryRoutes};
