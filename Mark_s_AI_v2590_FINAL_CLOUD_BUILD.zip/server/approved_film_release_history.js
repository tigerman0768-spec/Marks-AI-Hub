const fs=require("fs"),path=require("path");
const {getProject}=require("./film_projects");
function historyPath(id){return path.join(process.cwd(),"projects",String(id),"film_library","deliveries","release_history.json")}
function recordReleaseEvent(project,event){
  const p=historyPath(project.id);fs.mkdirSync(path.dirname(p),{recursive:true});
  let a=[];if(fs.existsSync(p)){try{a=JSON.parse(fs.readFileSync(p,"utf8"))||[]}catch{}}
  a.unshift({eventId:`evt_${Date.now()}_${Math.random().toString(16).slice(2,8)}`,at:new Date().toISOString(),...event});
  fs.writeFileSync(p,JSON.stringify(a.slice(0,100),null,2));return a[0];
}
function getReleaseHistory(id){const p=historyPath(id);if(!fs.existsSync(p))return[];try{const a=JSON.parse(fs.readFileSync(p,"utf8"));return Array.isArray(a)?a:[]}catch{return[]}}
module.exports={recordReleaseEvent,getReleaseHistory};
