const path=require("path");
const crypto=require("crypto");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function createDeliveryReceipt(project){
  const m=project.finalMasterDeliveryManifest;
  if(!m?.ready)return {ready:false,blockers:["delivery manifest is not ready"]};
  if(!m.outputPath||!fs.existsSync(m.outputPath))return {ready:false,blockers:["final output file is missing"]};
  const data=fs.readFileSync(m.outputPath);
  const sha256=crypto.createHash("sha256").update(data).digest("hex");
  if(sha256!==m.sha256)return {ready:false,blockers:["output file hash no longer matches delivery manifest"]};
  const receipt={
    receiptId:`receipt_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    filename:m.filename,bytes:m.bytes,sha256:m.sha256,duration:m.duration,
    video:m.video||null,audio:m.audio||null,
    verifiedAt:new Date().toISOString(),status:"verified"
  };
  project.finalMasterDeliveryReceipt=receipt;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,receipt};
}
module.exports={createDeliveryReceipt};
