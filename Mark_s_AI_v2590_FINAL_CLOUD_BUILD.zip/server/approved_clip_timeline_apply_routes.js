const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerApprovedClipTimelineApplyRoutes(app) {
  app.post("/api/projects/:id/edit-input-timeline/apply", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const input = Array.isArray(p.approvedClipEditTimeline) ? p.approvedClipEditTimeline : [];
    if (!input.length) return res.status(409).json({ error: "no edit input timeline" });

    const timeline = input.slice().sort((a,b)=>(a.order||0)-(b.order||0)).map((x,i)=>({
      id:x.id, clipId:x.clipId, shotId:x.shotId, scene:x.scene,
      sourcePath:x.sourcePath, start:Number(x.start)||0, end:x.end===null?null:Number(x.end),
      order:i, transition:x.transition||"cut"
    }));
    p.timeline = timeline;
    p.editTimeline = timeline;
    p.timelineSource = "approvedClipEditTimeline";
    p.timelineAppliedAt = new Date().toISOString();
    p.status = p.status === "draft" || p.status === "review" ? "producing" : p.status;
    saveProject(dir, p);
    res.json({ projectId:p.id, applied:true, source:p.timelineSource, count:timeline.length, timeline });
  });
}
module.exports = { registerApprovedClipTimelineApplyRoutes };
