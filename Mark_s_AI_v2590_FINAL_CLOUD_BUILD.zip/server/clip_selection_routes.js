const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadVersions,groupByShot}=require("./clip_version_manager");
const {selectBestVersions,applyBestVersions}=require("./best_clip_selector");
function registerClipSelectionRoutes(app){
  app.get("/api/projects/:id/clip-versions",(req,res)=>{
    const record=loadVersions(path.join(process.cwd(),"clip-versions"),req.params.id);
    res.json({projectId:req.params.id,groups:groupByShot(record),selections:selectBestVersions(record)});
  });
  app.post("/api/projects/:id/select-best-clips",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const project=getProject(dir,req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const record=loadVersions(path.join(process.cwd(),"clip-versions"),req.params.id);
    const selections=selectBestVersions(record);
    const jobs=applyBestVersions(project,selections);
    const saved=saveProject(dir,{...project,videoJobs:jobs,status:"best_clips_selected"});
    res.json({projectId:project.id,selections,jobs,savedStatus:saved.status});
  });
}
module.exports={registerClipSelectionRoutes};
