const path=require("path");
const {listJobs,updateJob}=require("./final_render_job_store");
const {smartOneClickFinalRender}=require("./smart_one_click_final_render");

const JOB_DIR=path.join(process.cwd(),"final-render-jobs");
const MAX_RETRIES=3;
const STALE_MS=30*60*1000;

function getCandidates(){
  return listJobs(JOB_DIR).filter(j=>j&&(j.status==="recoverable"||j.status==="running"));
}
function classifyStale(job){
  const t=Date.parse(job.updatedAt||job.createdAt||0);
  return Date.now()-t>STALE_MS;
}
async function recoverFinalRenderJobs(options={}){
  const jobs=getCandidates().filter(j=>!options.onlyJobId||String(j.id)===String(options.onlyJobId)),results=[];
  for(const job of jobs){
    const retryCount=Number(job.recoveryAttempts||0);
    if(retryCount>=MAX_RETRIES){
      results.push({jobId:job.id,result:updateJob(JOB_DIR,job.id,{
        status:"recovery_exhausted",recoveryAttempts:retryCount,
        recoveryMessage:`Maximum recovery attempts (${MAX_RETRIES}) reached. Manual review required.`
      })});
      continue;
    }
    if(job.status==="running"&&classifyStale(job)){
      updateJob(JOB_DIR,job.id,{status:"recoverable",staleDetectedAt:new Date().toISOString()});
    }
    const attempt=retryCount+1;
    updateJob(JOB_DIR,job.id,{status:"recovering",recoveryAttempts:attempt,
      recoveryStartedAt:new Date().toISOString(),recoveryMessage:`Recovery attempt ${attempt} of ${MAX_RETRIES}.`});
    try{
      const project=job.projectSnapshot||{
        id:job.projectId,title:job.title,idea:job.idea,genre:job.genre,length:job.length,
        style:job.style,aspectRatio:job.aspectRatio,status:"draft",completeFinalFilm:job.completeFinalFilm
      };
      const result=await smartOneClickFinalRender(project,{progressId:job.id,outputDir:options.outputDir});
      results.push({jobId:job.id,attempt,result});
    }catch(error){
      const exhausted=attempt>=MAX_RETRIES;
      updateJob(JOB_DIR,job.id,{status:exhausted?"recovery_exhausted":"recoverable",
        error:error.message,recoveryMessage:exhausted?"Maximum recovery attempts reached.":"Ready for another recovery attempt."
      });
      results.push({jobId:job.id,attempt,result:{status:"failed",error:error.message}});
    }
  }
  return results;
}
function getRecoveryCandidates(){
  return listJobs(JOB_DIR).filter(j=>j&&(j.status==="recoverable"||j.status==="running"||j.status==="recovery_exhausted"));
}
module.exports={recoverFinalRenderJobs,getCandidates,getRecoveryCandidates,MAX_RETRIES,STALE_MS};
