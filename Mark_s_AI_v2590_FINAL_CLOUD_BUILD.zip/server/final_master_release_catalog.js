const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createReleaseCatalogEntry(project){
  const snap=project.finalMasterReleaseSnapshot;
  const rec=project.finalMasterReleaseRecord;
  if(!snap?.status||snap.status!=="sealed"||!rec?.releaseId)
    return {ready:false,blockers:["sealed release snapshot and release record are required"]};
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))return {ready:false,blockers:["released film file is missing"]};
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  if(sha!==snap.sha256||sha!==rec.sha256)return {ready:false,blockers:["release integrity hash mismatch"]};
  const catalog={
    catalogId:`catalog_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    releaseId:rec.releaseId,snapshotId:snap.snapshotId,projectId:project.id,
    title:project.title||"Untitled Film",filename:snap.filename,bytes:fs.statSync(output).size,
    sha256:sha,duration:project.finalMasterDeliveryManifest?.duration||0,
    video:project.finalMasterDeliveryManifest?.video||null,
    audio:project.finalMasterDeliveryManifest?.audio||null,
    cataloguedAt:new Date().toISOString(),status:"catalogued"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"release_catalog");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"catalog_entry.json"),JSON.stringify(catalog,null,2));
  project.finalMasterReleaseCatalog=catalog;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,catalog};
}
module.exports={createReleaseCatalogEntry};
