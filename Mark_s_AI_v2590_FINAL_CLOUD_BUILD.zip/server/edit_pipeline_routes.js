const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildAutomaticEdit}=require("./ai_editing_engine");
const {saveTimeline}=require("./film_timeline");

function registerEditPipelineRoutes(app){
  app.post("/api/projects/:id/edit-pipeline/apply",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const edit=buildAutomaticEdit(project);
      if(!edit.items.length)return res.status(400).json({error:"no selected clips available"});
      const normalized=edit.items.map((x,i)=>({
        ...x,
        order:i,
        transition:{type:x.transition||"cut",duration:Number(x.transitionDuration||0)}
      }));
      const timeline=saveTimeline(path.join(process.cwd(),"timelines"),project.id,normalized);
      const saved=saveProject(dir,{...project,finalTimeline:{...edit,items:normalized},aiEditPlan:edit,status:"edit_ready"});
      res.json({projectId:project.id,edit:{...edit,items:normalized},timeline,savedStatus:saved.status});
    }catch(e){res.status(400).json({error:e.message});}
  });

  app.get("/api/projects/:id/edit-pipeline/readiness",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const items=project.finalTimeline?.items||project.finalCutPlan?.items||[];
    const ready=Array.isArray(items)&&items.some(x=>x.clipPath);
    res.json({projectId:project.id,ready,clipCount:items.length,
      message:ready?"Edit is ready for rendering.":"Select/download clips before editing."});
  });
}
module.exports={registerEditPipelineRoutes};
