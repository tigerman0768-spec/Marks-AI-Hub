const path=require("path");
const fs=require("fs");
const {listFilms,getFilm,saveFilmRecord,updateFilm,deleteFilm}=require("./film_library");
function libraryDir(){return path.join(process.cwd(),"films");}
function registerFilmLibraryRoutes(app){
  app.get("/api/films",(req,res)=>res.json(listFilms(libraryDir(),{
    query:req.query.q,genre:req.query.genre,sort:req.query.sort
  })));
  app.get("/api/films/:id/thumbnail",(req,res)=>{
    const film=getFilm(libraryDir(),req.params.id);
    if(!film||!film.thumbnailPath||!fs.existsSync(film.thumbnailPath)) return res.status(404).end();
    res.sendFile(path.resolve(film.thumbnailPath));
  });
  app.get("/api/films/:id",(req,res)=>{
    const film=getFilm(libraryDir(),req.params.id);
    if(!film)return res.status(404).json({error:"film not found"});
    res.json(film);
  });
  app.post("/api/films",(req,res)=>{
    try{res.status(201).json(saveFilmRecord(libraryDir(),req.body||{}));}
    catch(e){res.status(400).json({error:e.message});}
  });
  app.patch("/api/films/:id",(req,res)=>{
    try{
      const film=updateFilm(libraryDir(),req.params.id,req.body||{});
      if(!film)return res.status(404).json({error:"film not found"});
      res.json(film);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.delete("/api/films/:id",(req,res)=>{
    const ok=deleteFilm(libraryDir(),req.params.id);
    if(!ok)return res.status(404).json({error:"film not found"});
    res.json({ok:true});
  });
}
module.exports={registerFilmLibraryRoutes};
