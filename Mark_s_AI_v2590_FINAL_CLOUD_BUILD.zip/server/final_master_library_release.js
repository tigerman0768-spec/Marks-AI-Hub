const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function prepareLibraryRelease(project){
  const cat=project.finalMasterReleaseCatalog;
  if(!cat?.status||cat.status!=="catalogued")
    return {ready:false,blockers:["release catalogue entry is required"]};
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))
    return {ready:false,blockers:["final film file is missing"]};
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  if(sha!==cat.sha256)return {ready:false,blockers:["catalogue hash does not match current film"]};
  const release={
    libraryReleaseId:`library_release_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,catalogId:cat.catalogId,releaseId:cat.releaseId,
    title:project.title||"Untitled Film",filename:cat.filename,
    outputPath:output,bytes:fs.statSync(output).size,sha256:sha,
    duration:cat.duration||0,video:cat.video||null,audio:cat.audio||null,
    preparedAt:new Date().toISOString(),status:"ready_for_library"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"library_release.json"),JSON.stringify(release,null,2));
  project.finalMasterLibraryRelease=release;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,release};
}
module.exports={prepareLibraryRelease};
