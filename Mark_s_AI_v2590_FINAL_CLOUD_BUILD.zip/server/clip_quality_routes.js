const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {inspectClip,inspectProjectClips}=require("./clip_quality_inspector");

function registerClipQualityRoutes(app){
  app.get("/api/projects/:id/clips/quality",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const results=await inspectProjectClips(project);
      saveProject(dir,{...project,videoJobs:project.videoJobs,status:"clips_inspected"});
      res.json({projectId:project.id,results});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/:jobId/quality-check",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const job=(project.videoJobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"clip job not found"});
      const quality=await inspectClip(job.clipPath,req.body||{});
      job.qualityStatus=quality.status;
      job.qualityReport=quality;
      job.qualityCheckedAt=new Date().toISOString();
      saveProject(dir,{...project,videoJobs:project.videoJobs});
      res.json({jobId:job.id,quality});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerClipQualityRoutes};
