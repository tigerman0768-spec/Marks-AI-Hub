const fs=require("fs");
const crypto=require("crypto");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {releaseReadiness}=require("./approved_film_release_readiness");

function approveRelease(project){
  const readiness=releaseReadiness(project);
  if(!readiness.ready)return {approved:false,blockers:readiness.blockers};
  const snapshot=project.approvedFilmReleaseSnapshot;
  const approvalId=`release_approval_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const approval={
    approvalId,projectId:project.id,snapshotId:snapshot.snapshotId,
    deliveryId:project.approvedFilmDelivery.deliveryId,
    lockId:project.approvedFilmDeliveryLock.lockId,
    filename:snapshot.filename,bytes:snapshot.bytes,sha256:snapshot.sha256,
    approvedAt:new Date().toISOString(),status:"approved"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const approvalPath=path.join(dir,`${approvalId}.json`);
  fs.writeFileSync(approvalPath,JSON.stringify(approval,null,2));
  project.approvedFilmReleaseApproval={...approval,approvalPath};
  saveProject(path.join(process.cwd(),"projects"),project);
  return {approved:true,approval};
}
module.exports={approveRelease};
