const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function buildThumbnailArgs(videoPath,outputPath,options={}){
  if(!videoPath||!fs.existsSync(videoPath))throw new Error("video file unavailable");
  const ffmpeg=options.ffmpeg||process.env.FFMPEG_BIN||"ffmpeg";
  const time=String(options.time??"00:00:01");
  return {ffmpeg,args:["-y","-ss",time,"-i",videoPath,"-frames:v","1","-q:v","2",outputPath]};
}
function generateThumbnail(config){
  const output=config.outputPath;
  fs.mkdirSync(path.dirname(output),{recursive:true});
  const cmd=buildThumbnailArgs(config.videoPath,output,config);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]});
    let err="";child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`thumbnail generation failed (${code}): ${err.slice(-1200)}`));
      if(!fs.existsSync(output)||!fs.statSync(output).size)return reject(new Error("thumbnail is empty"));
      resolve({outputPath:output,bytes:fs.statSync(output).size});
    });
  });
}
module.exports={buildThumbnailArgs,generateThumbnail};
