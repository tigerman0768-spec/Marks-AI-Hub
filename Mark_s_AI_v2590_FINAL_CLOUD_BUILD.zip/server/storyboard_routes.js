const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildSceneBreakdown}=require("./storyboard");
function registerStoryboardRoutes(app){
  app.post("/api/projects/:id/storyboard",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const storyboard=buildSceneBreakdown(project);
      const saved=saveProject(dir,{...project,scenes:storyboard.scenes,directorPlan:storyboard.directorPlan,status:"storyboard_ready"});
      res.status(201).json({project:saved,storyboard});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerStoryboardRoutes};
