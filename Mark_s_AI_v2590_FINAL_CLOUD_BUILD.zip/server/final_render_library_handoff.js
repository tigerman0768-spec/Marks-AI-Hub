const path=require("path");
const {getJob,updateJob}=require("./final_render_job_store");
const {registerFinishedFilm}=require("./auto_library");
const DIR=path.join(process.cwd(),"final-render-jobs");
const FILMS=path.join(process.cwd(),"films");

async function handoffFinalRenderToLibrary(jobId,options={}){
 const job=getJob(DIR,jobId);
 if(!job)return null;
 if(job.status!=="completed")return {status:"not_ready",jobId,error:"render is not completed"};
 const result=job.result||{};
 const outputPath=result.outputPath||job.outputPath;
 if(!outputPath)return {status:"not_ready",jobId,error:"final film output is missing"};
 if(job.libraryId&&!options.force)return {status:"already_registered",jobId,libraryId:job.libraryId};
 const config={filmId:job.projectId,title:job.title||job.projectSnapshot?.title||"Untitled Film",
   duration:result.duration||job.duration||job.projectSnapshot?.length||0};
 const record=await registerFinishedFilm(config,{...result,outputPath},{
   dir:options.filmDir||FILMS,ffmpeg:options.ffmpeg
 });
 updateJob(DIR,jobId,{libraryId:record.id,lifecycle:"final_film_ready",libraryRecord:record});
 return {status:"registered",jobId,libraryId:record.id,record};
}
module.exports={handoffFinalRenderToLibrary};
