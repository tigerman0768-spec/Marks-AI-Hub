const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
const {createExportRecord}=require("./approved_film_export");
const {buildExportManifest,manifestHash}=require("./approved_film_export_manifest");
const {getExportHistory}=require("./approved_film_export_history");
const {createExportPackage}=require("./approved_film_export_package");
const {createDeliveryPackage}=require("./approved_film_delivery_package");
const {verifyDelivery}=require("./approved_film_delivery_verifier");
const {lockDelivery}=require("./approved_film_delivery_lock");
const {createReleaseSnapshot}=require("./approved_film_release_snapshot");
const {getReleaseCatalogue}=require("./approved_film_release_catalogue");
const {releaseReadiness}=require("./approved_film_release_readiness");
const {approveRelease}=require("./approved_film_release_approval");
const {sealRelease}=require("./approved_film_release_seal");
const {buildReleaseAudit,writeReleaseAudit}=require("./approved_film_release_audit");
const {createReleaseCertificate}=require("./approved_film_release_certificate");
const {getReleaseStatus}=require("./approved_film_release_status");
const {getReleaseHistory}=require("./approved_film_release_history");
const {buildReleaseManifest,saveReleaseManifest}=require("./approved_film_release_manifest");
const {verifyReleaseManifest}=require("./approved_film_release_manifest_verifier");

function registerApprovedFilmExportRoutes(app){
  app.get("/api/projects/:id/approved-film/export",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const e=p.approvedFilmExport||null;
    res.json({projectId:p.id,export:e,exists:!!e?.sourcePath&&fs.existsSync(e.sourcePath)});
  });
  app.post("/api/projects/:id/approved-film/export/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createExportRecord(p,req.body||{});
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
  app.get("/api/projects/:id/approved-film/export/download",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p?.approvedFilmExport?.sourcePath)return res.status(404).json({error:"export not ready"});
    if(!fs.existsSync(p.approvedFilmExport.sourcePath))return res.status(404).json({error:"film file missing"});
    res.download(path.resolve(p.approvedFilmExport.sourcePath),p.approvedFilmExport.filename||"film.mp4");
  });
  app.get("/api/projects/:id/approved-film/export/manifest",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    if(!p.approvedFilmExport)return res.status(404).json({error:"export not ready"});
    const manifest=buildExportManifest(p,p.approvedFilmExport);
    res.json({...manifest,manifestSha256:manifestHash(manifest)});
  });

  app.get("/api/projects/:id/approved-film/export/history",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,history:getExportHistory(p.id)});
  });
  app.get("/api/projects/:id/approved-film/export/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    const e=p?.approvedFilmExport;
    if(!p)return res.status(404).json({error:"project not found"});
    if(!e?.sourcePath||!fs.existsSync(e.sourcePath))return res.status(409).json({verified:false,error:"film file missing"});
    const stat=fs.statSync(e.sourcePath);
    const crypto=require("crypto");
    const sha=crypto.createHash("sha256").update(fs.readFileSync(e.sourcePath)).digest("hex");
    const verified=stat.size===Number(e.bytes)&&sha===e.sha256;
    res.json({projectId:p.id,verified,expectedBytes:e.bytes,actualBytes:stat.size,expectedSha256:e.sha256,actualSha256:sha});
  });

  app.post("/api/projects/:id/approved-film/export/package",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createExportPackage(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });

  app.post("/api/projects/:id/approved-film/export/delivery",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createDeliveryPackage(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });

  app.get("/api/projects/:id/approved-film/export/delivery/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    if(!p.approvedFilmDelivery)return res.status(404).json({error:"delivery not ready"});
    const result=verifyDelivery(p.approvedFilmDelivery);
    res.status(result.verified?200:409).json({projectId:p.id,deliveryId:p.approvedFilmDelivery.deliveryId,...result});
  });

  app.post("/api/projects/:id/approved-film/export/delivery/lock",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=lockDelivery(p);
    res.status(result.locked?200:409).json({projectId:p.id,...result});
  });

  app.post("/api/projects/:id/approved-film/export/release-snapshot",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleaseSnapshot(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });

  app.get("/api/projects/:id/approved-film/export/release-catalogue",(req,res)=>{
    const result=getReleaseCatalogue(req.params.id);
    res.status(result.found?200:404).json(result);
  });

  app.get("/api/projects/:id/approved-film/export/release-readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=releaseReadiness(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });

  app.post("/api/projects/:id/approved-film/export/release-approval",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=approveRelease(p);
    res.status(result.approved?200:409).json({projectId:p.id,...result});
  });

  app.post("/api/projects/:id/approved-film/export/release-seal",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=sealRelease(p);
    res.status(result.sealed?200:409).json({projectId:p.id,...result});
  });

  app.get("/api/projects/:id/approved-film/export/release-audit",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(buildReleaseAudit(p));
  });
  app.post("/api/projects/:id/approved-film/export/release-audit/save",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(writeReleaseAudit(p));
  });

  app.post("/api/projects/:id/approved-film/export/release-certificate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleaseCertificate(p);
    res.status(result.issued?200:409).json({projectId:p.id,...result});
  });

  app.get("/api/projects/:id/approved-film/export/release-status",(req,res)=>{
    const result=getReleaseStatus(req.params.id);
    res.status(result.found?200:404).json(result);
  });

  app.get("/api/projects/:id/approved-film/export/release-history",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,history:getReleaseHistory(p.id)});
  });

  app.get("/api/projects/:id/approved-film/export/release-manifest",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(buildReleaseManifest(p));
  });
  app.post("/api/projects/:id/approved-film/export/release-manifest/save",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const manifest=saveReleaseManifest(p); p.approvedFilmReleaseManifest=manifest; require("./film_projects").saveProject(path.join(process.cwd(),"projects"),p); res.json(manifest);
  });


  app.get("/api/projects/:id/approved-film/export/release-manifest/download",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const m=p.approvedFilmReleaseManifest||null;
    if(!m)return res.status(404).json({error:"saved release manifest not found"});
    const filePath=m.manifestPath;
    if(!filePath||!fs.existsSync(filePath))return res.status(404).json({error:"manifest file is missing"});
    res.setHeader("Content-Type","application/json; charset=utf-8");
    res.setHeader("Content-Disposition",`attachment; filename="release-manifest-${p.id}.json"`);
    res.sendFile(path.resolve(filePath));
  });
  app.get("/api/projects/:id/approved-film/export/release-manifest/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const m=p.approvedFilmReleaseManifest||null;
    if(!m)return res.status(404).json({error:"saved release manifest not found"});
    const result=verifyReleaseManifest(m);
    res.status(result.verified?200:409).json({projectId:p.id,...result});
  });

}
module.exports={registerApprovedFilmExportRoutes};
