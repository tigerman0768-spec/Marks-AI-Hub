const path=require("path");
const {getProject}=require("./film_projects");
const {getClipReview}=require("./clip_review");
function registerClipReviewUiRoutes(app){
  app.get("/api/projects/:id/clip-review-ui",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const reviews=getClipReview(path.join(process.cwd(),"reviews"),req.params.id);
    const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
    res.json({projectId:project.id,title:project.title,reviews,jobs:jobs.map(j=>({
      id:j.id,sceneId:j.sceneId,shotNumber:j.shotNumber,status:j.status,clipPath:j.clipPath||null,
      downloadStatus:j.downloadStatus||null,qualityStatus:j.qualityStatus||null,
      qualityReport:j.qualityReport||null,smartReview:j.smartReview||null,error:j.error||null
    }))});
  });
}
module.exports={registerClipReviewUiRoutes};
