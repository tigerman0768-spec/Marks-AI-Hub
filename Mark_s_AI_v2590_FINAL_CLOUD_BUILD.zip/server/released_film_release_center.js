const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject}=require("./film_projects");

function buildReleaseCenter(project){
  const release=project?.finalMasterFinalReleaseRecord||null;
  const sealed=project?.finalMasterReleasedFilmSealedDeliveryRecord||null;
  const snap=project?.finalMasterReleasedFilmDeliverySnapshot||null;
  const verify=project?.finalMasterReleasedFilmDeliverySnapshotVerification||null;
  const seal=project?.finalMasterReleasedFilmDeliverySeal||null;
  const lock=project?.finalMasterReleasedFilmDeliveryLock||null;
  const gate=project?.finalMasterReleasedFilmDeliveryGate||null;
  const output=release?.outputPath||sealed?.outputPath||seal?.outputPath||null;
  const blockers=[];
  let live=null;
  if(!output||!fs.existsSync(output)) blockers.push("released film file is missing");
  else {
    const stat=fs.statSync(output);
    const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
    live={outputPath:output,bytes:stat.size,sha256:sha};
    if(release?.sha256&&sha!==release.sha256) blockers.push("live SHA-256 does not match final release record");
    if(release?.bytes!=null&&stat.size!==Number(release.bytes)) blockers.push("live file size does not match final release record");
  }
  const center={
    centerId:`release_center_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    status:release?.status==="released"&&!blockers.length?"released":"blocked",
    releaseRecordId:release?.releaseRecordId||null,
    sealedDeliveryRecordId:sealed?.recordId||null,
    sealId:seal?.sealId||null,snapshotId:snap?.snapshotId||null,
    snapshotVerificationId:verify?.verificationId||null,
    lockId:lock?.lockId||null,gateId:gate?.gateId||null,
    outputPath:live?.outputPath||output,bytes:live?.bytes??null,sha256:live?.sha256??null,
    evidence:{
      release:!!release,sealedDelivery:!!sealed,seal:!!seal,
      snapshot:!!snap,snapshotVerification:!!verify,lock:!!lock,gate:!!gate
    },
    blockers,checkedAt:new Date().toISOString()
  };
  return center;
}
function saveReleaseCenter(project){
  const center=buildReleaseCenter(project);
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","release_center");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"release_center.json"),JSON.stringify(center,null,2));
  return center;
}
module.exports={buildReleaseCenter,saveReleaseCenter};
