const path = require("path");
const { getProject } = require("./film_projects");

function registerVideoGenerationBatchStatusRoutes(app) {
  app.get("/api/projects/:id/video-generation/batch-status", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const counts = {
      queued: jobs.filter(j => j.status === "queued").length,
      running: jobs.filter(j => j.status === "running").length,
      completed: jobs.filter(j => j.status === "completed").length,
      failed: jobs.filter(j => j.status === "failed").length,
      cancelled: jobs.filter(j => j.status === "cancelled").length
    };

    const total = jobs.length;
    const done = counts.completed + counts.failed + counts.cancelled;
    const progress = total
      ? Math.round(jobs.reduce((sum,j) => sum + Math.max(0, Math.min(100, Number(j.progress || 0))), 0) / total)
      : 0;

    res.json({
      projectId: p.id,
      title: p.title || "Untitled Film",
      total,
      counts,
      progress,
      finished: total > 0 && done === total,
      hasFailures: counts.failed > 0,
      reconciledAt: p.videoGenerationReconciledAt || null
    });
  });
}

module.exports = { registerVideoGenerationBatchStatusRoutes };
