const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {checkProjectContinuity}=require("./clip_continuity_checker");

function registerClipContinuityRoutes(app){
  app.get("/api/projects/:id/clips/continuity",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const report=checkProjectContinuity(project);
      saveProject(dir,{...project,continuityReport:report,status:"continuity_checked"});
      res.json(report);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerClipContinuityRoutes};
