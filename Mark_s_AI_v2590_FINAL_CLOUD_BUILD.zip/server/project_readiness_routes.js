const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectReadinessRoutes(app){
 app.get("/api/projects/:id/readiness",(req,res)=>{
  const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const gates=[
   ["story",!!(p.screenplay&&p.scenes?.length)],
   ["production",!!(p.characterBible&&p.storyboard&&p.shotCards?.length)],
   ["generation",!!(p.shotCards?.length)],
   ["edit",!!(p.finalTimeline||p.aiEditPlan)],
   ["finishing",!!p.finalFinishingPlan]
  ];
  const failed=gates.filter(x=>!x[1]).map(x=>x[0]);
  res.json({projectId:p.id,title:p.title,ready:failed.length===0,failedGates:failed,gates:Object.fromEntries(gates)});
 });
}
module.exports={registerProjectReadinessRoutes};
