const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function appendLockAudit(project,event,details={}){
  const audit=Array.isArray(project.finalMasterLockAudit)?project.finalMasterLockAudit:[];
  const entry={id:`lockaudit_${Date.now()}_${Math.random().toString(16).slice(2,8)}`,
    projectId:project.id,event:String(event),details,timestamp:new Date().toISOString()};
  audit.push(entry);project.finalMasterLockAudit=audit.slice(-100);
  saveProject(path.join(process.cwd(),"projects"),project);return entry;
}
function getLockAudit(project){return Array.isArray(project.finalMasterLockAudit)?project.finalMasterLockAudit:[];}
module.exports={appendLockAudit,getLockAudit};
