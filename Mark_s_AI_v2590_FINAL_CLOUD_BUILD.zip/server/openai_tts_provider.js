const fs=require("fs");
const path=require("path");

function createOpenAITTSProvider(options={}){
  const client=options.client;
  const model=options.model||process.env.OPENAI_TTS_MODEL||"gpt-4o-mini-tts";
  if(!client)throw new Error("OpenAI client is not configured");
  return {
    async synthesize(job,outputPath){
      const response=await client.audio.speech.create({
        model,
        voice:job.voice||"alloy",
        input:job.text,
        instructions:job.instructions||undefined,
        response_format:"mp3",
        speed:Math.max(0.5,Math.min(2,Number(job.speed||1)))
      });
      const buffer=Buffer.from(await response.arrayBuffer());
      fs.mkdirSync(path.dirname(outputPath),{recursive:true});
      fs.writeFileSync(outputPath,buffer);
      if(!buffer.length)throw new Error("TTS returned empty audio");
      return {audioPath:outputPath,bytes:buffer.length,model};
    }
  };
}
module.exports={createOpenAITTSProvider};
