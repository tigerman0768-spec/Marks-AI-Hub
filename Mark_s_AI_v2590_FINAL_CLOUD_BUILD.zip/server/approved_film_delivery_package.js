const fs=require("fs");
const path=require("path");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createDeliveryPackage(project){
  const e=project?.approvedFilmExport;
  const f=project?.approvedFilmLibraryFilm;
  if(!f?.outputPath||!fs.existsSync(f.outputPath)) return {ready:false,blockers:["completed Film Library film is required"]};
  const stat=fs.statSync(f.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(f.outputPath)).digest("hex");
  if(e?.sha256 && e.sha256!==sha) return {ready:false,blockers:["current film hash does not match export record"]};
  if(e?.bytes && Number(e.bytes)!==stat.size) return {ready:false,blockers:["current film size does not match export record"]};
  const deliveryId=`delivery_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const manifest={
    deliveryVersion:"1.0",deliveryId,projectId:project.id,
    title:project.title||"Untitled Film",filename:path.basename(f.outputPath),
    bytes:stat.size,sha256:sha,clipCount:Number(f.clipCount||0),
    duration:Number(f.duration||0),sourceExportId:e?.exportId||null,
    createdAt:new Date().toISOString(),verified:true
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const manifestPath=path.join(dir,`${deliveryId}.json`);
  fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2));
  const record={
    deliveryId,manifestPath,manifestSha256:crypto.createHash("sha256").update(JSON.stringify(manifest)).digest("hex"),
    filmPath:f.outputPath,filename:manifest.filename,bytes:stat.size,sha256:sha,status:"ready",createdAt:manifest.createdAt
  };
  project.approvedFilmDelivery=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,record,manifest};
}
module.exports={createDeliveryPackage};
