const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

function makeAudioMixFilter(tracks = []) {
  const inputs = tracks.map((_, i) => `[${i}:a]volume=1.0[a${i}]`).join(";");
  const mixed = tracks.map((_, i) => `[a${i}]`).join("");
  return tracks.length ? `${inputs};${mixed}amix=inputs=${tracks.length}:duration=longest:dropout_transition=2[aout]` : "";
}

function buildAudioCommand({ videoPath, tracks = [], outputPath, ffmpeg }) {
  if (!videoPath) throw new Error("videoPath is required");
  if (!outputPath) throw new Error("outputPath is required");
  const args = ["-y", "-i", videoPath];

  for (const track of tracks) {
    if (!track?.path || !fs.existsSync(track.path)) {
      throw new Error(`missing audio track: ${track?.path || "unknown"}`);
    }
    args.push("-i", track.path);
  }

  if (!tracks.length) {
    args.push("-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", outputPath);
    return { ffmpeg: ffmpeg || process.env.FFMPEG_BIN || "ffmpeg", args };
  }

  const filter = makeAudioMixFilter(tracks);
  args.push(
    "-filter_complex", filter,
    "-map", "0:v:0",
    "-map", "[aout]",
    "-c:v", "copy",
    "-c:a", "aac",
    "-b:a", "192k",
    "-shortest",
    "-movflags", "+faststart",
    outputPath
  );
  return { ffmpeg: ffmpeg || process.env.FFMPEG_BIN || "ffmpeg", args };
}

function mixAudioIntoFilm(config) {
  const command = buildAudioCommand(config);
  return new Promise((resolve, reject) => {
    const child = spawn(command.ffmpeg, command.args, { stdio: ["ignore","ignore","pipe"] });
    let stderr = "";
    child.stderr.on("data", d => stderr += d.toString());
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) return reject(new Error(`FFmpeg audio mix failed (${code}): ${stderr.slice(-2000)}`));
      if (!fs.existsSync(config.outputPath) || fs.statSync(config.outputPath).size === 0)
        return reject(new Error("mixed film is empty"));
      resolve({ outputPath: config.outputPath, bytes: fs.statSync(config.outputPath).size });
    });
  });
}

module.exports = { makeAudioMixFilter, buildAudioCommand, mixAudioIntoFilm };
