const {saveTimeline}=require("./film_timeline");
function buildTimelineFromFinalCut(project={}){
  const plan=project.finalCutPlan||{};
  const items=(plan.items||[]).filter(x=>x.clipPath).map((x,i)=>({
    id:`ai-cut-${x.jobId||i}`,jobId:x.jobId,order:i+1,sceneId:x.sceneId,
    sceneTitle:x.sceneTitle||`Scene ${x.sceneId||i+1}`,shotNumber:x.shotNumber,
    shotType:x.shotType||"cinematic",clipPath:x.clipPath,
    clipUrl:x.clipUrl||null,duration:Number(x.duration||0),
    transition:x.transition||"cut"
  }));
  return {projectId:project.id,items,source:"ai-final-cut",createdAt:new Date().toISOString()};
}
function applyAiTimeline(project,dir){
  const timeline=buildTimelineFromFinalCut(project);
  saveTimeline(dir,project.id,timeline.items);
  return timeline;
}
module.exports={buildTimelineFromFinalCut,applyAiTimeline};
