function normaliseTrack(track, fallbackDuration = 5) {
  return {
    type: track.type || "sfx",
    path: track.path,
    start: Math.max(0, Number(track.start || 0)),
    duration: Math.max(0.1, Number(track.duration || fallbackDuration)),
    volume: Math.max(0, Number(track.volume ?? 1))
  };
}

function buildSceneAudioPlan(scene = {}, options = {}) {
  const duration = Number(scene.duration || options.defaultDuration || 5);
  const plan = [];

  for (const d of (scene.dialogue || [])) {
    plan.push(normaliseTrack({
      type: "dialogue",
      path: d.path,
      start: d.start,
      duration: d.duration,
      volume: d.volume ?? 1
    }, duration));
  }

  if (scene.music?.path) {
    plan.push(normaliseTrack({
      type: "music",
      path: scene.music.path,
      start: scene.music.start || 0,
      duration: scene.music.duration || duration,
      volume: scene.music.volume ?? 0.35
    }, duration));
  }

  for (const s of (scene.sfx || [])) {
    plan.push(normaliseTrack({
      type: "sfx",
      path: s.path,
      start: s.start,
      duration: s.duration,
      volume: s.volume ?? 0.8
    }, 1));
  }

  return { sceneId: scene.id || "", duration, tracks: plan };
}

function buildFilmAudioPlan(scenes = [], options = {}) {
  let offset = 0;
  const scenesPlan = scenes.map(scene => {
    const plan = buildSceneAudioPlan(scene, options);
    const shifted = plan.tracks.map(t => ({ ...t, filmStart: offset + t.start }));
    offset += plan.duration;
    return { ...plan, filmOffset: offset - plan.duration, tracks: shifted };
  });
  return {
    duration: offset,
    scenes: scenesPlan,
    tracks: scenesPlan.flatMap(s => s.tracks)
  };
}

module.exports = { buildSceneAudioPlan, buildFilmAudioPlan };
