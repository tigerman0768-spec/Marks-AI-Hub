const path=require("path");
const {getProject}=require("./film_projects");
const {processRegeneration}=require("./real_clip_regeneration_worker");

function registerRealClipRegenerationWorkerRoutes(app){
  app.post("/api/projects/:id/clips/regenerations/:regenerationId/check",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    (async()=>{try{
      const result=await processRegeneration(p,req.params.regenerationId);
      res.status(result.ready?200:409).json({projectId:p.id,...result});
    }catch(e){res.status(502).json({error:e.message,provider:"runway"});}})();
  });
}
module.exports={registerRealClipRegenerationWorkerRoutes};
