const fs=require("fs");
const crypto=require("crypto");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");

function lockDelivery(project){
  const d=project?.approvedFilmDelivery;
  if(!d)return {locked:false,reason:"delivery record is missing"};
  if(!d.filmPath||!fs.existsSync(d.filmPath))return {locked:false,reason:"delivery film file is missing"};
  const stat=fs.statSync(d.filmPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(d.filmPath)).digest("hex");
  if(Number(d.bytes)!==stat.size||d.sha256!==sha)
    return {locked:false,reason:"delivery file identity no longer matches the record"};
  const lockId=`delivery_lock_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const lock={
    lockId,deliveryId:d.deliveryId,projectId:project.id,
    filename:d.filename,bytes:stat.size,sha256:sha,
    lockedAt:new Date().toISOString(),status:"locked"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const lockPath=path.join(dir,`${lockId}.json`);
  fs.writeFileSync(lockPath,JSON.stringify(lock,null,2));
  project.approvedFilmDeliveryLock={...lock,lockPath};
  saveProject(path.join(process.cwd(),"projects"),project);
  return {locked:true,lock};
}
module.exports={lockDelivery};
