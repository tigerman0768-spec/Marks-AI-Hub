const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildVisualContinuityPlan}=require("./visual_continuity_director");

function registerVisualContinuityRoutes(app){
  app.post("/api/projects/:id/visual-continuity/generate",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildVisualContinuityPlan(project);
      saveProject(dir,{...project,visualContinuityPlan:plan,status:"visual_continuity_ready"});
      res.json({projectId:project.id,visualContinuityPlan:plan});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/visual-continuity",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json({projectId:project.id,visualContinuityPlan:project.visualContinuityPlan||null});
  });
}
module.exports={registerVisualContinuityRoutes};
