const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
const {probeMedia}=require("./final_render_media_probe");

async function verifyFinalRenderProject(project,ffprobe="ffprobe"){
  const q=project.finalRenderQueueRecord||{};
  const output=q.outputPath||project.finalRenderOutput||null;
  const exists=Boolean(output&&fs.existsSync(output));
  if(!exists){
    q.outputExists=false;q.mediaVerified=false;q.verificationError="output file missing";
    project.finalRenderReady=false;
    return {verified:false,exists:false,error:q.verificationError};
  }
  const probe=await probeMedia(output,ffprobe);
  const valid=probe.ok&&probe.size>0&&probe.duration>0&&!!probe.video;
  q.outputExists=true;q.mediaVerified=valid;q.mediaMetadata=probe;
  q.verificationError=valid?null:(probe.error||"media output is incomplete or has no video stream");
  if(valid){
    q.progress=100;q.stage="verified";q.status="completed";project.finalRenderReady=true;
  }else project.finalRenderReady=false;
  return {verified:valid,exists:true,metadata:probe,error:q.verificationError};
}
async function verifyAndSave(projectId,ffprobe="ffprobe"){
  const dir=path.join(process.cwd(),"projects"),p=getProject(dir,projectId);
  if(!p)return null;
  const result=await verifyFinalRenderProject(p,ffprobe);saveProject(dir,p);return result;
}
module.exports={verifyFinalRenderProject,verifyAndSave};
