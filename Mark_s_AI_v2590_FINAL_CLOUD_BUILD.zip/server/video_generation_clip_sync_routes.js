const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerVideoGenerationClipSyncRoutes(app) {
  app.post("/api/projects/:id/video-generation/sync-clips", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const clips = Array.isArray(p.generatedClips) ? p.generatedClips : [];
    let added = 0;
    let updated = 0;

    for (const job of jobs) {
      if (job.status !== "completed" || !job.clipPath) continue;
      const existing = clips.find(c =>
        String(c.jobId || c.videoJobId || "") === String(job.id) ||
        String(c.shotId || "") === String(job.shotId || "")
      );

      if (existing) {
        if (!existing.path && job.clipPath) {
          existing.path = job.clipPath;
          updated++;
        }
        continue;
      }

      clips.push({
        id: `generated-clip-${job.id}`,
        jobId: job.id,
        shotId: job.shotId,
        scene: job.scene,
        index: job.index,
        path: job.clipPath,
        provider: job.provider,
        duration: job.duration,
        status: "available",
        createdAt: new Date().toISOString()
      });
      added++;
    }

    p.generatedClips = clips;
    p.videoGenerationClipsSyncedAt = new Date().toISOString();
    saveProject(dir, p);

    res.json({
      projectId: p.id,
      added,
      updated,
      totalClips: clips.length,
      syncedAt: p.videoGenerationClipsSyncedAt
    });
  });
}

module.exports = { registerVideoGenerationClipSyncRoutes };
