const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectValidationRoutes(app){
  app.get("/api/projects/:id/validate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const checks=[
      ["identity",Boolean(p.id&&p.title)],
      ["story",Boolean(p.idea||p.screenplay)],
      ["format",Boolean(p.genre&&p.style&&p.aspectRatio)],
      ["scenes",Boolean((p.scenes||[]).length)],
      ["production",Boolean(p.characterBible||p.storyboard||p.shotCards)]
    ];
    const issues=checks.filter(x=>!x[1]).map(x=>x[0]);
    res.json({projectId:p.id,valid:issues.length===0,issues,checks:Object.fromEntries(checks)});
  });
}
module.exports={registerProjectValidationRoutes};
