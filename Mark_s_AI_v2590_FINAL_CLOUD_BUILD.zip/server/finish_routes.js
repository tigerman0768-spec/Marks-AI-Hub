function registerFinishRoutes(app){
  app.post("/api/film/finish",(req,res)=>{
    try{ res.status(202).json(require("./finish_api").createFinishRun(req.body||{})); }
    catch(err){res.status(400).json({error:err.message});}
  });
  app.get("/api/film/finish/:id",(req,res)=>{
    const run=require("./finish_api").getFinishRun(req.params.id);
    if(!run)return res.status(404).json({error:"finish run not found"});
    res.json(run);
  });
}
module.exports={registerFinishRoutes};
