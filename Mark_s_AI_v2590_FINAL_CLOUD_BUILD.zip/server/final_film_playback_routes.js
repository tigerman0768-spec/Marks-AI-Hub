const fs=require("fs");
const path=require("path");
const {getPlayableFinalFilm}=require("./final_film_playback");
function registerFinalFilmPlaybackRoutes(app){
 app.get("/api/final-render/jobs/:id/play",(req,res)=>{
  try{
   const x=getPlayableFinalFilm(req.params.id);
   if(!x)return res.status(404).json({error:"final render job not found"});
   if(!x.playable)return res.status(409).json(x);
   res.sendFile(path.resolve(x.outputPath),err=>{if(err&&!res.headersSent)res.status(500).json({error:err.message});});
  }catch(e){res.status(500).json({error:e.message});}
 });
 app.get("/api/final-render/jobs/:id/play-info",(req,res)=>{
  try{
   const x=getPlayableFinalFilm(req.params.id);
   if(!x)return res.status(404).json({error:"final render job not found"});
   res.json(x);
  }catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFinalFilmPlaybackRoutes};
