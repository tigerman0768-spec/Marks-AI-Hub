const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildShotCards}=require("./shot_cards");
const {createVideoGenerationRun}=require("./video_generation");
const {runVideoGeneration}=require("./video_generation_worker");
const {createRunwayVideoProvider}=require("./runway_video_provider");
const {downloadClip}=require("./generated_clip_downloader");
const {linkGeneratedClips}=require("./clip_linker");
const runs=new Map();

function registerVideoGenerationRoutes(app,options={}){
  const providerFactory=options.providerFactory;
  app.post("/api/projects/:id/video-generation",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const shots=buildShotCards(project);
      if(!shots.length)return res.status(400).json({error:"generate a storyboard first"});
      const run=createVideoGenerationRun({...project,...(req.body||{})},shots);
      runs.set(run.id,run);
      saveProject(dir,{...project,status:"video_generation_running"});
      res.status(202).json(run);

      setImmediate(async()=>{
        try{
          let provider=providerFactory?await providerFactory(project):null;
          if(!provider){
            let client=null;
            try{
              if(process.env.RUNWAY_API_KEY){
                const Runway=require("@runwayml/sdk");
                client=new Runway({apiKey:process.env.RUNWAY_API_KEY});
              }
            }catch(e){run.providerError=e.message;}
            provider=createRunwayVideoProvider({client});
          }
          await runVideoGeneration(run,provider,{maxRetries:2});
          if(run.status==="completed"){
            const clipDir=path.join(process.cwd(),"assets","clips",project.id);
            for(const job of run.jobs){
              try{
                const clip=await downloadClip(job.output,clipDir,job.id);
                job.clipPath=clip.path; job.clipBytes=clip.bytes; job.downloadStatus="downloaded";
              }catch(e){
                job.downloadStatus="failed"; job.downloadError=e.message;
              }
            }
            run.jobs=linkGeneratedClips(project,run);
            saveProject(dir,{...project,status:"video_clips_ready",videoJobs:run.jobs});
          }else saveProject(dir,{...project,status:"video_generation_failed",videoJobs:run.jobs});
        }catch(e){
          run.status="failed";run.error=e.message;run.finishedAt=new Date().toISOString();
          saveProject(dir,{...project,status:"video_generation_failed",videoJobs:run.jobs});
        }
      });
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/video-generation/latest/:projectId",(req,res)=>{
    const matches=[...runs.values()].filter(r=>r.jobs?.some(j=>j.sceneId===req.params.projectId));
    const run=matches.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))[0];
    if(!run)return res.status(404).json({error:"no generation run found"});
    res.json(run);
  });
  app.get("/api/video-generation/:id",(req,res)=>{
    const run=runs.get(req.params.id);
    if(!run)return res.status(404).json({error:"generation run not found"});
    res.json(run);
  });
}
module.exports={registerVideoGenerationRoutes};
