const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
function registerFinalRenderWorkerSyncRoutes(app){
  app.post("/api/projects/:id/final-render/worker-sync",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q)return res.status(409).json({error:"no render queue record"});
    if(req.body?.status)q.status=String(req.body.status);
    if(req.body?.stage!==undefined)q.stage=String(req.body.stage);
    if(req.body?.progress!==undefined)q.progress=Math.max(0,Math.min(100,Number(req.body.progress)||0));
    if(req.body?.outputPath!==undefined){q.outputPath=String(req.body.outputPath);q.outputExists=fs.existsSync(q.outputPath);}
    if(req.body?.error!==undefined)q.error=req.body.error?String(req.body.error):null;
    q.updatedAt=new Date().toISOString();saveProject(dir,p);res.json(q);
  });
}
module.exports={registerFinalRenderWorkerSyncRoutes};
