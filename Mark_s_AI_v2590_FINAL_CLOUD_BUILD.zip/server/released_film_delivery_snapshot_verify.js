const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function verifyReleasedFilmDeliverySnapshot(project){
  const snap=project?.finalMasterReleasedFilmDeliverySnapshot;
  if(snap?.status!=="captured")return {verified:false,blockers:["delivery snapshot is not captured"]};
  if(!snap.outputPath||!fs.existsSync(snap.outputPath))return {verified:false,blockers:["snapshot film file is missing"]};
  const stat=fs.statSync(snap.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(snap.outputPath)).digest("hex");
  const blockers=[];
  if(sha!==snap.sha256)blockers.push("snapshot SHA-256 mismatch");
  if(stat.size!==Number(snap.bytes))blockers.push("snapshot file size mismatch");
  const verification={
    verificationId:`snapshot_verify_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    snapshotId:snap.snapshotId,projectId:project.id,bytes:stat.size,
    sha256:sha,expectedSha256:snap.sha256,verified:blockers.length===0,
    blockers,verifiedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_snapshot");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"snapshot_verification.json"),JSON.stringify(verification,null,2));
  project.finalMasterReleasedFilmDeliverySnapshotVerification=verification;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {verified:verification.verified,verification};
}
module.exports={verifyReleasedFilmDeliverySnapshot};
