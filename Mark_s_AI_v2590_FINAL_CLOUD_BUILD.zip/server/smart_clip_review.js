function scoreClip(job={}){
  const q=job.qualityReport||{};
  const issues=Array.isArray(q.issues)?q.issues:[];
  let score=100;
  if(q.status==="failed"||q.valid===false) score-=55;
  if(!q.playable) score-=35;
  if(!q.width||!q.height) score-=20;
  if(q.duration<0.5) score-=25;
  if(issues.length) score-=Math.min(30,issues.length*10);
  score=Math.max(0,Math.min(100,score));
  let decision="review";
  if(score>=90) decision="recommended";
  else if(score<60) decision="regenerate";
  return {score,decision,issues,qualityStatus:q.status||"unchecked"};
}
function reviewProjectClips(project={}){
  const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
  return jobs.filter(j=>j.downloadStatus==="downloaded").map(job=>{
    const review=scoreClip(job);
    job.smartReview=review;
    job.smartReviewAt=new Date().toISOString();
    return {jobId:job.id,shotNumber:job.shotNumber,...review};
  });
}
module.exports={scoreClip,reviewProjectClips};
