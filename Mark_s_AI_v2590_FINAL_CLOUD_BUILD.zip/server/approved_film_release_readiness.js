const fs=require("fs");
function releaseReadiness(project){
  const c=project?.approvedFilmReleaseSnapshot, l=project?.approvedFilmDeliveryLock;
  const blockers=[];
  if(!project?.approvedFilmLibraryFilm)blockers.push("Film Library record missing");
  if(!project?.approvedFilmExport)blockers.push("export record missing");
  if(!project?.approvedFilmDelivery)blockers.push("delivery record missing");
  if(!l)blockers.push("delivery is not locked");
  if(!c)blockers.push("release snapshot missing");
  if(l?.filmPath&&!fs.existsSync(l.filmPath))blockers.push("locked film file missing");
  if(c?.sha256&&l?.sha256&&c.sha256!==l.sha256)blockers.push("snapshot hash differs from delivery lock");
  if(c?.bytes&&l?.bytes&&Number(c.bytes)!==Number(l.bytes))blockers.push("snapshot size differs from delivery lock");
  return {ready:blockers.length===0,blockers,checkedAt:new Date().toISOString()};
}
module.exports={releaseReadiness};
