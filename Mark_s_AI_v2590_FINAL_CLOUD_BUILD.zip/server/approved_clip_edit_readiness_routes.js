const path = require("path");
const fs = require("fs");
const { getProject } = require("./film_projects");

function registerApprovedClipEditReadinessRoutes(app) {
  app.get("/api/projects/:id/approved-clips/edit-readiness", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const approved = Array.isArray(p.approvedGeneratedClips) ? p.approvedGeneratedClips : [];
    const timeline = Array.isArray(p.approvedClipEditTimeline) ? p.approvedClipEditTimeline : [];
    const files = approved.length > 0 && approved.every(c => c.path && fs.existsSync(c.path));
    res.json({
      projectId: p.id,
      finalized: Boolean(p.generatedClipReviewFinalizedAt),
      approvedCount: approved.length,
      sourceFilesAvailable: files,
      editTimelinePrepared: timeline.length === approved.length && timeline.length > 0,
      ready: Boolean(p.generatedClipReviewFinalizedAt) && files &&
        timeline.length === approved.length && timeline.length > 0
    });
  });
}
module.exports = { registerApprovedClipEditReadinessRoutes };
