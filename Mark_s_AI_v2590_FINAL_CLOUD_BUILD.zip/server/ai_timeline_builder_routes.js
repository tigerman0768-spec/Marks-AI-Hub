const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildTimelineFromFinalCut,applyAiTimeline}=require("./ai_timeline_builder");

function registerAiTimelineBuilderRoutes(app){
  app.get("/api/projects/:id/ai-timeline",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(buildTimelineFromFinalCut(project));
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/ai-timeline/build", (req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const timeline=applyAiTimeline(project,path.join(process.cwd(),"timelines"));
      saveProject(dir,{...project,finalTimeline:timeline,status:"timeline_built"});
      res.json(timeline);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiTimelineBuilderRoutes};
