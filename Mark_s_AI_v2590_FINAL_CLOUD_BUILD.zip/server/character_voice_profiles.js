const fs=require("fs");
const path=require("path");

function profileFile(dir,projectId){return path.join(dir,`${projectId}.json`);}
function defaults(character="Character"){
  return {character,voice:"alloy",style:"natural cinematic",tone:"calm",pitch:"neutral",
    speed:1.0,instructions:`Speak as ${character} in a natural cinematic style. Keep the character consistent across scenes.`};
}
function loadVoiceProfiles(dir,projectId){
  const f=profileFile(dir,projectId);
  if(!fs.existsSync(f))return {projectId,profiles:[],updatedAt:null};
  try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch{return {projectId,profiles:[],updatedAt:null}};
}
function saveVoiceProfiles(dir,projectId,profiles){
  fs.mkdirSync(dir,{recursive:true});
  const clean=profiles.map(p=>({...defaults(p.character),...p,
    speed:Math.max(.5,Math.min(2,Number(p.speed??1))),
    instructions:String(p.instructions||"")}));
  const record={projectId,profiles:clean,updatedAt:new Date().toISOString()};
  fs.writeFileSync(profileFile(dir,projectId),JSON.stringify(record,null,2));
  return record;
}
function upsertVoiceProfile(dir,projectId,profile){
  const current=loadVoiceProfiles(dir,projectId);
  const i=current.profiles.findIndex(p=>p.character===profile.character);
  const profiles=[...current.profiles];
  if(i<0)profiles.push(profile);else profiles[i]={...profiles[i],...profile};
  return saveVoiceProfiles(dir,projectId,profiles);
}
module.exports={defaults,loadVoiceProfiles,saveVoiceProfiles,upsertVoiceProfile};
