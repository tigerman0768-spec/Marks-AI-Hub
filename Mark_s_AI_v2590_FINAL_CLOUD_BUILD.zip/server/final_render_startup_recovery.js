const {inspectWorkers,takeOverInterruptedJobs}=require("./final_render_worker_manager");
async function runStartupFinalRenderRecovery(options={}){
  if(options.enabled===false)return {status:"disabled",jobs:[]};
  const workers=inspectWorkers();
  const restartable=workers.filter(x=>x.workerState==="restartable");
  if(!restartable.length)return {status:"nothing_to_recover",jobs:[]};
  return {status:"recovery_started",jobs:await takeOverInterruptedJobs(options)};
}
module.exports={runStartupFinalRenderRecovery};
