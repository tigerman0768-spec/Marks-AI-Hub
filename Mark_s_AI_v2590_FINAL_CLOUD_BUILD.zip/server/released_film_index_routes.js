const {buildReleasedFilmIndex}=require("./released_film_index");
function registerReleasedFilmIndexRoutes(app){
  app.get("/api/films/released",(req,res)=>{
    const result=buildReleasedFilmIndex();
    const q=String(req.query.q||"").trim().toLowerCase();
    if(!q)return res.json(result);
    res.json({...result,films:result.films.filter(f=>
      String(f.title).toLowerCase().includes(q) ||
      String(f.filename).toLowerCase().includes(q) ||
      String(f.projectId).toLowerCase().includes(q))});
  });
}
module.exports={registerReleasedFilmIndexRoutes};
