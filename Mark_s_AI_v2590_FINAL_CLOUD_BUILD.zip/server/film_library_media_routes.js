const fs=require("fs");
const path=require("path");
const {getFilm}=require("./film_library");
const DIR=path.join(process.cwd(),"films");

function sendExisting(res,file){
 const p=path.resolve(file||"");
 if(!file||!fs.existsSync(p)||!fs.statSync(p).isFile())return res.status(404).json({error:"media not found"});
 res.sendFile(p,err=>{if(err&&!res.headersSent)res.status(500).json({error:err.message});});
}
function registerFilmLibraryMediaRoutes(app){
 app.get("/api/film-library/:id/thumbnail",(req,res)=>{
  try{
   const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});
   sendExisting(res,f.thumbnailPath);
  }catch(e){res.status(500).json({error:e.message});}
 });
 app.get("/api/film-library/:id/play",(req,res)=>{
  try{
   const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});
   sendExisting(res,f.outputPath);
  }catch(e){res.status(500).json({error:e.message});}
 });
 app.get("/api/film-library/:id/media-info",(req,res)=>{
  try{
   const f=getFilm(DIR,req.params.id);if(!f)return res.status(404).json({error:"film not found"});
   res.json({id:f.id,title:f.title,outputPath:f.outputPath,thumbnailPath:f.thumbnailPath,
     playable:!!f.outputPath&&fs.existsSync(path.resolve(f.outputPath)),
     hasThumbnail:!!f.thumbnailPath&&fs.existsSync(path.resolve(f.thumbnailPath))});
  }catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFilmLibraryMediaRoutes};
