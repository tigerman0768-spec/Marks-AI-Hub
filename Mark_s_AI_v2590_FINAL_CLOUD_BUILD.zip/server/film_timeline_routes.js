const path=require("path");
const {getProject}=require("./film_projects");
const {buildTimeline,saveTimeline,loadTimeline}=require("./film_timeline");

function registerFilmTimelineRoutes(app){
  app.get("/api/projects/:id/timeline",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const dir=path.join(process.cwd(),"timelines");
    const stored=loadTimeline(dir,project.id);
    if(stored)return res.json(stored);
    const timeline=buildTimeline(project);
    res.json({projectId:project.id,updatedAt:null,items:timeline});
  });

  app.post("/api/projects/:id/timeline/build",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const timeline=buildTimeline(project);
      if(!timeline.length)return res.status(400).json({error:"approve at least one downloaded clip first"});
      res.json(saveTimeline(path.join(process.cwd(),"timelines"),project.id,timeline));
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFilmTimelineRoutes};
