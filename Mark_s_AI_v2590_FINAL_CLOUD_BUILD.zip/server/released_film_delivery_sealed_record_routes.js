const path=require("path");
const {getProject}=require("./film_projects");
const {createSealedReleaseDeliveryRecord}=require("./released_film_delivery_sealed_record");
function registerReleasedFilmDeliverySealedRecordRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-sealed-record",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,record:p.finalMasterReleasedFilmSealedDeliveryRecord||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-sealed-record/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createSealedReleaseDeliveryRecord(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliverySealedRecordRoutes};
