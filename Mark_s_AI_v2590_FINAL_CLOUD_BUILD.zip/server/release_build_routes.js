const crypto = require('crypto');

function config(){
  const owner=process.env.GITHUB_OWNER || '';
  const repo=process.env.GITHUB_REPO || '';
  const workflow=process.env.GITHUB_RELEASE_WORKFLOW || 'android-release.yml';
  const ref=process.env.GITHUB_RELEASE_REF || 'main';
  return {owner,repo,workflow,ref,configured:Boolean(owner&&repo&&process.env.GITHUB_TOKEN)};
}

function registerReleaseBuildRoutes(app){
  app.get('/api/release-build',(req,res)=>{
    const c=config();
    const workflowUrl=c.owner&&c.repo?`https://github.com/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/workflows/${encodeURIComponent(c.workflow)}`:null;
    res.json({version:'v2570',configured:c.configured,owner:c.owner||null,repo:c.repo||null,workflow:c.workflow,ref:c.ref,workflowUrl,artifacts:['marks-ai-android-apk','marks-ai-android-aab'],message:c.configured?'GitHub Actions Android build is ready to dispatch.':'Set GITHUB_OWNER, GITHUB_REPO and GITHUB_TOKEN to enable one-tap dispatch.'});
  });

  app.post('/api/release-build/dispatch',async(req,res)=>{
    const c=config();
    if(!c.configured)return res.status(503).json({error:'GitHub release build is not configured',required:['GITHUB_OWNER','GITHUB_REPO','GITHUB_TOKEN']});
    const releaseVersion=String(req.body?.releaseVersion||'v2570').trim() || 'v2570';
    if(!/^v\d+(?:\.\d+)?$/.test(releaseVersion))return res.status(400).json({error:'releaseVersion must look like v2560'});
    const url=`https://api.github.com/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/workflows/${encodeURIComponent(c.workflow)}/dispatches`;
    try{
      const r=await fetch(url,{method:'POST',headers:{'Accept':'application/vnd.github+json','Authorization':`Bearer ${process.env.GITHUB_TOKEN}`,'X-GitHub-Api-Version':'2022-11-28','Content-Type':'application/json','User-Agent':"Mark's-AI-Release-Center"},body:JSON.stringify({ref:c.ref,inputs:{release_version:releaseVersion}})});
      if(!r.ok){const text=await r.text();return res.status(r.status).json({error:'GitHub workflow dispatch failed',detail:text.slice(0,1000)});}
      return res.status(202).json({status:'dispatched',releaseVersion,workflow:c.workflow,ref:c.ref,requestId:crypto.randomUUID(),workflowUrl:`https://github.com/${c.owner}/${c.repo}/actions/workflows/${c.workflow}`});
    }catch(e){return res.status(502).json({error:'Unable to reach GitHub',detail:e.message});}
  });
}

module.exports={registerReleaseBuildRoutes};
