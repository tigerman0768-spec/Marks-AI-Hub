const { buildSceneGenerationJobs } = require("./generation_jobs");
const { validateGenerationBatch } = require("./quality");

function createProductionRun(scenes, options = {}) {
  const jobs = buildSceneGenerationJobs(scenes, options);
  const validation = validateGenerationBatch(jobs);

  return {
    runId: `run-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    status: validation.ok ? "ready" : "blocked",
    createdAt: new Date().toISOString(),
    jobs: jobs.map((job, index) => ({
      ...job,
      order: index + 1,
      status: validation.ok ? "queued" : "blocked"
    })),
    validation
  };
}

function nextQueuedJob(run) {
  if (!run || !Array.isArray(run.jobs)) return null;
  return run.jobs.find(j => j.status === "queued") || null;
}

function markJob(run, jobId, patch = {}) {
  const job = (run.jobs || []).find(j => j.id === jobId);
  if (!job) throw new Error("job not found");
  Object.assign(job, patch);
  return job;
}

module.exports = { createProductionRun, nextQueuedJob, markJob };
