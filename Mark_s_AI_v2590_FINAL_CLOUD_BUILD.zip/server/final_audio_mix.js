const fs=require("fs");
const {spawn}=require("child_process");

function collectAudioTracks(plan={}){
  const tracks=[];
  for(const scene of (plan.scenes||[])){
    for(const voice of (scene.voiceAssets||[])){
      if(voice.localPath) tracks.push({
        type:"dialogue",path:voice.localPath,start:Number(voice.filmStart??scene.offset??0),
        duration:Number(voice.duration||3),volume:Number(voice.volume??1)
      });
    }
    if(scene.music?.path) tracks.push({
      type:"music",path:scene.music.path,start:Number(scene.music.filmStart??scene.offset??0),
      duration:Number(scene.music.duration||scene.duration||5),volume:Number(scene.music.volume??.35)
    });
    for(const sfx of (scene.sfx||[])){
      if(sfx.path) tracks.push({
        type:"sfx",path:sfx.path,start:Number(sfx.filmStart??(scene.offset||0)+Number(sfx.start||0)),
        duration:Number(sfx.duration||1),volume:Number(sfx.volume??.8)
      });
    }
  }
  for(const t of tracks){
    if(!fs.existsSync(t.path)||!fs.statSync(t.path).size)
      throw new Error(`audio asset unavailable: ${t.path}`);
  }
  return tracks;
}

function buildFinalMixArgs(videoPath,tracks,outputPath,ffmpeg){
  if(!videoPath||!fs.existsSync(videoPath)) throw new Error("video file unavailable");
  const bin=ffmpeg||process.env.FFMPEG_BIN||"ffmpeg";
  const args=["-y","-i",videoPath];
  tracks.forEach(t=>args.push("-i",t.path));
  if(!tracks.length) return {ffmpeg:bin,args:[...args,"-c","copy","-movflags","+faststart",outputPath]};
  const filters=tracks.map((t,i)=>{
    const delay=Math.max(0,Math.round(t.start*1000));
    return `[${i+1}:a]adelay=${delay}|${delay},volume=${t.volume}[a${i}]`;
  }).join(";");
  const labels=tracks.map((_,i)=>`[a${i}]`).join("");
  const filter=`${filters};${labels}amix=inputs=${tracks.length}:duration=longest:dropout_transition=2:normalize=0[aout]`;
  return {ffmpeg:bin,args:[...args,"-filter_complex",filter,"-map","0:v:0","-map","[aout]",
    "-c:v","copy","-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath]};
}

async function buildFinalAudioMix({videoPath,plan,outputPath,ffmpeg}){
  const tracks=collectAudioTracks(plan||{});
  const cmd=buildFinalMixArgs(videoPath,tracks,outputPath,ffmpeg);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]});
    let err=""; child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`final audio mix failed (${code}): ${err.slice(-1800)}`));
      if(!fs.existsSync(outputPath)||!fs.statSync(outputPath).size)
        return reject(new Error("final mix output is empty"));
      resolve({
        outputPath,bytes:fs.statSync(outputPath).size,
        trackCount:tracks.length,
        dialogue:tracks.filter(x=>x.type==="dialogue").length,
        music:tracks.filter(x=>x.type==="music").length,
        sfx:tracks.filter(x=>x.type==="sfx").length
      });
    });
  });
}
module.exports={collectAudioTracks,buildFinalMixArgs,buildFinalAudioMix};
