const path=require("path");
const fs=require("fs");
const {spawn}=require("child_process");
const {getProject,saveProject}=require("./film_projects");

function renderApprovedFilm(project,options={}){
  const tl=project?.approvedFilmTimeline;
  if(!tl?.clips?.length)return {ready:false,blockers:["approved film timeline is empty"]};
  const existing=tl.clips.filter(c=>c.sourcePath&&fs.existsSync(c.sourcePath));
  if(existing.length!==tl.clips.length)return {ready:false,blockers:["one or more timeline clip files are missing"]};
  const dir=path.join(process.cwd(),"projects",String(project.id),"final_render","approved_film");
  fs.mkdirSync(dir,{recursive:true});
  const listPath=path.join(dir,"concat_list.txt");
  const outputPath=path.join(dir,options.filename||"approved_film.mp4");
  const lines=existing.map(c=>`file '${String(path.resolve(c.sourcePath)).replace(/'/g,"'\\\\''")}'`).join("\n")+"\n";
  fs.writeFileSync(listPath,lines);
  const job={
    renderId:`approved_render_${Date.now()}`,projectId:project.id,
    outputPath,listPath,clipCount:existing.length,status:"running",
    startedAt:new Date().toISOString()
  };
  project.approvedFilmRender=job; saveProject(path.join(process.cwd(),"projects"),project);
  const child=spawn("ffmpeg",["-y","-f","concat","-safe","0","-i",listPath,"-c","copy",outputPath],{stdio:["ignore","pipe","pipe"]});
  child.on("close",code=>{
    const p=getProject(path.join(process.cwd(),"projects"),project.id)||project;
    const current=p.approvedFilmRender||job;
    if(code===0&&fs.existsSync(outputPath)){
      const stat=fs.statSync(outputPath);
      current.status="completed"; current.bytes=stat.size; current.completedAt=new Date().toISOString();
    }else{current.status="failed";current.error=`ffmpeg exited with code ${code}`;}
    p.approvedFilmRender=current;saveProject(path.join(process.cwd(),"projects"),p);
  });
  return {ready:true,job};
}
module.exports={renderApprovedFilm};
