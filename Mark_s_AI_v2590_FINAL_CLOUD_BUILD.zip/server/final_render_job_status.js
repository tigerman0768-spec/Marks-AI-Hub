const path=require("path");
const {getJob}=require("./final_render_job_store");
const {getProcessState}=require("./final_render_process_registry");
const {getProgress}=require("./final_render_progress");

const DIR=path.join(process.cwd(),"final-render-jobs");

function getFinalRenderJobStatus(id){
  const job=getJob(DIR,id);
  if(!job)return null;
  let progress=null;
  try{ progress=getProgress(id); }catch(_){}
  return {
    id:job.id,
    projectId:job.projectId,
    title:job.title||job.projectSnapshot?.title||"Untitled Film",
    status:job.status,
    progressId:job.progressId||job.id,
    progress:progress?.progress ?? job.progress ?? 0,
    stage:progress?.stage ?? job.stage ?? "",
    message:progress?.message ?? "",
    queuePosition:job.queuePosition||0,
    startedAt:job.startedAt||null,
    finishedAt:job.finishedAt||null,
    result:job.result||null,
    error:job.error||progress?.error||null,
    process:getProcessState(id)||null,
    updatedAt:job.updatedAt||null
  };
}
module.exports={getFinalRenderJobStatus};
