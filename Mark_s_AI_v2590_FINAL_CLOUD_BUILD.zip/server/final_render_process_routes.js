const {getProcessState,getProcess}=require("./final_render_process_registry");
function registerFinalRenderProcessRoutes(app){
  app.get("/api/final-render/jobs/:id/process",(req,res)=>{
    const state=getProcessState(req.params.id);
    if(!state)return res.status(404).json({error:"process state not found"});
    res.json({...state,ownedByThisServer:!!getProcess(req.params.id)});
  });
}
module.exports={registerFinalRenderProcessRoutes};
