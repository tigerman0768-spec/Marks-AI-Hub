const path = require("path");
const { getProject, saveProject } = require("./film_projects");
const allowed=["pending","keep","remove","needs_trim"];

function registerCanonicalTimelineReviewDecisionRoutes(app){
  app.patch("/api/projects/:id/timeline-review/:timelineId",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    if(!p.timelineReview?.itemDecisions)return res.status(404).json({error:"review not started"});
    const d=p.timelineReview.itemDecisions.find(x=>x.timelineId===req.params.timelineId);
    if(!d)return res.status(404).json({error:"timeline item not found"});
    const status=String(req.body?.status||"");
    if(!allowed.includes(status))return res.status(400).json({error:"invalid status",allowed});
    d.status=status; d.note=req.body?.note?String(req.body.note):null; d.updatedAt=new Date().toISOString();
    saveProject(dir,p); res.json(d);
  });
}
module.exports={registerCanonicalTimelineReviewDecisionRoutes};
