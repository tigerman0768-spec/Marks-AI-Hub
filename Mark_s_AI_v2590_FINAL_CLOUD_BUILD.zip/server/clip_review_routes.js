const path=require("path");
const {getClipReview,setClipReview}=require("./clip_review");
const {getProject,saveProject}=require("./film_projects");
function registerClipReviewRoutes(app){
  app.get("/api/projects/:projectId/clip-review",(req,res)=>{
    res.json(getClipReview(path.join(process.cwd(),"reviews"),req.params.projectId));
  });
  app.patch("/api/projects/:projectId/clip-review/:jobId",(req,res)=>{
    try{
      const body=req.body||{};
      const allowed=["decision","notes"];
      const changes={};
      for(const k of allowed)if(body[k]!==undefined)changes[k]=body[k];
      if(changes.decision&&!["pending","accepted","rejected"].includes(changes.decision))
        return res.status(400).json({error:"invalid decision"});
      const review=setClipReview(path.join(process.cwd(),"reviews"),req.params.projectId,req.params.jobId,changes);
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.projectId);
      if(project){
        const clipReviews={...(project.clipReviews||{}),[req.params.jobId]:review};
        saveProject(dir,{...project,clipReviews,status:review.decision==="accepted"?"clips_reviewed":project.status});
      }
      res.json(review);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerClipReviewRoutes};
