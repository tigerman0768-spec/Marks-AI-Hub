const fs=require("fs");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");
function registerProjectRecoveryRoutes(app){
 app.get("/api/projects/:id/recovery",(req,res)=>{
  const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const backup=path.join(process.cwd(),"project-backups",`${p.id}.json`);
  const archive=path.join(process.cwd(),"project-archives",`${p.id}.json`);
  const backups=[];
  if(fs.existsSync(backup))backups.push({type:"backup",path:backup,modifiedAt:fs.statSync(backup).mtime.toISOString()});
  if(fs.existsSync(archive))backups.push({type:"archive",path:archive,modifiedAt:fs.statSync(archive).mtime.toISOString()});
  res.json({projectId:p.id,currentUpdatedAt:p.updatedAt||null,recoveryPoints:backups});
 });
 app.post("/api/projects/:id/recover",(req,res)=>{
  const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const type=req.body?.type==="archive"?"archive":"backup";
  const file=path.join(process.cwd(),type==="archive"?"project-archives":"project-backups",`${p.id}.json`);
  if(!fs.existsSync(file))return res.status(404).json({error:`${type} not found`});
  const snapshot=JSON.parse(fs.readFileSync(file,"utf8"));
  const restored=saveProject(dir,{...snapshot,id:p.id,status:"draft",recoveredAt:new Date().toISOString()});
  res.json({projectId:restored.id,status:restored.status,recoveredAt:restored.recoveredAt});
 });
}
module.exports={registerProjectRecoveryRoutes};
