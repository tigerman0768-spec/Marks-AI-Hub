const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createSealedReleaseDeliveryRecord(project){
  const seal=project?.finalMasterReleasedFilmDeliverySeal;
  const snap=project?.finalMasterReleasedFilmDeliverySnapshot;
  const sv=project?.finalMasterReleasedFilmDeliverySnapshotVerification;
  if(seal?.status!=="sealed")return {ready:false,blockers:["delivery seal is required"]};
  if(snap?.status!=="captured")return {ready:false,blockers:["delivery snapshot is required"]};
  if(!sv?.verified)return {ready:false,blockers:["delivery snapshot verification must pass"]};
  const output=seal.outputPath;
  if(!output||!fs.existsSync(output))return {ready:false,blockers:["final film file is missing"]};
  const stat=fs.statSync(output);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  const blockers=[];
  if(sha!==seal.sha256||sha!==snap.sha256||sha!==sv.sha256)blockers.push("final film hash does not match sealed evidence");
  if(stat.size!==Number(seal.bytes)||stat.size!==Number(snap.bytes)||stat.size!==Number(sv.bytes))blockers.push("final film size does not match sealed evidence");
  const record={
    recordId:`sealed_delivery_record_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",outputPath:output,
    bytes:stat.size,sha256:sha,sealId:seal.sealId,snapshotId:snap.snapshotId,
    snapshotVerificationId:sv.verificationId,createdAt:new Date().toISOString(),
    status:blockers.length?"blocked":"sealed",blockers
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","sealed_delivery_record");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"sealed_delivery_record.json"),JSON.stringify(record,null,2));
  project.finalMasterReleasedFilmSealedDeliveryRecord=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:blockers.length===0,record};
}
module.exports={createSealedReleaseDeliveryRecord};
