const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildProjectVideoPrompts}=require("./video_prompt_director");

function registerVideoPromptRoutes(app){
  app.post("/api/projects/:id/video-prompts/generate",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const prompts=buildProjectVideoPrompts(project);
      saveProject(dir,{...project,videoPromptPlan:prompts,status:"video_prompts_ready"});
      res.json({projectId:project.id,prompts,count:prompts.length});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/video-prompts",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json({projectId:project.id,prompts:project.videoPromptPlan||[]});
  });
}
module.exports={registerVideoPromptRoutes};
