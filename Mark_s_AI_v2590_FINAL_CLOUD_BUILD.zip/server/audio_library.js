const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function ensureAudioLibrary(dir){fs.mkdirSync(dir,{recursive:true});return dir;}
function listAudio(dir){
  ensureAudioLibrary(dir);
  return fs.readdirSync(dir).filter(f=>/\.(mp3|wav|m4a|aac|ogg)$/i.test(f)).map(file=>{
    const p=path.join(dir,file), st=fs.statSync(p);
    return {id:path.basename(file,path.extname(file)),name:file,path:p,bytes:st.size};
  });
}
function addAudioRecord(dir,data={}){
  ensureAudioLibrary(dir);
  const id=data.id||crypto.randomUUID();
  const record={id,name:String(data.name||id),path:String(data.path||""),type:data.type||"music",
    start:Number(data.start||0),end:data.end==null?null:Number(data.end),volume:Number(data.volume??0.35),
    fadeIn:Number(data.fadeIn||0),fadeOut:Number(data.fadeOut||0)};
  const meta=path.join(dir,`${id}.json`);
  fs.writeFileSync(meta,JSON.stringify(record,null,2));
  return record;
}
function loadAudioRecords(dir){
  ensureAudioLibrary(dir);
  return fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{
    try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"));}catch{return null;}
  }).filter(Boolean);
}
function removeAudioRecord(dir,id){
  const f=path.join(dir,`${id}.json`);
  if(!fs.existsSync(f))return false;
  fs.unlinkSync(f);return true;
}
module.exports={ensureAudioLibrary,listAudio,addAudioRecord,loadAudioRecords,removeAudioRecord};
