const path=require("path");
const {getProject}=require("./film_projects");
function registerFinalRenderInputRoutes(app){
  app.get("/api/projects/:id/final-render-input",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,ready:p.finalRenderInputReady===true,
      preparedAt:p.finalRenderInputPreparedAt||null,input:p.finalRenderInput||null});
  });
}
module.exports={registerFinalRenderInputRoutes};
