const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function registerFinalCutReviewRoutes(app){
  app.get("/api/projects/:id/final-cut/review",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const plan=p.finalCutPlan||{clips:[]};
    res.json({projectId:p.id,preparedAt:p.finalCutPreparedAt||null,
      status:p.finalCutReview?.status||"not_started",
      review:p.finalCutReview||null,clips:plan.clips||[]});
  });

  app.post("/api/projects/:id/final-cut/review/start",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const clips=Array.isArray(p.finalCutPlan?.clips)?p.finalCutPlan.clips:[];
    if(!clips.length)return res.status(409).json({error:"final cut plan is empty"});
    p.finalCutReview={
      id:`final-cut-review-${p.id}-${Date.now()}`,status:"in_review",
      startedAt:new Date().toISOString(),
      decisions:clips.map((c,i)=>({timelineId:c.id,index:i,status:"pending"}))
    };
    saveProject(dir,p);res.status(201).json(p.finalCutReview);
  });
}
module.exports={registerFinalCutReviewRoutes};
