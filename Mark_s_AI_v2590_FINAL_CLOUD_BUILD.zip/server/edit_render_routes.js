const path=require("path");
const {getProject}=require("./film_projects");
const {buildAutomaticEdit}=require("./ai_editing_engine");
function registerEditRenderRoutes(app){
  app.get("/api/projects/:id/render-readiness",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const items=project.finalTimeline?.items||project.aiEditPlan?.items||[];
    const clips=items.filter(x=>x.clipPath);
    const ready=clips.length>0;
    res.json({projectId:project.id,ready,clipCount:clips.length,
      audioReady:Boolean(project.dialogueAudio||project.musicPath||project.audioMix),
      subtitlesReady:Boolean(project.subtitleFile||project.subtitles),
      message:ready?"Timeline has footage and can proceed to render.":"No rendered footage is available."});
  });
}
module.exports={registerEditRenderRoutes};
