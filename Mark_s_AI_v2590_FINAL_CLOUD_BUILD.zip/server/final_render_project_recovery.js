const path=require("path");
const {getProject}=require("./film_projects");
const {getProgress}=require("./final_render_progress");
const {recoverFinalRenderJobs}=require("./final_render_recovery");

async function restartProjectFinalRender(projectId,options={}){
  const project=getProject(path.join(process.cwd(),"projects"),projectId);
  if(!project)throw new Error("project not found");
  const progressId=project.smartOneClickFinalRender?.progressId;
  if(!progressId)throw new Error("no recoverable final render job for this project");
  const job=getProgress(progressId);
  if(!job)throw new Error("final render job not found");
  if(job.status==="recovering"||job.status==="running")return {status:"already_running",job};
  if(job.status==="recovery_exhausted")return {status:"recovery_exhausted",job};
  const results=await recoverFinalRenderJobs({outputDir:options.outputDir});
  const found=results.find(x=>x.jobId===progressId);
  return found||{status:"not_recovered",job};
}
module.exports={restartProjectFinalRender};
