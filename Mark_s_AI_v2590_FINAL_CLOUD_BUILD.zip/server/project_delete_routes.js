const fs=require("fs"),path=require("path");
function registerProjectDeleteRoutes(app){
 app.delete("/api/projects/:id",(req,res)=>{
  const file=path.join(process.cwd(),"projects",`${req.params.id}.json`);
  if(!fs.existsSync(file))return res.status(404).json({error:"project not found"});
  fs.unlinkSync(file);
  res.json({projectId:req.params.id,deleted:true});
 });
}
module.exports={registerProjectDeleteRoutes};
