const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerCanonicalTimelineReviewRoutes(app) {
  app.get("/api/projects/:id/timeline-review", (req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const t=Array.isArray(p.timeline)?p.timeline:[];
    res.json({
      projectId:p.id, source:p.timelineSource||null, appliedAt:p.timelineAppliedAt||null,
      count:t.length, reviewed:Boolean(p.timelineReview),
      review:p.timelineReview||null, timeline:t
    });
  });

  app.post("/api/projects/:id/timeline-review/start",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const t=Array.isArray(p.timeline)?p.timeline:[];
    if(!t.length)return res.status(409).json({error:"timeline is empty"});
    p.timelineReview={
      id:`timeline-review-${p.id}-${Date.now()}`,
      status:"in_review",
      startedAt:new Date().toISOString(),
      itemDecisions:t.map((x,i)=>({timelineId:x.id,index:i,status:"pending"}))
    };
    saveProject(dir,p);
    res.status(201).json(p.timelineReview);
  });
}
module.exports={registerCanonicalTimelineReviewRoutes};
