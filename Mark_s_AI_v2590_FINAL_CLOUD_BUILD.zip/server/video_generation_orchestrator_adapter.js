const orchestrator = require("./video_generation_orchestrator");

async function submitManifest(project, manifest, options = {}) {
  if (!orchestrator || typeof orchestrator.createOrchestratedRun !== "function") {
    throw new Error("createOrchestratedRun is not available");
  }

  // The existing orchestrator is job-building infrastructure. Feed it the
  // persisted project/manifest data without inventing provider results.
  const jobs = typeof orchestrator.buildOrchestratedJobs === "function"
    ? orchestrator.buildOrchestratedJobs(project, manifest.shots || [], options)
    : [];

  const run = await orchestrator.createOrchestratedRun(project, jobs, options);
  return {
    run,
    jobCount: Array.isArray(jobs) ? jobs.length : 0,
    submittedToProvider: Boolean(options.submitToProvider)
  };
}

module.exports = { submitManifest };
