const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function libraryFile(dir,id){return path.join(dir,`${id}.json`);}
function ensureLibrary(dir){fs.mkdirSync(dir,{recursive:true});return dir;}

function saveFilmRecord(dir,record={}){
  ensureLibrary(dir);
  const id=record.id||crypto.randomUUID();
  const item={id,title:record.title||"Untitled Film",
    outputPath:record.outputPath||"",duration:Number(record.duration||0),
    createdAt:record.createdAt||new Date().toISOString(),
    updatedAt:new Date().toISOString(),status:record.status||"completed",
    favourite:Boolean(record.favourite||false),description:record.description||"",
    thumbnailPath:record.thumbnailPath||"",
    genre:record.genre||"Other",style:record.style||"Cinematic",
    resolution:record.resolution||"1080p",aspectRatio:record.aspectRatio||"16:9"};
  fs.writeFileSync(libraryFile(dir,id),JSON.stringify(item,null,2));
  return item;
}
function listFilms(dir,options={}){
  const query=String(options.query||"").trim().toLowerCase();
  const genre=String(options.genre||"").trim().toLowerCase();
  const sort=String(options.sort||"newest").toLowerCase();

  ensureLibrary(dir);
  let items=fs.readdirSync(dir).filter(x=>x.endsWith(".json")).map(x=>{
    try{return JSON.parse(fs.readFileSync(path.join(dir,x),"utf8"));}catch{return null;}
  }).filter(Boolean);
  if(query)items=items.filter(x=>[x.title,x.description,x.genre,x.style].some(v=>String(v||"").toLowerCase().includes(query)));
  if(genre&&genre!=="all")items=items.filter(x=>String(x.genre||"").toLowerCase()===genre);
  items.sort((a,b)=>{
    if(sort==="oldest")return String(a.createdAt).localeCompare(String(b.createdAt));
    if(sort==="az")return String(a.title||"").localeCompare(String(b.title||""));
    if(sort==="za")return String(b.title||"").localeCompare(String(a.title||""));
    return String(b.updatedAt||b.createdAt).localeCompare(String(a.updatedAt||a.createdAt));
  });
  return items;
}
function updateFilmRecord(dir,id,patch={}){
  const p=libraryFile(dir,id);
  if(!fs.existsSync(p)) return null;
  const item=JSON.parse(fs.readFileSync(p,"utf8"));
  Object.assign(item,patch,{updatedAt:new Date().toISOString()});
  fs.writeFileSync(p,JSON.stringify(item,null,2));
  return item;
}
function getFilm(dir,id){
  const p=libraryFile(dir,id);
  if(!fs.existsSync(p)) return null;
  return JSON.parse(fs.readFileSync(p,"utf8"));
}
function updateFilm(dir,id,changes={}){
  const current=getFilm(dir,id);
  if(!current) return null;
  const next={...current};
  if(changes.title!==undefined) next.title=String(changes.title).trim()||"Untitled Film";
  if(changes.favourite!==undefined) next.favourite=Boolean(changes.favourite);
  if(changes.description!==undefined) next.description=String(changes.description);
  next.updatedAt=new Date().toISOString();
  fs.writeFileSync(libraryFile(dir,id),JSON.stringify(next,null,2));
  return next;
}
function deleteFilm(dir,id){
  const p=libraryFile(dir,id);
  if(!fs.existsSync(p)) return false;
  fs.unlinkSync(p); return true;
}
module.exports={ensureLibrary,saveFilmRecord,listFilms,getFilm,updateFilmRecord,deleteFilm};
