const path=require("path");
const {getJob,updateJob}=require("./final_render_job_store");
const DIR=path.join(process.cwd(),"final-render-jobs");

function addHistory(id,event,data={}){
  const job=getJob(DIR,id); if(!job)return null;
  const history=Array.isArray(job.history)?job.history:[];
  history.push({event,...data,at:new Date().toISOString()});
  return updateJob(DIR,id,{history});
}
function getHistory(id){
  const job=getJob(DIR,id); return job?{id:job.id,status:job.status,projectId:job.projectId,
    progress:job.progress,stage:job.stage,history:Array.isArray(job.history)?job.history:[],
    error:job.error||null,outputPath:job.outputPath||null,recoveryAttempts:Number(job.recoveryAttempts||0)}:null;
}
module.exports={addHistory,getHistory};
