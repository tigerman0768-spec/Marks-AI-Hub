const path=require("path");
const crypto=require("crypto");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");

function createReleaseRecord(project){
  const r=project.finalMasterReleaseReadiness;
  const receipt=project.finalMasterDeliveryReceipt;
  const manifest=project.finalMasterDeliveryManifest;
  const lock=project.finalMasterLock;
  const archive=project.finalMasterDeliveryArchive;
  if(!r?.ready)return {released:false,blockers:["final master is not release ready"]};
  if(!receipt||receipt.status!=="verified"||!manifest?.ready||!lock?.locked||!archive?.archiveId)
    return {released:false,blockers:["complete delivery evidence is required"]};
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))return {released:false,blockers:["final output file is missing"]};
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  if(sha!==manifest.sha256||sha!==receipt.sha256||sha!==lock.sha256||sha!==archive.sha256)
    return {released:false,blockers:["final output integrity evidence does not match"]};
  const record={
    releaseId:`release_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    filename:manifest.filename,bytes:fs.statSync(output).size,sha256:sha,
    releasedAt:new Date().toISOString(),status:"released"
  };
  project.finalMasterReleaseRecord=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {released:true,record};
}
module.exports={createReleaseRecord};
