const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {createOrchestratedRun}=require("./video_generation_orchestrator");
const {createRunwayVideoProvider}=require("./runway_video_provider");
const {executeProductionRun}=require("./provider_runner");
const {downloadCompletedClips}=require("./auto_clip_download");
const {inspectProjectClips}=require("./clip_quality_inspector");
const {reviewProjectClips}=require("./smart_clip_review");
const {checkProjectContinuity}=require("./clip_continuity_checker");
const {checkCinematicConsistency}=require("./cinematic_consistency_engine");
const {buildDirectorPass}=require("./film_level_ai_director");
const {buildFinalCutPlan}=require("./ai_final_cut_planner");

function registerVideoGenerationOrchestratorRoutes(app){
  app.get("/api/projects/:id/video-generation/readiness",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const project=getProject(dir,req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const scenes=Array.isArray(project.scenes)||(Array.isArray(project.screenplay?.scenes));
    const directed=Array.isArray(project.directorPlan)&&project.directorPlan.some(x=>(x.shots||[]).length);
    const cards=Array.isArray(project.shotCards)&&project.shotCards.length>0;
    const providerConfigured=!!(process.env.RUNWAY_API_KEY||process.env.RUNWAYML_API_SECRET);
    const ready=Boolean(scenes&&directed&&cards);
    res.json({
      projectId:project.id,ready,
      checks:{screenplay:scenes,directorPlan:directed,shotCards:cards,runwayConfigured:providerConfigured},
      mode:providerConfigured?"provider-ready":"dry-run-ready",
      message:ready
        ? (providerConfigured?"Production plan is ready for video generation.":"Production plan is ready for dry-run planning; configure Runway for real clips.")
        : "Complete the screenplay and production plan before video generation."
    });
  });


  app.post("/api/projects/:id/video-generation/orchestrate",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const run=createOrchestratedRun(project);
      if(!run.jobs.length)return res.status(400).json({error:"no directed shots available"});
      const maxRetries=Number(req.body?.maxRetries??2);
      const dryRun=Boolean(req.body?.dryRun);
      if(dryRun){
        saveProject(dir,{...project,videoGenerationRun:run,status:"video_generation_ready"});
        return res.json({projectId:project.id,run,dryRun:true});
      }
      if(!process.env.RUNWAY_API_KEY && !process.env.RUNWAYML_API_SECRET){
        saveProject(dir,{...project,videoGenerationRun:run,status:"video_generation_ready"});
        return res.status(503).json({error:"RUNWAY_API_KEY or RUNWAYML_API_SECRET is not configured",run});
      }
      saveProject(dir,{...project,videoGenerationRun:run,status:"video_generation_running"});
      const provider=createRunwayVideoProvider({
        apiKey:process.env.RUNWAY_API_KEY||process.env.RUNWAYML_API_SECRET
      });
      const completed=await executeProductionRun(run,provider,{maxRetries});
      let finalRun=completed;
      let downloadResults=[];
      if(completed.status==="completed"){
        const downloaded=await downloadCompletedClips(project,completed,{});
        finalRun={...completed,jobs:downloaded.jobs};
        downloadResults=downloaded.results;
        const qualityResults=await inspectProjectClips({...project,videoJobs:finalRun.jobs});
        finalRun={...finalRun,jobs:finalRun.jobs};
        for(const q of qualityResults){
          const job=finalRun.jobs.find(j=>j.id===q.jobId);
          if(job){job.qualityStatus=q.status;job.qualityReport=q;job.qualityCheckedAt=new Date().toISOString();}
        }
        const smartReviewResults=reviewProjectClips({...project,videoJobs:finalRun.jobs});
        for(const r of smartReviewResults){
          const job=finalRun.jobs.find(j=>j.id===r.jobId);
          if(job){job.smartReview={score:r.score,decision:r.decision,issues:r.issues,qualityStatus:r.qualityStatus};job.smartReviewAt=new Date().toISOString();}
        }
        const continuityReport=checkProjectContinuity({...project,videoJobs:finalRun.jobs});
        const cinematicConsistencyReport=checkCinematicConsistency({...project,videoJobs:finalRun.jobs});
        finalRun.continuityReport=continuityReport;
        finalRun.cinematicConsistencyReport=cinematicConsistencyReport;
        finalRun.directorPass=buildDirectorPass({...project,videoJobs:finalRun.jobs,continuityReport,cinematicConsistencyReport});
        finalRun.finalCutPlan=buildFinalCutPlan({...project,videoJobs:finalRun.jobs});
      }
      saveProject(dir,{...project,videoGenerationRun:finalRun,videoJobs:finalRun.jobs,status:finalRun.status==="completed"?"clips_downloaded":"video_generation_failed"});
      res.json({projectId:project.id,run:finalRun,downloadResults,continuityReport:finalRun.continuityReport,cinematicConsistencyReport:finalRun.cinematicConsistencyReport,directorPass:finalRun.directorPass,finalCutPlan:finalRun.finalCutPlan,
        qualityResults:finalRun.jobs.filter(j=>j.qualityReport).map(j=>({jobId:j.id,shotNumber:j.shotNumber,...j.qualityReport})),
        smartReviewResults:finalRun.jobs.filter(j=>j.smartReview).map(j=>({jobId:j.id,shotNumber:j.shotNumber,...j.smartReview}))});
    }catch(e){res.status(400).json({error:e.message});}
  });

  app.get("/api/projects/:id/video-generation/status",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const run=project.videoGenerationRun||null;
    res.json({projectId:project.id,status:run?.status||"not_started",run});
  });
}
module.exports={registerVideoGenerationOrchestratorRoutes};
