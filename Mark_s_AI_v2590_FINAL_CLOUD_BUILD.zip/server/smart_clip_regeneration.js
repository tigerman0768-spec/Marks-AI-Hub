const crypto=require("crypto");

function buildRegenerationJob(project,job,reason="smart review"){
  const source={...job};
  const id=crypto.randomUUID();
  return {
    id, projectId:project.id, sceneId:source.sceneId, shotNumber:source.shotNumber,
    provider:source.provider||"runway", duration:source.duration, aspectRatio:source.aspectRatio,
    prompt:source.prompt, status:"queued", attempts:0, regenerationOf:source.id,
    regenerationReason:reason, createdAt:new Date().toISOString()
  };
}
function queueSmartRegenerations(project={}){
  const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
  const additions=[];
  for(const job of jobs){
    if(job.downloadStatus!=="downloaded") continue;
    if(job.smartReview?.decision!=="regenerate") continue;
    if(job.regenerationQueued) continue;
    const replacement=buildRegenerationJob(project,job,
      (job.smartReview.issues||[]).join("; ")||"smart review score below threshold");
    job.regenerationQueued=true;
    job.regenerationJobId=replacement.id;
    additions.push(replacement);
  }
  project.videoJobs=[...jobs,...additions];
  return additions;
}
module.exports={buildRegenerationJob,queueSmartRegenerations};
