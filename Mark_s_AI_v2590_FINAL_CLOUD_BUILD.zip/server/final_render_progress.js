const path=require("path");
const {createJob,getJob,updateJob}=require("./final_render_job_store");
const {addHistory}=require("./final_render_job_history");
const {registerProcess,unregisterProcess}=require("./final_render_process_registry");
const dir=path.join(process.cwd(),"final-render-jobs");
function createProgress(projectId){
  const id=`final-${projectId}-${Date.now()}`;
  createJob(dir,{id,projectId,status:"running",stage:"starting",progress:0});
  return id;
}
function updateProgress(id,stage,progress,extra={}){
  const result=updateJob(dir,id,{stage,progress,...extra}); addHistory(id,stage,{progress,...extra}); return result;
}
function finishProgress(id,status,extra={}){
  const result=updateJob(dir,id,{stage:"complete",progress:100,status,...extra}); addHistory(id,"complete",{status,...extra}); return result;
}
function getProgress(id){return getJob(dir,id);}
module.exports={createProgress,updateProgress,finishProgress,getProgress,registerProcess,unregisterProcess};
