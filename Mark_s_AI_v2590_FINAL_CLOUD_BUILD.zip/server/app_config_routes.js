function registerAppConfigRoutes(app){
 app.get("/api/config",(req,res)=>res.json({
  service:"marks-ai",
  apiVersion:1,
  capabilities:{projects:true,screenplay:true,productionPlan:true,videoGeneration:true,editing:true,finishing:true,library:true},
  serverTime:new Date().toISOString()
 }));
}
module.exports={registerAppConfigRoutes};
