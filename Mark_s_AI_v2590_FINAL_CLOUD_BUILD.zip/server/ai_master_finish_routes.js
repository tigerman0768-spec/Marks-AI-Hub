const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {masterFilm}=require("./ai_master_finish");
function registerAiMasterFinishRoutes(app){
  app.post("/api/projects/:id/ai-master",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"), project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await masterFilm(project);
      saveProject(dir,{...project,aiMasterFinish:result,status:"ai_mastered"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/ai-master",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.aiMasterFinish||{outputPath:null});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiMasterFinishRoutes};
