const path=require("path");
const {getProject}=require("./film_projects");
const {createDeliveryReceipt}=require("./final_master_delivery_receipt");
function registerFinalMasterDeliveryReceiptRoutes(app){
  app.get("/api/projects/:id/final-render/delivery-receipt",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,receipt:p.finalMasterDeliveryReceipt||null});
  });
  app.post("/api/projects/:id/final-render/delivery-receipt/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createDeliveryReceipt(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterDeliveryReceiptRoutes};
