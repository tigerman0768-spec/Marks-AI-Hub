const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");
const {getRunwayTask,downloadRunwayOutput}=require("./runway_real_clip_provider");

async function processRegeneration(project,regenerationId){
  const regs=[...(project.realClipRegenerations||[])];
  const i=regs.findIndex(r=>String(r.regenerationId)===String(regenerationId));
  if(i<0)return {ready:false,blockers:["regeneration not found"]};
  const reg=regs[i];
  if(!reg.taskId)return {ready:false,blockers:["regeneration task id missing"]};
  const result=await getRunwayTask(reg.taskId);
  if(!result.ready)return result;
  const task=result.task||{};
  const state=String(task.status||"unknown").toUpperCase();
  if(state==="SUCCEEDED"&&Array.isArray(task.output)&&task.output[0]){
    const dir=path.join(process.cwd(),"projects",String(project.id),"video_generation","real_clips");
    fs.mkdirSync(dir,{recursive:true});
    const file=path.join(dir,`runway_regen_${regenerationId}.mp4`);
    if(!fs.existsSync(file))await downloadRunwayOutput(task.output[0],file);
    const stat=fs.statSync(file);
    const sha=crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
    const clip={
      clipId:`real_clip_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`,
      shotId:project.generatedRealClips?.find(c=>String(c.clipId)===String(reg.sourceClipId))?.shotId||null,
      provider:"runway",taskId:reg.taskId,outputPath:file,bytes:stat.size,sha256:sha,
      request:{prompt:reg.prompt,duration:reg.duration,aspectRatio:reg.aspectRatio},
      sourceRegenerationId:regenerationId,createdAt:new Date().toISOString(),status:"ready"
    };
    regs[i]={...reg,status:"downloaded",outputPath:file,bytes:stat.size,sha256:sha,completedAt:new Date().toISOString()};
    project.realClipRegenerations=regs;
    project.generatedRealClips=[...(project.generatedRealClips||[]),clip];
    saveProject(path.join(process.cwd(),"projects"),project);
    return {ready:true,state:"downloaded",clip,regeneration:regs[i]};
  }
  regs[i]={...reg,status:state.toLowerCase(),lastCheckedAt:new Date().toISOString()};
  project.realClipRegenerations=regs;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,state:state.toLowerCase(),regeneration:regs[i],task};
}
module.exports={processRegeneration};
