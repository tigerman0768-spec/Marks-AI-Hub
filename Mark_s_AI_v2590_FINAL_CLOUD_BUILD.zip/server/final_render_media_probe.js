const {spawn}=require("child_process");
function probeMedia(filePath,ffprobe="ffprobe"){
  return new Promise((resolve)=>{
    if(!filePath)return resolve({ok:false,error:"no output path"});
    const p=spawn(ffprobe,["-v","error","-show_entries","format=duration,size:stream=codec_name,codec_type,width,height","-of","json",filePath]);
    let out="",err="";p.stdout.on("data",d=>out+=d);p.stderr.on("data",d=>err+=d);
    p.on("error",e=>resolve({ok:false,error:e.message}));
    p.on("close",code=>{
      if(code!==0)return resolve({ok:false,error:err||`ffprobe exited ${code}`});
      try{
        const j=JSON.parse(out),f=j.format||{},streams=j.streams||[];
        const video=streams.find(s=>s.codec_type==="video")||null,audio=streams.find(s=>s.codec_type==="audio")||null;
        resolve({ok:true,duration:Number(f.duration||0),size:Number(f.size||0),video:video?{codec:video.codec_name,width:video.width||0,height:video.height||0}:null,audio:audio?{codec:audio.codec_name}:null});
      }catch(e){resolve({ok:false,error:e.message});}
    });
  });
}
module.exports={probeMedia};
