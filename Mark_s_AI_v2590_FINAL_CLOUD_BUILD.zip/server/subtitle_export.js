const fs=require("fs");
const {spawn}=require("child_process");

function buildSubtitleBurnArgs(videoPath,srtPath,outputPath,options={}){
  if(!videoPath||!fs.existsSync(videoPath)) throw new Error("video file unavailable");
  if(!srtPath||!fs.existsSync(srtPath)) throw new Error("subtitle file unavailable");
  if(!outputPath) throw new Error("outputPath required");
  const ffmpeg=options.ffmpeg||process.env.FFMPEG_BIN||"ffmpeg";
  const fontSize=Number(options.fontSize||22);
  const marginV=Number(options.marginV||36);
  const escaped=srtPath.replace(/\\/g,"\\\\").replace(/:/g,"\\:");
  const filter=`subtitles='${escaped}':force_style='FontSize=${fontSize},MarginV=${marginV},Alignment=2'`;
  return {ffmpeg,args:["-y","-i",videoPath,"-vf",filter,"-c:v","libx264","-preset",options.preset||"medium",
    "-crf",String(options.crf??18),"-c:a","copy","-movflags","+faststart",outputPath]};
}

async function burnSubtitles(config){
  const cmd=buildSubtitleBurnArgs(config.videoPath,config.srtPath,config.outputPath,config);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]});
    let err=""; child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`subtitle burn failed (${code}): ${err.slice(-1800)}`));
      if(!fs.existsSync(config.outputPath)||!fs.statSync(config.outputPath).size)
        return reject(new Error("subtitle output is empty"));
      resolve({outputPath:config.outputPath,bytes:fs.statSync(config.outputPath).size,
        fontSize:Number(config.fontSize||22)});
    });
  });
}
module.exports={buildSubtitleBurnArgs,burnSubtitles};
