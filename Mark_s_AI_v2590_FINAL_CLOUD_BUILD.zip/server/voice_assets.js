const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function ensureDir(dir){fs.mkdirSync(dir,{recursive:true});return dir;}
function createVoiceAssetRecord(job,outputUrl,assetsDir){
  if(!job||!outputUrl) throw new Error("voice job and outputUrl are required");
  const id=crypto.randomUUID();
  const ext=".mp3";
  const filename=`voice_${id}${ext}`;
  return {id,type:"dialogue",speaker:job.speaker,text:job.text,
    voice:job.voice,language:job.language,emotion:job.emotion,
    filmStart:Number(job.filmStart||0),duration:Number(job.duration||3),
    sourceUrl:outputUrl,localPath:path.join(ensureDir(assetsDir),filename),
    status:"remote_ready"};
}
function markVoiceDownloaded(asset,localPath){
  if(!asset||!localPath) throw new Error("asset and localPath are required");
  if(!fs.existsSync(localPath)||!fs.statSync(localPath).size) throw new Error("voice file is empty or missing");
  return {...asset,localPath,status:"stored",bytes:fs.statSync(localPath).size};
}
function attachVoiceAssets(scene,assets=[]){
  const byScene=assets.filter(a=>a.sceneId===scene.id||a.sceneId===String(scene.id||""));
  return {...scene,voiceAssets:byScene};
}
module.exports={ensureDir,createVoiceAssetRecord,markVoiceDownloaded,attachVoiceAssets};
