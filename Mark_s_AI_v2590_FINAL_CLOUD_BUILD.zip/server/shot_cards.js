function buildShotCards(project){
  const plans=project?.storyboard?.directorPlan||project?.directorPlan||[];
  return plans.flatMap(scene=> (scene.shots||[]).map(shot=>({
    id:shot.id,sceneId:scene.sceneId,sceneTitle:scene.sceneTitle,
    shotNumber:shot.shotNumber,shotType:shot.shotType,
    cameraMovement:shot.cameraMovement,purpose:shot.purpose,
    emotion:shot.emotion,lighting:shot.lighting,
    continuity:shot.continuity||{preserveCharacters:[],preserveLocation:"",wardrobe:"consistent"},
    prompt:[
      shot.shotType+" shot",shot.cameraMovement,shot.purpose,
      `emotion: ${shot.emotion}`,`lighting: ${shot.lighting}`,
      `characters: ${(shot.continuity?.preserveCharacters||[]).join(", ")}`,
      `location: ${shot.continuity?.preserveLocation||"consistent"}`,
      `wardrobe: ${shot.continuity?.wardrobe||"consistent"}`
    ].filter(Boolean).join(". ")
  })));
}
module.exports={buildShotCards};

function applyCinematicShotDirection(project, cards=[]){
  const plan=project.cinematicShotPlan||[];
  const map=new Map(plan.flatMap(s=>s.shots||[]).map(x=>[x.shotId,x]));
  return cards.map(card=>{
    const d=map.get(card.id);
    if(!d)return card;
    return {...card,cinematic:d,prompt:[card.prompt||"",d.promptAddendum].filter(Boolean).join(". ")};
  });
}
module.exports.applyCinematicShotDirection=applyCinematicShotDirection;
