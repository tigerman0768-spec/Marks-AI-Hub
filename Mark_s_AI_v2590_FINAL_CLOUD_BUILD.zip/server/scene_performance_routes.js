const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadDialogue}=require("./dialogue_timeline");
const {buildFilmPerformancePlan}=require("./scene_performance_director");

function registerScenePerformanceRoutes(app){
  app.post("/api/projects/:id/performance-director/generate",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const dialogue=loadDialogue(path.join(process.cwd(),"dialogue"),project.id).tracks||[];
      const directorPlan=project.directorPlan||[];
      const plan=buildFilmPerformancePlan(project,dialogue,directorPlan);
      saveProject(path.join(process.cwd(),"projects"),{...project,performancePlan:plan,status:"performance_ready"});
      res.json({projectId:project.id,performancePlan:plan,scenes:plan.length});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/performance-director",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json({projectId:project.id,performancePlan:project.performancePlan||[]});
  });
}
module.exports={registerScenePerformanceRoutes};
