const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {createCharacterBibleDraft}=require("./character_bible");
const {buildSceneBreakdown}=require("./storyboard");
const {buildShotCards}=require("./shot_cards");

function buildProductionPlan(project){
  if(!project) throw new Error("project not found");
  if(!project.screenplay || !Array.isArray(project.screenplay.scenes || project.scenes)){
    throw new Error("screenplay required");
  }
  const scenes=Array.isArray(project.screenplay.scenes) ? project.screenplay.scenes : project.scenes;
  const screenplay={...project.screenplay,scenes};
  const characterBible=createCharacterBibleDraft(project);
  const storyboard=buildSceneBreakdown({...project,screenplay,characters:characterBible.characters,scenes});
  const shotCards=buildShotCards({...project,storyboard:storyboard});
  return {characterBible,storyboard,shotCards};
}

function registerProductionPlanRoutes(app){
  app.get("/api/projects/:id/production-plan",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json({
        projectId:project.id,
        title:project.title,
        status:project.status,
        characterBible:project.characterBible||{characters:project.characters||[]},
        storyboard:{scenes:project.storyboard?.scenes||project.scenes||[],directorPlan:project.storyboard?.directorPlan||project.directorPlan||[]},
        shotCards:project.shotCards||[]
      });
    }catch(e){res.status(400).json({error:e.message});}
  });

  app.post("/api/projects/:id/build-production-plan",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildProductionPlan(project);
      const saved=saveProject(dir,{
        ...project,
        characterBible:plan.characterBible,
        storyboard:plan.storyboard,
        shotCards:plan.shotCards,
        status:"production_plan_ready"
      });
      res.status(201).json({project:saved,productionPlan:plan});
    }catch(e){
      res.status(400).json({error:e.message});
    }
  });
}
module.exports={buildProductionPlan,registerProductionPlanRoutes};
