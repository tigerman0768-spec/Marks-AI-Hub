const {handoffFinalRenderToLibrary}=require("./final_render_library_handoff");
function registerFinalRenderLibraryHandoffRoutes(app){
 app.post("/api/final-render/jobs/:id/library-handoff",async(req,res)=>{
  try{
   const x=await handoffFinalRenderToLibrary(req.params.id,{filmDir:req.body?.filmDir});
   if(!x)return res.status(404).json({error:"final render job not found"});
   if(x.status==="not_ready")return res.status(409).json(x);
   res.json(x);
  }catch(e){res.status(500).json({error:e.message});}
 });
}
module.exports={registerFinalRenderLibraryHandoffRoutes};
