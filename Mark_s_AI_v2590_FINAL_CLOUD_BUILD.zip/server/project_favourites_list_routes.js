const fs=require("fs"),path=require("path");
function registerProjectFavouritesListRoutes(app){
 app.get("/api/projects/favourites",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});
  const projects=fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"))}catch{return null}}).filter(Boolean).filter(p=>p.favourite===true);
  res.json({count:projects.length,projects:projects.map(p=>({id:p.id,title:p.title||"Untitled Film",status:p.status||"draft",genre:p.genre||"Drama",length:p.length||5}))});
 });
}
module.exports={registerProjectFavouritesListRoutes};
