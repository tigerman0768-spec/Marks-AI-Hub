const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function evaluateReleasedFilmDeliveryGate(project){
  const cat=project?.finalMasterReleaseCatalog;
  const rel=project?.finalMasterLibraryRelease;
  const rv=project?.finalMasterLibraryReleaseVerification;
  const exp=project?.finalMasterReleasedFilmDeliveryExport;
  const ev=project?.finalMasterReleasedFilmDeliveryExportVerification;
  const blockers=[];
  if(cat?.status!=="catalogued") blockers.push("release catalogue is not complete");
  if(rel?.status!=="ready_for_library") blockers.push("library release is not ready");
  if(!rv?.verified) blockers.push("library release verification has not passed");
  if(!exp?.exportId) blockers.push("delivery export is missing");
  if(!ev?.verified) blockers.push("delivery export verification has not passed");
  const output=exp?.outputPath||rel?.outputPath;
  if(!output||!fs.existsSync(output)) blockers.push("final film file is missing");
  let actualSha=null,bytes=0;
  if(output&&fs.existsSync(output)){
    bytes=fs.statSync(output).size;
    actualSha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
    if(ev?.sha256&&actualSha!==ev.sha256) blockers.push("current film hash differs from verified export");
  }
  const gate={
    gateId:`delivery_gate_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    ready:blockers.length===0,blockers,outputPath:output||null,bytes,sha256:actualSha,
    checkedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_gate");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"delivery_gate.json"),JSON.stringify(gate,null,2));
  project.finalMasterReleasedFilmDeliveryGate=gate;
  saveProject(path.join(process.cwd(),"projects"),project);
  return gate;
}
module.exports={evaluateReleasedFilmDeliveryGate};
