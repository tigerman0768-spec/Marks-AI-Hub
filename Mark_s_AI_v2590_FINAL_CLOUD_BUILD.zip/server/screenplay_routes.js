const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {createScreenplayDraft}=require("./screenplay_generator");
function registerScreenplayRoutes(app){
  app.post("/api/projects/:id/generate-screenplay",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const draft=createScreenplayDraft(project);
      const saved=saveProject(dir,{...project,screenplay:draft,scenes:draft.scenes,status:"screenplay_ready"});
      res.status(201).json({project:saved,screenplay:draft});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerScreenplayRoutes};
