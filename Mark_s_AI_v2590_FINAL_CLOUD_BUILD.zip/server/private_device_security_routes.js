const os = require('os');

function registerPrivateDeviceSecurityRoutes(app) {
  app.get('/api/private-device-security', (req, res) => {
    res.json({
      privateMode: true,
      appPurpose: 'personal',
      hostname: os.hostname(),
      platform: process.platform,
      nodeVersion: process.version,
      apiKeysConfigured: {
        openai: Boolean(process.env.OPENAI_API_KEY),
        runway: Boolean(process.env.RUNWAYML_API_SECRET),
        github: Boolean(process.env.GITHUB_TOKEN)
      },
      secretsExposed: false,
      note: 'Secret values are never returned by this endpoint.'
    });
  });
}

module.exports = { registerPrivateDeviceSecurityRoutes };
