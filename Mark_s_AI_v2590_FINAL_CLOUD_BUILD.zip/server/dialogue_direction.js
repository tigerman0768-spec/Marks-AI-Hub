function normaliseDialogue(dialogue = []) {
  return dialogue.map((d, i) => ({
    id: d.id || `dialogue-${i + 1}`,
    speaker: d.speaker || "Character",
    text: String(d.text || "").trim(),
    start: Math.max(0, Number(d.start || 0)),
    end: Math.max(Number(d.end || 0), Number(d.start || 0) + Math.max(1, Number(d.duration || 2))),
    emotion: d.emotion || "neutral",
    listener: d.listener || null
  }));
}

function buildInteractionDirection(dialogue = []) {
  const lines = normaliseDialogue(dialogue);
  return lines.map((line, i) => {
    const next = lines[i + 1];
    const interaction = next && next.speaker !== line.speaker
      ? `respond naturally to ${next.speaker}`
      : "maintain conversational continuity";
    return {
      ...line,
      direction: [
        `speaker: ${line.speaker}`,
        `emotion: ${line.emotion}`,
        interaction,
        line.listener ? `address ${line.listener}` : ""
      ].filter(Boolean).join(", ")
    };
  });
}

function buildLipSyncPlan(dialogue = [], options = {}) {
  const lines = buildInteractionDirection(dialogue);
  return {
    language: options.language || "en-GB",
    mode: options.mode || "provider-assisted",
    cues: lines.map(line => ({
      dialogueId: line.id,
      speaker: line.speaker,
      start: line.start,
      end: line.end,
      text: line.text,
      actingDirection: line.direction
    }))
  };
}

function applyDialogueDirection(jobs = [], scenes = []) {
  const map = new Map(scenes.map(s => [s.id, s]));
  return jobs.map(job => {
    const scene = map.get(job.sceneId) || {};
    const plan = buildLipSyncPlan(scene.dialogue || {}, {
      language: scene.language || "en-GB"
    });
    const dialogue = Array.isArray(scene.dialogue) ? scene.dialogue : [];
    const direction = buildInteractionDirection(dialogue)
      .map(x => x.direction).join(". ");
    return {
      ...job,
      dialoguePlan: plan,
      prompt: `${job.prompt}. Dialogue performance: ${direction || "synchronise mouth movement naturally to the generated dialogue."} Ensure speaker turns and reactions are visually clear.`
    };
  });
}

module.exports = { normaliseDialogue, buildInteractionDirection, buildLipSyncPlan, applyDialogueDirection };
