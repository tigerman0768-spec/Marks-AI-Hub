const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
const {loadDialogue}=require("./dialogue_timeline");
const {writeDialogueSrt}=require("./dialogue_subtitles");

function registerFinalAudioSubtitleRoutes(app){
  app.get("/api/projects/:id/final-audio-status",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const dialogue=loadDialogue(path.join(process.cwd(),"dialogue"),p.id);
    const tracks=dialogue.tracks||p.dialogueTracks||[];
    res.json({projectId:p.id,dialogueTracks:tracks.length,
      musicConfigured:Boolean(p.musicPath||p.backgroundMusicPath),
      sfxConfigured:Boolean(p.sfxPath),
      subtitlesConfigured:Boolean(p.subtitleFile||p.subtitles),
      audioReady:Boolean(tracks.length||p.musicPath||p.backgroundMusicPath||p.sfxPath)});
  });

  app.post("/api/projects/:id/subtitles/build",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const p=getProject(dir,req.params.id);
      if(!p)return res.status(404).json({error:"project not found"});
      const screenplay=p.screenplay||{};
      const scenes=screenplay.scenes||p.scenes||[];
      const output=path.join(process.cwd(),"subtitles",`${p.id}.srt`);
      const result=writeDialogueSrt(scenes,output);
      const saved=saveProject(dir,{...p,subtitleFile:result.outputPath,subtitleCues:result.cues,status:"subtitles_ready"});
      res.json({projectId:p.id,...result,status:saved.status});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalAudioSubtitleRoutes};
