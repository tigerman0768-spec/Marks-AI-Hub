const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
function existsFile(p){return Boolean(p&&fs.existsSync(p)&&fs.statSync(p).size>0);}
function registerFinalMasterReadinessRoutes(app){
  app.get("/api/projects/:id/final-master/readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const source=p.finalTimeline?.outputPath||p.finalCutRender?.outputPath||null;
    const subtitle=p.subtitleFile||null;
    const dialogue=(p.dialogueTracks||[]).length;
    const ready={
      sourceVideo:existsFile(source),
      finishingPlan:Boolean(p.finalFinishingPlan),
      subtitles:!subtitle||existsFile(subtitle),
      dialogueConfigured:dialogue>0,
      renderQueueAvailable:true
    };
    res.json({projectId:p.id,ready:Boolean(ready.sourceVideo&&ready.finishingPlan&&ready.subtitles),
      checks:ready});
  });
}
module.exports={registerFinalMasterReadinessRoutes};
