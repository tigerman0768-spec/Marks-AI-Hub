const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function probeDuration(file){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffprobe",["-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",file]);
    let out="",err=""; p.stdout.on("data",d=>out+=d); p.stderr.on("data",d=>err+=d);
    p.on("close",code=>code===0&&Number(out)>0?resolve(Number(out)):reject(new Error(err||"ffprobe failed")));
  });
}
function renderTrimmedClip(item,outPath){
  return new Promise((resolve,reject)=>{
    const source=Number(item.sourceDuration||item.duration||0);
    const target=Number(item.targetDuration||item.duration||0);
    const start=Math.max(0,Number(item.trimStart||0));
    const max=Math.max(0,source-start);
    const duration=Math.min(Math.max(0.1,target),max||target);
    const args=["-y","-ss",String(start),"-i",item.clipPath,"-t",String(duration),
      "-c:v","libx264","-preset","veryfast","-crf","18","-c:a","aac","-movflags","+faststart",outPath];
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});
    let err=""; p.stderr.on("data",d=>err+=d);
    p.on("close",code=>code===0?resolve({path:outPath,duration}):reject(new Error(err.slice(-2000))));
  });
}
async function renderAiEditedTimeline(project,options={}){
  const items=project.editingDecisions?.items||[];
  if(!items.length)throw new Error("no editing decisions available");
  const outputDir=options.outputDir||path.join(process.cwd(),"assets","edited-clips",project.id);
  fs.mkdirSync(outputDir,{recursive:true});
  const rendered=[];
  for(const item of items){
    if(!item.clipPath||!fs.existsSync(item.clipPath))continue;
    const out=path.join(outputDir,`${item.order}-${item.jobId||"shot"}.mp4`);
    const r=await renderTrimmedClip(item,out);
    rendered.push({...item,originalClipPath:item.clipPath,clipPath:out,renderedDuration:r.duration,trimApplied:true});
  }
  return {projectId:project.id,items:rendered,renderedCount:rendered.length,
    totalDuration:rendered.reduce((n,x)=>n+Number(x.renderedDuration||0),0),
    createdAt:new Date().toISOString(),engine:"ai-timeline-trim-renderer"};
}
module.exports={renderAiEditedTimeline,renderTrimmedClip,probeDuration};
