const fs=require("fs"),path=require("path");
function registerProjectDuplicateRoutes(app){
 app.post("/api/projects/:id/duplicate",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");const src=path.join(dir,`${req.params.id}.json`);
  if(!fs.existsSync(src))return res.status(404).json({error:"project not found"});
  const p=JSON.parse(fs.readFileSync(src,"utf8"));const id=`${p.id}-copy-${Date.now()}`;
  const copy={...p,id,title:`${p.title||"Untitled Film"} (Copy)`,status:"draft",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
  fs.writeFileSync(path.join(dir,`${id}.json`),JSON.stringify(copy,null,2));res.status(201).json({projectId:id,title:copy.title,status:copy.status});
 });
}
module.exports={registerProjectDuplicateRoutes};
