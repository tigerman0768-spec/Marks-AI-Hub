const path=require("path");
const {getProject}=require("./film_projects");
const {loadProjectAudio,editProjectAudio}=require("./timeline_audio_editor");
function registerTimelineAudioEditorRoutes(app){
  const dir=path.join(process.cwd(),"timeline-audio");
  app.get("/api/projects/:id/timeline/audio",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(loadProjectAudio(dir,p.id));
  });
  app.patch("/api/projects/:id/timeline/audio",(req,res)=>{
    try{
      const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!p)return res.status(404).json({error:"project not found"});
      res.json(editProjectAudio(dir,p.id,req.body?.action,req.body||{}));
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerTimelineAudioEditorRoutes};
