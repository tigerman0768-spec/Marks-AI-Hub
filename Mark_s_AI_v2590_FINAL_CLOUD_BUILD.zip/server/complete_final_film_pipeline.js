const fs=require("fs");
const path=require("path");
const {renderAiTransitions}=require("./ai_transition_renderer");
const {professionalDuck}=require("./professional_audio_ducking");
const {getProject,saveProject}=require("./film_projects");
const {spawn}=require("child_process");

function run(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});let err="";
    p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-5000))));
  });
}
function file(v){return typeof v==="string"&&fs.existsSync(v)?v:null;}
function subtitle(project){
  return file(project.subtitleFile)||file(project.subtitles?.path)||file(project.subtitleExport?.path);
}
async function completeFinalFilm(project={},options={}){
  const dir=options.outputDir||path.join(process.cwd(),"output");fs.mkdirSync(dir,{recursive:true});
  const transition=await renderAiTransitions(project,{outputPath:path.join(dir,`${project.id}-pipeline-video.mp4`)});
  const staged={...project,aiTransitionRender:transition};
  const ducked=await professionalDuck(staged,{outputPath:path.join(dir,`${project.id}-pipeline-audio.mp4`)});
  const sub=subtitle(project), source=ducked.outputPath;
  const finalPath=options.outputPath||path.join(dir,`${project.id}-FINAL-FILM.mp4`);
  if(sub){
    const escaped=sub.replace(/\\/g,"/").replace(/'/g,"\\\\'");
    await run(["-y","-i",source,"-vf",`subtitles=${escaped}`,"-c:v","libx264","-preset","veryfast","-crf","18",
      "-c:a","copy","-movflags","+faststart",finalPath]);
  }else fs.copyFileSync(source,finalPath);
  return {projectId:project.id,outputPath:finalPath,
    stages:{transitions:true,audioDucking:!!ducked.duckingApplied,subtitles:!!sub,
      finalMaster:true},duckWindows:ducked.duckWindows||0,createdAt:new Date().toISOString(),
    engine:"complete-final-film-pipeline"};
}
function registerCompleteFinalFilmRoutes(app){
  app.post("/api/projects/:id/complete-final-film",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await completeFinalFilm(project);
      saveProject(dir,{...project,completeFinalFilm:result,status:"final_film_ready"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/complete-final-film",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.completeFinalFilm||{outputPath:null});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={completeFinalFilm,registerCompleteFinalFilmRoutes};
