const ACTING = {
  happy: { expression:"warm genuine smile", body:"open relaxed posture", gesture:"natural light gestures", energy:"upbeat" },
  sad: { expression:"subtle sadness, watery eyes", body:"slightly lowered posture", gesture:"minimal restrained movement", energy:"low" },
  angry: { expression:"controlled anger", body:"tense posture", gesture:"firm deliberate gestures", energy:"high" },
  afraid: { expression:"fear and alertness", body:"tense defensive posture", gesture:"small cautious movements", energy:"high" },
  surprised: { expression:"authentic surprise", body:"brief recoil then focus", gesture:"quick reaction", energy:"medium-high" },
  nervous: { expression:"uncertain nervous expression", body:"slightly tense posture", gesture:"small fidgeting movements", energy:"medium" },
  romantic: { expression:"soft affectionate expression", body:"relaxed close posture", gesture:"gentle natural movement", energy:"low" },
  neutral: { expression:"natural neutral expression", body:"relaxed posture", gesture:"subtle realistic movement", energy:"medium" }
};

function getActingDirection(scene = {}) {
  const key = String(scene.emotion || scene.mood || "neutral").toLowerCase();
  const selected = Object.keys(ACTING).find(k => key.includes(k)) || "neutral";
  const a = ACTING[selected];
  return {
    emotion: selected,
    ...a,
    direction: `${a.expression}; ${a.body}; ${a.gesture}; ${a.energy} performance energy`
  };
}

function applyActingDirection(jobs = [], scenes = []) {
  const map = new Map(scenes.map(s => [s.id, s]));
  return jobs.map(job => {
    const acting = getActingDirection(map.get(job.sceneId) || {});
    return {
      ...job,
      acting,
      prompt: `${job.prompt}. Character acting: ${acting.direction}. Keep performance natural and consistent across shots.`
    };
  });
}

module.exports = { getActingDirection, applyActingDirection };
