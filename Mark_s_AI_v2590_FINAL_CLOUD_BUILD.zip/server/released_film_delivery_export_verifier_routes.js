const path=require("path");
const {getProject}=require("./film_projects");
const {verifyReleasedFilmDeliveryExport}=require("./released_film_delivery_export_verifier");

function registerReleasedFilmDeliveryExportVerifierRoutes(app){
  app.get("/api/projects/:id/final-render/library-release/delivery-export/verification",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,verification:p.finalMasterReleasedFilmDeliveryExportVerification||null});
  });
  app.post("/api/projects/:id/final-render/library-release/delivery-export/verify",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=verifyReleasedFilmDeliveryExport(p);
    res.status(result.verified?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliveryExportVerifierRoutes};
