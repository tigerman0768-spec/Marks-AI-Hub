const path=require("path");
const {getProject}=require("./film_projects");
const {evaluateReleasedFilmDeliveryGate}=require("./released_film_delivery_final_gate");
function registerReleasedFilmDeliveryFinalGateRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-gate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,gate:p.finalMasterReleasedFilmDeliveryGate||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-gate/check",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const gate=evaluateReleasedFilmDeliveryGate(p);
    res.status(gate.ready?200:409).json({projectId:p.id,gate});
  });
}
module.exports={registerReleasedFilmDeliveryFinalGateRoutes};
