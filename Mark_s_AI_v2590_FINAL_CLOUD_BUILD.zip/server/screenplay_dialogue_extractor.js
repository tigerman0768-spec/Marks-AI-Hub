const crypto=require("crypto");

function cleanCharacter(value="Speaker"){
  return String(value||"Speaker").replace(/\s+/g," ").trim().slice(0,120)||"Speaker";
}
function extractFromScenes(scenes=[]){
  const tracks=[];
  for(let si=0;si<scenes.length;si++){
    const scene=scenes[si]||{};
    const sceneId=scene.id||`scene-${si+1}`;
    const source=String(scene.dialogue||scene.script||scene.action||"");
    const lines=source.split(/\r?\n/);
    for(let i=0;i<lines.length;i++){
      const line=lines[i].trim();
      const m=line.match(/^([A-Z][A-Z0-9 ._'’-]{1,60})\s*:\s*(.+)$/);
      if(!m)continue;
      const text=m[2].trim();
      if(!text)continue;
      tracks.push({
        id:crypto.randomUUID(),
        sceneId,
        character:cleanCharacter(m[1]),
        text,
        audioPath:"",
        start:0,
        duration:0,
        volume:1,
        duckMusic:true,
        duckLevel:.25,
        voice:"",
        instructions:"",
        source:"screenplay",
        order:tracks.length
      });
    }
  }
  return tracks;
}
function extractFromScreenplayText(text=""){
  const scenes=[];
  let current={id:"scene-1",script:""};
  String(text).split(/\r?\n/).forEach(line=>{
    const t=line.trim();
    if(/^SCENE\s+\d+/i.test(t)){
      if(current.script)scenes.push(current);
      current={id:`scene-${scenes.length+1}`,script:""};
    }else current.script+=line+"\n";
  });
  if(current.script)scenes.push(current);
  return extractFromScenes(scenes);
}
function extractDialogue(project={}){
  const existing=project.dialogueTracks||project.dialogue?.tracks||[];
  if(existing.length)return existing;
  if(Array.isArray(project.scenes)&&project.scenes.length)return extractFromScenes(project.scenes);
  return extractFromScreenplayText(project.screenplay||"");
}
module.exports={extractDialogue,extractFromScenes,extractFromScreenplayText};
