const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {verifyFinalRenderProject}=require("./final_render_verification");

async function evaluateFinalMasterGate(project){
  const result=await verifyFinalRenderProject(project);
  const q=project.finalRenderQueueRecord||{};
  const gate={
    projectId:project.id,
    outputVerified:result.verified===true,
    mediaVerified:q.mediaVerified===true,
    finalRenderReady:project.finalRenderReady===true,
    status:q.status||"not_queued",
    stage:q.stage||"waiting",
    duration:Number(q.mediaMetadata?.duration||0),
    width:Number(q.mediaMetadata?.video?.width||0),
    height:Number(q.mediaMetadata?.video?.height||0),
    codec:q.mediaMetadata?.video?.codec||null,
    blockers:[]
  };
  if(!gate.outputVerified)gate.blockers.push(result.error||"final output is not verified");
  if(!gate.mediaVerified)gate.blockers.push("media verification has not passed");
  if(!gate.duration)gate.blockers.push("duration is missing");
  if(!gate.width||!gate.height)gate.blockers.push("video dimensions are missing");
  gate.ready=gate.blockers.length===0;
  project.finalMasterGate=gate;
  project.finalRenderReady=gate.ready;
  if(gate.ready){q.status="completed";q.stage="master_ready";q.progress=100;}
  saveProject(path.join(process.cwd(),"projects"),project);
  return gate;
}
module.exports={evaluateFinalMasterGate};
