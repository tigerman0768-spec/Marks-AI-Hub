const fs=require("fs");
const path=require("path");
const {getProject}=require("./film_projects");

function getReleaseCatalogue(projectId){
  const p=getProject(path.join(process.cwd(),"projects"),projectId);
  if(!p)return {found:false,error:"project not found"};
  const film=p.approvedFilmLibraryFilm||null;
  const e=p.approvedFilmExport||null;
  const d=p.approvedFilmDelivery||null;
  const l=p.approvedFilmDeliveryLock||null;
  const s=p.approvedFilmReleaseSnapshot||null;
  return {
    found:true,projectId:p.id,title:p.title||"Untitled Film",
    stages:{
      library:!!film,
      export:!!e,
      delivery:!!d,
      deliveryVerified:!!d&&!!l,
      deliveryLocked:!!l,
      releaseSnapshot:!!s
    },
    film:film?{filmId:film.filmId,duration:film.duration,clipCount:film.clipCount,bytes:film.bytes,sha256:film.sha256}:null,
    export:e?{exportId:e.exportId,bytes:e.bytes,sha256:e.sha256}:null,
    delivery:d?{deliveryId:d.deliveryId,bytes:d.bytes,sha256:d.sha256}:null,
    lock:l?{lockId:l.lockId,bytes:l.bytes,sha256:l.sha256,lockedAt:l.lockedAt}:null,
    snapshot:s?{snapshotId:s.snapshotId,bytes:s.bytes,sha256:s.sha256,createdAt:s.createdAt}:null
  };
}
module.exports={getReleaseCatalogue};
