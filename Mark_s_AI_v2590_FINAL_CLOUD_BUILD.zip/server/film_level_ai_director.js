function clamp(n){return Math.max(0,Math.min(100,Math.round(n)));}
function buildDirectorPass(project={}){
  const jobs=(project.videoJobs||[]).filter(j=>j.downloadStatus==="downloaded");
  const quality=jobs.length?jobs.reduce((n,j)=>n+Number(j.qualityReport?.valid?100:60),0)/jobs.length:100;
  const smart=jobs.length?jobs.reduce((n,j)=>n+Number(j.smartReview?.score??70),0)/jobs.length:70;
  const continuity=Number(project.continuityReport?.score??100);
  const cinematic=Number(project.cinematicConsistencyReport?.score??100);
  const overall=clamp(quality*.2+smart*.3+continuity*.2+cinematic*.3);
  const notes=[];
  if(smart<80)notes.push("Review lower-scoring clips before final edit.");
  if(continuity<85)notes.push("Resolve shot-to-shot continuity mismatches.");
  if(cinematic<85)notes.push("Resolve cinematic direction mismatches.");
  const regenerate=jobs.filter(j=>
    j.smartReview?.decision==="regenerate" ||
    Number(j.smartReview?.score??100)<60 ||
    j.qualityStatus==="failed");
  return {projectId:project.id,overallScore:overall,grade:overall>=90?"A":overall>=80?"B":overall>=70?"C":"D",
    clipCount:jobs.length,regenerationCandidates:regenerate.map(j=>({jobId:j.id,shotNumber:j.shotNumber,reason:j.smartReview?.issues||[]})),
    notes,readyForEdit:regenerate.length===0&&overall>=75,
    generatedAt:new Date().toISOString()};
}
module.exports={buildDirectorPass};
