const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function registerFinalCutReadinessRoutes(app){
  app.get("/api/projects/:id/final-cut/readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const timeline=Array.isArray(p.timeline)?p.timeline:[];
    const files=timeline.filter(x=>x.sourcePath&&fs.existsSync(x.sourcePath)).length;
    const checks={
      timeline:Boolean(p.timelineReviewReady&&timeline.length),
      sourceFiles:files===timeline.length,
      timelineReview:p.timelineReview?.status==="finalized",
      editTimeline:Boolean(p.timelineAppliedAt)
    };
    res.json({projectId:p.id,ready:Object.values(checks).every(Boolean),checks,
      itemCount:timeline.length,availableFiles:files});
  });
}
module.exports={registerFinalCutReadinessRoutes};
