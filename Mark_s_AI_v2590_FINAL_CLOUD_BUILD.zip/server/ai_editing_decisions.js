function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
function decideEdit(item={},analysis={}){
  const source=Number(item.duration||analysis.sourceDuration||analysis.recommendedHold||3);
  const type=analysis.contentType||"general";
  let target=analysis.recommendedHold||2.4;
  if(type==="action") target=1.6;
  if(type==="dialogue") target=2.4;
  if(type==="establishing") target=3.5;
  if(type==="emotional") target=3.0;
  target=clamp(Math.min(source,target),0.8,source);
  let reason="balanced cinematic pacing";
  if(type==="action")reason="shorter cuts increase action energy";
  else if(type==="dialogue")reason="dialogue pacing keeps attention on performance";
  else if(type==="establishing")reason="longer hold establishes geography";
  else if(type==="emotional")reason="slightly longer hold supports emotion";
  return {targetDuration:Number(target.toFixed(2)),trimStart:0,
    trimEnd:Number(Math.max(0,source-target).toFixed(2)),
    reason,pacingBeat:type};
}
function buildEditingDecisions(project={}){
  const analyses=Object.fromEntries((project.shotContentAnalysis?.items||[]).map(x=>[x.jobId,x.analysis||{}]));
  const base=project.aiEditPlan?.items||project.finalTimeline?.items||project.finalCutPlan?.items||[];
  const items=base.filter(x=>x.clipPath).map((item,i)=>{
    const a=analyses[item.jobId]||{};
    const d=decideEdit(item,a);
    return {...item,...d,order:i+1,sourceDuration:Number(item.duration||a.sourceDuration||0)};
  });
  return {projectId:project.id,items,createdAt:new Date().toISOString(),
    engine:"ai-editing-decisions",readyToRender:items.length>0};
}
module.exports={decideEdit,buildEditingDecisions};
