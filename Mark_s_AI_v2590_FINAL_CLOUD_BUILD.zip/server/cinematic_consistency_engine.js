function norm(v){return String(v??"").trim().toLowerCase();}
function compareField(a,b,field){
  const x=norm(a?.[field]),y=norm(b?.[field]);
  if(!x||!y)return {field,status:"unknown",match:true};
  return {field,status:x===y?"match":"mismatch",match:x===y,from:x,to:y};
}
function getCinematic(job={}){
  return job.cinematic||job.cinematicDirection||job.cinematicShotDirection||{};
}
function compareCinematic(a,b){
  const ca=getCinematic(a),cb=getCinematic(b);
  const fields=["framing","lens","movement","lighting","composition","depth"];
  const checks=fields.map(f=>compareField(ca,cb,f));
  const mismatches=checks.filter(x=>x.status==="mismatch");
  return {fromJobId:a?.id,toJobId:b?.id,score:Math.max(0,100-mismatches.length*14),
    consistent:mismatches.length===0,checks,mismatches};
}
function checkCinematicConsistency(project={}){
  const jobs=(project.videoJobs||[]).filter(j=>j.downloadStatus==="downloaded");
  const ordered=[...jobs].sort((a,b)=>String(a.sceneId).localeCompare(String(b.sceneId))||Number(a.shotNumber||0)-Number(b.shotNumber||0));
  const pairs=[];
  for(let i=1;i<ordered.length;i++)pairs.push(compareCinematic(ordered[i-1],ordered[i]));
  const score=pairs.length?Math.round(pairs.reduce((n,p)=>n+p.score,0)/pairs.length):100;
  return {projectId:project.id,score,consistent:pairs.every(p=>p.consistent),pairs,
    recommendations:pairs.filter(p=>!p.consistent).map(p=>`Review cinematic mismatch between ${p.fromJobId} and ${p.toJobId}`)};
}
module.exports={compareCinematic,checkCinematicConsistency};
