const path=require("path");
const {getProject}=require("./film_projects");
const {verifyArchive}=require("./final_master_archive_verify");

async function evaluateReleaseReadiness(project){
  const blockers=[];
  const gate=project.finalMasterGate||{};
  const receipt=project.finalMasterDeliveryReceipt||{};
  const manifest=project.finalMasterDeliveryManifest||{};
  const lock=project.finalMasterLock||{};
  const archive=project.finalMasterDeliveryArchive||{};
  if(!gate.ready)blockers.push("final master gate has not passed");
  if(receipt.status!=="verified")blockers.push("delivery receipt is not verified");
  if(!manifest.ready)blockers.push("delivery manifest is not ready");
  if(!lock.locked)blockers.push("final master is not locked");
  if(!archive.archiveId)blockers.push("delivery archive is missing");
  const verification=archive.archiveId?await verifyArchive(project):null;
  if(!verification?.verified)blockers.push("delivery archive integrity has not passed");
  const ready=blockers.length===0;
  project.finalMasterReleaseReadiness={
    ready,projectId:project.id,title:project.title||"Untitled Film",
    checkedAt:new Date().toISOString(),blockers,
    evidence:{gate:gate.ready===true,receipt:receipt.status==="verified",
      manifest:manifest.ready===true,lock:lock.locked===true,
      archive:Boolean(archive.archiveId),archiveVerified:verification?.verified===true}
  };
  require("./film_projects").saveProject(path.join(process.cwd(),"projects"),project);
  return project.finalMasterReleaseReadiness;
}
module.exports={evaluateReleaseReadiness};
