const path = require("path");
const fs = require("fs");
const { getProject } = require("./film_projects");

function registerGeneratedClipReviewSummaryRoutes(app) {
  app.get("/api/projects/:id/generated-clips/review-summary", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const set = p.clipReviewSet || { clips: [] };
    const clips = Array.isArray(set.clips) ? set.clips : [];
    const counts = { pending: 0, accepted: 0, rejected: 0, needs_regeneration: 0, missing: 0 };
    for (const c of clips) {
      const exists = Boolean(c.path && fs.existsSync(c.path));
      if (!exists) counts.missing++;
      const s = counts[c.reviewStatus] !== undefined ? c.reviewStatus : "pending";
      counts[s]++;
    }
    const reviewed = counts.accepted + counts.rejected + counts.needs_regeneration;
    res.json({
      projectId: p.id,
      reviewSetId: p.clipReviewSet?.id || null,
      total: clips.length,
      reviewed,
      pending: counts.pending,
      accepted: counts.accepted,
      rejected: counts.rejected,
      needsRegeneration: counts.needs_regeneration,
      missing: counts.missing,
      readyForEdit: clips.length > 0 && counts.pending === 0 && counts.missing === 0 && counts.accepted > 0,
      counts
    });
  });
}
module.exports = { registerGeneratedClipReviewSummaryRoutes };
