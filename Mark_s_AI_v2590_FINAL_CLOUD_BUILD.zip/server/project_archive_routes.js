const fs=require("fs");
const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectArchiveRoutes(app){
  app.post("/api/projects/:id/archive",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const dir=path.join(process.cwd(),"project-archives");fs.mkdirSync(dir,{recursive:true});
    const record={...p,status:"archived",archivedAt:new Date().toISOString()};
    const file=path.join(dir,`${p.id}.json`);fs.writeFileSync(file,JSON.stringify(record,null,2));
    res.json({projectId:p.id,status:"archived",archivePath:file,archivedAt:record.archivedAt});
  });
  app.delete("/api/projects/:id/archive",(req,res)=>{
    const file=path.join(process.cwd(),"project-archives",`${req.params.id}.json`);
    if(!fs.existsSync(file))return res.status(404).json({error:"archive not found"});
    fs.unlinkSync(file);res.json({projectId:req.params.id,status:"archive_deleted"});
  });
}
module.exports={registerProjectArchiveRoutes};
