function summariseRun(run={}){
  const jobs=Array.isArray(run.jobs)?run.jobs:[];
  const counts={queued:0,generating:0,waiting:0,retrying:0,completed:0,failed:0};
  for(const job of jobs) counts[job.status] = (counts[job.status]||0)+1;
  const total=jobs.length;
  const finished=counts.completed+counts.failed;
  return {
    id:run.id||null,projectId:run.projectId||null,status:run.status||"not_started",
    total,finished,progress:total?Math.round((finished/total)*100):0,
    counts,
    current:jobs.find(j=>["generating","waiting","retrying"].includes(j.status))||null,
    jobs:jobs.map(j=>({
      id:j.id,sceneId:j.sceneId,shotNumber:j.shotNumber,status:j.status,
      attempts:Number(j.attempts||0),providerTaskId:j.providerTaskId||null,
      error:j.error||null,output:j.output||null
    }))
  };
}
module.exports={summariseRun};
