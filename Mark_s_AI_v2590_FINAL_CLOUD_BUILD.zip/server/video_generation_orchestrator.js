const crypto=require("crypto");
const {buildVideoGenerationJobs,createVideoGenerationRun}=require("./video_generation");

function buildOrchestratedJobs(project={}){
  const directorShots=(project.directorPlan||[]).flatMap(s=>s.shots||[]);
  const promptMap=new Map((project.videoPromptPlan||[]).map(x=>[x.shotId,x.prompt]));
  const jobs=buildVideoGenerationJobs(project,directorShots);
  return jobs.map(job=>{
    const prompt=promptMap.get(job.id)||promptMap.get(
      directorShots.find(s=>s.sceneId===job.sceneId&&s.shotNumber===job.shotNumber)?.id
    );
    return prompt?{...job,prompt,orchestrated:true}:job;
  });
}

function createOrchestratedRun(project={}){
  const jobs=buildOrchestratedJobs(project);
  const run=createVideoGenerationRun(project,jobs);
  run.id=crypto.randomUUID();
  run.projectId=project.id;
  run.mode="ai-video-orchestrated";
  run.createdAt=new Date().toISOString();
  run.total=jobs.length;
  run.completed=jobs.filter(x=>x.status==="completed").length;
  run.failed=jobs.filter(x=>x.status==="failed").length;
  return run;
}
module.exports={buildOrchestratedJobs,createOrchestratedRun};
