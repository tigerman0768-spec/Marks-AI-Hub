const path=require("path");
const {getProject}=require("./film_projects");
const {enqueueFinalRender}=require("./final_render_worker_queue");

function registerFinalCutRenderLaunchRoutes(app){
  app.post("/api/projects/:id/final-cut-render/queue",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const items=project.finalTimeline?.items||project.finalCutPlan?.items||[];
      const clips=items.filter(x=>x.clipPath);
      if(!clips.length)return res.status(400).json({error:"final cut has no clips"});
      const job=enqueueFinalRender(project,{outputDir:req.body?.outputDir});
      res.status(202).json({projectId:project.id,job,status:job.status,queueId:job.id});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalCutRenderLaunchRoutes};
