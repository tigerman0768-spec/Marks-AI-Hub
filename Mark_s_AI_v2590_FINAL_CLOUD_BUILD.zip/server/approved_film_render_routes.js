const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
const {renderApprovedFilm}=require("./approved_film_render");

function registerApprovedFilmRenderRoutes(app){
  app.get("/api/projects/:id/approved-film-render/status",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const j=p.approvedFilmRender||null;
    res.json({projectId:p.id,job:j,outputExists:!!j?.outputPath&&fs.existsSync(j.outputPath)});
  });
  app.post("/api/projects/:id/approved-film-render/start",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    if(p.approvedFilmRender?.status==="running")return res.status(409).json({error:"render already running",job:p.approvedFilmRender});
    try{
      const result=renderApprovedFilm(p,req.body||{});
      res.status(result.ready?202:409).json({projectId:p.id,...result});
    }catch(e){res.status(500).json({error:e.message});}
  });
}
module.exports={registerApprovedFilmRenderRoutes};
