const path=require("path");
const {getProject}=require("./film_projects");
const {regenerateRealClip}=require("./real_clip_regeneration");

function registerRealClipRegenerationRoutes(app){
  app.post("/api/projects/:id/clips/real/:clipId/regenerate",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    (async()=>{
      try{
        const result=await regenerateRealClip(p,req.params.clipId,req.body||{});
        res.status(result.ready?202:409).json({projectId:p.id,...result});
      }catch(e){res.status(502).json({error:e.message,provider:"runway"});}
    })();
  });
  app.get("/api/projects/:id/clips/regenerations",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,regenerations:p.realClipRegenerations||[]});
  });
}
module.exports={registerRealClipRegenerationRoutes};
