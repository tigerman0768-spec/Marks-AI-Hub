const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildVoiceJobs}=require("./voice_generation");
const {createOpenAITTSProvider}=require("./openai_tts_provider");
const {loadVoiceProfiles}=require("./character_voice_profiles");

function registerVoiceGenerationRoutes(app,options={}){
  app.post("/api/projects/:id/voice-generation",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const jobs=buildVoiceJobs({...project,dialogueTracks:project.dialogueTracks||project.dialogue?.tracks||[]});
      if(!jobs.length)return res.status(400).json({error:"no dialogue text to generate"});
      let client=options.client||null;
      if(!client){
        if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"OPENAI_API_KEY is not configured"});
        const OpenAI=require("openai");
        client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
      }
      const provider=createOpenAITTSProvider({client});
      const profiles=loadVoiceProfiles(path.join(process.cwd(),"voice-profiles"),project.id).profiles;
      const profileMap=new Map(profiles.map(p=>[p.character,p]));
      for(const job of jobs){
        const profile=profileMap.get(job.character);
        if(profile){
          job.voice=profile.voice||job.voice;
          job.instructions=profile.instructions||job.instructions;
          job.speed=profile.speed||1;
        }
      }
      for(const job of jobs){
        const track=(project.dialogueTracks||[]).find(t=>t.id===job.id || (t.character===job.character&&t.text===job.text));
        if(track){
          const acting=[track.emotion&&`Emotion: ${track.emotion}`,track.intensity&&`Intensity: ${track.intensity}`,
            track.delivery&&`Delivery: ${track.delivery}`,track.emphasis&&`Emphasis: ${track.emphasis}`,
            track.actingNotes&&`Acting notes: ${track.actingNotes}`].filter(Boolean).join(". ");
          if(acting)job.instructions=`${job.instructions} ${acting}`;
          job.pauseBefore=Number(track.pauseBefore||0); job.pauseAfter=Number(track.pauseAfter||0);
        }
      }
      const voiceDir=path.join(process.cwd(),"assets","voice",project.id);
      const results=[];
      for(const job of jobs){
        try{
          const output=path.join(voiceDir,`${job.id}.mp3`);
          const result=await provider.synthesize(job,output);
          job.status="completed";job.audioPath=result.audioPath;job.bytes=result.bytes;
          results.push(job);
        }catch(e){job.status="failed";job.error=e.message;results.push(job);}
      }
      const dialogueTracks=(project.dialogueTracks||project.dialogue?.tracks||[]).map(track=>{
        const match=results.find(j=>j.id===track.id);
        return match&&match.status==="completed"?{...track,audioPath:match.audioPath,duration:match.duration||track.duration}:track;
      });
      saveProject(dir,{...project,dialogueTracks,voiceJobs:results,status:results.some(x=>x.status==="failed")?"voice_generation_partial":"voice_ready"});
      res.json({projectId:project.id,jobs:results,completed:results.filter(x=>x.status==="completed").length,failed:results.filter(x=>x.status==="failed").length});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerVoiceGenerationRoutes};
