const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");
const {inspectFinalFilm}=require("./final_film_quality_inspector");

function run(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});let err="";
    p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-5000))));
  });
}
function repairable(report){
  if(!report||report.status==="passed")return false;
  return (report.issues||[]).some(x=>["missing video dimensions","missing video codec","unexpected container","no audio stream"].includes(x));
}
async function autoRepairFinalFilm(project={},options={}){
  const source=project.completeFinalFilm?.outputPath||project.aiDuckedMaster?.outputPath||
    project.aiMasterFinish?.outputPath||project.aiFinalFinish?.outputPath;
  if(!source||!fs.existsSync(source))throw new Error("no final film available");
  const before=await inspectFinalFilm(source);
  if(before.status==="passed")return {status:"already_valid",sourcePath:source,before};
  if(!repairable(before))return {status:"needs_manual_review",sourcePath:source,before};
  const dir=options.outputDir||path.join(process.cwd(),"output");fs.mkdirSync(dir,{recursive:true});
  const repaired=options.outputPath||path.join(dir,`${project.id}-auto-repaired.mp4`);
  await run(["-y","-i",source,"-map","0:v:0","-map","0:a:0?","-c:v","libx264","-preset","veryfast","-crf","18",
    "-c:a","aac","-b:a","192k","-movflags","+faststart",repaired]);
  const after=await inspectFinalFilm(repaired);
  return {status:after.status==="passed"?"repaired":"repair_failed",
    sourcePath:source,repairedPath:repaired,before,after,
    createdAt:new Date().toISOString(),engine:"final-film-auto-repair"};
}
module.exports={autoRepairFinalFilm,repairable};
