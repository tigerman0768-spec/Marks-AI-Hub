function buildReleaseCenterSummary(project){
  const r=project?.approvedFilmReleaseReadiness||{};
  const a=project?.approvedFilmReleaseApproval||{};
  const s=project?.approvedFilmReleaseSeal||{};
  const c=project?.approvedFilmReleaseCertificate||{};
  const m=project?.approvedFilmReleaseManifest||{};
  return {
    projectId:project?.id||null,
    title:project?.title||"Untitled Film",
    ready:Boolean(r.ready),
    approved:Boolean(a.approved),
    sealed:Boolean(s.sealed),
    certified:Boolean(c.certificateId||c.id),
    manifestSaved:Boolean(m.manifestPath),
    nextAction: !r.ready ? "Check release readiness"
      : !a.approved ? "Approve final release"
      : !s.sealed ? "Seal approved release"
      : !c.certificateId&&!c.id ? "Issue release certificate"
      : !m.manifestPath ? "Save release manifest"
      : "Release package complete"
  };
}
module.exports={buildReleaseCenterSummary};
