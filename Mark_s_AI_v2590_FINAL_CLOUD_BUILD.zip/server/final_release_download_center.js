const fs=require('fs');
const path=require('path');

function fileInfo(p){
  if(!p || !fs.existsSync(p)) return {exists:false,path:p||null};
  const s=fs.statSync(p);
  return {exists:true,path:p,name:path.basename(p),bytes:s.size};
}
function buildFinalReleaseDownloadCenter(project){
  const filmPath=project?.finalMasterFinalReleaseRecord?.outputPath || project?.approvedFilmLibraryFilm?.outputPath || null;
  const exportPath=project?.approvedFilmExport?.sourcePath || null;
  const manifestPath=project?.approvedFilmReleaseManifest?.manifestPath || null;
  const certificatePath=project?.approvedFilmReleaseCertificate?.certificatePath || null;
  const items=[
    {id:'film',label:'Final film MP4',available:fileInfo(filmPath).exists,downloadPath:`/api/projects/${project?.id}/final-render/download-center/film`,info:fileInfo(filmPath)},
    {id:'export',label:'Approved film export',available:fileInfo(exportPath).exists,downloadPath:`/api/projects/${project?.id}/approved-film/export/download`,info:fileInfo(exportPath)},
    {id:'manifest',label:'Release manifest',available:fileInfo(manifestPath).exists,downloadPath:`/api/projects/${project?.id}/approved-film/export/release-manifest/download`,info:fileInfo(manifestPath)},
    {id:'certificate',label:'Release certificate',available:fileInfo(certificatePath).exists,downloadPath:`/api/projects/${project?.id}/final-render/download-center/certificate`,info:fileInfo(certificatePath)}
  ];
  return {projectId:project?.id||null,title:project?.title||'Untitled Film',items,availableCount:items.filter(x=>x.available).length,totalCount:items.length,generatedAt:new Date().toISOString()};
}
module.exports={buildFinalReleaseDownloadCenter};
