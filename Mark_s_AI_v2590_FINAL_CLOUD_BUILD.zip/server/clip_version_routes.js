const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadVersions,snapshotClip,groupByShot,chooseVersion}=require("./clip_version_manager");

function registerClipVersionRoutes(app){
  app.get("/api/projects/:id/clips/versions",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"clip-versions");
      const record=loadVersions(dir,req.params.id);
      res.json({...record,groups:groupByShot(record)});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/:jobId/version",(req,res)=>{
    try{
      const pdir=path.join(process.cwd(),"projects");
      const project=getProject(pdir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const job=(project.videoJobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"clip job not found"});
      const v=snapshotClip(path.join(process.cwd(),"clip-versions"),project.id,job);
      res.json({version:v});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/:jobId/select-version",(req,res)=>{
    try{
      const pdir=path.join(process.cwd(),"projects");
      const project=getProject(pdir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const job=(project.videoJobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"clip job not found"});
      const record=loadVersions(path.join(process.cwd(),"clip-versions"),project.id);
      const selected=chooseVersion(record,`${job.sceneId}:${job.shotNumber}`,req.body?.version);
      if(!selected)return res.status(404).json({error:"version not found"});
      job.selectedVersionId=selected.id;job.selectedClipPath=selected.clipPath;
      saveProject(pdir,{...project,videoJobs:project.videoJobs});
      res.json({jobId:job.id,selected});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerClipVersionRoutes};
