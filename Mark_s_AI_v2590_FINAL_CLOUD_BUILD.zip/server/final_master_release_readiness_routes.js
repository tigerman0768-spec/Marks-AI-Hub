const path=require("path");
const {getProject}=require("./film_projects");
const {evaluateReleaseReadiness}=require("./final_master_release_readiness");
function registerFinalMasterReleaseReadinessRoutes(app){
  app.get("/api/projects/:id/final-render/release-readiness",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,readiness:p.finalMasterReleaseReadiness||null});
  });
  app.post("/api/projects/:id/final-render/release-readiness/check",async(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const readiness=await evaluateReleaseReadiness(p);
    res.status(readiness.ready?200:409).json({projectId:p.id,readiness});
  });
}
module.exports={registerFinalMasterReleaseReadinessRoutes};
