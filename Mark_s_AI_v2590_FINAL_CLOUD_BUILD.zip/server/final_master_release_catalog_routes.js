const path=require("path");
const {getProject}=require("./film_projects");
const {createReleaseCatalogEntry}=require("./final_master_release_catalog");
function registerFinalMasterReleaseCatalogRoutes(app){
  app.get("/api/projects/:id/final-render/release-catalog",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,catalog:p.finalMasterReleaseCatalog||null});
  });
  app.post("/api/projects/:id/final-render/release-catalog/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleaseCatalogEntry(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterReleaseCatalogRoutes};
