const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {inspectFinalFilm}=require("./final_film_quality_inspector");
function registerFinalFilmQualityRoutes(app){
  app.get("/api/projects/:id/final-film-quality",async(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const file=project.completeFinalFilm?.outputPath||project.oneClickFinalFilm?.final?.outputPath||
        project.aiDuckedMaster?.outputPath||project.aiMasterFinish?.outputPath;
      res.json(await inspectFinalFilm(file));
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/final-film-quality/check",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const file=project.completeFinalFilm?.outputPath||project.oneClickFinalFilm?.final?.outputPath||
        project.aiDuckedMaster?.outputPath||project.aiMasterFinish?.outputPath;
      const report=await inspectFinalFilm(file);
      saveProject(dir,{...project,finalFilmQuality:report,status:report.status==="passed"?"final_film_validated":"final_film_needs_review"});
      res.json(report);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalFilmQualityRoutes};
