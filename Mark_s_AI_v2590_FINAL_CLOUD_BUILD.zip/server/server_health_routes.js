function registerServerHealthRoutes(app){
 app.get("/api/health",(req,res)=>res.json({ok:true,service:"marks-ai",time:new Date().toISOString()}));
}
module.exports={registerServerHealthRoutes};
