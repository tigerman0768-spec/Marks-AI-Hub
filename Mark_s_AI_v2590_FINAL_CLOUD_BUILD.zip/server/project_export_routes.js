const fs=require("fs"),path=require("path");
function registerProjectExportRoutes(app){
 app.get("/api/projects/:id/export-json",(req,res)=>{
  const file=path.join(process.cwd(),"projects",`${req.params.id}.json`);
  if(!fs.existsSync(file))return res.status(404).json({error:"project not found"});
  const p=JSON.parse(fs.readFileSync(file,"utf8"));res.setHeader("Content-Type","application/json");res.setHeader("Content-Disposition",`attachment; filename="${p.id}.json"`);res.send(JSON.stringify(p,null,2));
 });
}
module.exports={registerProjectExportRoutes};
