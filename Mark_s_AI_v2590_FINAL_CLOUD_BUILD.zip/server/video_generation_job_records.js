const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function createJobRecords(project, manifest, runId) {
  return (manifest.shots || []).map((shot, index) => ({
    id: `video-job-${project.id}-${index + 1}`,
    projectId: project.id,
    runId,
    manifestId: manifest.id,
    shotId: shot.id,
    scene: shot.scene,
    index: index + 1,
    prompt: shot.prompt,
    duration: Number(shot.duration || 5),
    provider: manifest.provider || "runway",
    status: "queued",
    progress: 0,
    clipPath: null,
    providerJobId: null,
    error: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }));
}

function registerVideoGenerationJobRecordRoutes(app) {
  app.get("/api/projects/:id/video-generation/jobs", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    res.json({
      projectId: p.id,
      jobs: Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : []
    });
  });

  app.patch("/api/projects/:id/video-generation/jobs/:jobId", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const index = jobs.findIndex(j => j.id === req.params.jobId);
    if (index < 0) return res.status(404).json({ error: "job not found" });

    const allowed = ["status", "progress", "clipPath", "providerJobId", "error"];
    for (const key of allowed) {
      if (Object.prototype.hasOwnProperty.call(req.body || {}, key)) {
        jobs[index][key] = req.body[key];
      }
    }
    jobs[index].updatedAt = new Date().toISOString();
    p.videoGenerationJobs = jobs;
    saveProject(dir, p);
    res.json(jobs[index]);
  });
}

module.exports = { createJobRecords, registerVideoGenerationJobRecordRoutes };
