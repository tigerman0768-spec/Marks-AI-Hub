const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
const queue=require("./final_render_worker_queue");

function reconcileFinalRenderProject(project){
  const q=project.finalRenderQueueRecord||{};
  const worker=[...queue.activeJobs(),...queue.queuedJobs()].find(j=>j.id===q.workerJobId);
  if(worker){
    if(worker.status==="running"||worker.state==="running") q.status="running";
    if(worker.progress!=null) q.progress=Math.max(Number(q.progress)||0,Number(worker.progress)||0);
    if(worker.stage) q.stage=String(worker.stage);
    if(worker.error) q.error=String(worker.error);
  }
  const output=q.outputPath||project.finalRenderOutput||null;
  const exists=Boolean(output&&fs.existsSync(output));
  q.outputExists=exists;
  if(exists){
    q.progress=100;q.stage="complete";q.status="completed";q.error=null;
    project.finalRenderOutput=output;project.finalRenderReady=true;
  } else if(q.status==="completed"){
    q.status="running";q.stage="awaiting_output";q.progress=Math.min(Number(q.progress)||99,99);
    project.finalRenderReady=false;
  }
  return q;
}

function reconcileAllFinalRenders(){
  const dir=path.join(process.cwd(),"projects");
  if(!fs.existsSync(dir)) return [];
  const results=[];
  for(const id of fs.readdirSync(dir)){
    const p=getProject(dir,id); if(!p||!p.finalRenderQueueRecord) continue;
    reconcileFinalRenderProject(p); saveProject(dir,p);
    results.push({projectId:p.id,status:p.finalRenderQueueRecord.status,progress:p.finalRenderQueueRecord.progress,outputExists:p.finalRenderQueueRecord.outputExists});
  }
  return results;
}
module.exports={reconcileFinalRenderProject,reconcileAllFinalRenders};
