const fs=require("fs");
const crypto=require("crypto");
function verifyDelivery(record){
  if(!record?.filmPath||!fs.existsSync(record.filmPath))
    return {verified:false,reason:"delivery film file is missing"};
  const stat=fs.statSync(record.filmPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(record.filmPath)).digest("hex");
  const sizeOk=Number(record.bytes)===stat.size;
  const hashOk=record.sha256===sha;
  return {
    verified:sizeOk&&hashOk,
    sizeOk,hashOk,
    expectedBytes:Number(record.bytes),actualBytes:stat.size,
    expectedSha256:record.sha256,actualSha256:sha
  };
}
module.exports={verifyDelivery};
