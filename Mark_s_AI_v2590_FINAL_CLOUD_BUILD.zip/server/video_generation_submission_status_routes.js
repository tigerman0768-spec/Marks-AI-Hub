const path = require("path");
const { getProject } = require("./film_projects");

function registerVideoGenerationSubmissionStatusRoutes(app) {
  app.get("/api/projects/:id/video-generation/submission-status", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const launch = p.videoGenerationLaunch || null;
    const submission = p.videoGenerationSubmission || null;
    const jobs = Array.isArray(p.generationJobs) ? p.generationJobs : [];

    let status = "not_started";
    if (submission?.status === "submitted") status = "submitted";
    else if (submission?.status === "failed") status = "failed";
    else if (launch?.status === "queued") status = "queued";

    const completedJobs = jobs.filter(j =>
      ["completed", "complete", "succeeded", "success"].includes(String(j.status).toLowerCase())
    ).length;

    res.json({
      projectId: p.id,
      title: p.title || "Untitled Film",
      status,
      launch,
      submission,
      jobCount: jobs.length,
      completedJobs,
      manifestShotCount: p.videoGenerationManifest?.shots?.length || 0,
      providerResults: jobs
    });
  });
}

module.exports = { registerVideoGenerationSubmissionStatusRoutes };
