const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createReleaseSnapshot(project){
  const record=project.finalMasterReleaseRecord;
  if(!record||record.status!=="released")return {created:false,blockers:["final master release record is required"]};
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))return {created:false,blockers:["released output file is missing"]};
  const bytes=fs.readFileSync(output);
  const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
  if(sha256!==record.sha256)return {created:false,blockers:["current output hash differs from release record"]};
  const snapshot={
    snapshotId:`snapshot_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    releaseId:record.releaseId,projectId:project.id,title:project.title||"Untitled Film",
    filename:record.filename,bytes:bytes.length,sha256,
    createdAt:new Date().toISOString(),status:"sealed"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"release_snapshot");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"release_snapshot.json"),JSON.stringify(snapshot,null,2));
  project.finalMasterReleaseSnapshot=snapshot;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {created:true,snapshot};
}
module.exports={createReleaseSnapshot};
