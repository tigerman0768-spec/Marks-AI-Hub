/**
 * Provider-neutral execution adapter.
 *
 * The existing Runway integration can be supplied through submit/poll
 * functions. This layer owns production-run state and retries without
 * hard-coding provider credentials into the Flutter app.
 */
async function executeProductionRun(run, provider, options = {}) {
  const maxRetries = Number(options.maxRetries ?? 2);
  if (!run || !Array.isArray(run.jobs)) throw new Error("invalid production run");
  if (!provider || typeof provider.submit !== "function" ||
      typeof provider.poll !== "function") {
    throw new Error("provider adapter must expose submit() and poll()");
  }

  run.status = "running";
  run.startedAt ||= new Date().toISOString();

  for (const job of run.jobs) {
    if (job.status === "completed") continue;
    job.status = "generating";
    job.attempts = Number(job.attempts || 0);

    let lastError = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      job.attempts++;
      try {
        if (!job.providerTaskId) {
          job.providerTaskId = await provider.submit(job);
        }
        const result = await provider.poll(job.providerTaskId, options.pollOptions || {});
        if (result && (result.status === "completed" || result.status === "succeeded")) {
          job.status = "completed";
          job.output = result.output || result.url || result;
          lastError = null;
          break;
        }
        if (result && (result.status === "failed" || result.status === "error")) {
          throw new Error(result.error || "provider generation failed");
        }
        job.status = "waiting";
        if (typeof options.onWaiting === "function") await options.onWaiting(job, result);
        if (attempt < maxRetries) {
          job.status = "generating";
          continue;
        }
      } catch (err) {
        lastError = err;
        job.status = "retrying";
        if (attempt === maxRetries) break;
      }
    }

    if (lastError) {
      job.status = "failed";
      job.error = lastError.message;
      run.status = "failed";
      run.error = `Generation failed for ${job.id}`;
      run.finishedAt = new Date().toISOString();
      return run;
    }
  }

  run.status = "completed";
  run.finishedAt = new Date().toISOString();
  return run;
}

module.exports = { executeProductionRun };
