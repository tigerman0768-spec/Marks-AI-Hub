const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildCinematicShotPlan}=require("./cinematic_shot_director");

function registerCinematicShotRoutes(app){
  app.post("/api/projects/:id/cinematic-shots/generate",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildCinematicShotPlan(project,project.performancePlan||[],project.directorPlan||[]);
      saveProject(dir,{...project,cinematicShotPlan:plan,status:"cinematic_shots_ready"});
      res.json({projectId:project.id,cinematicShotPlan:plan,scenes:plan.length});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/cinematic-shots",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json({projectId:project.id,cinematicShotPlan:project.cinematicShotPlan||[]});
  });
}
module.exports={registerCinematicShotRoutes};
