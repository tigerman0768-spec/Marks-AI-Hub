function transitionName(type){
  if(type==="dissolve")return "dissolve";
  if(type==="dip-to-black")return "fadeblack";
  if(type==="fade")return "fade";
  return null;
}
function buildTransitionGraph(items){
  const filters=[];
  items.forEach((item,i)=>filters.push(`[${i}:v]settb=AVTB,setpts=PTS-STARTPTS,format=yuv420p[v${i}]`));
  if(items.length===1)return {filters,video:"[v0]"};
  let current="[v0]", accumulated=0;
  for(let i=1;i<items.length;i++){
    const prev=items[i-1];
    const tr=typeof prev.transition==="string"?{type:prev.transition,duration:0}:(prev.transition||{});
    const effect=transitionName(tr.type||"cut");
    const d=Math.max(0,Math.min(5,Number(tr.duration||0)));
    if(effect&&d>0){
      const outDur=Math.max(0.1,Number(prev.duration||5));
      accumulated+=outDur-d;
      filters.push(`${current}[v${i}]xfade=transition=${effect}:duration=${d}:offset=${Math.max(0,accumulated)}[x${i}]`);
      current=`[x${i}]`;
    }else{
      filters.push(`${current}[v${i}]concat=n=2:v=1:a=0[v${i}c]`);
      current=`[v${i}c]`;
      accumulated+=Number(prev.duration||5);
    }
  }
  return {filters,video:current};
}
module.exports={buildTransitionGraph};
