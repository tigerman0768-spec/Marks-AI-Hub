const path=require("path");
const {getProject}=require("./film_projects");
const {saveDeliveryManifest}=require("./final_master_delivery_manifest");
function registerFinalMasterDeliveryManifestRoutes(app){
  app.get("/api/projects/:id/final-render/delivery-manifest",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,manifest:p.finalMasterDeliveryManifest||null});
  });
  app.post("/api/projects/:id/final-render/delivery-manifest/build",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const manifest=saveDeliveryManifest(p);
    res.status(manifest.ready?200:409).json({projectId:p.id,manifest});
  });
}
module.exports={registerFinalMasterDeliveryManifestRoutes};
