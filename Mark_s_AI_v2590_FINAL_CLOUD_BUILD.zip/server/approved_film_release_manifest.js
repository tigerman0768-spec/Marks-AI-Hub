const fs=require("fs"),path=require("path"),crypto=require("crypto");
const {getProject}=require("./film_projects");
function buildReleaseManifest(project){
  const c=project?.approvedFilmReleaseCertificate,s=project?.approvedFilmReleaseSeal;
  return {manifestVersion:"1.0",projectId:project.id,title:project.title||"Untitled Film",
    status:c?.status==="released"?"released":"sealed",
    certificateId:c?.certificateId||null,sealId:s?.sealId||null,
    snapshotId:project?.approvedFilmReleaseSnapshot?.snapshotId||null,
    deliveryId:project?.approvedFilmDelivery?.deliveryId||null,
    filename:c?.filename||s?.filename||null,bytes:Number(c?.bytes||s?.bytes||0),
    sha256:c?.sha256||s?.sha256||null,generatedAt:new Date().toISOString()};
}
function saveReleaseManifest(project){
  const m=buildReleaseManifest(project), dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const manifestSha256=crypto.createHash("sha256").update(JSON.stringify(m)).digest("hex");
  const file=path.join(dir,`release_manifest_${Date.now()}.json`);
  fs.writeFileSync(file,JSON.stringify({...m,manifestSha256},null,2));
  return {...m,manifestSha256,manifestPath:file};
}
module.exports={buildReleaseManifest,saveReleaseManifest};
