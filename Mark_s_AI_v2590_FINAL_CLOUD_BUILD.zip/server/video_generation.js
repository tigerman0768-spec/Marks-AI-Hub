const crypto=require("crypto");

function buildVideoGenerationJobs(project,shots=[]){
  const duration=Number(project?.shotDuration||5);
  return shots.map((shot,i)=>({
    id:shot.id||crypto.randomUUID(),
    sceneId:shot.sceneId,
    shotNumber:shot.shotNumber||i+1,
    provider:project?.videoProvider||"runway",
    duration,
    aspectRatio:project?.aspectRatio||"16:9",
    prompt:shot.prompt||`${shot.shotType||"cinematic"} shot, ${shot.cameraMovement||"locked camera"}, ${shot.purpose||""}`,
    status:"queued",
    attempts:0,
    output:null,
    error:null
  }));
}
function createVideoGenerationRun(project,shots=[]){
  const jobs=buildVideoGenerationJobs(project,shots);
  return {id:crypto.randomUUID(),status:"queued",createdAt:new Date().toISOString(),
    total:jobs.length,completed:0,failed:0,jobs};
}
module.exports={buildVideoGenerationJobs,createVideoGenerationRun};

function applyDirectedVideoPrompts(project, jobs=[]){
  const map=new Map((project.videoPromptPlan||[]).map(x=>[x.shotId,x.prompt]));
  return jobs.map(job=>map.has(job.id)?{...job,prompt:map.get(job.id)}:job);
}
module.exports.applyDirectedVideoPrompts=applyDirectedVideoPrompts;
