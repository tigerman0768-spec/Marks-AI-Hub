const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
function registerFinalRenderOutputInspectorRoutes(app){
  app.get("/api/projects/:id/final-render/output-inspection",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord||{},output=q.outputPath||p.finalRenderOutput||null;
    const exists=Boolean(output&&fs.existsSync(output));
    const stat=exists?fs.statSync(output):null;
    res.json({
      projectId:p.id,exists,path:output,
      bytes:stat?.size||0,modifiedAt:stat?.mtime?.toISOString()||null,
      ready:exists&&Number(stat?.size||0)>0,
      queueStatus:q.status||"not_queued"
    });
  });
}
module.exports={registerFinalRenderOutputInspectorRoutes};
