const fs=require("fs");
const path=require("path");
const {pipeline}=require("stream/promises");

function pickOutputUrl(output){
  if(typeof output==="string")return output;
  if(Array.isArray(output))return output[0]?.url||output[0];
  if(output&&typeof output==="object"){
    return output.url||output.video_url||output.videoUrl||
      output.output?.url||output.output?.video_url||
      (Array.isArray(output.outputs)?(output.outputs[0]?.url||output.outputs[0]):null);
  }
  return null;
}
async function downloadClip(output,dir,id,options={}){
  const url=pickOutputUrl(output);
  if(!url)throw new Error(`no downloadable video URL for ${id}`);
  fs.mkdirSync(dir,{recursive:true});
  const ext=options.extension||".mp4";
  const destination=path.join(dir,`${id}${ext}`);
  const res=await fetch(url);
  if(!res.ok)throw new Error(`clip download failed (${res.status})`);
  await pipeline(res.body,fs.createWriteStream(destination));
  if(!fs.existsSync(destination)||!fs.statSync(destination).size)throw new Error("downloaded clip is empty");
  return {path:destination,url,bytes:fs.statSync(destination).size};
}
module.exports={pickOutputUrl,downloadClip};
