const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {saveDialogue}=require("./dialogue_timeline");
const {buildDialoguePrompt,validateDialogue}=require("./ai_dialogue_generator");

function registerAIDialogueRoutes(app){
  app.post("/api/projects/:id/ai-dialogue/generate",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"OPENAI_API_KEY is not configured"});
      const OpenAI=require("openai");
      const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
      const scenes=Array.isArray(project.scenes)?project.scenes:[];
      const wanted=req.body?.sceneId;
      const selected=wanted?scenes.filter(s=>s.id===wanted):scenes;
      if(!selected.length)return res.status(400).json({error:"no scenes available"});
      const characters=project.characters||[];
      const generated=[];
      for(const scene of selected){
        const prompt=buildDialoguePrompt(project,scene,characters);
        const response=await client.responses.create({
          model:process.env.OPENAI_DIALOGUE_MODEL||"gpt-5.6-luna",
          input:prompt,
          text:{format:{
            type:"json_schema",name:"scene_dialogue",strict:true,
            schema:{type:"object",properties:{
              dialogue:{type:"array",items:{type:"object",properties:{
                character:{type:"string"},text:{type:"string"}
              },required:["character","text"],additionalProperties:false}}
            },required:["dialogue"],additionalProperties:false}
          }}
        });
        const parsed=JSON.parse(response.output_text||'{"dialogue":[]}');
        generated.push({sceneId:scene.id||"",dialogue:validateDialogue(parsed.dialogue,characters)});
      }
      const current=project.dialogueTracks||[];
      const keep=req.body?.replace?[]:current;
      let tracks=[...keep];
      for(const block of generated){
        for(const line of block.dialogue){
          tracks.push({
            id:require("crypto").randomUUID(),sceneId:block.sceneId,
            character:line.character,text:line.text,audioPath:"",
            start:0,duration:0,volume:1,duckMusic:true,duckLevel:.25,
            voice:"",instructions:"",source:"ai-screenplay-dialogue",order:tracks.length
          });
        }
      }
      const record=saveDialogue(path.join(process.cwd(),"dialogue"),project.id,tracks);
      saveProject(dir,{...project,dialogueTracks:record.tracks,status:"ai_dialogue_ready"});
      res.json({projectId:project.id,scenes:generated,tracks:record.tracks,created:tracks.length-keep.length});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAIDialogueRoutes};
