const fs=require("fs");
const path=require("path");

function formatSrtTime(seconds){
  const ms=Math.max(0,Math.round(Number(seconds||0)*1000));
  const h=Math.floor(ms/3600000), m=Math.floor((ms%3600000)/60000);
  const s=Math.floor((ms%60000)/1000), x=ms%1000;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(x).padStart(3,"0")}`;
}

function buildDialogueSubtitles(scenePlans=[]){
  const cues=[];
  let n=1;
  for(const scene of scenePlans){
    for(const line of (scene.dialogue||[])){
      const text=String(line.text||"").trim();
      if(!text) continue;
      const start=Number(line.filmStart??(scene.offset||0)+Number(line.start||0));
      const duration=Math.max(.4,Number(line.duration||Math.max(1,text.length/14)));
      cues.push({
        number:n++,start,end:start+duration,
        speaker:String(line.speaker||"").trim(),text
      });
    }
  }
  return cues;
}

function cuesToSrt(cues=[]){
  return cues.map(c=>{
    const label=c.speaker?`${c.speaker}: `:"";
    return `${c.number}\n${formatSrtTime(c.start)} --> ${formatSrtTime(c.end)}\n${label}${c.text}\n`;
  }).join("\n");
}

function writeDialogueSrt(scenePlans=[],outputPath){
  if(!outputPath) throw new Error("outputPath required");
  const cues=buildDialogueSubtitles(scenePlans);
  fs.mkdirSync(path.dirname(outputPath),{recursive:true});
  fs.writeFileSync(outputPath,cuesToSrt(cues),"utf8");
  return {outputPath,cues:cues.length,bytes:fs.statSync(outputPath).size};
}
module.exports={formatSrtTime,buildDialogueSubtitles,cuesToSrt,writeDialogueSrt};
