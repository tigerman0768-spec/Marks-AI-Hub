const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

function quote(s) {
  return `'${String(s).replace(/'/g, "'\\''")}'`;
}

function makeConcatFile(clips, filePath) {
  if (!clips.length) throw new Error("no local clips supplied");
  const lines = clips.map(c => {
    if (!c || !c.localAsset) throw new Error("every clip needs localAsset");
    return `file ${quote(path.resolve(c.localAsset))}`;
  });
  fs.writeFileSync(filePath, lines.join("\n") + "\n");
}

function renderFilm(clips, outputPath, options = {}) {
  const ffmpeg = options.ffmpeg || process.env.FFMPEG_BIN || "ffmpeg";
  const workDir = options.workDir || path.dirname(outputPath);
  fs.mkdirSync(workDir, { recursive: true });
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  const concatFile = path.join(workDir, `concat-${Date.now()}.txt`);
  makeConcatFile(clips, concatFile);

  return new Promise((resolve, reject) => {
    const args = [
      "-y", "-f", "concat", "-safe", "0", "-i", concatFile,
      "-c:v", "libx264", "-preset", options.preset || "medium",
      "-crf", String(options.crf ?? 20),
      "-pix_fmt", "yuv420p",
      "-c:a", "aac", "-b:a", options.audioBitrate || "192k",
      "-movflags", "+faststart",
      outputPath
    ];
    const child = spawn(ffmpeg, args, { stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr.on("data", d => { stderr += d.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      try { fs.unlinkSync(concatFile); } catch {}
      if (code !== 0) return reject(new Error(`FFmpeg exited ${code}: ${stderr.slice(-2000)}`));
      const stat = fs.statSync(outputPath);
      if (!stat.size) return reject(new Error("rendered film is empty"));
      resolve({ outputPath, bytes: stat.size });
    });
  });
}

module.exports = { renderFilm, makeConcatFile };
