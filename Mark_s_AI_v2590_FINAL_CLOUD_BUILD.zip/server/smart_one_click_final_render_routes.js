const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {smartOneClickFinalRender,enqueueSmartOneClickFinalRender}=require("./smart_one_click_final_render");
const {getProgress}=require("./final_render_progress");
function registerSmartOneClickFinalRenderRoutes(app){

  // v127: production-facing endpoint queues renders instead of bypassing the worker queue.
  app.post("/api/projects/:id/smart-one-click-final-render", async (req,res)=>{
    try{
      const project={...(req.body||{}),id:req.params.id};
      const job=enqueueSmartOneClickFinalRender(project,{outputDir:req.body?.outputDir});
      res.status(202).json({
        status:"queued",
        progressId:job.id,
        queueId:job.id,
        job
      });
    }catch(error){
      res.status(400).json({error:error.message});
    }
  });


  app.post("/api/projects/:id/smart-one-click-final-render/direct",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await smartOneClickFinalRender(project,{outputDir:path.join(process.cwd(),"output")});
      saveProject(dir,{...project,smartOneClickFinalRender:result,status:result.status==="completed"?"final_film_completed":result.status==="needs_review"?"final_film_needs_review":"final_film_failed"});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/smart-one-click-final-render/progress/:progressId",(req,res)=>{
    const result=getProgress(req.params.progressId);
    if(!result)return res.status(404).json({error:"progress not found"});
    res.json(result);
  });
  app.get("/api/projects/:id/smart-one-click-final-render",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json(project.smartOneClickFinalRender||{status:"not_run"});
  });
}
module.exports={registerSmartOneClickFinalRenderRoutes};
