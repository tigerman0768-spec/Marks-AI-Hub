const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function buildVoiceJobs(project={}){
  const tracks=project.dialogueTracks||project.dialogue?.tracks||[];
  return tracks.filter(t=>t.text).map((t,i)=>({
    id:t.id||crypto.randomUUID(),
    character:t.character||"Speaker",
    text:String(t.text),
    voice:t.voice||"alloy",
    instructions:t.instructions||`Natural cinematic dialogue for ${t.character||"the character"}.`,
    start:Number(t.start||0),
    duration:Number(t.duration||0),
    status:"queued",
    audioPath:t.audioPath||"",
    error:null,
    order:i
  }));
}
function ensureVoiceDir(dir){fs.mkdirSync(dir,{recursive:true});return dir;}
module.exports={buildVoiceJobs,ensureVoiceDir};
