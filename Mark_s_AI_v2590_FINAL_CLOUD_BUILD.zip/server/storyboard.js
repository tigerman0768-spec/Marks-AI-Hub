const {buildDirectorPlan}=require("./director");

function buildSceneBreakdown(project){
  const scenes=Array.isArray(project?.scenes)?project.scenes:[];
  const characters=Array.isArray(project?.characters)?project.characters:[];
  const characterNames=characters.map(c=>c.name).filter(Boolean);
  const source=scenes.length?scenes:[{id:"scene-1",number:1,title:"Opening",location:"TBD",time:"TBD",characters:characterNames,action:"Establish the story."},
    {id:"scene-2",number:2,title:"Conflict",location:"TBD",time:"TBD",characters:characterNames,action:"Develop the central conflict."},
    {id:"scene-3",number:3,title:"Resolution",location:"TBD",time:"TBD",characters:characterNames,action:"Resolve the story."}];
  const enriched=source.map((s,i)=>({
    id:s.id||`scene-${i+1}`,number:s.number||i+1,title:s.title||`Scene ${i+1}`,
    location:s.location||"TBD",time:s.time||"TBD",characters:s.characters||characterNames,
    action:s.action||"TBD",emotion:s.emotion||"natural",lighting:s.lighting||"cinematic",
    wardrobe:s.wardrobe||"consistent",shotCount:Number(s.shotCount||4)
  }));
  return {scenes:enriched,directorPlan:buildDirectorPlan(enriched)};
}
module.exports={buildSceneBreakdown};
