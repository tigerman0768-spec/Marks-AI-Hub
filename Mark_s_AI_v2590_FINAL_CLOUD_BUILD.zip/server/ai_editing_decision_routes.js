const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildEditingDecisions}=require("./ai_editing_decisions");
function registerAiEditingDecisionRoutes(app){
  app.get("/api/projects/:id/editing-decisions",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(buildEditingDecisions(project));
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/editing-decisions/apply",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildEditingDecisions(project);
      saveProject(dir,{...project,editingDecisions:plan,status:"editing_decisions_ready"});
      res.json(plan);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiEditingDecisionRoutes};
