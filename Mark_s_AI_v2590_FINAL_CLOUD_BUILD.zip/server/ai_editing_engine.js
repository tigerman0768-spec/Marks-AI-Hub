const allowed=["cut","fade","dissolve","dip-to-black"];
function chooseTransition(prev,next,index){
  if(index===0)return {type:"cut",duration:0,reason:"opening shot"};
  if(prev.sceneId!==next.sceneId)return {type:"dissolve",duration:0.5,reason:"scene change"};
  if(next.smartReview?.decision==="recommended")return {type:"cut",duration:0,reason:"strong take"};
  return {type:"cut",duration:0,reason:"maintain pacing"};
}
function choosePacing(job,index,total){
  const score=Number(job.smartReview?.score??75);
  if(index===0)return "establish";
  if(index===total-1)return "resolve";
  if(score>=90)return "hold";
  return "normal";
}
function buildAutomaticEdit(project={}){
  const base=project.finalTimeline?.items||project.finalCutPlan?.items||[];
  const items=[...base].filter(x=>x.clipPath).map(x=>({...x}));
  for(let i=0;i<items.length;i++){
    const prev=items[i-1],next=items[i];
    const t=chooseTransition(prev,next,i);
    items[i].transition=allowed.includes(t.type)?t.type:"cut";
    items[i].transitionDuration=t.duration;
    items[i].transitionReason=t.reason;
    items[i].pacing=choosePacing(items[i],i,items.length);
  }
  const cuts=items.filter(x=>x.transition==="cut").length;
  const transitions=items.length?items.length-cuts:0;
  return {projectId:project.id,items,cutCount:cuts,transitionCount:transitions,
    pacing:"automatic",createdAt:new Date().toISOString(),readyToRender:items.length>0};
}
module.exports={buildAutomaticEdit};
