const {getFinalRenderJobStatus}=require("./final_render_job_status");
function registerFinalRenderJobStatusRoutes(app){
  app.get("/api/final-render/jobs/:id/status",(req,res)=>{
    try{
      const status=getFinalRenderJobStatus(req.params.id);
      if(!status)return res.status(404).json({error:"final render job not found"});
      res.json(status);
    }catch(error){res.status(500).json({error:error.message});}
  });
}
module.exports={registerFinalRenderJobStatusRoutes};
