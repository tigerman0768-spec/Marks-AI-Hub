const path=require("path");
const {getProject,saveProject}=require("./film_projects");
function registerProjectLifecycleRoutes(app){
 app.patch("/api/projects/:id/lifecycle",(req,res)=>{
  const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const allowed=["draft","planning","producing","review","complete","archived"];
  const status=String(req.body?.status||"").toLowerCase();
  if(!allowed.includes(status))return res.status(400).json({error:"invalid lifecycle status"});
  const saved=saveProject(dir,{...p,status});res.json({projectId:saved.id,status:saved.status,updatedAt:saved.updatedAt});
 });
}
module.exports={registerProjectLifecycleRoutes};
