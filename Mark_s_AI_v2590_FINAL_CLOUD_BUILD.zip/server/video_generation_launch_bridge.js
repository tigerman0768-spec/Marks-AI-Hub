const path = require("path");
const { getProject, saveProject } = require("./film_projects");
const { submitManifest } = require("./video_generation_orchestrator_adapter");
const { createJobRecords } = require("./video_generation_job_records");

function registerVideoGenerationLaunchBridge(app) {
  app.post("/api/projects/:id/video-generation/submit", async (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const manifest = p.videoGenerationManifest;
    if (!manifest?.shots?.length) {
      return res.status(409).json({ error: "video generation manifest required" });
    }

    const providerConfigured = Boolean(
      process.env.RUNWAY_API_KEY || process.env.VIDEO_API_KEY
    );
    if (!providerConfigured) {
      return res.status(409).json({
        error: "video provider is not configured",
        mode: "dry-run",
        message: "Configure a provider before real submission."
      });
    }

    const launch = p.videoGenerationLaunch;
    if (!launch) {
      return res.status(409).json({
        error: "generation launch record required",
        message: "Create a launch record before provider submission."
      });
    }

    try {
      const result = await submitManifest(p, manifest, {
        provider: launch.provider || manifest.provider || "runway",
        requestId: launch.id,
        submitToProvider: true
      });

      const updated = getProject(dir, req.params.id) || p;
      const runId = result?.run?.id || result?.runId || launch.id;
      const existingJobs = Array.isArray(updated.videoGenerationJobs)
        ? updated.videoGenerationJobs
        : [];
      const jobs = existingJobs.length
        ? existingJobs
        : createJobRecords(updated, manifest, runId);

      updated.videoGenerationJobs = jobs.map(j => ({
        ...j,
        runId: j.runId || runId
      }));
      updated.videoGenerationSubmission = {
        launchId: launch.id,
        submittedAt: new Date().toISOString(),
        provider: launch.provider || manifest.provider || "runway",
        status: "submitted",
        runId,
        result
      };
      saveProject(dir, updated);

      res.status(202).json({
        projectId: p.id,
        launchId: launch.id,
        status: "submitted",
        provider: launch.provider || manifest.provider || "runway",
        result
      });
    } catch (error) {
      const updated = getProject(dir, req.params.id) || p;
      updated.videoGenerationSubmission = {
        launchId: launch.id,
        submittedAt: new Date().toISOString(),
        provider: launch.provider || manifest.provider || "runway",
        status: "failed",
        error: String(error?.message || error)
      };
      saveProject(dir, updated);

      res.status(502).json({
        error: "video generation submission failed",
        launchId: launch.id,
        details: String(error?.message || error)
      });
    }
  });
}

module.exports = { registerVideoGenerationLaunchBridge };
