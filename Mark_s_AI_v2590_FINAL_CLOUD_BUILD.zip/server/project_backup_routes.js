const fs=require("fs");
const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectBackupRoutes(app){
  app.get("/api/projects/:id/backup",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const backupDir=path.join(process.cwd(),"project-backups"); fs.mkdirSync(backupDir,{recursive:true});
    const file=path.join(backupDir,`${p.id}.json`);
    fs.writeFileSync(file,JSON.stringify(p,null,2));
    res.json({projectId:p.id,backupPath:file,bytes:fs.statSync(file).size,createdAt:new Date().toISOString()});
  });
}
module.exports={registerProjectBackupRoutes};
