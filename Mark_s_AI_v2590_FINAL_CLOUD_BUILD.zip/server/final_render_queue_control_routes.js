const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const allowed={queued:["running","cancelled"],running:["completed","failed","cancelled"],failed:["queued"],cancelled:["queued"],completed:[]};
function registerFinalRenderQueueControlRoutes(app){
  app.post("/api/projects/:id/final-render/queue/status",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q)return res.status(404).json({error:"render is not queued"});
    const next=String(req.body?.status||"");
    if(!allowed[q.status]?.includes(next))return res.status(409).json({error:"invalid render status transition",from:q.status,to:next});
    q.status=next;q.updatedAt=new Date().toISOString();
    if(req.body?.progress!==undefined)q.progress=Math.max(0,Math.min(100,Number(req.body.progress)||0));
    if(req.body?.stage!==undefined)q.stage=String(req.body.stage);
    if(req.body?.error!==undefined)q.error=req.body.error?String(req.body.error):null;
    saveProject(dir,p);res.json(q);
  });
}
module.exports={registerFinalRenderQueueControlRoutes};
