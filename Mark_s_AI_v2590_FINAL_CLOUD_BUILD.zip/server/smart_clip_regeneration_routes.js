const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {queueSmartRegenerations,buildRegenerationJob}=require("./smart_clip_regeneration");

function registerSmartClipRegenerationRoutes(app){
  app.post("/api/projects/:id/clips/auto-regenerate",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const queued=queueSmartRegenerations(project);
      saveProject(dir,{...project,status:queued.length?"regeneration_queued":"no_regeneration_needed"});
      res.json({projectId:project.id,queuedCount:queued.length,queuedJobs:queued});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/:jobId/auto-regenerate",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const job=(project.videoJobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"clip job not found"});
      const replacement=buildRegenerationJob(project,job,req.body?.reason||"manual regeneration");
      job.regenerationQueued=true;job.regenerationJobId=replacement.id;
      project.videoJobs=[...(project.videoJobs||[]),replacement];
      saveProject(dir,{...project,status:"regeneration_queued"});
      res.json({projectId:project.id,job:replacement});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerSmartClipRegenerationRoutes};
