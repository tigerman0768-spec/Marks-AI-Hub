function config(){
  const owner=process.env.GITHUB_OWNER||'';
  const repo=process.env.GITHUB_REPO||'';
  const workflow=process.env.GITHUB_RELEASE_WORKFLOW||'android-release.yml';
  const ref=process.env.GITHUB_RELEASE_REF||'main';
  return {owner,repo,workflow,ref,configured:Boolean(owner&&repo&&process.env.GITHUB_TOKEN)};
}

async function github(path){
  const c=config();
  const r=await fetch(`https://api.github.com${path}`,{headers:{'Accept':'application/vnd.github+json','Authorization':`Bearer ${process.env.GITHUB_TOKEN}`,'X-GitHub-Api-Version':'2022-11-28','User-Agent':"Mark's-AI-Release-Monitor"}});
  const text=await r.text();
  let body={}; try{body=JSON.parse(text);}catch{body={message:text.slice(0,500)};}
  if(!r.ok){const e=new Error(body.message||`GitHub API ${r.status}`);e.status=r.status;throw e;}
  return body;
}

function registerReleaseBuildMonitorRoutes(app){
  app.get('/api/release-build/monitor',async(req,res)=>{
    const c=config();
    if(!c.configured)return res.status(200).json({configured:false,status:'not_configured',message:'Configure GITHUB_OWNER, GITHUB_REPO and GITHUB_TOKEN to monitor builds.',run:null,artifacts:[]});
    try{
      const runs=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/workflows/${encodeURIComponent(c.workflow)}/runs?per_page=10`);
      const run=runs.workflow_runs?.[0]||null;
      let artifacts=[];
      if(run){
        const a=await github(`/repos/${encodeURIComponent(c.owner)}/${encodeURIComponent(c.repo)}/actions/runs/${run.id}/artifacts?per_page=20`);
        artifacts=(a.artifacts||[]).filter(x=>!x.expired).map(x=>({id:x.id,name:x.name,sizeBytes:x.size_in_bytes,expired:x.expired,createdAt:x.created_at,updatedAt:x.updated_at,downloadUrl:`/api/release-build/artifacts/${encodeURIComponent(String(x.id))}/download`,archiveUrl:x.archive_download_url}));
      }
      const status=run? (run.status==='completed'?(run.conclusion==='success'?'success':run.conclusion==='failure'?'failure':run.conclusion||'completed'):run.status):'no_runs';
      res.json({configured:true,status,workflow:c.workflow,ref:c.ref,run:run?{id:run.id,name:run.name,status:run.status,conclusion:run.conclusion,branch:run.head_branch,event:run.event,createdAt:run.created_at,updatedAt:run.updated_at,runNumber:run.run_number,htmlUrl:run.html_url}:null,artifacts,message:run?`Latest GitHub Actions run is ${status}.`:'No GitHub Actions run has been recorded yet.'});
    }catch(e){res.status(e.status===401||e.status===403?502:500).json({configured:true,status:'error',message:'Unable to read GitHub Actions build status.',detail:e.message});}
  });
}
module.exports={registerReleaseBuildMonitorRoutes};
