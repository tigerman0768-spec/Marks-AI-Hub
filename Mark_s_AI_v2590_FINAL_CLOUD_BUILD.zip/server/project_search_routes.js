const fs=require("fs"),path=require("path");
function registerProjectSearchRoutes(app){
 app.get("/api/projects/search",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});
  const q=String(req.query.q||"").trim().toLowerCase(),status=String(req.query.status||"").trim().toLowerCase();
  const projects=fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"))}catch{return null}}).filter(Boolean)
   .filter(p=>!q||String(p.title||"").toLowerCase().includes(q)||String(p.genre||"").toLowerCase().includes(q))
   .filter(p=>!status||String(p.status||"draft").toLowerCase()===status)
   .map(p=>({id:p.id,title:p.title||"Untitled Film",status:p.status||"draft",genre:p.genre||"Drama",length:p.length||5,updatedAt:p.updatedAt||null}));
  res.json({count:projects.length,query:q,status,projects});
 });
}
module.exports={registerProjectSearchRoutes};
