const {reconcileAllFinalRenders}=require("./final_render_worker_reconcile");
function startFinalRenderHeartbeat(intervalMs=5000){
  const timer=setInterval(()=>{try{reconcileAllFinalRenders();}catch(e){console.error("[final-render-heartbeat]",e.message)}},intervalMs);
  if(timer.unref) timer.unref();
  return timer;
}
module.exports={startFinalRenderHeartbeat};
