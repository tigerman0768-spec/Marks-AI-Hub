const path=require("path");
const {listProjects}=require("./film_projects");
function registerProjectDashboardRoutes(app){
 app.get("/api/projects/dashboard",(req,res)=>{
  const projects=listProjects(path.join(process.cwd(),"projects"))||[];
  const summary={total:projects.length,draft:0,planning:0,producing:0,review:0,complete:0,archived:0};
  projects.forEach(p=>{const s=p.status||"draft";if(summary[s]!==undefined)summary[s]++;});
  res.json({summary,projects:projects.map(p=>({id:p.id,title:p.title,status:p.status||"draft",updatedAt:p.updatedAt||null,genre:p.genre||"Drama",length:p.length||5}))});
 });
}
module.exports={registerProjectDashboardRoutes};
