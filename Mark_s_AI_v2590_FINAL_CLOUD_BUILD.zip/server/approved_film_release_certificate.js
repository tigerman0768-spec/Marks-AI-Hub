const fs=require("fs");
const crypto=require("crypto");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {recordReleaseEvent}=require("./approved_film_release_history");
const {buildReleaseAudit}=require("./approved_film_release_audit");

function createReleaseCertificate(project){
  const audit=buildReleaseAudit(project);
  if(!audit.complete)return {issued:false,reason:"release audit is incomplete",audit};
  const seal=project.approvedFilmReleaseSeal;
  if(!seal)return {issued:false,reason:"release seal is missing"};
  const certificateId=`release_certificate_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const certificate={
    certificateVersion:"1.0",certificateId,projectId:project.id,
    title:project.title||"Untitled Film",status:"released",
    approvalId:project.approvedFilmReleaseApproval.approvalId,
    snapshotId:project.approvedFilmReleaseSnapshot.snapshotId,
    deliveryId:project.approvedFilmDelivery.deliveryId,
    lockId:project.approvedFilmDeliveryLock.lockId,
    sealId:seal.sealId,filename:seal.filename,bytes:seal.bytes,
    sha256:seal.sha256,issuedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const certificatePath=path.join(dir,`${certificateId}.json`);
  fs.writeFileSync(certificatePath,JSON.stringify(certificate,null,2));
  certificate.certificatePath=certificatePath;
  project.approvedFilmReleaseCertificate=certificate;
  saveProject(path.join(process.cwd(),"projects"),project);
  recordReleaseEvent(project,{event:"certificate-issued",id:certificate.certificateId});
  return {issued:true,certificate};
}
module.exports={createReleaseCertificate};
