const fs=require("fs");
const path=require("path");
const {getProject}=require("./film_projects");

function buildReleaseAudit(project){
  const stages=[
    ["filmLibrary","Film Library",!!project?.approvedFilmLibraryFilm],
    ["export","Export",!!project?.approvedFilmExport],
    ["delivery","Delivery",!!project?.approvedFilmDelivery],
    ["deliveryLock","Delivery Lock",!!project?.approvedFilmDeliveryLock],
    ["snapshot","Release Snapshot",!!project?.approvedFilmReleaseSnapshot],
    ["approval","Release Approval",!!project?.approvedFilmReleaseApproval],
    ["seal","Release Seal",!!project?.approvedFilmReleaseSeal]
  ];
  return {
    projectId:project.id,title:project.title||"Untitled Film",
    auditedAt:new Date().toISOString(),
    complete:stages.every(x=>x[2]),
    stages:stages.map(([key,name,complete])=>({key,name,complete})),
    sealId:project?.approvedFilmReleaseSeal?.sealId||null,
    approvalId:project?.approvedFilmReleaseApproval?.approvalId||null,
    snapshotId:project?.approvedFilmReleaseSnapshot?.snapshotId||null
  };
}
function writeReleaseAudit(project){
  const audit=buildReleaseAudit(project);
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,`release_audit_${Date.now()}.json`);
  fs.writeFileSync(file,JSON.stringify(audit,null,2));
  return {...audit,auditPath:file};
}
module.exports={buildReleaseAudit,writeReleaseAudit};
