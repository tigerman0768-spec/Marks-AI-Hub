const fs=require("fs");
const path=require("path");
const DIR=path.join(process.cwd(),"final-render-jobs");
const processes=new Map();

function statePath(jobId){fs.mkdirSync(DIR,{recursive:true});return path.join(DIR,`${jobId}.process.json`);}
function writeState(jobId,data){fs.writeFileSync(statePath(jobId),JSON.stringify({...data,updatedAt:new Date().toISOString()},null,2));}
function readState(jobId){try{return JSON.parse(fs.readFileSync(statePath(jobId),"utf8"));}catch{return null;}}
function registerProcess(jobId,child,meta={}){
  processes.set(jobId,child);
  writeState(jobId,{jobId,pid:child.pid,status:"running",...meta});
  child.on("close",(code,signal)=>{
    writeState(jobId,{jobId,pid:child.pid,status:"exited",exitCode:code,signal});
    processes.delete(jobId);
  });
  return child;
}
function getProcess(jobId){return processes.get(jobId)||null;}
function getProcessState(jobId){return readState(jobId);}
function unregisterProcess(jobId){processes.delete(jobId);}
function cancelProcess(jobId){
  const child=getProcess(jobId);
  if(!child){
    const state=readState(jobId);
    return {cancelled:false,reason:"process_not_owned",state};
  }
  try{
    writeState(jobId,{jobId,pid:child.pid,status:"stopping"});
    child.kill("SIGTERM");
    setTimeout(()=>{try{if(!child.killed)child.kill("SIGKILL");}catch{}},5000);
  }catch(error){return {cancelled:false,reason:error.message};}
  return {cancelled:true,pid:child.pid};
}
module.exports={registerProcess,getProcess,getProcessState,unregisterProcess,cancelProcess};
