const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function transitionFilter(items){
  if(items.length===1)return `[0:v]setpts=PTS-STARTPTS[vout]`;
  let filters=[],labels=[];
  items.forEach((_,i)=>filters.push(`[${i}:v]setpts=PTS-STARTPTS[v${i}]`));
  labels.push("[v0]");
  for(let i=1;i<items.length;i++){
    const prev=items[i-1], cur=items[i];
    const type=String(cur.transition||"cut");
    const d=Math.max(0,Math.min(5,Number(cur.transitionDuration||0)));
    if(!d||type==="cut"){labels.push(`[v${i}]`);continue;}
    const out=`x${i}`;
    const offset=Math.max(0,items.slice(0,i).reduce((n,x)=>n+Number(x.renderedDuration||x.targetDuration||x.duration||0),0)-d);
    filters.push(`${labels.pop()}[v${i}]xfade=transition=${type==="fade"?"fade":type==="dip-to-black"?"fade":"dissolve"}:duration=${d}:offset=${offset.toFixed(2)}[${out}]`);
    labels.push(`[${out}]`);
  }
  filters.push(`${labels[0]}format=yuv420p[vout]`);
  return filters.join(";");
}
function renderTransitions(items,outPath){
  return new Promise((resolve,reject)=>{
    const args=["-y"];
    items.forEach(x=>args.push("-i",x.clipPath));
    args.push("-filter_complex",transitionFilter(items),"-map","[vout]",
      "-an","-c:v","libx264","-preset","veryfast","-crf","18","-movflags","+faststart",outPath);
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});
    let err="";p.stderr.on("data",d=>err+=d);
    p.on("close",code=>code===0?resolve({path:outPath}):reject(new Error(err.slice(-3500))));
  });
}
async function renderAiTransitions(project={},options={}){
  const items=(project.renderedAiEdit?.items||[]).filter(x=>x.clipPath&&fs.existsSync(x.clipPath)).sort((a,b)=>Number(a.order||0)-Number(b.order||0));
  if(!items.length)throw new Error("no rendered AI edit clips available");
  const dir=options.outputDir||path.join(process.cwd(),"output");
  fs.mkdirSync(dir,{recursive:true});
  const outputPath=options.outputPath||path.join(dir,`${project.id}-ai-final-transitioned.mp4`);
  const result=await renderTransitions(items,outputPath);
  return {projectId:project.id,outputPath:result.path,clipCount:items.length,
    transitions:items.map(x=>({order:x.order,type:x.transition||"cut",duration:Number(x.transitionDuration||0)})),
    createdAt:new Date().toISOString(),engine:"ai-transition-renderer"};
}
module.exports={renderAiTransitions,renderTransitions,transitionFilter};
