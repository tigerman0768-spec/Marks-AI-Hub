const fs=require("fs"),path=require("path");
function registerProjectRecentRoutes(app){
 app.get("/api/projects/recent",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});
  const limit=Math.min(Math.max(Number(req.query.limit||10),1),50);
  const projects=fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"))}catch{return null}}).filter(Boolean).sort((a,b)=>String(b.updatedAt||"").localeCompare(String(a.updatedAt||""))).slice(0,limit);
  res.json({count:projects.length,projects:projects.map(p=>({id:p.id,title:p.title||"Untitled Film",status:p.status||"draft",genre:p.genre||"Drama",length:p.length||5,updatedAt:p.updatedAt||null,favourite:p.favourite===true}))});
 });
}
module.exports={registerProjectRecentRoutes};
