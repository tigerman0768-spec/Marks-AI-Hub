const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
const queue=require("./final_render_worker_queue");

function registerFinalRenderExecutionRoutes(app){
  app.post("/api/projects/:id/final-render/execute",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q?.workerJobId)return res.status(409).json({error:"render has not been dispatched"});
    if(!["dispatched","running"].includes(q.status))
      return res.status(409).json({error:"render is not executable in its current state",status:q.status});
    const active=queue.activeJobs();
    const job=active.find(x=>x.id===q.workerJobId)||queue.queuedJobs().find(x=>x.id===q.workerJobId);
    if(!job)return res.status(409).json({error:"worker job is not present"});
    q.status="running";q.stage="execution_requested";q.progress=Math.max(Number(q.progress)||0,1);
    q.executionRequestedAt=new Date().toISOString();
    saveProject(dir,p);
    res.status(202).json({projectId:p.id,workerJobId:q.workerJobId,status:q.status,stage:q.stage});
  });

  app.post("/api/projects/:id/final-render/complete",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q)return res.status(409).json({error:"no render queue record"});
    const output=String(req.body?.outputPath||q.outputPath||"");
    if(!output||!fs.existsSync(output))
      return res.status(409).json({error:"render output file does not exist",outputPath:output});
    q.outputPath=output;q.outputExists=true;q.progress=100;q.stage="complete";
    q.status="completed";q.completedAt=new Date().toISOString();q.error=null;
    p.finalRenderOutput=output;p.finalRenderReady=true;
    saveProject(dir,p);
    res.json({projectId:p.id,completed:true,outputPath:output,queue:q});
  });
}
module.exports={registerFinalRenderExecutionRoutes};
