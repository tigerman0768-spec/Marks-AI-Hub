const path=require('path');
const {saveProject}=require('./film_projects');

function recordIntegrityVerification(project, verification, dir){
  const history=Array.isArray(project?.releasePackageIntegrityHistory)?project.releasePackageIntegrityHistory.slice():[];
  const entry={
    verificationId:`verify_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
    checkedAt:verification?.checkedAt||new Date().toISOString(),
    verified:Boolean(verification?.verified),
    reason:verification?.reason||null,
    package:verification?.package||null,
    fileCount:Number(verification?.manifest?.fileCount||verification?.files?.length||0),
    failedFiles:Array.isArray(verification?.files)?verification.files.filter(f=>!f.exists||!f.hashMatches||!f.sizeMatches).map(f=>f.name):[]
  };
  history.unshift(entry);
  if(history.length>50)history.length=50;
  const updated=saveProject(dir,{...project,releasePackageIntegrityHistory:history});
  return {entry,history,projectId:updated.id};
}
function getIntegrityHistory(project){
  return {projectId:project?.id||null,title:project?.title||'Untitled Film',count:Array.isArray(project?.releasePackageIntegrityHistory)?project.releasePackageIntegrityHistory.length:0,history:Array.isArray(project?.releasePackageIntegrityHistory)?project.releasePackageIntegrityHistory:[]};
}
module.exports={recordIntegrityVerification,getIntegrityHistory};
