const fs=require("fs");

function createRunwayVideoProvider(options={}){
  const client=options.client;
  const model=options.model||process.env.RUNWAY_VIDEO_MODEL||"gen4.5";
  const duration=Number(options.defaultDuration||5);
  const ratio=options.aspectRatio||"16:9";

  return {
    name:"runway",
    async submit(job){
      if(!client||!client.tasks||typeof client.tasks.create!=="function"){
        throw new Error("Runway client is not configured");
      }
      const input={
        model:job.model||model,
        promptText:job.prompt,
        duration:Number(job.duration||duration),
        ratio:job.aspectRatio||ratio
      };
      const task=await client.tasks.create({type:"video",input});
      return task.id||task.taskId;
    },
    async poll(taskId){
      if(!client||!client.tasks||typeof client.tasks.retrieve!=="function"){
        throw new Error("Runway client is not configured");
      }
      const task=await client.tasks.retrieve(taskId);
      const status=String(task.status||"").toLowerCase();
      if(status==="succeeded"||status==="completed"){
        const output=task.output||task.outputs||task.result;
        return {status:"completed",output};
      }
      if(status==="failed"||status==="error"){
        return {status:"failed",error:task.failure||task.error||"Runway task failed"};
      }
      return {status:"processing",raw:task};
    }
  };
}
module.exports={createRunwayVideoProvider};
