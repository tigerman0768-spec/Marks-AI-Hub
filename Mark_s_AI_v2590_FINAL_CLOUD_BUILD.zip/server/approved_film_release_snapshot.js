const fs=require("fs");
const crypto=require("crypto");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");

function createReleaseSnapshot(project){
  const lock=project?.approvedFilmDeliveryLock;
  if(!lock)return {ready:false,reason:"verified delivery must be locked first"};
  if(!lock.lockPath||!fs.existsSync(lock.lockPath))return {ready:false,reason:"delivery lock record is missing"};
  if(!lock.filmPath||!fs.existsSync(lock.filmPath))return {ready:false,reason:"locked film file is missing"};
  const stat=fs.statSync(lock.filmPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(lock.filmPath)).digest("hex");
  if(Number(lock.bytes)!==stat.size||lock.sha256!==sha)
    return {ready:false,reason:"locked film no longer matches its recorded identity"};
  const snapshotId=`release_snapshot_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const snapshot={
    snapshotId,projectId:project.id,deliveryId:lock.deliveryId,lockId:lock.lockId,
    title:project.title||"Untitled Film",filename:lock.filename,
    bytes:stat.size,sha256:sha,createdAt:new Date().toISOString(),status:"sealed-snapshot"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const snapshotPath=path.join(dir,`${snapshotId}.json`);
  fs.writeFileSync(snapshotPath,JSON.stringify(snapshot,null,2));
  project.approvedFilmReleaseSnapshot={...snapshot,snapshotPath};
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,snapshot};
}
module.exports={createReleaseSnapshot};
