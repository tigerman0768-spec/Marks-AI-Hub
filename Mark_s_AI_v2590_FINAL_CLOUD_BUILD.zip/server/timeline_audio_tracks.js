function normaliseTrack(t={}){
  return {id:String(t.id||""),name:String(t.name||"Audio"),
    path:String(t.path||""),type:t.type==="sfx"?"sfx":"music",
    start:Math.max(0,Number(t.start||0)),
    end:t.end==null?null:Math.max(0,Number(t.end)),
    volume:Math.max(0,Math.min(2,Number(t.volume??0.35))),
    fadeIn:Math.max(0,Math.min(10,Number(t.fadeIn||0))),
    fadeOut:Math.max(0,Math.min(10,Number(t.fadeOut||0)))};
}
function buildTrackFilters(tracks=[],duration=0){
  const filters=[];
  tracks.forEach((raw,i)=>{
    const t=normaliseTrack(raw);
    const delay=Math.round(t.start*1000);
    let chain=`[${i}:a]aresample=48000,volume=${t.volume}`;
    if(t.fadeIn>0)chain+=`,afade=t=in:st=${t.start}:d=${t.fadeIn}`;
    if(t.fadeOut>0&&t.end!=null)chain+=`,afade=t=out:st=${Math.max(t.start,t.end-t.fadeOut)}:d=${t.fadeOut}`;
    chain+=`,adelay=${delay}|${delay}[track${i}]`;
    filters.push(chain);
  });
  return filters;
}
module.exports={normaliseTrack,buildTrackFilters};
