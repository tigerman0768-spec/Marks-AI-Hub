const path = require("path");
const { getProject } = require("./film_projects");

function registerVideoGenerationPreflightRoutes(app) {
  app.get("/api/projects/:id/video-generation-preflight", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const manifest = p.videoGenerationManifest;
    const providerConfigured = Boolean(
      process.env.RUNWAY_API_KEY || process.env.VIDEO_API_KEY
    );

    const checks = [
      ["promptPack", Boolean(p.aiPromptPack)],
      ["manifest", Boolean(manifest && Array.isArray(manifest.shots) && manifest.shots.length)],
      ["provider", providerConfigured],
      ["settings", Boolean(manifest?.settings?.aspectRatio && manifest?.settings?.resolution)]
    ];

    const missing = checks.filter(c => !c[1]).map(c => c[0]);
    res.json({
      projectId: p.id,
      provider: manifest?.provider || "runway",
      ready: missing.length === 0,
      mode: providerConfigured ? "provider-ready" : "dry-run",
      missing,
      checks: Object.fromEntries(checks),
      shotCount: manifest?.shots?.length || 0
    });
  });
}

module.exports = { registerVideoGenerationPreflightRoutes };
