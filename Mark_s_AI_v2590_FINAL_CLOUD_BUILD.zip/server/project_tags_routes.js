const fs=require("fs"),path=require("path");
function registerProjectTagsRoutes(app){
 app.get("/api/projects/:id/tags",(req,res)=>{const f=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(f))return res.status(404).json({error:"project not found"});const p=JSON.parse(fs.readFileSync(f,"utf8"));res.json({projectId:p.id,tags:Array.isArray(p.tags)?p.tags:[]});});
 app.patch("/api/projects/:id/tags",(req,res)=>{const f=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(f))return res.status(404).json({error:"project not found"});const p=JSON.parse(fs.readFileSync(f,"utf8"));const tags=Array.isArray(req.body?.tags)?req.body.tags.map(x=>String(x).trim()).filter(Boolean).slice(0,30):[];p.tags=[...new Set(tags)];p.updatedAt=new Date().toISOString();fs.writeFileSync(f,JSON.stringify(p,null,2));res.json({projectId:p.id,tags:p.tags});});
}
module.exports={registerProjectTagsRoutes};
