function normaliseLocation(location = {}) {
  return {
    id: location.id || location.name || `location-${Math.random().toString(36).slice(2,8)}`,
    name: location.name || "Location",
    description: location.description || "",
    architecture: location.architecture || "",
    geography: location.geography || "",
    timePeriod: location.timePeriod || "",
    weather: location.weather || "",
    timeOfDay: location.timeOfDay || "",
    props: Array.isArray(location.props) ? location.props : [],
    palette: location.palette || "",
    referenceImage: location.referenceImage || null
  };
}

function buildWorldBible(locations = []) {
  const bible = {};
  for (const location of locations) {
    const n = normaliseLocation(location);
    bible[n.id] = n;
  }
  return bible;
}

function buildWorldContinuityPrompt(scene, bible = {}) {
  const names = scene.locations || (scene.location ? [scene.location] : []);
  return names.map(name => {
    const loc = Object.values(bible).find(x => x.name === name || x.id === name);
    if (!loc) return `location ${name}: maintain environmental continuity`;
    return [
      `${loc.name}`,
      loc.description && `setting ${loc.description}`,
      loc.architecture && `architecture ${loc.architecture}`,
      loc.geography && `geography ${loc.geography}`,
      loc.timePeriod && `time period ${loc.timePeriod}`,
      loc.weather && `weather ${loc.weather}`,
      loc.timeOfDay && `time of day ${loc.timeOfDay}`,
      loc.props.length && `important props ${loc.props.join(", ")}`,
      loc.palette && `visual palette ${loc.palette}`,
      loc.referenceImage && `use location reference ${loc.referenceImage}`
    ].filter(Boolean).join(", ");
  }).join(". ");
}

function applyWorldContinuity(jobs = [], scenes = [], locations = []) {
  const bible = buildWorldBible(locations);
  const sceneMap = new Map(scenes.map(s => [s.id, s]));
  return jobs.map(job => {
    const scene = sceneMap.get(job.sceneId) || {};
    const continuity = buildWorldContinuityPrompt(scene, bible);
    return {
      ...job,
      worldContinuity: continuity,
      prompt: continuity
        ? `${job.prompt}. ${continuity}. Preserve location layout, props, weather and time-of-day continuity between shots.`
        : `${job.prompt}. Preserve environmental continuity between shots.`
    };
  });
}

module.exports = { buildWorldBible, buildWorldContinuityPrompt, applyWorldContinuity };
