const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const resolutions=["720p","1080p","4K"];
const ratios=["16:9","9:16","1:1"];
function registerFinalRenderConfigRoutes(app){
  app.get("/api/projects/:id/final-render/config",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,config:p.finalRenderConfig||{
      resolution:p.resolution||"1080p",aspectRatio:p.aspectRatio||"16:9",fps:p.fps||24,format:p.exportFormat||"mp4"
    }});
  });
  app.patch("/api/projects/:id/final-render/config",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const old=p.finalRenderConfig||{};
    const c={
      resolution:req.body?.resolution??old.resolution??p.resolution??"1080p",
      aspectRatio:req.body?.aspectRatio??old.aspectRatio??p.aspectRatio??"16:9",
      fps:Number(req.body?.fps??old.fps??p.fps??24),
      format:String(req.body?.format??old.format??p.exportFormat??"mp4")
    };
    if(!resolutions.includes(c.resolution)||!ratios.includes(c.aspectRatio)||![24,25,30,60].includes(c.fps))
      return res.status(400).json({error:"invalid render configuration",resolutions,ratios,fps:[24,25,30,60]});
    p.finalRenderConfig=c;p.finalRenderConfigUpdatedAt=new Date().toISOString();saveProject(dir,p);
    res.json({projectId:p.id,config:c});
  });
}
module.exports={registerFinalRenderConfigRoutes};
