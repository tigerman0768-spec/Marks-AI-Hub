const path=require("path");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");
const {submitRunwayClip}=require("./runway_real_clip_provider");

async function regenerateRealClip(project,clipId,overrides={}){
  const clip=(project.generatedRealClips||[]).find(c=>String(c.clipId)===String(clipId));
  if(!clip)return {ready:false,blockers:["generated clip not found"]};
  if(!clip.request?.prompt && !overrides.prompt)return {ready:false,blockers:["original clip prompt is unavailable"]};
  const prompt=String(overrides.prompt||clip.request?.prompt||"").trim();
  const result=await submitRunwayClip({
    prompt,duration:Number(overrides.duration||clip.request?.duration||5),
    aspectRatio:String(overrides.aspectRatio||clip.request?.aspectRatio||project.aspectRatio||"16:9"),
    model:String(overrides.model||"gen4.5")
  });
  if(!result.ready)return result;
  const record={
    regenerationId:`clip_regen_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    sourceClipId:clipId,provider:"runway",taskId:result.taskId,status:"submitted",
    prompt,duration:Number(overrides.duration||clip.request?.duration||5),
    aspectRatio:String(overrides.aspectRatio||clip.request?.aspectRatio||project.aspectRatio||"16:9"),
    createdAt:new Date().toISOString()
  };
  project.realClipRegenerations=[...(project.realClipRegenerations||[]),record];
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,regeneration:record};
}
module.exports={regenerateRealClip};
