const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function buildDialogueTracks(scenePlans=[]){
  const tracks=[];
  for(const scene of scenePlans){
    for(const voice of (scene.voiceAssets||[])){
      if(!voice.localPath) continue;
      if(!fs.existsSync(voice.localPath)||!fs.statSync(voice.localPath).size)
        throw new Error(`dialogue asset unavailable: ${voice.localPath}`);
      tracks.push({
        path:voice.localPath,
        start:Number(voice.filmStart ?? scene.offset ?? 0),
        duration:Number(voice.duration||3),
        volume:Number(voice.volume ?? 1)
      });
    }
  }
  return tracks;
}

function buildDialogueMixArgs(videoPath,tracks,outputPath,ffmpeg){
  if(!videoPath||!fs.existsSync(videoPath)) throw new Error("video file unavailable");
  if(!outputPath) throw new Error("outputPath required");
  const bin=ffmpeg||process.env.FFMPEG_BIN||"ffmpeg";
  const args=["-y","-i",videoPath];
  tracks.forEach(t=>args.push("-i",t.path));
  if(!tracks.length) return {ffmpeg:bin,args:[...args,"-c","copy","-movflags","+faststart",outputPath]};
  const filters=tracks.map((t,i)=>{
    const delay=Math.max(0,Math.round(t.start*1000));
    return `[${i+1}:a]adelay=${delay}|${delay},volume=${t.volume}[d${i}]`;
  }).join(";");
  const labels=tracks.map((_,i)=>`[d${i}]`).join("");
  const filter=`${filters};${labels}amix=inputs=${tracks.length}:duration=longest:dropout_transition=2:normalize=0[aout]`;
  return {ffmpeg:bin,args:[...args,"-filter_complex",filter,"-map","0:v:0","-map","[aout]",
    "-c:v","copy","-c:a","aac","-b:a","192k","-shortest","-movflags","+faststart",outputPath]};
}

async function mixDialogue({videoPath,scenePlans,outputPath,ffmpeg}){
  const tracks=buildDialogueTracks(scenePlans||[]);
  const cmd=buildDialogueMixArgs(videoPath,tracks,outputPath,ffmpeg);
  return new Promise((resolve,reject)=>{
    const child=spawn(cmd.ffmpeg,cmd.args,{stdio:["ignore","ignore","pipe"]});
    let err=""; child.stderr.on("data",d=>err+=d.toString());
    child.on("error",reject);
    child.on("close",code=>{
      if(code!==0)return reject(new Error(`dialogue mix failed (${code}): ${err.slice(-1800)}`));
      if(!fs.existsSync(outputPath)||!fs.statSync(outputPath).size)
        return reject(new Error("dialogue output is empty"));
      resolve({outputPath,tracks:tracks.length,bytes:fs.statSync(outputPath).size});
    });
  });
}
module.exports={buildDialogueTracks,buildDialogueMixArgs,mixDialogue};
