const {getProject,saveProject}=require("./film_projects");

function resumeProject(dir,id){
  const project=getProject(dir,id);
  if(!project) return null;
  return {
    project,
    creatorState:{
      id:project.id,title:project.title,idea:project.idea,genre:project.genre,
      length:project.length,style:project.style,aspectRatio:project.aspectRatio,
      screenplay:project.screenplay,characters:project.characters,scenes:project.scenes,
      status:project.status
    }
  };
}
function saveCreatorState(dir,id,state={}){
  return saveProject(dir,{...state,id,status:state.status||"draft"});
}
module.exports={resumeProject,saveCreatorState};
