const crypto=require("crypto");

const shotBeats=["establish","observe","reaction","interaction","emotion","consequence"];
const pacingModes=["slow","measured","normal","fast","urgent"];

function buildPerformancePlan(scene={},dialogueTracks=[],shots=[]){
  const lines=dialogueTracks.filter(x=>x.sceneId===scene.id);
  const shotList=shots.length?shots:[];
  return {
    id:crypto.randomUUID(),
    sceneId:scene.id||"scene",
    sceneTitle:scene.title||"Scene",
    pacing:pacingModes.includes(scene.pacing)?scene.pacing:"normal",
    emotionalArc:scene.emotionalArc||scene.emotion||"natural",
    beats:lines.map((line,i)=>({
      dialogueId:line.id,
      character:line.character,
      emotion:line.emotion||"neutral",
      intensity:line.intensity||"medium",
      beat:shotBeats[i%shotBeats.length],
      reactionRequired:i>0,
      pauseBefore:Number(line.pauseBefore||0),
      pauseAfter:Number(line.pauseAfter||0)
    })),
    shotDirection:shotList.map((shot,i)=>({
      shotId:shot.id,
      shotNumber:shot.shotNumber||i+1,
      shotType:shot.shotType||"medium",
      cameraMovement:shot.cameraMovement||"locked-off",
      beat:shotBeats[i%shotBeats.length],
      performanceFocus:lines[i%Math.max(lines.length,1)]?.character||"ensemble"
    }))
  };
}
function buildFilmPerformancePlan(project={},dialogueTracks=[],directorPlan=[]){
  return (project.scenes||[]).map(scene=>{
    const shots=(directorPlan.find(x=>x.sceneId===scene.id)||{}).shots||[];
    return buildPerformancePlan(scene,dialogueTracks,shots);
  });
}
module.exports={buildPerformancePlan,buildFilmPerformancePlan};
