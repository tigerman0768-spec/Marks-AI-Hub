const fs=require("fs"),path=require("path");
function registerProjectSortRoutes(app){
 app.get("/api/projects/sorted",(req,res)=>{
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});const sort=String(req.query.sort||"updated");
  const projects=fs.readdirSync(dir).filter(f=>f.endsWith(".json")).map(f=>{try{return JSON.parse(fs.readFileSync(path.join(dir,f),"utf8"))}catch{return null}}).filter(Boolean);
  projects.sort((a,b)=>sort==="title"?String(a.title||"").localeCompare(String(b.title||"")):sort==="length"?Number(a.length||0)-Number(b.length||0):String(b.updatedAt||"").localeCompare(String(a.updatedAt||"")));
  res.json({sort,projects:projects.map(p=>({id:p.id,title:p.title||"Untitled Film",status:p.status||"draft",genre:p.genre||"Drama",length:p.length||5,updatedAt:p.updatedAt||null,favourite:p.favourite===true}))});
 });
}
module.exports={registerProjectSortRoutes};
