const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function renderAssembly(items,outPath){
  return new Promise((resolve,reject)=>{
    if(!items.length) return reject(new Error("no rendered clips"));
    const args=["-y"];
    for(const item of items) args.push("-i",item.clipPath);
    const filter=[];
    items.forEach((_,i)=>filter.push(`[${i}:v]setpts=PTS-STARTPTS[v${i}]`));
    const concatInputs=items.map((_,i)=>`[v${i}]`).join("");
    filter.push(`${concatInputs}concat=n=${items.length}:v=1:a=0[vout]`);
    args.push("-filter_complex",filter.join(";"),"-map","[vout]",
      "-an","-c:v","libx264","-preset","veryfast","-crf","18","-movflags","+faststart",outPath);
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});
    let err=""; p.stderr.on("data",d=>err+=d);
    p.on("close",code=>code===0?resolve({path:outPath}):reject(new Error(err.slice(-3000))));
  });
}

async function assembleAiFilm(project={},options={}){
  const rendered=project.renderedAiEdit?.items||[];
  const items=rendered.filter(x=>x.clipPath&&fs.existsSync(x.clipPath)).sort((a,b)=>Number(a.order||0)-Number(b.order||0));
  if(!items.length) throw new Error("no rendered AI edit clips available");
  const outputDir=options.outputDir||path.join(process.cwd(),"output");
  fs.mkdirSync(outputDir,{recursive:true});
  const outputPath=options.outputPath||path.join(outputDir,`${project.id}-ai-edit.mp4`);
  const result=await renderAssembly(items,outputPath);
  return {projectId:project.id,outputPath:result.path,clipCount:items.length,
    totalDuration:items.reduce((n,x)=>n+Number(x.renderedDuration||0),0),
    transitions:items.slice(1).map(x=>({order:x.order,type:x.transition||"cut"})),
    createdAt:new Date().toISOString(),engine:"ai-film-assembler"};
}
module.exports={assembleAiFilm,renderAssembly};
