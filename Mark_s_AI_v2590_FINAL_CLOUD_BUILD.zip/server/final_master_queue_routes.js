const path=require("path");
const {getProject}=require("./film_projects");
const {enqueue}=require("./final_render_worker_queue");
function registerFinalMasterQueueRoutes(app){
  app.post("/api/projects/:id/final-master/queue",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const p=getProject(dir,req.params.id);
      if(!p)return res.status(404).json({error:"project not found"});
      if(!p.finalFinishingPlan)return res.status(400).json({error:"prepare final finishing first"});
      const job=enqueue(p,{outputDir:req.body?.outputDir});
      res.status(202).json({projectId:p.id,queueId:job.id,status:job.status});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalMasterQueueRoutes};
