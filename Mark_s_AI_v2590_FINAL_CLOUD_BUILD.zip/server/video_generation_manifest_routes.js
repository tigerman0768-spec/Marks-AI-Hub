const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerVideoGenerationManifestRoutes(app) {
  app.post("/api/projects/:id/video-generation-manifest", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const pack = p.aiPromptPack;
    if (!pack || !Array.isArray(pack.shots) || !pack.shots.length) {
      return res.status(409).json({ error: "create an AI prompt pack first" });
    }

    const requestedProvider = String(req.body?.provider || "runway");
    const provider = requestedProvider.toLowerCase();
    const supported = ["runway"];
    if (!supported.includes(provider)) {
      return res.status(400).json({ error: "unsupported video provider", supported });
    }

    const manifest = {
      id: `manifest-${p.id}-${Date.now()}`,
      projectId: p.id,
      provider,
      createdAt: new Date().toISOString(),
      settings: {
        aspectRatio: p.aspectRatio || "16:9",
        resolution: p.resolution || "1080p",
        fps: Number(p.fps || 24)
      },
      shots: pack.shots.map((shot, index) => ({
        index: index + 1,
        id: shot.id || `shot-${index + 1}`,
        scene: shot.scene,
        prompt: shot.prompt,
        duration: Number(shot.duration || 5),
        status: "pending"
      }))
    };

    p.videoGenerationManifest = manifest;
    p.videoGenerationManifestCreatedAt = manifest.createdAt;
    saveProject(path.join(process.cwd(), "projects"), p);

    res.status(201).json(manifest);
  });

  app.get("/api/projects/:id/video-generation-manifest", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    if (!p.videoGenerationManifest) {
      return res.status(404).json({ error: "generation manifest not created" });
    }
    res.json(p.videoGenerationManifest);
  });
}

module.exports = { registerVideoGenerationManifestRoutes };
