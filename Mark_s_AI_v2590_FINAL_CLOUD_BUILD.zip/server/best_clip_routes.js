const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadVersions}=require("./clip_version_manager");
const {selectBestVersions,applyBestVersions}=require("./best_clip_selector");

function registerBestClipRoutes(app){
  app.get("/api/projects/:id/clips/best",(req,res)=>{
    try{
      const pdir=path.join(process.cwd(),"projects");
      const project=getProject(pdir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const record=loadVersions(path.join(process.cwd(),"clip-versions"),project.id);
      const selections=selectBestVersions(record);
      res.json({projectId:project.id,selections});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/best/apply",(req,res)=>{
    try{
      const pdir=path.join(process.cwd(),"projects");
      const project=getProject(pdir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const record=loadVersions(path.join(process.cwd(),"clip-versions"),project.id);
      const selections=selectBestVersions(record);
      project.videoJobs=applyBestVersions(project,selections);
      saveProject(pdir,{...project,status:"best_clips_selected"});
      res.json({projectId:project.id,selections,videoJobs:project.videoJobs});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerBestClipRoutes};
