const path=require("path");
const {listAudio,addAudioRecord,loadAudioRecords,removeAudioRecord}=require("./audio_library");
function registerAudioLibraryRoutes(app){
  const dir=path.join(process.cwd(),"audio-library");
  app.get("/api/audio-library",(req,res)=>res.json({files:listAudio(dir),tracks:loadAudioRecords(dir)}));
  app.post("/api/audio-library/tracks",(req,res)=>{
    try{
      const b=req.body||{};
      if(!b.path)return res.status(400).json({error:"audio path required"});
      res.status(201).json(addAudioRecord(dir,b));
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.delete("/api/audio-library/tracks/:id",(req,res)=>{
    if(!removeAudioRecord(dir,req.params.id))return res.status(404).json({error:"track not found"});
    res.json({ok:true});
  });
}
module.exports={registerAudioLibraryRoutes};
