const path=require("path");
const {getProject}=require("./film_projects");
const {loadVoiceProfiles,upsertVoiceProfile}=require("./character_voice_profiles");
function registerCharacterVoiceProfileRoutes(app){
  const dir=path.join(process.cwd(),"voice-profiles");
  app.get("/api/projects/:id/voice-profiles",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(loadVoiceProfiles(dir,p.id));
  });
  app.patch("/api/projects/:id/voice-profiles",(req,res)=>{
    try{
      const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!p)return res.status(404).json({error:"project not found"});
      if(!req.body?.character)return res.status(400).json({error:"character required"});
      res.json(upsertVoiceProfile(dir,p.id,req.body));
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerCharacterVoiceProfileRoutes};
