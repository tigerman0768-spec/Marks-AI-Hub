const fs=require("fs");
const path=require("path");
const {completeFinalFilm}=require("./complete_final_film_pipeline");
const {inspectFinalFilm}=require("./final_film_quality_inspector");
const {autoRepairFinalFilm}=require("./final_film_auto_repair");
const {registerFinishedFilm}=require("./auto_library");
const {createProgress,updateProgress,finishProgress,registerProcess,unregisterProcess}=require("./final_render_progress");
const {updateJob}=require("./final_render_job_store");

async function smartOneClickFinalRender(project={},options={}){
  const progressId=options.progressId||createProgress(project.id||"unknown");
  const registry=require("./final_render_process_registry");
  if(!options.progressId) updateProgress(progressId,"starting",0,{projectSnapshot:project});
  const stages={render:null,qualityBeforeRepair:null,autoRepair:null,qualityFinal:null,library:null};
  const startedAt=new Date().toISOString();
  try{
    updateProgress(progressId,"rendering final film",20,{
      outputPath:null,projectId:project.id||"unknown",projectSnapshot:project,
      title:project.title,idea:project.idea,genre:project.genre,length:project.length,
      style:project.style,aspectRatio:project.aspectRatio,completeFinalFilm:project.completeFinalFilm
    });
    stages.render=await completeFinalFilm(project,{outputDir:options.outputDir});
    const candidate=stages.render.outputPath; updateProgress(progressId,"rendering final film",45,{outputPath:candidate});
    if(require("./final_render_process_registry").getProcess(progressId)?.cancelRequested){
      finishProgress(progressId,"cancelled",{cancelledAt:new Date().toISOString()});
      return {status:"cancelled",progressId,stages,startedAt,completedAt:new Date().toISOString()};
    }
    updateProgress(progressId,"checking final film",55,{outputPath:candidate});
    stages.qualityBeforeRepair=await inspectFinalFilm(candidate);
    let finalPath=candidate;
    if(stages.qualityBeforeRepair.status!=="passed"){
      updateProgress(progressId,"auto-repairing final film",70);
      const repairProject={...project,completeFinalFilm:{...project.completeFinalFilm,outputPath:candidate}};
      stages.autoRepair=await autoRepairFinalFilm(repairProject,{outputDir:options.outputDir,outputPath:options.repairOutputPath||path.join(options.outputDir||path.dirname(candidate),`${project.id}-smart-final.mp4`)});
      if(stages.autoRepair.repairedPath)finalPath=stages.autoRepair.repairedPath;
    }
    updateProgress(progressId,"final quality validation",85);
    stages.qualityFinal=await inspectFinalFilm(finalPath);
    if(stages.qualityFinal.status==="passed"){
      updateProgress(progressId,"adding to film library",92);
      stages.library=await registerFinishedFilm(
        {...project,filmTitle:project.title||"Untitled Film",duration:stages.qualityFinal.duration},
        {outputPath:finalPath,duration:stages.qualityFinal.duration},
        {dir:path.join(process.cwd(),"films")}
      );
    }
    const status=stages.qualityFinal.status==="passed"?"completed":"needs_review";
    finishProgress(progressId,status,{outputPath:finalPath});
    registry.unregisterProcess(progressId); return {status,progressId,outputPath:finalPath,playable:stages.qualityFinal.playable,stages,startedAt,completedAt:new Date().toISOString()};
  }catch(error){
    finishProgress(progressId,"failed",{error:error.message});
    registry.unregisterProcess(progressId); return {status:"failed",progressId,error:error.message,stages,startedAt,completedAt:new Date().toISOString()};
  }
}
module.exports={smartOneClickFinalRender};

const {enqueue: enqueueFinalRenderJob}=require("./final_render_worker_queue");

function enqueueSmartOneClickFinalRender(project, options={}){
  if(!project || !project.id) throw new Error("project.id required");
  return enqueueFinalRenderJob(project, options);
}
