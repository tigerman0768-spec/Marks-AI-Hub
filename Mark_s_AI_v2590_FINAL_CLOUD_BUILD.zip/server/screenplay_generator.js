function buildScreenplayPrompt(project){
  return [
    "Create a production-ready screenplay from the project below.",
    `Title: ${project.title||"Untitled Film"}`,
    `Genre: ${project.genre||"Drama"}`,
    `Length: ${project.length||5} minutes`,
    `Visual style: ${project.style||"Cinematic"}`,
    `Aspect ratio: ${project.aspectRatio||"16:9"}`,
    `Story idea: ${project.idea||""}`,
    "",
    "Return a structured screenplay with:",
    "1. Main characters with goals, traits and relationships.",
    "2. Locations and time of day.",
    "3. A beginning, escalating middle and satisfying ending.",
    "4. Scene-by-scene action and dialogue.",
    "5. Visual/camera direction suitable for video generation.",
    "6. Emotional beat and continuity notes for every scene.",
    "7. Scene count and pacing appropriate to the requested runtime."
  ].join("\\n");
}

function sceneCountForLength(length){
  const minutes=Number(length||5);
  if(minutes<=1)return 3;
  if(minutes<=5)return 6;
  if(minutes<=10)return 10;
  if(minutes<=30)return 18;
  return 30;
}

function makeCharacter(id,name,role,goal,traits,relationships=[]){
  return {id,name,role,goal,traits,relationships};
}

function createScreenplayDraft(project){
  if(!project||!String(project.idea||"").trim())throw new Error("film idea required");
  const title=project.title||"Untitled Film";
  const genre=project.genre||"Drama";
  const count=sceneCountForLength(project.length);
  const characters=[
    makeCharacter("character-1","Protagonist","main character",
      "Pursue the central goal while overcoming the main conflict.",
      ["determined","human","emotionally grounded"]),
    makeCharacter("character-2","Antagonist","opposing force",
      "Prevent the protagonist from achieving the central goal.",
      ["driven","unpredictable","conflicted"]),
    makeCharacter("character-3","Ally","supporting character",
      "Help the protagonist while pursuing a personal need.",
      ["loyal","practical","empathetic"],
      ["Supports Protagonist"])
  ];
  const phases=count<=3?["opening","conflict","resolution"]:
    Array.from({length:count},(_,i)=>{
      if(i===0)return "opening";
      if(i===count-1)return "resolution";
      if(i<Math.ceil(count*0.35))return "rising_action";
      if(i<Math.ceil(count*0.7))return "escalation";
      return "climax";
    });

  const scenes=phases.map((phase,i)=>{
    const n=i+1;
    const characterIds=n===1?["character-1","character-3"]:
      n===count?["character-1","character-2","character-3"]:
      ["character-1","character-2"];
    const titles={
      opening:"The Beginning",
      rising_action:"The First Turn",
      escalation:"Pressure Builds",
      climax:"The Turning Point",
      resolution:"The Resolution"
    };
    const actions={
      opening:"Establish the world, protagonist and immediate situation.",
      rising_action:"Introduce the first obstacle and force a meaningful choice.",
      escalation:"Complicate the goal, raise the stakes and deepen the conflict.",
      climax:"Bring the central conflict to its decisive confrontation.",
      resolution:"Show the consequences and give the story an emotionally satisfying ending."
    };
    return {
      id:`scene-${n}`,
      number:n,
      title:titles[phase]||`Scene ${n}`,
      location:n%2===0?"Primary story location":"Secondary story location",
      time:n===1?"Day":n===count?"Night":"Later",
      characters:characterIds,
      action:actions[phase],
      dialogue:[
        {character:"Protagonist",text:n===1?"We have to do this.":"There has to be another way."},
        ...(phase==="climax"?[{character:"Antagonist",text:"This ends here."}]:[])
      ],
      visualDirection:{
        shot:"cinematic medium shot",
        movement:phase==="climax"?"slow push-in":"gentle tracking",
        lighting:"cinematic",
        style:project.style||"Cinematic"
      },
      emotionalBeat:phase==="opening"?"curiosity":
        phase==="resolution"?"release":
        phase==="climax"?"high tension":"rising tension",
      continuity:{
        preserveCharacters:characterIds,
        preserveLocation:n%2===0?"Primary story location":"Secondary story location",
        wardrobe:"consistent with previous scene"
      }
    };
  });

  return {
    title,genre,length:Number(project.length||5),style:project.style||"Cinematic",
    aspectRatio:project.aspectRatio||"16:9",
    status:"draft",
    prompt:buildScreenplayPrompt(project),
    characters,
    scenes,
    metadata:{
      sceneCount:scenes.length,
      estimatedRuntimeMinutes:Number(project.length||5),
      generatedAt:new Date().toISOString(),
      generationMode:"structured-production-draft"
    }
  };
}

module.exports={buildScreenplayPrompt,createScreenplayDraft,sceneCountForLength};
