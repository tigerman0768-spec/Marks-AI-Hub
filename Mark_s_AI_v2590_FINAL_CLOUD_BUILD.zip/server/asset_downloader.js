const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

function safeName(name) {
  return String(name || "asset")
    .replace(/[^a-zA-Z0-9._-]+/g, "_")
    .slice(0, 120);
}

async function downloadAsset(url, destinationDir, nameHint = "asset") {
  if (!/^https?:\/\//i.test(url)) throw new Error("asset URL must be HTTP(S)");
  fs.mkdirSync(destinationDir, { recursive: true });

  const response = await fetch(url, { redirect: "follow" });
  if (!response.ok) throw new Error(`asset download failed: ${response.status}`);

  const type = response.headers.get("content-type") || "";
  const ext = type.includes("video") ? ".mp4"
    : type.includes("audio") ? ".mp3"
    : type.includes("image") ? ".png" : "";

  const filename = `${safeName(nameHint)}-${crypto.randomUUID()}${ext}`;
  const target = path.join(destinationDir, filename);
  const buffer = Buffer.from(await response.arrayBuffer());

  if (!buffer.length) throw new Error("downloaded asset is empty");
  fs.writeFileSync(target, buffer);

  return {
    path: target,
    filename,
    bytes: buffer.length,
    contentType: type
  };
}

async function persistJobOutput(job, destinationDir) {
  const output = job && job.output;
  const url = typeof output === "string" ? output : output?.url;
  if (!url) throw new Error(`job ${job?.id || "unknown"} has no output URL`);

  const asset = await downloadAsset(url, destinationDir, job.id || "generated");
  job.localAsset = asset.path;
  job.assetBytes = asset.bytes;
  job.assetContentType = asset.contentType;
  job.status = "stored";
  return asset;
}

module.exports = { downloadAsset, persistJobOutput };
