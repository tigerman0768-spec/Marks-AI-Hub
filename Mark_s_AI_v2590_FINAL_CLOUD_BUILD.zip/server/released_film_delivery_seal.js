const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function sealReleasedFilmDelivery(project){
  const gate=project?.finalMasterReleasedFilmDeliveryGate;
  const lock=project?.finalMasterReleasedFilmDeliveryLock;
  if(!gate?.ready)return {sealed:false,blockers:["final delivery gate must pass"]};
  if(lock?.status!=="locked")return {sealed:false,blockers:["final delivery must be locked"]};
  const output=lock.outputPath;
  if(!output||!fs.existsSync(output))return {sealed:false,blockers:["locked final film file is missing"]};
  const stat=fs.statSync(output);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(output)).digest("hex");
  if(sha!==lock.sha256||stat.size!==Number(lock.bytes))
    return {sealed:false,blockers:["locked film no longer matches its recorded integrity"]};

  const seal={
    sealId:`delivery_seal_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    outputPath:output,bytes:stat.size,sha256:sha,
    gateId:gate.gateId,lockId:lock.lockId,
    sealedAt:new Date().toISOString(),status:"sealed"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_seal");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"delivery_seal.json"),JSON.stringify(seal,null,2));
  project.finalMasterReleasedFilmDeliverySeal=seal;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {sealed:true,seal};
}
module.exports={sealReleasedFilmDelivery};
