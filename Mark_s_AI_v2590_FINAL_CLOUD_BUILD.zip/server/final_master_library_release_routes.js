const path=require("path");
const {getProject}=require("./film_projects");
const {prepareLibraryRelease}=require("./final_master_library_release");
function registerFinalMasterLibraryReleaseRoutes(app){
  app.get("/api/projects/:id/final-render/library-release",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,release:p.finalMasterLibraryRelease||null});
  });
  app.post("/api/projects/:id/final-render/library-release/prepare",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=prepareLibraryRelease(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterLibraryReleaseRoutes};
