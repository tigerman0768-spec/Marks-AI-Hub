const fs=require("fs");
const path=require("path");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createExportPackage(project){
  const e=project?.approvedFilmExport, f=project?.approvedFilmLibraryFilm;
  if(!f?.outputPath||!fs.existsSync(f.outputPath)) return {ready:false,blockers:["completed Film Library film is required"]};
  const stat=fs.statSync(f.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(f.outputPath)).digest("hex");
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","exports");
  fs.mkdirSync(dir,{recursive:true});
  const packageId=`film_package_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const manifest={
    packageVersion:"1.0",packageId,projectId:project.id,
    title:project.title||"Untitled Film",filename:path.basename(f.outputPath),
    bytes:stat.size,sha256:sha,clipCount:Number(f.clipCount||0),
    duration:Number(f.duration||0),createdAt:new Date().toISOString()
  };
  const manifestPath=path.join(dir,`${packageId}.json`);
  fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2));
  const record={...(e||{}),packageId,packageManifestPath:manifestPath,packageManifestSha256:crypto.createHash("sha256").update(JSON.stringify(manifest)).digest("hex"),status:"package-ready"};
  project.approvedFilmExport=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,record,manifest};
}
module.exports={createExportPackage};
