const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function archiveDelivery(project){
  const exp=project.finalMasterDeliveryManifest;
  const receipt=project.finalMasterDeliveryReceipt;
  const lock=project.finalMasterLock;
  if(!exp?.ready||receipt?.status!=="verified"||!lock?.locked)
    return {ready:false,blockers:["verified delivery manifest, receipt and lock are required"]};
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath;
  if(!output||!fs.existsSync(output))return {ready:false,blockers:["final output file is missing"]};
  const bytes=fs.readFileSync(output);
  const sha256=crypto.createHash("sha256").update(bytes).digest("hex");
  if(sha256!==exp.sha256||sha256!==receipt.sha256||sha256!==lock.sha256)
    return {ready:false,blockers:["final output integrity hash does not match delivery evidence"]};
  const dir=path.join(process.cwd(),"projects",String(project.id),"delivery_archive");
  fs.mkdirSync(dir,{recursive:true});
  const record={
    archiveId:`archive_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    filename:exp.filename,bytes:bytes.length,sha256,
    archivedAt:new Date().toISOString(),sourcePath:output,
    status:"archived"
  };
  fs.writeFileSync(path.join(dir,"archive_record.json"),JSON.stringify(record,null,2));
  project.finalMasterDeliveryArchive=record;saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,archive:record};
}
module.exports={archiveDelivery};
