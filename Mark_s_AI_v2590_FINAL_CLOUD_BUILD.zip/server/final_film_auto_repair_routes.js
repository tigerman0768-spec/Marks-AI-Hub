const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {autoRepairFinalFilm}=require("./final_film_auto_repair");
function registerFinalFilmAutoRepairRoutes(app){
  app.post("/api/projects/:id/final-film-auto-repair",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects"),project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=await autoRepairFinalFilm(project);
      saveProject(dir,{...project,finalFilmAutoRepair:result,
        status:result.status==="repaired"?"final_film_repaired":project.status});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/final-film-auto-repair",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(project.finalFilmAutoRepair||{status:"not_run"});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalFilmAutoRepairRoutes};
