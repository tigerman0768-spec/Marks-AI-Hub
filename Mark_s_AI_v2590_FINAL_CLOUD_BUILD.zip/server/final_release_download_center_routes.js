const path=require('path');
const fs=require('fs');
const {getProject}=require('./film_projects');
const {buildFinalReleaseDownloadCenter}=require('./final_release_download_center');
function registerFinalReleaseDownloadCenterRoutes(app){
  app.get('/api/projects/:id/final-render/download-center',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    res.json(buildFinalReleaseDownloadCenter(p));
  });
  app.get('/api/projects/:id/final-render/download-center/film',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    const file=p?.finalMasterFinalReleaseRecord?.outputPath||p?.approvedFilmLibraryFilm?.outputPath;
    if(!p)return res.status(404).json({error:'project not found'});
    if(!file||!fs.existsSync(file))return res.status(404).json({error:'final film file missing'});
    res.download(path.resolve(file),path.basename(file));
  });
  app.get('/api/projects/:id/final-render/download-center/certificate',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    const file=p?.approvedFilmReleaseCertificate?.certificatePath;
    if(!p)return res.status(404).json({error:'project not found'});
    if(!file||!fs.existsSync(file))return res.status(404).json({error:'release certificate missing'});
    res.download(path.resolve(file),path.basename(file));
  });
}
module.exports={registerFinalReleaseDownloadCenterRoutes};
