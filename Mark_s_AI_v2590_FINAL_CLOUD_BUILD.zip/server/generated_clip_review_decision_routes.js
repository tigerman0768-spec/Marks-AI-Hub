const path = require("path");
const { getProject, saveProject } = require("./film_projects");

const allowed = ["pending", "accepted", "rejected", "needs_regeneration"];

function registerGeneratedClipReviewDecisionRoutes(app) {
  app.patch("/api/projects/:id/generated-clips/review-set/:clipId", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const set = p.clipReviewSet;
    if (!set || !Array.isArray(set.clips)) {
      return res.status(404).json({ error: "review set not created" });
    }

    const clip = set.clips.find(c => c.id === req.params.clipId);
    if (!clip) return res.status(404).json({ error: "review clip not found" });

    const status = String(req.body?.reviewStatus || "");
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: "invalid review status", allowed });
    }

    clip.reviewStatus = status;
    clip.reviewNote = req.body?.reviewNote ? String(req.body.reviewNote) : null;
    clip.reviewedAt = new Date().toISOString();
    saveProject(dir, p);
    res.json(clip);
  });
}

module.exports = { registerGeneratedClipReviewDecisionRoutes };
