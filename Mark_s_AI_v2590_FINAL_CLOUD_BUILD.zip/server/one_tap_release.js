function buildOneTapReleasePlan(project){
  const readiness=project?.approvedFilmReleaseReadiness||{};
  const approval=project?.approvedFilmReleaseApproval||{};
  const seal=project?.approvedFilmReleaseSeal||{};
  const certificate=project?.approvedFilmReleaseCertificate||{};
  const manifest=project?.approvedFilmReleaseManifest||{};
  const steps=[];
  if(!readiness.ready) steps.push('readiness');
  else if(!approval.approved) steps.push('approval');
  else if(!seal.sealed) steps.push('seal');
  else if(!(certificate.certificateId||certificate.id)) steps.push('certificate');
  else if(!manifest.manifestPath) steps.push('manifest');
  return {projectId:project?.id||null,complete:steps.length===0,nextStep:steps[0]||null,steps};
}
module.exports={buildOneTapReleasePlan};
