const {executeProductionRun}=require("./provider_runner");

async function runVideoGeneration(run,provider,options={}){
  return executeProductionRun(run,provider,{
    maxRetries:Number(options.maxRetries??2),
    onWaiting:async(job,result)=>{
      job.providerStatus=result?.status||"processing";
      if(typeof options.onProgress==="function")await options.onProgress(run,job);
    }
  });
}
module.exports={runVideoGeneration};
