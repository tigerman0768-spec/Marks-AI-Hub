const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const queue=require("./final_render_worker_queue");
function registerFinalRenderWorkerBridgeRoutes(app){
  app.post("/api/projects/:id/final-render/dispatch",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q)return res.status(409).json({error:"final render is not queued"});
    if(q.status!=="queued")return res.status(409).json({error:"only queued renders can be dispatched",status:q.status});
    const job=queue.enqueue(p,{outputDir:req.body?.outputDir});
    q.workerJobId=job.id;q.status="dispatched";q.dispatchedAt=new Date().toISOString();
    saveProject(dir,p);res.status(202).json({projectId:p.id,queue:q,workerJobId:job.id});
  });
  app.post("/api/projects/:id/final-render/claim",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q?.workerJobId)return res.status(409).json({error:"render has not been dispatched"});
    const claimed=queue.claimNext();
    if(!claimed)return res.status(409).json({error:"no worker job available"});
    q.status="running";q.stage="rendering";q.progress=0;q.startedAt=new Date().toISOString();
    saveProject(dir,p);res.json({projectId:p.id,workerJobId:q.workerJobId,claimed});
  });
}
module.exports={registerFinalRenderWorkerBridgeRoutes};
