const fs=require('fs');
const path=require('path');
const crypto=require('crypto');

function buildReleasePackageDashboard(project){
  const release=project?.finalMasterFinalReleaseRecord||project?.approvedFilmReleaseRecord||null;
  const certificate=project?.approvedFilmReleaseCertificate||null;
  const manifest=project?.approvedFilmReleaseManifest||null;
  const center=project?.releaseCenter||null;
  const output=release?.outputPath||project?.approvedFilmLibraryFilm?.outputPath||null;
  let file=null;
  const blockers=[];
  if(output && fs.existsSync(output)){
    const stat=fs.statSync(output);
    const sha=crypto.createHash('sha256').update(fs.readFileSync(output)).digest('hex');
    file={name:path.basename(output),bytes:stat.size,sha256:sha,exists:true};
    if(release?.sha256 && release.sha256!==sha) blockers.push('File SHA-256 does not match the release record.');
    if(release?.bytes!=null && Number(release.bytes)!==stat.size) blockers.push('File size does not match the release record.');
  }else if(output){ blockers.push('Final film file is missing.'); }
  else blockers.push('No final film output is recorded.');

  const verification={
    filePresent:Boolean(file?.exists),
    hashMatches:Boolean(file && (!release?.sha256 || release.sha256===file.sha256)),
    sizeMatches:Boolean(file && (release?.bytes==null || Number(release.bytes)===file.bytes)),
    releaseRecord:Boolean(release),
    certificate:Boolean(certificate?.certificateId||certificate?.id),
    manifest:Boolean(manifest?.manifestPath),
    blocked:blockers.length>0
  };
  const verified=Object.entries(verification).filter(([k])=>!['blocked'].includes(k)).every(([,v])=>v===true) && !verification.blocked;
  return {
    projectId:project?.id||null,
    title:project?.title||'Untitled Film',
    finalRelease:{status:release?.status||'not released',releaseRecordId:release?.releaseRecordId||null,releasedAt:release?.releasedAt||release?.createdAt||null},
    film:{outputPath:output||null,file,mediaPath:output?`/api/projects/${project?.id}/approved-film/library/media`:null},
    certificate:{id:certificate?.certificateId||certificate?.id||null,issued:verification.certificate},
    manifest:{path:manifest?.manifestPath||null,saved:verification.manifest},
    verification:{...verification,verified},
    blockers,
    generatedAt:new Date().toISOString()
  };
}
module.exports={buildReleasePackageDashboard};
