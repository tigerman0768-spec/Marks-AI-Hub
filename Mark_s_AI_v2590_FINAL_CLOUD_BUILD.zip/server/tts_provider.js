const fs=require("fs");
const path=require("path");

async function downloadVoiceAsset(url, destination){
  if(!url) throw new Error("voice output URL required");
  fs.mkdirSync(path.dirname(destination),{recursive:true});
  const res=await fetch(url);
  if(!res.ok) throw new Error(`voice download failed (${res.status})`);
  const buffer=Buffer.from(await res.arrayBuffer());
  if(!buffer.length) throw new Error("voice download returned an empty file");
  fs.writeFileSync(destination,buffer);
  return {path:destination,bytes:buffer.length};
}

function buildRunwayTtsRequest(job, options={}){
  if(!job||!job.text) throw new Error("valid voice job required");
  return {
    model: options.model||"eleven_multilingual_v2",
    text: job.text,
    voice: job.voice||"default",
    language: job.language||"en-GB"
  };
}

async function generateAndStoreVoice({client,job,assetsDir,outputUrl}){
  if(!client||!client.textToSpeech||typeof client.textToSpeech.create!=="function")
    throw new Error("TTS client is not configured");
  const request=buildRunwayTtsRequest(job);
  const task=await client.textToSpeech.create(request);
  if(!task||!task.id) throw new Error("TTS provider did not return a task id");
  const result={taskId:task.id,jobId:job.id,status:"submitted"};
  if(outputUrl){
    const ext=".mp3";
    const destination=path.join(assetsDir,`voice_${job.id}${ext}`);
    const file=await downloadVoiceAsset(outputUrl,destination);
    result.status="stored"; result.path=file.path; result.bytes=file.bytes;
  }
  return result;
}
module.exports={downloadVoiceAsset,buildRunwayTtsRequest,generateAndStoreVoice};
