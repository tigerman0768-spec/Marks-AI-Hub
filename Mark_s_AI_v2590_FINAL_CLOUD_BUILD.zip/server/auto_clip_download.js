const fs=require("fs");
const path=require("path");
const {downloadClip}=require("./generated_clip_downloader");
const {linkGeneratedClips}=require("./clip_linker");

function providerOutput(job){
  return job?.output?.url||job?.output?.video_url||job?.output?.videoUrl||
    (Array.isArray(job?.output?.output)?job.output.output[0]:null)||
    (typeof job?.output==="string"?job.output:null);
}
async function downloadCompletedClips(project,run,options={}){
  const results=[];
  const jobs=(run?.jobs||[]).filter(j=>j.status==="completed");
  for(const job of jobs){
    if(job.downloadStatus==="downloaded"&&job.clipPath&&fs.existsSync(job.clipPath)){
      results.push({jobId:job.id,status:"already_downloaded",clipPath:job.clipPath});
      continue;
    }
    const url=providerOutput(job);
    if(!url){results.push({jobId:job.id,status:"missing_output"});continue;}
    try{
      const clipPath=await downloadClip(url,project.id,job.id,options);
      job.clipPath=clipPath;job.downloadStatus="downloaded";
      job.downloadedAt=new Date().toISOString();
      job.clipSize=fs.statSync(clipPath).size;
      results.push({jobId:job.id,status:"downloaded",clipPath,bytes:job.clipSize});
    }catch(e){
      job.downloadStatus="failed";job.downloadError=e.message;
      results.push({jobId:job.id,status:"failed",error:e.message});
    }
  }
  const linked=linkGeneratedClips(project,{...run,jobs});
  return {jobs:linked.jobs||jobs,results};
}
module.exports={downloadCompletedClips,providerOutput};
