const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {summariseRun}=require("./video_generation_monitor");

function registerVideoGenerationMonitorRoutes(app){
  app.get("/api/projects/:id/video-generation/monitor",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    res.json(summariseRun(project.videoGenerationRun||{}));
  });
  app.post("/api/projects/:id/video-generation/jobs/:jobId/retry",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const run=project.videoGenerationRun;
      if(!run)return res.status(400).json({error:"no video generation run"});
      const job=(run.jobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"job not found"});
      job.status="queued";job.error=null;job.providerTaskId=null;
      run.status="running";run.error=null;
      saveProject(dir,{...project,videoGenerationRun:run,status:"video_generation_ready"});
      res.json(summariseRun(run));
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerVideoGenerationMonitorRoutes};
