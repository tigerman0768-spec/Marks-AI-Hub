const path=require("path");
const {createJob,getJob,updateJob,listJobs}=require("./final_render_job_store");
const {smartOneClickFinalRender}=require("./smart_one_click_final_render");
const {handoffFinalRenderToLibrary}=require("./final_render_library_handoff");

const DIR=path.join(process.cwd(),"final-render-jobs");
const MAX_ACTIVE=Math.max(1,Number(process.env.FINAL_RENDER_MAX_WORKERS||1));
let dispatching=false;

function queueJobs(){
  return listJobs(DIR).filter(j=>j&&j.queue);
}
function activeJobs(){
  return queueJobs().filter(j=>["claimed","running","recovering"].includes(j.status));
}
function queuedJobs(){
  return queueJobs().filter(j=>j.status==="queued").sort((a,b)=>Date.parse(a.enqueuedAt||a.createdAt)-Date.parse(b.enqueuedAt||b.createdAt));
}
function refreshPositions(){
  queuedJobs().forEach((j,i)=>updateJob(DIR,j.id,{queuePosition:i+1}));
}
function enqueue(project,options={}){
  const existing=queueJobs().find(j=>j.projectId===project.id&&["queued","claimed","running","recovering"].includes(j.status));
  if(existing)return existing;
  const id=options.jobId||`queue-${project.id}-${Date.now()}`;
  const now=new Date().toISOString();
  const job=createJob(DIR,{
    id,projectId:project.id,title:project.title||"Untitled Film",status:"queued",queue:true,
    projectSnapshot:project,queuePosition:queuedJobs().length+1,enqueuedAt:now,createdAt:now
  });
  refreshPositions();
  setImmediate(()=>dispatch(options.outputDir));
  return job;
}
function claimNext(){
  if(activeJobs().length>=MAX_ACTIVE)return null;
  const next=queuedJobs()[0];
  if(!next)return null;
  return updateJob(DIR,next.id,{status:"claimed",claimedAt:new Date().toISOString(),queuePosition:0});
}
async function runJob(job,outputDir){
  updateJob(DIR,job.id,{status:"running",startedAt:new Date().toISOString()});
  try{
    const result=await smartOneClickFinalRender(job.projectSnapshot||{id:job.projectId,title:job.title},{progressId:job.id,outputDir});
    const completed=result?.status==="completed"&&!!result?.outputPath;
    updateJob(DIR,job.id,{status:completed?"completed":"failed",finishedAt:new Date().toISOString(),
      result,outputPath:result?.outputPath||null,thumbnailPath:result?.thumbnailPath||null,
      duration:Number(result?.duration||0),libraryId:result?.libraryId||null,
      progress:result?.progress??(completed?100:0),
      stage:result?.stage??(completed?"Completed":"Failed"),
      lifecycle:completed?"final_film_ready":"render_failed"});
    if(completed){
      try{
        const handoff=await handoffFinalRenderToLibrary(job.id,{});
        if(handoff?.libraryId) updateJob(DIR,job.id,{libraryId:handoff.libraryId,libraryRecord:handoff.record});
      }catch(error){
        updateJob(DIR,job.id,{libraryHandoffError:error.message,lifecycle:"final_film_ready"});
      }
    }
  }catch(error){
    updateJob(DIR,job.id,{status:"failed",finishedAt:new Date().toISOString(),error:error.message});
  }finally{
    refreshPositions();
    dispatch(outputDir);
  }
}
async function dispatch(outputDir){
  if(dispatching)return;
  dispatching=true;
  try{
    while(activeJobs().length<MAX_ACTIVE){
      const job=claimNext();
      if(!job)break;
      // Start asynchronously so enqueue/HTTP requests return immediately.
      runJob(job,outputDir);
      if(activeJobs().length>=MAX_ACTIVE)break;
    }
  }finally{dispatching=false;}
}
function cancelQueued(jobId){
  const j=getJob(DIR,jobId);
  if(!j||j.status!=="queued")return j;
  const updated=updateJob(DIR,jobId,{status:"cancelled",queuePosition:0,finishedAt:new Date().toISOString()});
  refreshPositions(); dispatch();
  return updated;
}
function getQueue(){
  refreshPositions();
  return queueJobs().sort((a,b)=>{
    const rank={running:0,claimed:1,recovering:2,queued:3,completed:4,failed:5,cancelled:6};
    return (rank[a.status]??9)-(rank[b.status]??9) ||
      Date.parse(a.enqueuedAt||a.createdAt)-Date.parse(b.enqueuedAt||b.createdAt);
  });
}
function recoverQueue(outputDir){
  for(const j of queueJobs()){
    if(["claimed","running"].includes(j.status) && !activeJobs().some(x=>x.id===j.id)){
      updateJob(DIR,j.id,{status:"queued",requeuedAt:new Date().toISOString()});
    }
  }
  refreshPositions();
  return dispatch(outputDir);
}
function enqueueFinalRender(project,options={}){return enqueue(project,options);}
module.exports={enqueueFinalRender,enqueue,claimNext,dispatch,cancelQueued,getQueue,activeJobs,queuedJobs,recoverQueue,MAX_ACTIVE};
