const fs=require("fs");
const path=require("path");
const {setTransition}=require("./timeline_transitions");

function timelineFile(dir,id){return path.join(dir,`${id}.json`);}
function loadEditableTimeline(dir,id){
  const f=timelineFile(dir,id);
  if(!fs.existsSync(f))return null;
  try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch{return null;}
}
function saveEditableTimeline(dir,id,items){
  fs.mkdirSync(dir,{recursive:true});
  const clean=items.map((x,i)=>({...x,order:i}));
  const record={projectId:id,updatedAt:new Date().toISOString(),items:clean};
  fs.writeFileSync(timelineFile(dir,id),JSON.stringify(record,null,2));
  return record;
}
function editTimeline(dir,id,action,payload={}){
  const current=loadEditableTimeline(dir,id);
  if(!current)throw new Error("timeline not found");
  let items=[...(current.items||[])];
  if(action==="reorder"){
    const from=Number(payload.from),to=Number(payload.to);
    if(!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=items.length||to>=items.length)
      throw new Error("invalid timeline positions");
    const [moved]=items.splice(from,1);items.splice(to,0,moved);
  }else if(action==="remove"){
    const index=Number(payload.index);
    if(!Number.isInteger(index)||index<0||index>=items.length)throw new Error("invalid timeline index");
    items.splice(index,1);
  }else if(action==="transition"){
    items=setTransition(items,Number(payload.index),payload.transition);
  }else if(action==="restore"){
    if(!payload.item)throw new Error("item required");
    items.splice(Math.min(Math.max(Number(payload.index)||items.length,0),items.length),0,payload.item);
  }else throw new Error("unsupported timeline action");
  return saveEditableTimeline(dir,id,items);
}
module.exports={loadEditableTimeline,saveEditableTimeline,editTimeline};
