const fs = require("fs");
const path = require("path");

function escapeSrt(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatSrtTime(seconds) {
  const ms = Math.max(0, Math.round(Number(seconds || 0) * 1000));
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const milli = ms % 1000;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(milli).padStart(3,"0")}`;
}

function buildSrt(cues = []) {
  return cues.map((cue, i) => {
    const start = formatSrtTime(cue.start);
    const end = formatSrtTime(Math.max(cue.end, cue.start + 0.1));
    return `${i + 1}\n${start} --> ${end}\n${escapeSrt(cue.text)}\n`;
  }).join("\n");
}

function buildDialogueCues(dialogue = [], defaultDuration = 3) {
  let cursor = 0;
  return dialogue.map(item => {
    const duration = Number(item.duration || defaultDuration);
    const cue = {
      speaker: item.speaker || "",
      text: item.text || "",
      start: Number(item.start ?? cursor),
      end: Number(item.end ?? (Number(item.start ?? cursor) + duration))
    };
    cursor = cue.end;
    return cue;
  });
}

function writeSrt(filePath, cues) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, buildSrt(cues), "utf8");
  return filePath;
}

module.exports = { buildSrt, buildDialogueCues, writeSrt, formatSrtTime };
