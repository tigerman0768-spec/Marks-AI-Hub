# Mark's AI v1381–1400

- v1381–1390: Added a persistent Final Master Library Release preparation stage.
- v1391–1400: Added live SHA-256 verification and a Flutter Film Library Release screen.
- The library release requires a catalogued final master and a matching current film hash.
- Records library-release ID, catalogue/release IDs, file identity, metadata and preparation timestamp.
- All JavaScript files were checked with node --check.

Full Android compilation still requires the Flutter SDK in the build environment.
