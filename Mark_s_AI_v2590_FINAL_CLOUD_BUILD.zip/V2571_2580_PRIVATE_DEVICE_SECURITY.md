# Mark's AI v2571–2580 — Private Device & Security Center

## Purpose
This milestone makes the app's personal/private-use intent visible in the Android UI and adds a safe configuration-status endpoint.

## Added
- `GET /api/private-device-security` private runtime status endpoint.
- Explicit personal/private mode status.
- Secret protection status: endpoint never returns secret values.
- Boolean configuration checks for OpenAI, Runway and GitHub credentials without exposing values.
- Flutter `PrivateDeviceSecurityScreen` with refresh support.
- Dashboard entry for Private Device & Security.
- Flutter version `1.0.0+2580` and project version `v2580`.

## Safety / privacy
- No API keys, tokens, passwords or secret values are sent to the Flutter screen.
- The endpoint only reports whether supported credentials are configured.
- No public sharing or commercial-distribution workflow was added in this milestone.

## Validation
- All JavaScript files should pass `node --check`.
- Flutter compilation is not claimed unless a Flutter SDK is available in the build environment.
