# Mark's AI v1781–1800

- v1781–1790: Regenerate now submits a new Runway generation using the original clip prompt/settings.
- Regeneration requests receive a new task ID and are persisted separately.
- v1791–1800: Added an Approved Clips Timeline screen backed by approvedGeneratedClips.
- Kept clips are now visible as numbered film-timeline inputs.
- This milestone starts the real loop: generate → download → review → regenerate if needed → keep → timeline.
- Provider completion/download for regenerated tasks still uses the existing Runway task polling/download infrastructure and can be wired to automatically promote regenerated outputs next.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
