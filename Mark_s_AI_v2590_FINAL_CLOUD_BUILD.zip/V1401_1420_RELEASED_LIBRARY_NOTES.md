# Mark's AI v1401–1420

- v1401–1410: Added a persistent released-film index built from project library-release records.
- v1411–1420: Added released-film search and a Flutter Released Films library screen.
- The index only includes library releases whose status is ready_for_library.
- Search supports title, filename and project ID.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK in the build environment.
