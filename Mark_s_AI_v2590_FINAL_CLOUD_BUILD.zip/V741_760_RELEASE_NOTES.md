# Mark's AI v741–760

- v741–750: Added persistent per-shot video-generation job records.
- Jobs track shot ID, scene, prompt, duration, provider, status, progress, provider job ID, clip path and errors.
- Provider submission now creates shot-level records from the persisted manifest when needed.
- v751–760: Added the Flutter Video Generation Jobs monitor with automatic polling and completion counts.
- Jobs can be individually updated through the API for future worker/provider integration.
- All JavaScript files were checked with `node --check`.

Full Android compilation still requires the Flutter SDK in the build environment.
