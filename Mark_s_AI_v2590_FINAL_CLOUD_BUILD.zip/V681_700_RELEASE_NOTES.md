# Mark's AI v681–700

- v681–690: Added video-generation preflight checks.
- v691–700: Added a persistent video-generation launch/audit record and Flutter launch screen.
- The launch layer distinguishes provider-ready mode from dry-run mode.
- Dry-run mode never claims a provider generated video.
- Actual provider submission remains delegated to the existing video-generation orchestrator.
- All JavaScript files were checked with `node --check`.

Full Android compilation still requires the Flutter SDK in the build environment.
