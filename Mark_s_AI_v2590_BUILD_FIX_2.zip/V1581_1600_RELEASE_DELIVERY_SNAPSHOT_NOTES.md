# Mark's AI v1581–1600

- v1581–1590: Added a persistent Final Release Delivery Snapshot.
- v1591–1600: Added a final live hash/size check and snapshot evidence.
- Snapshot capture requires a sealed final delivery.
- The snapshot records film identity, bytes, SHA-256, seal ID, audit-event count and capture time.
- A Flutter Release Delivery Snapshot screen was added.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK.
