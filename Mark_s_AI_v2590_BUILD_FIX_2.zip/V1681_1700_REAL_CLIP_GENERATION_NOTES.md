# Mark's AI v1681–1700

- v1681–1690: Added the Real Clip Generation Bridge.
- Builds a clip request directly from a selected shot card and project settings.
- Uses the existing video-generation orchestrator rather than creating a parallel pipeline.
- Persists real clip-generation job records under the project.
- v1691–1700: Added Generate/Prepare/List API routes and a Flutter Generate Real Clip screen.
- The workflow now has an explicit Generate Clip entry point and queues an orchestrated video job.
- This milestone does NOT claim that an external video provider has successfully returned a video; provider credentials and a working provider adapter are still required for actual remote generation.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
