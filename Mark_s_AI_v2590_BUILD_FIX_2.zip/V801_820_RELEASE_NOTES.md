# Mark's AI v801–820

- v801–810: Added completed-clip synchronisation into the project's generated clip inventory.
- v811–820: Added generated clip inventory/readiness checking and a Flutter clip inventory screen.
- Completed jobs with persisted clip paths can now become generated-clip records.
- Inventory checks whether referenced clip files actually exist on disk.
- Added manual Sync Completed Clips action.
- All JavaScript files were checked with `node --check`.

Full Android compilation still requires the Flutter SDK in the build environment.
