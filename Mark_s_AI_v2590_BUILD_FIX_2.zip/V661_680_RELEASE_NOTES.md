# Mark's AI v661–680

- v661–670: Added the Video Generation Manifest API.
- v671–680: Added the Video Generation Manifest review screen.
- Converts the AI Director prompt pack into a concrete provider request manifest with shot order, prompts, durations and project output settings.
- The manifest is persisted with the project and can be reviewed before provider submission.
- Provider submission remains separate so the app does not falsely report generated video.
- All JavaScript files were checked with `node --check`.

Full Android compilation still requires the Flutter SDK in the build environment.
