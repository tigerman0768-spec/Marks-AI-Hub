$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { Write-Error "Flutter SDK not found."; exit 2 }
if (-not (Test-Path "android/app")) { Write-Error "Android host project is missing. Run: flutter create ." ; exit 3 }
flutter pub get
flutter build apk --release
flutter build appbundle --release
Write-Host "APK: build/app/outputs/flutter-apk/app-release.apk"
Write-Host "AAB: build/app/outputs/bundle/release/app-release.aab"
