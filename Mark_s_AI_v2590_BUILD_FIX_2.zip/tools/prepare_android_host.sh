#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK not found."; exit 2; }

if [ ! -d android/app ]; then
  flutter create --platforms=android --org com.marksai .
fi

flutter pub get
echo "Android host is prepared."
echo "Build APK: flutter build apk --release"
echo "Build AAB: flutter build appbundle --release"
