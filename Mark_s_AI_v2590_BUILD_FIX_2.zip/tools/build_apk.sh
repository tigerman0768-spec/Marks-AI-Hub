#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required to build Mark's AI." >&2
  exit 2
fi

flutter pub get
flutter build apk --release --split-per-abi=false

APK="build/app/outputs/flutter-apk/app-release.apk"
if [ ! -f "$APK" ]; then
  echo "Build finished but APK was not found at $APK" >&2
  exit 3
fi

echo "APK_READY=$ROOT/$APK"
