#!/usr/bin/env bash
set -euo pipefail

command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK is required"; exit 1; }

if [ ! -d android/app ]; then
  flutter create --platforms=android --org com.marksai .
fi

if [ -f android/app/build.gradle.kts ]; then
  sed -i 's/com\.marksai\.marks_ai/com.marksai.app/g' android/app/build.gradle.kts
fi

OLD=android/app/src/main/kotlin/com/marksai/marks_ai
NEW=android/app/src/main/kotlin/com/marksai/app
if [ -d "$OLD" ] && [ ! -d "$NEW" ]; then
  mkdir -p "$(dirname "$NEW")"
  mv "$OLD" "$NEW"
fi

if [ -f "$NEW/MainActivity.kt" ]; then
  sed -i 's/package com\.marksai\.marks_ai/package com.marksai.app/' "$NEW/MainActivity.kt"
fi

flutter pub get
