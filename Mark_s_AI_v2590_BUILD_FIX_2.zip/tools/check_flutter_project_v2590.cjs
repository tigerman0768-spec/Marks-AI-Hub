const fs = require('fs');
const path = require('path');
const root = process.cwd();
const required = [
  'pubspec.yaml',
  'VERSION',
  'lib/main.dart',
  'lib/mark_ai_dashboard_screen.dart',
  '.github/workflows/android-release.yml',
];
for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
}
const version = fs.readFileSync(path.join(root, 'VERSION'), 'utf8').trim();
const pubspec = fs.readFileSync(path.join(root, 'pubspec.yaml'), 'utf8');
if (version !== 'v2590') throw new Error(`VERSION is ${version}, expected v2590`);
if (!/version:\s*1\.0\.0\+2590\b/.test(pubspec)) throw new Error('pubspec version is not 1.0.0+2590');
const main = fs.readFileSync(path.join(root, 'lib/main.dart'), 'utf8');
if (!main.includes("mark_ai_dashboard_screen.dart") || !main.includes('MarkAiDashboardScreen')) {
  throw new Error('lib/main.dart does not launch the MarkAi dashboard');
}
console.log('v2590 Flutter project check: PASS');
