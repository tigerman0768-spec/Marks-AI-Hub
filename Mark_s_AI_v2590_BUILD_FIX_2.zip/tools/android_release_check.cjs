#!/usr/bin/env node
const fs=require("fs"),path=require("path"),cp=require("child_process");
const root=path.resolve(__dirname,"..");
function command(c,args){try{const r=cp.spawnSync(c,args,{encoding:"utf8"});return {installed:r.status===0,output:(r.stdout||r.stderr||"").trim()};}catch(e){return {installed:false,output:e.message};}}
const flutter=command("flutter",["--version"]);
const dart=command("dart",["--version"]);
const adb=command("adb",["version"]);
const androidHome=process.env.ANDROID_HOME||process.env.ANDROID_SDK_ROOT||"";
const pubspec=fs.existsSync(path.join(root,"pubspec.yaml"));
const androidDir=fs.existsSync(path.join(root,"android"));
const result={project:"Mark's AI",releaseTarget:"Android",
apkCommand:"flutter build apk --release",aabCommand:"flutter build appbundle --release",
flutterInstalled:flutter.installed,dartInstalled:dart.installed,adbInstalled:adb.installed,
androidSdkDetected:!!androidHome,pubspecFound:pubspec,androidProjectFound:androidDir,
readyForBuild:Boolean(pubspec&&androidDir&&flutter.installed&&androidHome),
note:"APK/AAB compilation requires Flutter and Android SDK build tools."};
console.log(JSON.stringify(result,null,2));
