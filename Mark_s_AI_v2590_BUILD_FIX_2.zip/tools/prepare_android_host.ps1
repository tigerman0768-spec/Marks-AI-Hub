$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { Write-Error "Flutter SDK not found."; exit 2 }
if (-not (Test-Path "android/app")) { flutter create --platforms=android --org com.marksai . }
flutter pub get
Write-Host "Android host is prepared."
Write-Host "Build APK: flutter build apk --release"
Write-Host "Build AAB: flutter build appbundle --release"
