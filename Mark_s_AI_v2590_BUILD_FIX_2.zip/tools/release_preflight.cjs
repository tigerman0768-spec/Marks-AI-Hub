#!/usr/bin/env node
const fs=require('fs');
const path=require('path');
const cp=require('child_process');
const root=path.resolve(__dirname,'..');
const checks=[];
function add(name,ok,detail){checks.push({name,ok:Boolean(ok),detail});}
add('pubspec.yaml',fs.existsSync(path.join(root,'pubspec.yaml')),'Flutter project metadata present');
add('Android release workflow',fs.existsSync(path.join(root,'.github','workflows','android-release.yml')),'Remote APK/AAB build workflow present');
add('Android release metadata',fs.existsSync(path.join(root,'android_release_metadata.json')),'Release artifact paths documented');
let flutter=false;
try{cp.execFileSync('flutter',['--version'],{stdio:'ignore'});flutter=true;}catch{}
add('Local Flutter SDK',flutter,flutter?'Flutter available':'Not installed in this environment');
const apk=path.join(root,'build','app','outputs','flutter-apk','app-release.apk');
const aab=path.join(root,'build','app','outputs','bundle','release','app-release.aab');
add('Release APK',fs.existsSync(apk),fs.existsSync(apk)?'APK found':'Compile with Flutter/GitHub Actions');
add('Release AAB',fs.existsSync(aab),fs.existsSync(aab)?'AAB found':'Compile with Flutter/GitHub Actions');
const pass=checks.filter(x=>x.ok).length;
const result={version:'v2540',readyForSourceRelease:pass===checks.length,apkAvailable:fs.existsSync(apk),aabAvailable:fs.existsSync(aab),checks};
console.log(JSON.stringify(result,null,2));
process.exit(result.apkAvailable?0:2);
