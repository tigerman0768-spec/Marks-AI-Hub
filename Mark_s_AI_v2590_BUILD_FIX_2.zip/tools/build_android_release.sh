#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

command -v flutter >/dev/null 2>&1 || { echo "Flutter SDK not found."; exit 2; }

if [ ! -d android/app ]; then
  echo "Android host project is missing. Run: flutter create ."
  exit 3
fi

flutter pub get
flutter build apk --release
flutter build appbundle --release

echo "APK: build/app/outputs/flutter-apk/app-release.apk"
echo "AAB: build/app/outputs/bundle/release/app-release.aab"
