# Mark's AI v1461–1480

- v1461–1470: Added a persistent Released Film Delivery Export stage.
- v1471–1480: Added an export manifest with a fresh SHA-256 of the actual final film.
- Export is gated by the existing delivery package and successful release verification.
- The export records the real film path, file size, hash, package ID and manifest evidence.
- This stage prepares a verified export record; it does not duplicate the large video file.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK in the build environment.
