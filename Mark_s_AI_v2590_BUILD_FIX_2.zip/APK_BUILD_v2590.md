# Mark's AI v2590 — real APK build handoff

This milestone is focused on producing the **actual installable Android APK**.

## Local build
From the project root:

```bash
./tools/build_apk.sh
```

The installer is produced at:

`build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions build
The Android release workflow now defaults to `v2590` and publishes versioned APK/AAB artifacts.

The workflow still requires a repository containing this project. This source package itself does **not** contain an APK unless the Flutter build has actually been run.

## Important
Never rename a ZIP/source package to `.apk`. Only the real Flutter build output is an Android installer.
