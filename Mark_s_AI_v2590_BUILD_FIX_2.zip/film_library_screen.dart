import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'final_film_preview.dart';

class FilmLibraryScreen extends StatefulWidget {
  const FilmLibraryScreen({super.key});
  @override State<FilmLibraryScreen> createState()=>_FilmLibraryScreenState();
}
class _FilmLibraryScreenState extends State<FilmLibraryScreen>{
  List<Map<String,dynamic>> films=[]; bool loading=true;
  static const String base='http://10.0.2.2:3000';
  @override void initState(){super.initState();load();}
  Future<void> load() async{
    try{
      final c=HttpClient(); final r=await c.getUrl(Uri.parse('$base/api/films'));
      final res=await r.close(); final body=await res.transform(utf8.decoder).join(); c.close();
      if(res.statusCode>=400)throw Exception(body);
      final d=jsonDecode(body) as Map<String,dynamic>;
      if(mounted)setState(()=>films=List<Map<String,dynamic>>.from(d['films']??[]));
    }catch(_){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not load Film Library')));
    }finally{if(mounted)setState(()=>loading=false);}
  }
  Widget poster(Map<String,dynamic> f){
    final id=f['id']?.toString()??'';
    return ClipRRect(
      borderRadius:BorderRadius.circular(14),
      child:AspectRatio(aspectRatio:16/9,child:id.isEmpty
        ?const ColoredBox(color:Colors.black12,child:Icon(Icons.movie,size:48))
        :Image.network('$base/api/films/$id/thumbnail',fit:BoxFit.cover,
          errorBuilder:(_,__,___)=>const ColoredBox(color:Colors.black12,child:Icon(Icons.movie,size:48)),
          loadingBuilder:(c,child,p)=>p==null?child:const ColoredBox(color:Colors.black12,child:Center(child:CircularProgressIndicator(strokeWidth:2))),)),
    );
  }
  @override Widget build(BuildContext context){
    if(loading)return const Center(child:CircularProgressIndicator());
    if(films.isEmpty)return RefreshIndicator(onRefresh:load,child:ListView(children:[SizedBox(height:220),Center(child:Text('No finished films yet.'))]));
    return RefreshIndicator(onRefresh:load,child:GridView.builder(
      padding:const EdgeInsets.all(12),
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:16,childAspectRatio:.78),
      itemCount:films.length,itemBuilder:(context,i){
        final f=films[i]; final path=f['outputPath']?.toString()??'';
        return InkWell(borderRadius:BorderRadius.circular(14),onTap:path.isEmpty?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Scaffold(
          appBar:AppBar(title:Text(f['title']?.toString()??'Film')),body:FinalFilmPreview(videoPath:path)))),
          child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            poster(f),const SizedBox(height:8),
            Text(f['title']?.toString()??'Untitled Film',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:3),Text(f['status']?.toString()??'completed',style:Theme.of(context).textTheme.bodySmall),
          ]));
      },
    ));
  }
}
