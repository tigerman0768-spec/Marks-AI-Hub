# Mark's AI v1961–1980

- v1961–1970: Added persistent Film Export History (up to 50 records per project).
- Every successful export is recorded with its identity, filename, size, SHA-256 and timestamp.
- v1971–1980: Added a live export-integrity verification endpoint that re-hashes the actual rendered MP4 and compares it with the sealed export record.
- Flutter Export Film screen now has Verify Export Integrity and Export History.
- The export workflow now provides traceability and a final integrity check before sharing.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
