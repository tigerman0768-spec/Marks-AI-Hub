# Mark's AI v1641–1660

- v1641–1650: Added a persistent Final Release Record.
- v1651–1660: Added final live hash/size validation against the sealed delivery record.
- Release creation requires a sealed delivery record.
- The final release records film identity, file size, SHA-256 and source sealed-record ID.
- A Flutter Final Release Record screen was added.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK.
