# Mark's AI v2261–2280

- v2261–2270: Added Release Manifest persistence on the project record and a manifest verifier.
- The verifier re-reads the saved manifest and recalculates its manifest SHA-256.
- v2271–2280: Added the manifest verification API and Flutter Verify Release Manifest action.
- This independently verifies the release manifest itself, not just the underlying MP4.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
