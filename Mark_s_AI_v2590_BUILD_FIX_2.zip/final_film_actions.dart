import 'dart:io';
import 'package:flutter/services.dart';

class FinalFilmActions {
  static const _channel=MethodChannel('marks_ai/final_film');

  static Future<bool> saveToGallery(String path) async {
    if(!File(path).existsSync()) throw Exception('Final film not found');
    return await _channel.invokeMethod<bool>('saveToGallery',{'path':path}) ?? false;
  }

  static Future<void> share(String path) async {
    if(!File(path).existsSync()) throw Exception('Final film not found');
    await _channel.invokeMethod('share',{'path':path});
  }
}
