# Mark's AI v1881–1900

- v1881–1890: Added project-scoped media serving for the completed Film Library MP4.
- v1891–1900: Added a full-screen Flutter Film Library player using video_player.
- Added play/pause and 10-second seek controls.
- Added a Play Film action from the Film Library screen.
- The player uses the actual rendered MP4; it does not create a duplicate copy.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
