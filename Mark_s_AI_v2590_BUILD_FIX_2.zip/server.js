const { registerApprovedFilmShareRoutes } = require("./server/approved_film_share_routes");
const { registerApprovedFilmExportRoutes } = require("./server/approved_film_export_routes");
const { registerApprovedFilmLibraryMediaRoutes } = require("./server/approved_film_library_media_routes");
const { registerApprovedFilmLibraryHandoffRoutes } = require("./server/approved_film_library_handoff_routes");
const { registerApprovedFilmRenderRoutes } = require("./server/approved_film_render_routes");
const { registerApprovedFilmAssemblerRoutes } = require("./server/approved_clips_film_assembler_routes");
const { registerRealClipRegenerationWorkerRoutes } = require("./server/real_clip_regeneration_worker_routes");
const { registerRealClipRegenerationRoutes } = require("./server/real_clip_regeneration_routes");
const { registerRealClipReviewRoutes } = require("./server/real_clip_review_routes");
const { registerRealClipMediaRoutes } = require("./server/real_clip_media_routes");
const { registerRealClipProviderRoutes } = require("./server/real_clip_provider_routes");
const { registerRealClipGenerationRoutes } = require("./server/real_clip_generation_routes");
const { registerReleaseCenterRoutes } = require("./server/released_film_release_center_routes");
const { registerReleasePackageDashboardRoutes } = require("./server/release_package_dashboard_routes");
const { registerFinalReleaseDownloadCenterRoutes } = require("./server/final_release_download_center_routes");
const { registerFinalReleaseTransferPackageRoutes } = require("./server/final_release_transfer_package_routes");
const { registerFinalReleasePackageVerifierRoutes } = require("./server/final_release_package_verifier_routes");
const { registerReleasePackageIntegrityHistoryRoutes } = require("./server/release_package_integrity_history_routes");
const { registerReleasePreflightRoutes } = require("./server/release_preflight_routes");
const { registerReleaseBuildRoutes } = require("./server/release_build_routes");
const { registerReleaseBuildMonitorRoutes } = require("./server/release_build_monitor_routes");
const { registerReleaseBuildArtifactRoutes } = require("./server/release_build_artifact_routes");
const { registerPrivateDeviceSecurityRoutes } = require("./server/private_device_security_routes");
const { registerFinalReleaseRecordRoutes } = require("./server/released_film_delivery_release_record_routes");
const { registerReleasedFilmDeliverySealedRecordRoutes } = require("./server/released_film_delivery_sealed_record_routes");
const { registerReleasedFilmDeliverySnapshotVerifyRoutes } = require("./server/released_film_delivery_snapshot_verify_routes");
const { registerReleasedFilmDeliverySnapshotRoutes } = require("./server/released_film_delivery_snapshot_routes");
const { registerReleasedFilmDeliverySealRoutes } = require("./server/released_film_delivery_seal_routes");
const { registerReleasedFilmDeliveryAuditRoutes } = require("./server/released_film_delivery_audit_routes");
const { registerReleasedFilmDeliveryLockRoutes } = require("./server/released_film_delivery_lock_routes");
const { registerReleasedFilmDeliveryFinalGateRoutes } = require("./server/released_film_delivery_final_gate_routes");
const { registerReleasedFilmDeliveryExportVerifierRoutes } = require("./server/released_film_delivery_export_verifier_routes");
const { registerReleasedFilmDeliveryExportRoutes } = require("./server/released_film_delivery_export_routes");
const { registerReleasedFilmDeliveryPackageRoutes } = require("./server/released_film_delivery_package_routes");
const { registerReleasedFilmVerifierRoutes } = require("./server/released_film_verifier_routes");
const { registerReleasedFilmIndexRoutes } = require("./server/released_film_index_routes");
const { registerFinalMasterLibraryReleaseRoutes } = require("./server/final_master_library_release_routes");
const { registerFinalMasterReleaseCatalogRoutes } = require("./server/final_master_release_catalog_routes");
const { registerFinalMasterReleaseSnapshotRoutes } = require("./server/final_master_release_snapshot_routes");
const { registerFinalMasterReleaseRecordRoutes } = require("./server/final_master_release_record_routes");
const { registerFinalMasterReleaseReadinessRoutes } = require("./server/final_master_release_readiness_routes");
const { registerFinalMasterArchiveVerifyRoutes } = require("./server/final_master_archive_verify_routes");
const { registerFinalMasterDeliveryArchiveRoutes } = require("./server/final_master_delivery_archive_routes");
const { registerFinalMasterDeliveryExportRoutes } = require("./server/final_master_delivery_export_routes");
const { registerFinalMasterLockAuditRoutes } = require("./server/final_master_lock_audit_routes");
const { registerFinalMasterDeliveryLockRoutes } = require("./server/final_master_delivery_lock_routes");
const { registerFinalMasterDeliveryReceiptRoutes } = require("./server/final_master_delivery_receipt_routes");
const { registerFinalMasterDeliveryManifestRoutes } = require("./server/final_master_delivery_manifest_routes");
const { registerFinalMasterDeliveryRoutes } = require("./server/final_master_delivery_routes");
const { registerFinalRenderMasterGateRoutes } = require("./server/final_render_master_gate_routes");
const { registerFinalRenderVerificationRoutes } = require("./server/final_render_verification_routes");
const { startFinalRenderHeartbeat } = require("./server/final_render_worker_heartbeat");
const { registerFinalRenderWorkerReconcileRoutes } = require("./server/final_render_worker_reconcile_routes");
const { registerFinalRenderOutputInspectorRoutes } = require("./server/final_render_output_inspector_routes");
const { registerFinalRenderWorkerAutoRunRoutes } = require("./server/final_render_worker_auto_run_routes");
const { registerFinalRenderExecutionStatusRoutes } = require("./server/final_render_execution_status_routes");
const { registerFinalRenderExecutionRoutes } = require("./server/final_render_execution_routes");
const { registerFinalRenderWorkerSyncRoutes } = require("./server/final_render_worker_sync_routes");
const { registerFinalRenderWorkerBridgeRoutes } = require("./server/final_render_worker_bridge_routes");
const { registerFinalRenderQueueControlRoutes } = require("./server/final_render_queue_control_routes");
const { registerFinalRenderQueueBridgeRoutes } = require("./server/final_render_queue_bridge_routes");
const { registerFinalRenderConfigRoutes } = require("./server/final_render_config_routes");
const { registerFinalRenderPackageRoutes } = require("./server/final_render_package_routes");
const { registerFinalRenderInputRoutes } = require("./server/final_render_input_routes");
const { registerFinalCutRenderBridgeRoutes } = require("./server/final_cut_render_bridge_routes");
const { registerFinalCutReviewFinalizeRoutes } = require("./server/final_cut_review_finalize_routes");
const { registerFinalCutReviewDecisionRoutes } = require("./server/final_cut_review_decision_routes");
const { registerFinalCutReviewRoutes } = require("./server/final_cut_review_routes");
const { registerFinalCutPlanRoutes } = require("./server/final_cut_plan_routes");
const { registerFinalCutPrepareRoutes } = require("./server/final_cut_prepare_routes");
const { registerFinalCutReadinessRoutes } = require("./server/final_cut_readiness_routes");
const { registerCanonicalTimelineReviewFinalizeRoutes } = require("./server/canonical_timeline_review_finalize_routes");
const { registerCanonicalTimelineReviewDecisionRoutes } = require("./server/canonical_timeline_review_decision_routes");
const { registerCanonicalTimelineReviewRoutes } = require("./server/canonical_timeline_review_routes");
const { registerApprovedClipTimelineApplyRoutes } = require("./server/approved_clip_timeline_apply_routes");
const { registerApprovedClipTimelineRoutes } = require("./server/approved_clip_timeline_routes");
const { registerApprovedClipEditReadinessRoutes } = require("./server/approved_clip_edit_readiness_routes");
const { registerApprovedClipEditBridgeRoutes } = require("./server/approved_clip_edit_bridge_routes");
const { registerGeneratedClipReviewFinalizeRoutes } = require("./server/generated_clip_review_finalize_routes");
const { registerGeneratedClipReviewSummaryRoutes } = require("./server/generated_clip_review_summary_routes");
const { registerGeneratedClipReviewDecisionRoutes } = require("./server/generated_clip_review_decision_routes");
const { registerGeneratedClipReviewSetRoutes } = require("./server/generated_clip_review_set_routes");
const { registerVideoGenerationClipInventoryRoutes } = require("./server/video_generation_clip_inventory_routes");
const { registerVideoGenerationClipSyncRoutes } = require("./server/video_generation_clip_sync_routes");
const { registerVideoGenerationBatchStatusRoutes } = require("./server/video_generation_batch_status_routes");
const { registerVideoGenerationReconciliationRoutes } = require("./server/video_generation_reconciliation_routes");
const { registerVideoGenerationJobRecoveryRoutes } = require("./server/video_generation_job_recovery_routes");
const { registerVideoGenerationJobControlRoutes } = require("./server/video_generation_job_control_routes");
const { registerVideoGenerationJobRecordRoutes } = require("./server/video_generation_job_records");
const { registerVideoGenerationSubmissionStatusRoutes } = require("./server/video_generation_submission_status_routes");
const { registerVideoGenerationLaunchBridge } = require("./server/video_generation_launch_bridge");
const { registerVideoGenerationLaunchRoutes } = require("./server/video_generation_launch_routes");
const { registerVideoGenerationPreflightRoutes } = require("./server/video_generation_preflight_routes");
const { registerVideoGenerationManifestRoutes } = require("./server/video_generation_manifest_routes");
const { registerAiPromptPackRoutes } = require("./server/ai_prompt_pack_routes");
const { registerAiProviderRoutes } = require("./server/ai_provider_routes");
const { registerProjectNextActionRoutes } = require("./server/project_next_action_routes");
const { registerProjectCommandsRoutes } = require("./server/project_commands_routes");
const { registerProjectOverviewRoutes } = require('./server/project_overview_routes');
const {registerProjectFilterRoutes}=require("./server/project_filter_routes");
const {registerProjectRecentRoutes}=require("./server/project_recent_routes");
const {registerProjectFavouritesListRoutes}=require("./server/project_favourites_list_routes");
const {registerProjectSortRoutes}=require("./server/project_sort_routes");
const {registerProjectFavouritesRoutes}=require("./server/project_favourites_routes");
const {registerProjectTagsRoutes}=require("./server/project_tags_routes");
const {registerProjectNotesRoutes}=require("./server/project_notes_routes");
const {registerProjectStatsRoutes}=require("./server/project_stats_routes");
const {registerProjectCloneTemplateRoutes}=require("./server/project_clone_template_routes");
const {registerProjectImportRoutes}=require("./server/project_import_routes");
const {registerProjectExportRoutes}=require("./server/project_export_routes");
const {registerProjectDuplicateRoutes}=require("./server/project_duplicate_routes");
const {registerProjectSearchRoutes}=require("./server/project_search_routes");
const {registerProjectDeleteRoutes}=require("./server/project_delete_routes");
const {registerAppConfigRoutes}=require("./server/app_config_routes");
const {registerServerHealthRoutes}=require("./server/server_health_routes");
const {registerProjectDashboardRoutes}=require("./server/project_dashboard_routes");
const {registerProjectReadinessRoutes}=require("./server/project_readiness_routes");
const {registerProjectHealthRoutes}=require("./server/project_health_routes");
const {registerProjectActivityRoutes}=require("./server/project_activity_routes");
const {registerProjectRecoveryRoutes}=require("./server/project_recovery_routes");
const {registerProjectResumeRoutes}=require("./server/project_resume_routes");
const {registerProjectLifecycleRoutes}=require("./server/project_lifecycle_routes");
const {registerProjectArchiveRoutes}=require("./server/project_archive_routes");
const {registerProjectValidationRoutes}=require("./server/project_validation_routes");
const {registerProjectBackupRoutes}=require("./server/project_backup_routes");
const {registerProjectSettingsRoutes}=require("./server/project_settings_routes");
const {registerProjectProductionSummaryRoutes}=require("./server/project_production_summary_routes");
const {registerFilmExportRoutes}=require("./server/film_export_routes");
const {registerProductionHealthRoutes}=require("./server/production_health_routes");
const {registerFinalMasterReadinessRoutes}=require("./server/final_master_readiness_routes");
const {registerFinalMasterStatusRoutes}=require("./server/final_master_status_routes");
const {registerFinalMasterQueueRoutes}=require("./server/final_master_queue_routes");
const {registerFinalFinishingOrchestratorRoutes}=require("./server/final_finishing_orchestrator_routes");
const {registerFinalAudioSubtitleRoutes}=require("./server/final_audio_subtitle_routes");
const {registerFinalCutRenderLaunchRoutes}=require("./server/final_cut_render_launch_routes");
const {registerFinalCutRenderRoutes}=require("./server/final_cut_render_routes");
const {registerEditRenderRoutes}=require("./server/edit_render_routes");
const {registerEditPipelineRoutes}=require("./server/edit_pipeline_routes");
const {registerClipSelectionRoutes}=require("./server/clip_selection_routes");
const {registerClipReviewUiRoutes}=require("./server/clip_review_ui_routes");
const {registerProductionPlanRoutes}=require("./server/production_plan_routes");
import { createRequire } from "module";
const require = createRequire(import.meta.url);
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {execFile} from 'child_process';
import {promisify} from 'util';
import OpenAI from 'openai';
import RunwayML from '@runwayml/sdk';
import finishApi from './server/finish_api.js';
import filmLibraryRoutes from './server/film_library_routes.js';

const exec=promisify(execFile); const app=express(); app.use(cors()); app.use(express.json({limit:'2mb'}));
const ROOT=process.cwd(), DATA=path.join(ROOT,'data'), ASSETS=path.join(ROOT,'assets'), RENDER=path.join(ROOT,'render'), FILMS=path.join(ROOT,'films');
for(const d of [DATA,ASSETS,RENDER,FILMS])fs.mkdirSync(d,{recursive:true});
const openai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
const runway=process.env.RUNWAYML_API_SECRET?new RunwayML({apiKey:process.env.RUNWAYML_API_SECRET}):null;
const publicBase=process.env.PUBLIC_BASE_URL||'';
const safe=s=>String(s||'').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,100);
const file=id=>path.join(DATA,`${safe(id)}.json`); const jobFile=id=>path.join(RENDER,`${safe(id)}.json`);
const now=()=>new Date().toISOString();
function readProject(id){if(!fs.existsSync(file(id)))return null;return JSON.parse(fs.readFileSync(file(id),'utf8'));}
function writeProject(p){p.updatedAt=now();fs.writeFileSync(file(p.id),JSON.stringify(p,null,2));}
function saveAssetRecord(projectId,record){const p=readProject(projectId);if(!p)throw new Error('project not found');p.assets=p.assets||[];p.assets.push({...record,id:record.id||crypto.randomUUID(),createdAt:now()});writeProject(p);return p.assets.at(-1);}
function lengthSeconds(v){return ({'1 min':60,'5 min':300,'10 min':600,'30 min':1800,'60 min':3600}[v]||300);}
function fallback(idea,genre,style,length){const count=length==='1 min'?3:length==='5 min'?6:length==='10 min'?10:Math.min(24,Math.ceil(lengthSeconds(length)/45)); const chars=[{name:'Alex',role:'Lead',appearance:'cinematic, distinctive face, expressive eyes',clothing:'practical modern clothing',personality:'determined and warm',voice:'Maya'}]; const scenes=Array.from({length:count},(_,i)=>({id:crypto.randomUUID(),title:`Scene ${i+1}`,description:`${i===0?'Opening':i===count-1?'Finale':'Rising action'} scene for ${idea}.`,prompt:`${style} ${genre} film. ${idea}. Scene ${i+1} of ${count}. Consistent main character Alex, cinematic composition, natural motion, coherent lighting and continuity.`,duration:Math.min(10,Math.max(5,Math.round(lengthSeconds(length)/count)))})); return {title:idea.slice(0,60),logline:idea,characters:chars,scenes};}
async function screenplay(idea,genre,style,length){
 if(!openai)return fallback(idea,genre,style,length);
 const schema={type:'object',additionalProperties:false,properties:{title:{type:'string'},logline:{type:'string'},characters:{type:'array',items:{type:'object',additionalProperties:false,properties:{name:{type:'string'},role:{type:'string'},appearance:{type:'string'},clothing:{type:'string'},personality:{type:'string'},voice:{type:'string'}},required:['name','role','appearance','clothing','personality','voice']}},scenes:{type:'array',items:{type:'object',additionalProperties:false,properties:{title:{type:'string'},description:{type:'string'},prompt:{type:'string'},duration:{type:'integer',minimum:5,maximum:10}},required:['title','description','prompt','duration']}}},required:['title','logline','characters','scenes']};
 const response=await openai.responses.create({model:process.env.OPENAI_TEXT_MODEL||'gpt-5-mini',input:[{role:'system',content:'You are a film screenwriter and AI director. Return a practical shot-ready plan. Keep recurring characters visually consistent. Scene durations must be 5-10 seconds because the video provider works in short clips.'},{role:'user',content:`Create a ${length} ${genre} ${style} film from this idea: ${idea}.` }],text:{format:{type:'json_schema',name:'film_plan',strict:true,schema}}});
 return JSON.parse(response.output_text);
}
async function runwayTask(kind,payload){if(!runway)throw new Error('RUNWAYML_API_SECRET is not configured'); if(kind==='image')return runway.textToImage.create(payload); if(kind==='tts')return runway.textToSpeech.create(payload); if(kind==='sfx')return runway.soundEffect.create(payload); throw new Error('Unsupported task');}
async function downloadAsset(url,target){if(!/^https?:\/\//i.test(url))throw new Error('Asset URL must be HTTP(S)'); const res=await fetch(url,{redirect:'follow',signal:AbortSignal.timeout(180000)}); if(!res.ok)throw new Error(`Download failed (${res.status})`); fs.mkdirSync(path.dirname(target),{recursive:true}); fs.writeFileSync(target,Buffer.from(await res.arrayBuffer())); return target;}
function localAsset(projectId,assetId,ext){const dir=path.join(ASSETS,safe(projectId));fs.mkdirSync(dir,{recursive:true});return path.join(dir,`${safe(assetId)}.${ext}`);}

app.get('/api/health',(q,r)=>r.json({ok:true,name:"Mark's AI",providers:{openai:!!openai,runway:!!runway,ffmpeg:!!process.env.FFMPEG_BIN},personalMode:true,noCredits:true,noAccounts:true}));
app.get('/api/projects',(q,r)=>{const projects=fs.readdirSync(DATA).filter(x=>x.endsWith('.json')).map(x=>JSON.parse(fs.readFileSync(path.join(DATA,x),'utf8'))).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));r.json(projects);});
app.get('/api/projects/:id',(q,r)=>{const p=readProject(q.params.id);p?r.json(p):r.status(404).json({error:'project not found'});});
app.put('/api/projects/:id',(q,r)=>{const p=readProject(q.params.id);if(!p)return r.status(404).json({error:'project not found'});Object.assign(p,q.body||{});writeProject(p);r.json(p);});
app.delete('/api/projects/:id',(q,r)=>{const p=readProject(q.params.id);if(!p)return r.status(404).json({error:'project not found'});fs.rmSync(file(p.id),{force:true});r.json({deleted:true});});
app.post('/api/film/create',async(q,r)=>{const {idea,genre='Sci-Fi',style='Cinematic',length='5 min'}=q.body||{};if(!idea?.trim())return r.status(400).json({error:'idea required'});try{const plan=await screenplay(idea.trim(),genre,style,length);const id=crypto.randomUUID();const p={id,title:plan.title||idea.slice(0,60),idea,genre,style,length,createdAt:now(),updatedAt:now(),status:'draft',characters:(plan.characters||[]).map(c=>({...c,referenceUrl:null})),scenes:(plan.scenes||[]).map(s=>({...s,id:s.id||crypto.randomUUID(),status:'Ready',taskId:null,videoUrl:null,dialogueUrl:null,sfxUrl:null})),musicUrl:null,production:null,assets:[],storyboard:{shots:[]}};writeProject(p);r.json({projectId:id,...p});}catch(e){r.status(502).json({error:e.message});}});

app.post('/api/characters/:name/reference',async(q,r)=>{if(!runway)return r.json({status:'provider_not_configured'});const {appearance='',clothing='',personality=''}=q.body||{};try{const t=await runwayTask('image',{model:process.env.RUNWAY_IMAGE_MODEL||'gen4_image',promptText:`Character reference portrait. Keep a single consistent identity. ${appearance}. ${clothing}. Personality: ${personality}. Neutral background, cinematic realistic lighting.`,ratio:'1920:1080'});r.json({status:'submitted',taskId:t.id});}catch(e){r.status(502).json({error:e.message});}});
app.get('/api/character-task/:id',async(q,r)=>{if(!runway)return r.json({status:'provider_not_configured'});try{r.json(await runway.tasks.retrieve(q.params.id));}catch(e){r.status(502).json({error:e.message});}});
app.post('/api/audio',async(q,r)=>{const {type='dialogue',text='',voiceId='Maya',duration=5}=q.body||{};if(!text)return r.status(400).json({error:'text required'});if(!runway)return r.json({status:'provider_not_configured'});try{let t;if(type==='dialogue')t=await runwayTask('tts',{model:'eleven_multilingual_v2',promptText:text,voice:{type:'runway-preset',presetId:voiceId}});else if(type==='sfx')t=await runwayTask('sfx',{model:'eleven_text_to_sound_v2',promptText:text,duration:Math.max(.5,Math.min(30,Number(duration)||5)),loop:false});else t=await runwayTask('tts',{model:'seed_audio',promptText:text,outputFormat:'mp3'});r.json({status:'submitted',taskId:t.id,type});}catch(e){r.status(502).json({error:e.message});}});
app.get('/api/audio-task/:id',async(q,r)=>{if(!runway)return r.json({status:'provider_not_configured'});try{r.json(await runway.tasks.retrieve(q.params.id));}catch(e){r.status(502).json({error:e.message});}});
app.post('/api/video',async(q,r)=>{const {prompt,duration=5,referenceImage}=q.body||{};if(!prompt)return r.status(400).json({error:'prompt required'});if(!runway)return r.json({status:'provider_not_configured'});try{const payload={model:process.env.RUNWAY_VIDEO_MODEL||'gen4.5',promptText:prompt,ratio:process.env.VIDEO_RATIO||'1280:720',duration:Math.min(10,Math.max(5,Number(duration)||5))};if(referenceImage)payload.promptImage=referenceImage;const t=await runway.imageToVideo.create(payload);r.json({status:'submitted',taskId:t.id});}catch(e){r.status(502).json({error:e.message});}});
app.get('/api/video/:id',async(q,r)=>{if(!runway)return r.json({status:'provider_not_configured'});try{r.json(await runway.tasks.retrieve(q.params.id));}catch(e){r.status(502).json({error:e.message});}});

app.post('/api/assets/download',async(q,r)=>{const {projectId,assetId,url,kind='asset',sceneId=null}=q.body||{};if(!projectId||!url)return r.status(400).json({error:'projectId and url required'});try{const ext=kind==='image'?'png':kind==='audio'?'mp3':'mp4';const target=localAsset(projectId,assetId||crypto.randomUUID(),ext);await downloadAsset(url,target);const assetUrl=`/assets/${safe(projectId)}/${path.basename(target)}`;const asset=saveAssetRecord(projectId,{assetId:assetId||path.basename(target,`.${ext}`),kind,sceneId,url:assetUrl,localPath:target});r.json({status:'downloaded',assetUrl,asset});}catch(e){r.status(502).json({error:e.message});}});

app.post('/api/storyboard/plan',async(q,r)=>{const p=readProject(q.body?.projectId);if(!p)return r.status(404).json({error:'project not found'});const shots=[];for(const scene of (p.scenes||[])){const base=scene.prompt||scene.description||'';shots.push({id:crypto.randomUUID(),sceneId:scene.id,type:'wide',duration:Math.max(2,Math.round((scene.duration||6)*0.35)),prompt:`Wide establishing shot. ${base}. Strong sense of place, cinematic composition.`});shots.push({id:crypto.randomUUID(),sceneId:scene.id,type:'medium',duration:Math.max(2,Math.round((scene.duration||6)*0.35)),prompt:`Medium character shot. ${base}. Natural performance, expressive body language, consistent character.`});shots.push({id:crypto.randomUUID(),sceneId:scene.id,type:'close-up',duration:Math.max(1,Math.round((scene.duration||6)*0.30)),prompt:`Close-up emotional shot. ${base}. Detailed face, cinematic lighting, shallow depth of field.`});}p.storyboard={shots,createdAt:now()};writeProject(p);r.json(p.storyboard);});
app.get('/api/storyboard/:id',(q,r)=>{const p=readProject(q.params.id);p?r.json(p.storyboard||{shots:[]}):r.status(404).json({error:'project not found'});});
app.post('/api/projects/:id/duplicate',async(q,r)=>{const p=readProject(q.params.id);if(!p)return r.status(404).json({error:'project not found'});const copy=JSON.parse(JSON.stringify(p));copy.id=crypto.randomUUID();copy.title=`${p.title} Copy`;copy.createdAt=now();copy.updatedAt=now();copy.status='draft';copy.production=null;for(const s of (copy.scenes||[])){s.taskId=null;s.videoUrl=null;s.status='Ready';}writeProject(copy);r.json(copy);});

app.use('/assets',express.static(ASSETS)); app.use('/films',express.static(FILMS));

const {createFinishRun,getFinishRun}=finishApi;
const {registerFilmLibraryRoutes}=filmLibraryRoutes;
registerFilmLibraryRoutes(app,{dir:FILMS});
app.post('/api/film/finish',(req,res)=>{try{res.status(202).json(createFinishRun(req.body||{}));}catch(e){res.status(400).json({error:e.message});}});
app.get('/api/film/finish/:id',(req,res)=>{const run=getFinishRun(req.params.id);if(!run)return res.status(404).json({error:'finish run not found'});res.json(run);});

async function renderJob(job){const f=jobFile(job.id);try{job.status='downloading';job.progress=10;fs.writeFileSync(f,JSON.stringify(job,null,2));const work=path.join(RENDER,'work',job.id);fs.mkdirSync(work,{recursive:true});const clips=[];for(let i=0;i<job.scenes.length;i++){const s=job.scenes[i], target=path.join(work,`scene_${String(i).padStart(3,'0')}.mp4`);await downloadAsset(s.videoUrl,target);clips.push(target);job.progress=10+Math.round((i+1)/job.scenes.length*45);fs.writeFileSync(f,JSON.stringify(job,null,2));}const manifest=path.join(work,'concat.txt');fs.writeFileSync(manifest,clips.map(x=>`file '${x.replaceAll("'","'\\''")}'`).join('\n'));job.status='rendering';job.progress=60;fs.writeFileSync(f,JSON.stringify(job,null,2));if(!process.env.FFMPEG_BIN)throw new Error('FFMPEG_BIN is not configured');const temp=path.join(work,'video.mp4');await exec(process.env.FFMPEG_BIN,['-y','-f','concat','-safe','0','-i',manifest,'-c:v','libx264','-preset','veryfast','-pix_fmt','yuv420p','-an',temp]);const out=path.join(FILMS,`${safe(job.projectId)}_${Date.now()}.mp4`);await exec(process.env.FFMPEG_BIN,['-y','-i',temp,'-c:v','copy','-an',out]);job.status='complete';job.progress=100;job.filmUrl=`${publicBase}/films/${path.basename(out)}`;job.outputPath=out;job.message='Film rendered successfully.';}catch(e){job.status='failed';job.message=String(e.stderr||e.message||e);}fs.writeFileSync(f,JSON.stringify(job,null,2));const p=readProject(job.projectId);if(p){p.status=job.status;p.production=job;writeProject(p);}}
app.post('/api/render',(q,r)=>{const id=q.body?.projectId,p=readProject(id);if(!p)return r.status(404).json({error:'project not found'});const scenes=(p.scenes||[]).filter(s=>s.videoUrl);const job={id:crypto.randomUUID(),projectId:id,status:'queued',progress:0,scenes,createdAt:now(),filmUrl:null};fs.writeFileSync(jobFile(job.id),JSON.stringify(job,null,2));r.json(job);});
app.get('/api/render/:id',(q,r)=>{const f=jobFile(q.params.id);fs.existsSync(f)?r.json(JSON.parse(fs.readFileSync(f))):r.status(404).json({error:'job not found'});});
app.post('/api/render/:id/run',(q,r)=>{const f=jobFile(q.params.id);if(!fs.existsSync(f))return r.status(404).json({error:'job not found'});const job=JSON.parse(fs.readFileSync(f));renderJob(job);r.json({started:true,id:job.id});});

app.post('/api/film/produce',async(q,r)=>{const p=readProject(q.body?.projectId);if(!p)return r.status(404).json({error:'project not found'});const production={id:crypto.randomUUID(),projectId:p.id,status:'planning',progress:0,startedAt:now(),steps:['screenplay','characters','clips','audio','render'],message:'Production queued'};p.production=production;p.status='producing';writeProject(p);r.json(production);runProduction(p.id).catch(console.error);});
app.get('/api/film/produce/:id',(q,r)=>{const p=readProject(q.params.id);p?.production?r.json(p.production):r.status(404).json({error:'production not found'});});
async function runProduction(id){const p=readProject(id);if(!p)return;const pr=p.production;try{pr.status='generating_clips';pr.progress=15;pr.message='Generating scene clips';writeProject(p);if(!runway){pr.status='waiting_for_provider';pr.message='Add RUNWAYML_API_SECRET to enable real video generation.';writeProject(p);return;}for(let i=0;i<p.scenes.length;i++){const s=p.scenes[i];if(s.videoUrl)continue;const t=await runway.imageToVideo.create({model:process.env.RUNWAY_VIDEO_MODEL||'gen4.5',promptText:s.prompt,ratio:process.env.VIDEO_RATIO||'1280:720',duration:Math.min(10,Math.max(5,s.duration||5))});s.taskId=t.id;s.status='Generating';while(true){await new Promise(x=>setTimeout(x,3000));const x=await runway.tasks.retrieve(t.id),st=String(x.status||'').toLowerCase();if(st.includes('succeed')||st.includes('complete')){s.videoUrl=x.output?.toString()||x.outputUrl?.toString();s.status='Complete';break;}if(st.includes('fail'))throw new Error(`Scene ${i+1} failed`);}pr.progress=15+Math.round((i+1)/p.scenes.length*60);writeProject(p);}pr.status='ready_to_render';pr.progress=80;pr.message='All clips generated. Render when ready.';writeProject(p);}catch(e){pr.status='failed';pr.message=e.message;writeProject(p);}}

if (process.env.AUTO_RECOVER_FINAL_RENDERS === "true") runStartupFinalRenderRecovery({outputDir:require("path").join(process.cwd(),"output")}).catch(()=>{});
registerProjectOverviewRoutes(app);
registerProjectCommandsRoutes(app);
registerProjectNextActionRoutes(app);
registerAiProviderRoutes(app);
registerAiPromptPackRoutes(app);
registerVideoGenerationManifestRoutes(app);
registerVideoGenerationPreflightRoutes(app);
registerVideoGenerationLaunchRoutes(app);
registerVideoGenerationLaunchBridge(app);
registerVideoGenerationSubmissionStatusRoutes(app);
registerVideoGenerationJobRecordRoutes(app);
registerVideoGenerationJobControlRoutes(app);
registerVideoGenerationJobRecoveryRoutes(app);
registerVideoGenerationReconciliationRoutes(app);
registerVideoGenerationBatchStatusRoutes(app);
registerVideoGenerationClipSyncRoutes(app);
registerVideoGenerationClipInventoryRoutes(app);
registerGeneratedClipReviewSetRoutes(app);
registerGeneratedClipReviewDecisionRoutes(app);
registerGeneratedClipReviewSummaryRoutes(app);
registerGeneratedClipReviewFinalizeRoutes(app);
registerApprovedClipEditBridgeRoutes(app);
registerApprovedClipEditReadinessRoutes(app);
registerApprovedClipTimelineRoutes(app);
registerApprovedClipTimelineApplyRoutes(app);
registerCanonicalTimelineReviewRoutes(app);
registerCanonicalTimelineReviewDecisionRoutes(app);
registerCanonicalTimelineReviewFinalizeRoutes(app);
registerFinalCutReadinessRoutes(app);
registerFinalCutPrepareRoutes(app);
registerFinalCutPlanRoutes(app);
registerFinalCutReviewRoutes(app);
registerFinalCutReviewDecisionRoutes(app);
registerFinalCutReviewFinalizeRoutes(app);
registerFinalCutRenderBridgeRoutes(app);
registerFinalRenderInputRoutes(app);
registerFinalRenderPackageRoutes(app);
registerFinalRenderConfigRoutes(app);
registerFinalRenderQueueBridgeRoutes(app);
registerFinalRenderQueueControlRoutes(app);
registerFinalRenderWorkerBridgeRoutes(app);
registerFinalRenderWorkerSyncRoutes(app);
registerFinalRenderExecutionRoutes(app);
registerFinalRenderExecutionStatusRoutes(app);
registerFinalRenderWorkerAutoRunRoutes(app);
registerFinalRenderOutputInspectorRoutes(app);
registerFinalRenderWorkerReconcileRoutes(app);
startFinalRenderHeartbeat();
registerFinalRenderVerificationRoutes(app);
registerFinalRenderMasterGateRoutes(app);
registerFinalMasterDeliveryRoutes(app);
registerFinalMasterDeliveryManifestRoutes(app);
registerFinalMasterDeliveryReceiptRoutes(app);
registerFinalMasterDeliveryLockRoutes(app);
registerFinalMasterLockAuditRoutes(app);
registerFinalMasterDeliveryExportRoutes(app);
registerFinalMasterDeliveryArchiveRoutes(app);
registerFinalMasterArchiveVerifyRoutes(app);
registerFinalMasterReleaseReadinessRoutes(app);
registerFinalMasterReleaseRecordRoutes(app);
registerFinalMasterReleaseSnapshotRoutes(app);
registerFinalMasterReleaseCatalogRoutes(app);
registerFinalMasterLibraryReleaseRoutes(app);
registerReleasedFilmIndexRoutes(app);
registerReleasedFilmVerifierRoutes(app);
registerReleasedFilmDeliveryPackageRoutes(app);
registerReleasedFilmDeliveryExportRoutes(app);


































































registerReleasedFilmDeliveryExportVerifierRoutes(app);
registerReleasedFilmDeliveryFinalGateRoutes(app);
registerReleasedFilmDeliveryLockRoutes(app);
registerReleasedFilmDeliveryAuditRoutes(app);
registerReleasedFilmDeliverySealRoutes(app);
registerReleasedFilmDeliverySnapshotRoutes(app);
registerReleasedFilmDeliverySnapshotVerifyRoutes(app);
registerReleasedFilmDeliverySealedRecordRoutes(app);
registerFinalReleaseRecordRoutes(app);
registerReleaseCenterRoutes(app);
registerReleasePackageDashboardRoutes(app);
registerFinalReleaseDownloadCenterRoutes(app);
registerFinalReleaseTransferPackageRoutes(app);
registerFinalReleasePackageVerifierRoutes(app);
registerReleasePackageIntegrityHistoryRoutes(app);
registerReleasePreflightRoutes(app);
registerReleaseBuildRoutes(app);
registerReleaseBuildMonitorRoutes(app);
registerReleaseBuildArtifactRoutes(app);
registerPrivateDeviceSecurityRoutes(app);
registerRealClipGenerationRoutes(app);
registerRealClipProviderRoutes(app);
registerRealClipMediaRoutes(app);
registerRealClipReviewRoutes(app);
registerRealClipRegenerationRoutes(app);
registerRealClipRegenerationWorkerRoutes(app);
registerApprovedFilmAssemblerRoutes(app);
registerApprovedFilmRenderRoutes(app);
registerApprovedFilmLibraryHandoffRoutes(app);
registerApprovedFilmLibraryMediaRoutes(app);
registerApprovedFilmExportRoutes(app);
registerApprovedFilmShareRoutes(app);
app.listen(process.env.PORT||3000,()=>console.log("Mark's AI server running on port "+(process.env.PORT||3000)));

const { registerMarkAiDashboardRoutes } = require("./server/mark_ai_dashboard_routes");
registerMarkAiDashboardRoutes(app);
  registerProjectLifecycleRoutes(app);
  registerProjectResumeRoutes(app);
  registerProjectRecoveryRoutes(app);
  registerProjectActivityRoutes(app);
  registerProjectHealthRoutes(app);
  registerProjectReadinessRoutes(app);
  registerProjectDashboardRoutes(app);
  registerServerHealthRoutes(app);
  registerAppConfigRoutes(app);
  registerProjectDeleteRoutes(app);
  registerProjectSearchRoutes(app);
  registerProjectDuplicateRoutes(app);
  registerProjectExportRoutes(app);
  registerProjectImportRoutes(app);
  registerProjectCloneTemplateRoutes(app);
  registerProjectStatsRoutes(app);
  registerProjectNotesRoutes(app);
  registerProjectTagsRoutes(app);
  registerProjectFavouritesRoutes(app);
  registerProjectSortRoutes(app);
  registerProjectFavouritesListRoutes(app);
  registerProjectRecentRoutes(app);
  registerProjectFilterRoutes(app);
  registerProjectArchiveRoutes(app);
  registerProjectValidationRoutes(app);
  registerProjectBackupRoutes(app);
  registerProjectSettingsRoutes(app);
  registerProjectProductionSummaryRoutes(app);
  registerFilmExportRoutes(app);
  registerProductionHealthRoutes(app);
  registerFinalMasterReadinessRoutes(app);
  registerFinalMasterStatusRoutes(app);
  registerFinalMasterQueueRoutes(app);
  registerFinalFinishingOrchestratorRoutes(app);
  registerFinalAudioSubtitleRoutes(app);
  registerFinalCutRenderLaunchRoutes(app);
  registerFinalCutRenderRoutes(app);
  registerEditRenderRoutes(app);
  registerEditPipelineRoutes(app);
  registerClipSelectionRoutes(app);
  registerClipReviewUiRoutes(app);
  registerProductionPlanRoutes(app);
