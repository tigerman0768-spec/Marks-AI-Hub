# Mark's AI v2201–2220

- v2201–2210: Added a unified Release Status API.
- Status resolves to in-progress, approved, sealed, or released from the persistent release records.
- It exposes certificate/seal/approval/snapshot IDs and current file identity.
- v2211–2220: Added the Release Status API route and Flutter View Release Status action.
- This gives the app a simple authoritative state for the finished-film release lifecycle.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
