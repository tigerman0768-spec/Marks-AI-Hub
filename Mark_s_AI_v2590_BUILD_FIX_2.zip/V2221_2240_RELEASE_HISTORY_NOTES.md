# Mark's AI v2221–2240

- v2221–2230: Added persistent Release History for release lifecycle events.
- Release events are stored per project, capped at 100 recent events.
- Certificate issuance and release sealing now record lifecycle events.
- v2231–2240: Added Release History API and Flutter View Release History action.
- This provides a chronological audit trail alongside the current Release Status.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
