# Mark's AI v861–880

- v861–870: Added approved-clip inventory and an explicit bridge from finalized generated clips into editing.
- v871–880: Added edit-readiness checks and persistent approved-clip edit timeline preparation.
- The bridge only accepts finalized, approved clips whose source files still exist.
- Added Flutter Approved Clips → Edit screen.
- This connects the generated-video review stage to the downstream AI editing stage.
- All JavaScript files were checked with node --check.

Full Android compilation still requires the Flutter SDK in the build environment.
