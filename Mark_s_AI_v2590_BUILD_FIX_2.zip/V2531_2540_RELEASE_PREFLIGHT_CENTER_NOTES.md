# Mark's AI v2531–2540 — Release Preflight Center

This milestone turns the v2530 command-line final release preflight into an in-app release check.

## Added
- `GET /api/release-preflight` backend endpoint.
- Flutter **Release Preflight** screen.
- Real PASS/BLOCKED status for each preflight check.
- Explicit APK and AAB availability indicators.
- Clear `READY FOR SOURCE RELEASE` vs `NOT READY FOR SOURCE RELEASE` state.
- Refresh / re-run action.
- Dashboard entry for Release Preflight.

The existing preflight remains honest: this environment does not have Flutter installed, so the current check reports the build as blocked until a real Flutter/Android build produces the APK/AAB.
