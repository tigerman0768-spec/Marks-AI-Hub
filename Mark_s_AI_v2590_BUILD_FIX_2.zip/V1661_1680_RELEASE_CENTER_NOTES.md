# Mark's AI v1661–1680

- v1661–1670: Added a unified persistent Release Center aggregation.
- v1671–1680: Added live release-file SHA-256 and byte-size validation.
- Aggregates release record, sealed delivery, seal, snapshot, snapshot verification, lock and gate evidence.
- Persists a Release Center JSON record without duplicating the film.
- Added a Flutter Release Center screen with release status, evidence checklist, live file details and blockers.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK.
