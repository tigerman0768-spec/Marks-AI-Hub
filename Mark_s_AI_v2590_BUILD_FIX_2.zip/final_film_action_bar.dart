import 'dart:io';
import 'package:flutter/material.dart';
import 'final_film_actions.dart';

class FinalFilmActionBar extends StatefulWidget {
  final String videoPath;
  const FinalFilmActionBar({super.key, required this.videoPath});
  @override State<FinalFilmActionBar> createState()=>_FinalFilmActionBarState();
}
class _FinalFilmActionBarState extends State<FinalFilmActionBar>{
  bool busy=false;
  Future<void> _run(Future<void> Function() action,String message) async {
    setState(()=>busy=true);
    try{
      await action();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Action failed: $e')));
    }finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Row(
    mainAxisAlignment:MainAxisAlignment.center,
    children:[
      FilledButton.icon(
        onPressed:busy?null:()=>_run(
          ()=>FinalFilmActions.saveToGallery(widget.videoPath).then((_){ }),
          'Film saved to your gallery.',
        ),
        icon:const Icon(Icons.save_alt),label:const Text('SAVE'),
      ),
      const SizedBox(width:12),
      OutlinedButton.icon(
        onPressed:busy?null:()=>_run(
          ()=>FinalFilmActions.share(widget.videoPath),
          'Sharing film…',
        ),
        icon:const Icon(Icons.share),label:const Text('SHARE'),
      ),
    ],
  );
}
