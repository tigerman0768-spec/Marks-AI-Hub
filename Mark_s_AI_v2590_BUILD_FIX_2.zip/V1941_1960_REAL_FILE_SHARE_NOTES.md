# Mark's AI v1941–1960

- v1941–1950: Added a persistent export manifest builder and manifest SHA-256 endpoint.
- The manifest records the export identity, film title, filename, bytes, SHA-256, clip count and export timestamp.
- v1951–1960: upgraded Android sharing from sharing a download URL to sharing the actual rendered MP4 file.
- Flutter downloads the finished MP4 to temporary app storage and invokes the Android share sheet with `shareXFiles`.
- Added `path_provider` for temporary file storage.
- This is a real file-share path for compatible Android apps.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
