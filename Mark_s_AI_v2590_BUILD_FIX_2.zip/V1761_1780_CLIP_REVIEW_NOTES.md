# Mark's AI v1761–1780

- v1761–1770: Added persistent generated-clip review decisions with integrity checking.
- Decisions: keep, reject, regenerate.
- Kept clips are persisted to approvedGeneratedClips for downstream editing.
- v1771–1780: Added review/list API routes and a Flutter Generated Clip Review screen.
- Added Play, Keep, Reject and Regenerate controls.
- The regenerate action records the requested decision; provider re-submission can be wired next.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
