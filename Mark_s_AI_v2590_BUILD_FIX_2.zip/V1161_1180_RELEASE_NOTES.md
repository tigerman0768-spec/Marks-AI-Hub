# Mark's AI v1161–1180

- v1161–1170: Added a persistent Final Master Delivery Manifest.
- v1171–1180: Added SHA-256 integrity hashing of the actual final output file and a Flutter Delivery Manifest screen.
- The manifest requires a ready delivery package and a real output file.
- Records filename, byte size, duration, media metadata and SHA-256.
- All JavaScript files were checked with node --check.

Full Android compilation still requires the Flutter SDK in the build environment.
