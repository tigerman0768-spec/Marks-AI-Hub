# Mark's AI v1801–1820

- v1801–1810: Added regeneration task processing using the existing Runway status API and download helper.
- Successful regenerations are downloaded as MP4 files and persisted with SHA-256 and byte size.
- Downloaded regenerated clips are added to generatedRealClips with source regeneration linkage and original shot ID where available.
- v1811–1820: Added regeneration check route and updated the Approved Clips Timeline to show pending/completed regenerations.
- The workflow is now: Generate → Download → Review → Regenerate → Download replacement → Review/approve → Timeline.
- Automatic background scheduling is not claimed; the regeneration check endpoint can be invoked by the app.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
