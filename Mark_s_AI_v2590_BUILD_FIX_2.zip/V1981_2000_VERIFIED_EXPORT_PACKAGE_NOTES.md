# Mark's AI v1981–2000

- v1981–1990: Added a verified export-package builder.
- It re-reads the actual Film Library MP4, recalculates bytes and SHA-256, and creates a compact JSON manifest with package ID, film identity, file identity, clip count and timestamp.
- v1991–2000: Added the export-package API and a Flutter `Prepare Verified Export Package` action.
- The package manifest does not duplicate the large MP4; the MP4 remains the single rendered source file.
- Export records now retain the package ID, manifest path and manifest SHA-256.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
