# Mark's AI v1721–1740

- v1721–1730: Added automatic polling of Runway tasks and handling of SUCCEEDED / FAILED / CANCELED states.
- v1731–1740: Added automatic MP4 download of the completed Runway output into the project's real_clips directory.
- Persisted downloaded clip path, byte size and SHA-256.
- Added generatedRealClips records for downstream review/editing.
- Flutter generator now polls automatically every 6 seconds and reports completion/failure.
- Runway output URLs are ephemeral, so the server downloads the result into project storage instead of exposing the temporary URL.
- Provider behavior follows current Runway task/output documentation.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
