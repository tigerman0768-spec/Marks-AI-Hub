# Mark's AI v2241–2260

- v2241–2250: Added a unified Release Manifest builder containing the released film identity and all key release IDs.
- The manifest includes filename, bytes, SHA-256, certificate, seal, snapshot and delivery references.
- v2251–2260: Added Release Manifest GET/save API routes and Flutter View Release Manifest and Save Release Manifest actions.
- A manifest SHA-256 is generated for the manifest itself.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
