# Mark's AI v2490

## Release Package Sharing & Transfer

The Final Release Download Centre can now prepare a single ZIP transfer package from the release files that actually exist for the project.

The package includes:
- final film MP4 when available
- approved film export when available
- release manifest when available
- release certificate when available
- `MARKS_AI_RELEASE_PACKAGE.json` metadata

The Flutter app can download the generated ZIP and open Android's native share sheet so the complete package can be saved or transferred in one action.

No missing release file is invented or added as a placeholder.

Flutter/Android compilation still requires a Flutter and Android SDK environment.
