# Mark's AI v1501–1520

- v1501–1510: Added a persistent Final Release Delivery Gate.
- v1511–1520: Added live final-file SHA-256 checking across catalogue, library release, export and verification evidence.
- The gate checks the complete release-delivery chain and records blockers.
- A Flutter Release Delivery Gate screen exposes readiness and current file integrity.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK.
