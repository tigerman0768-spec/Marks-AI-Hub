# v2581–2590 — Real APK Build Handoff

## Goal
Move Mark's AI from source-package readiness to an explicitly reproducible **real Android APK build**.

## Changes
- Bumped project version to `1.0.0+2590`.
- Updated milestone marker to `v2590`.
- Updated Android release workflow default release version to `v2590`.
- Versioned GitHub Actions APK and AAB artifact names.
- Added `tools/build_apk.sh` to run `flutter pub get`, build the release APK, and fail unless the expected APK exists.
- Added `APK_BUILD_v2590.md` documenting the exact installer output path.

## Verification
The build handoff script is present and executable.
The current container still does not have the Flutter SDK, so this milestone does **not** claim an APK was compiled here.
