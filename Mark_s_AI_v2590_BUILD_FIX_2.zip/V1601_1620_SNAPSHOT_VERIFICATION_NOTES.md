# Mark's AI v1601–1620

- v1601–1610: Added persistent verification of the Final Release Delivery Snapshot.
- v1611–1620: Added live SHA-256 and file-size checks against the captured snapshot.
- Verification evidence is persisted under the delivery-snapshot directory.
- A Flutter Snapshot Verification screen exposes status and blockers.
- JavaScript syntax validation passed for the complete server tree.

Full Android compilation still requires the Flutter SDK.
