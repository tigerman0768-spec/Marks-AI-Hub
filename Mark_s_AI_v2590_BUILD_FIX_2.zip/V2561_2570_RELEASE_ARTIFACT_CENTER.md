# Mark's AI v2561–2570 — Release Artifact Center

## What changed
- Added `GET /api/release-build/artifacts` to enumerate the latest non-expired Android release artifacts.
- Added `GET /api/release-build/artifacts/:artifactId/download` as a server-side authenticated GitHub artifact proxy.
- Artifact IDs are validated against the latest configured Android release workflow and restricted to the expected APK/AAB artifact names.
- Release Build Monitor artifact records now include IDs, sizes, timestamps and safe in-app download endpoints.
- Release Build Center UI now presents produced artifact metadata and download/open actions.
- Flutter app version advanced to `1.0.0+2570`.

## Safety / truthfulness
- The app only exposes artifacts that GitHub reports as present and non-expired.
- No APK/AAB is claimed to exist until GitHub Actions actually produces the artifact.
- The proxy keeps the GitHub token server-side; it is never embedded in the Flutter app or download URL.

## Verification
- Node syntax checking covers all JavaScript files in the package.
