# Mark's AI v2081–2100

- v2081–2090: Added a unified Release Catalogue API for the completed film.
- It aggregates Film Library, Export, Delivery, Verification/Lock and Release Snapshot state in one project-scoped response.
- It exposes the release-stage IDs plus file identity information without copying the MP4.
- v2091–2100: Added a Flutter View Release Catalogue action with a visual stage checklist.
- The catalogue gives one place to see whether the film has reached each release checkpoint.
- Full Flutter compilation was not performed because the Flutter SDK is not installed in this environment.
