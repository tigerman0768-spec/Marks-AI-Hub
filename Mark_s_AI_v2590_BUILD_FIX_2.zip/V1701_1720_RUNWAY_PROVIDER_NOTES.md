# Mark's AI v1701–1720

- v1701–1710: Added a real Runway Dev provider adapter using the current documented video task API.
- Supports text-to-video submission through Runway's image_to_video endpoint with no prompt image.
- Uses GEN-4.5 by default and maps Mark's AI aspect ratios to supported output ratios.
- Requires RUNWAYML_API_SECRET (or RUNWAY_API_KEY) on the server; the key is never placed in Flutter.
- v1711–1720: Added provider submit/status routes and a Flutter Runway Clip Generator screen.
- This is the first milestone with an actual external provider submission path, but successful generation still depends on a valid Runway account/API secret and available provider capacity/credits.
- Runway's current documentation confirms text-to-video via image_to_video and task-based generation/status handling.
- JavaScript syntax validation passed for the complete server tree.
- Full Android compilation still requires the Flutter SDK.
