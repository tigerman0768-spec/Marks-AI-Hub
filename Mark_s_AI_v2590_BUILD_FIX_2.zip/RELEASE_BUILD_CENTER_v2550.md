# Release Build Center — v2550

The Release Build Center is the next step after Release Preflight.

## Server configuration
Set these environment variables on the Mark's AI server:

- `GITHUB_OWNER` — repository owner
- `GITHUB_REPO` — repository name
- `GITHUB_TOKEN` — token allowed to dispatch the workflow
- Optional `GITHUB_RELEASE_WORKFLOW` — defaults to `android-release.yml`
- Optional `GITHUB_RELEASE_REF` — defaults to `main`

The token is only used server-side and is never returned by the API.

## Build outputs
GitHub Actions builds:

- `marks-ai-android-apk`
- `marks-ai-android-aab`

The app only reports these as available after the real workflow produces them.
