# Mark's AI v2381–2400

A practical Release Center was added after the release-evidence work.

- v2381–2390: Added a unified Release Center summary service.
- It reports readiness, approval, seal, certificate and manifest state.
- It also tells the user the next required release action.
- v2391–2400: Added a Flutter Release Center screen with a visual stage checklist and refresh action.

This is a UI/status layer; it does not falsely claim a release is complete when a stage is missing.
