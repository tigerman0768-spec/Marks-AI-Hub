# Mark's AI Android release checklist

## Direct APK
- [ ] Flutter SDK installed
- [ ] Android SDK + build tools installed
- [ ] Android host generated
- [ ] `flutter pub get` succeeds
- [ ] `flutter build apk --release` succeeds
- [ ] APK installs on Android
- [ ] App launches to Mark's AI dashboard
- [ ] Film playback/export functions tested

## Google Play
- [ ] `flutter build appbundle --release` succeeds
- [ ] Release signing configured
- [ ] Store listing prepared
- [ ] AAB uploaded to Play Console

No APK is claimed by this source package unless the build command actually
produces the artifact.
