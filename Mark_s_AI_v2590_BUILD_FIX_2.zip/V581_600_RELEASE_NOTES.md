# Mark's AI v581–600

- v581–590: Unified Project Overview API.
- v591–600: Project Detail / Studio launch screen.
- Consolidates project identity, format, counts, tags, lifecycle, stage progress and Studio entry.
- Server JavaScript syntax checked after changes.
