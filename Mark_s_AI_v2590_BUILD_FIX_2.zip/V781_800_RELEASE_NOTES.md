# Mark's AI v781–800

- v781–790: Added video-generation job reconciliation.
- Reconciles persisted per-shot jobs with the existing generation job records when matching IDs are available.
- Copies provider job IDs, progress, clip paths and terminal status/error information.
- v791–800: Added batch generation status API and Flutter dashboard.
- Shows queued/running/completed/failed/cancelled counts and overall progress.
- Added a manual reconciliation action.
- All JavaScript files were checked with `node --check`.

Full Android compilation still requires the Flutter SDK in the build environment.
