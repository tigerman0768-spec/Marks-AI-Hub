# Mark's AI v2590 — Build Fix 2

This package keeps the exact v2590 project version (`1.0.0+2590`) and fixes the Dart compile errors shown by GitHub Actions.

Fixed:
- `video_generation_status_screen.dart`: corrected callable `Number` helper usage.
- `shot_cards_screen.dart`: corrected invalid `List???[]` syntax.
- `final_cut_review_screen.dart`: corrected invalid `List???[]` / `Map???{}` syntax.
- `canonical_timeline_review_screen.dart`: corrected invalid `List???[]` / `Map???{}` syntax.
- `approved_shots_screen.dart`: removed unsupported `jobs:` argument from `ClipReviewScreen`.
- added standard `lib/main.dart` Flutter entrypoint.
- hardened the v2590 Android host preparation script and release workflow.

The package has not been Flutter-compiled in this environment because the Flutter SDK is unavailable locally. GitHub Actions is the build environment.
