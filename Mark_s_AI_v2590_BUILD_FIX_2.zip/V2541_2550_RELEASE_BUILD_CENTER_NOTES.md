# v2541–v2550 — Release Build Center

Adds the final bridge from release preflight to a real Android build.

- Added `GET /api/release-build` for build configuration and artifact status metadata.
- Added `POST /api/release-build/dispatch` for GitHub Actions `workflow_dispatch`.
- Added strict release version validation.
- Added GitHub Actions workflow input `release_version`.
- Added Flutter `Release Build Center` screen.
- Added dashboard entry for Release Build Center.
- Added one-tap APK + AAB build dispatch when GitHub credentials are configured.
- Added copyable GitHub Actions workflow link.
- Keeps the build state honest: no local APK/AAB is claimed until GitHub Actions produces them.
- Flutter app version incremented to `1.0.0+2550`.
