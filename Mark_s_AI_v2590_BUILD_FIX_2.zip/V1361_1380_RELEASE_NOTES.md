# Mark's AI v1361–1380

- v1361–1370: Added a persistent Final Master Release Catalogue entry.
- v1371–1380: Added release-time integrity verification and a Flutter Release Catalogue screen.
- The catalogue requires a sealed release snapshot and release record, a real film file and matching SHA-256 evidence.
- Records catalogue ID, release/snapshot IDs, title, file identity, size, duration, media metadata and hash.
- All JavaScript files were checked with node --check.

Full Android compilation still requires the Flutter SDK in the build environment.
