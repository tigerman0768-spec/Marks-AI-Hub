const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
function registerFilmExportRoutes(app){
  app.get("/api/projects/:id/export-info",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const output=p.finalFilm?.outputPath||p.finalRender?.outputPath||p.finalMaster?.outputPath||null;
    const ready=Boolean(output&&fs.existsSync(output));
    res.json({projectId:p.id,title:p.title||"Untitled Film",ready,outputPath:ready?output:null,
      resolution:p.resolution||"1080p",aspectRatio:p.aspectRatio||"16:9",format:"MP4"});
  });
}
module.exports={registerFilmExportRoutes};
