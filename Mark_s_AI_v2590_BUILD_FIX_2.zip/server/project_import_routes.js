const fs=require("fs"),path=require("path");
function registerProjectImportRoutes(app){
 app.post("/api/projects/import",(req,res)=>{
  const incoming=req.body?.project;if(!incoming||typeof incoming!=="object")return res.status(400).json({error:"project payload required"});
  const dir=path.join(process.cwd(),"projects");fs.mkdirSync(dir,{recursive:true});
  const base=String(incoming.id||`import-${Date.now()}`).replace(/[^a-zA-Z0-9_-]/g,"-");let id=base,file=path.join(dir,`${id}.json`),i=1;
  while(fs.existsSync(file)){id=`${base}-${i++}`;file=path.join(dir,`${id}.json`);}
  const now=new Date().toISOString();const p={...incoming,id,title:String(incoming.title||"Imported Film"),status:"draft",createdAt:now,updatedAt:now};
  fs.writeFileSync(file,JSON.stringify(p,null,2));res.status(201).json({projectId:id,title:p.title,status:p.status});
 });
}
module.exports={registerProjectImportRoutes};
