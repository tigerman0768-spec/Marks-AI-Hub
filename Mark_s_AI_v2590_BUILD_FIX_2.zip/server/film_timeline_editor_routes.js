const path=require("path");
const {getProject}=require("./film_projects");
const {editTimeline,loadEditableTimeline}=require("./film_timeline_editor");

function registerFilmTimelineEditorRoutes(app){
  app.patch("/api/projects/:id/timeline",(req,res)=>{
    try{
      const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const result=editTimeline(path.join(process.cwd(),"timelines"),project.id,req.body?.action,req.body||{});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/projects/:id/timeline/editable",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const result=loadEditableTimeline(path.join(process.cwd(),"timelines"),project.id);
    if(!result)return res.status(404).json({error:"timeline not built"});
    res.json(result);
  });
}
module.exports={registerFilmTimelineEditorRoutes};
