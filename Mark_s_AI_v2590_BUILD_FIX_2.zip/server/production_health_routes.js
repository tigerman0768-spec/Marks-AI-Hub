const fs=require("fs");
const path=require("path");
const {getProject}=require("./film_projects");
function fileReady(p){try{return Boolean(p&&fs.existsSync(p)&&fs.statSync(p).size>0)}catch{return false}}
function registerProductionHealthRoutes(app){
  app.get("/api/projects/:id/production-health",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const checks=[
      ["screenplay",Boolean(p.screenplay&&(p.screenplay.scenes?.length||p.scenes?.length))],
      ["productionPlan",Boolean(p.characterBible||p.storyboard||p.shotCards)],
      ["clips",Boolean((p.videoJobs||[]).some(j=>j.videoUrl||j.outputUrl)||p.finalTimeline?.items?.length)],
      ["edit",Boolean(p.aiEditPlan||p.finalTimeline)],
      ["finalCut",Boolean(p.finalCutRender||p.finalTimeline)],
      ["subtitles",!p.subtitleFile||fileReady(p.subtitleFile)],
      ["finishing",Boolean(p.finalFinishingPlan)]
    ];
    const result=Object.fromEntries(checks);
    const readyCount=checks.filter(x=>x[1]).length;
    res.json({projectId:p.id,status:p.status||"draft",checks:result,readyCount,total:checks.length,
      completion:Math.round(readyCount/checks.length*100),next:checks.find(x=>!x[1])?.[0]||"final-master"});
  });
}
module.exports={registerProductionHealthRoutes};
