const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");
const {writeDialogueSrt}=require("./dialogue_subtitles");
const {buildFinalMixArgs,collectAudioTracks}=require("./final_audio_mix");
const {buildDuckedMixArgs,buildDuckingWindows}=require("./audio_ducking");
const {buildSubtitleBurnArgs}=require("./subtitle_export");

function ensureFile(p,label){if(!p||!fs.existsSync(p)||!fs.statSync(p).size)throw new Error(`${label} unavailable: ${p||"missing"}`);}
function runFfmpeg(args,ffmpeg){return new Promise((resolve,reject)=>{
 const child=spawn(ffmpeg||process.env.FFMPEG_BIN||"ffmpeg",args,{stdio:["ignore","ignore","pipe"]});
 let err=""; child.stderr.on("data",d=>err+=d.toString());
 child.on("error",reject);
 child.on("close",code=>code===0?resolve():reject(new Error(`FFmpeg failed (${code}): ${err.slice(-1800)}`)));
});}
async function finishFilm(config){
 const onStage=typeof config.onStage==='function'?config.onStage:()=>{};
 ensureFile(config.videoPath,"video");
 const work=config.workDir||path.dirname(config.outputPath); fs.mkdirSync(work,{recursive:true});
 const mixed=path.join(work,"01_audio_mix.mp4"),ducked=path.join(work,"02_ducked_mix.mp4");
 const srt=path.join(work,"03_dialogue.srt"),subtitled=path.join(work,"04_subtitled.mp4");
 const tracks=collectAudioTracks(config.plan||{});
 onStage('Audio Mix',20); await runFfmpeg(buildFinalMixArgs(config.videoPath,tracks,mixed,config.ffmpeg).args,config.ffmpeg);
 onStage('Audio Ducking',40); const windows=buildDuckingWindows(config.plan||{});
 await runFfmpeg(buildDuckedMixArgs(mixed,tracks,windows,ducked,config.ffmpeg).args,config.ffmpeg);
 onStage('Subtitles',60); writeDialogueSrt(config.scenePlans||config.plan?.scenes||[],srt);
 onStage('Burn Subtitles',80); await runFfmpeg(buildSubtitleBurnArgs(ducked,srt,subtitled,config).args,config.ffmpeg); onStage('Final MP4',95);
 ensureFile(subtitled,"final video"); fs.mkdirSync(path.dirname(config.outputPath),{recursive:true});
 fs.copyFileSync(subtitled,config.outputPath);
 return {outputPath:config.outputPath,bytes:fs.statSync(config.outputPath).size,
 stages:{audioMix:mixed,duckedMix:ducked,subtitles:srt,subtitled},trackCount:tracks.length,duckWindows:windows.length};
}
module.exports={finishFilm};
