const fs=require("fs"),path=require("path");
function registerProjectNotesRoutes(app){
 app.get("/api/projects/:id/notes",(req,res)=>{
  const file=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(file))return res.status(404).json({error:"project not found"});
  const p=JSON.parse(fs.readFileSync(file,"utf8"));res.json({projectId:p.id,title:p.title,notes:Array.isArray(p.notes)?p.notes:[]});
 });
 app.post("/api/projects/:id/notes",(req,res)=>{
  const file=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(file))return res.status(404).json({error:"project not found"});
  const p=JSON.parse(fs.readFileSync(file,"utf8"));const text=String(req.body?.text||"").trim();if(!text)return res.status(400).json({error:"note text required"});
  p.notes=Array.isArray(p.notes)?p.notes:[];p.notes.push({id:`note-${Date.now()}`,text,createdAt:new Date().toISOString()});p.updatedAt=new Date().toISOString();
  fs.writeFileSync(file,JSON.stringify(p,null,2));res.status(201).json(p.notes[p.notes.length-1]);
 });
}
module.exports={registerProjectNotesRoutes};
