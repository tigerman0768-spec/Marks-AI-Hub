const fs=require("fs");
const path=require("path");

function orderedApprovedShots(project={}){
  const jobs=Array.isArray(project.videoJobs)?project.videoJobs:[];
  const reviews=project.clipReviews||{};
  return jobs.filter(j=>
    (reviews[j.id]?.decision||j.reviewStatus||"pending")==="accepted" &&
    j.downloadStatus==="downloaded" && j.clipPath
  ).sort((a,b)=>{
    const sa=Number(a.sceneNumber??a.sceneIndex??0), sb=Number(b.sceneNumber??b.sceneIndex??0);
    if(sa!==sb)return sa-sb;
    return Number(a.shotNumber||0)-Number(b.shotNumber||0);
  });
}
function buildTimeline(project={}){
  const shots=orderedApprovedShots(project);
  return shots.map((j,i)=>({
    id:`timeline-${j.id}`,
    jobId:j.id,
    order:i,
    sceneId:j.sceneId,
    sceneTitle:j.sceneTitle||`Scene ${j.sceneId||i+1}`,
    shotNumber:Number(j.shotNumber||i+1),
    shotType:j.shotType||"shot",
    clipPath:j.clipPath,
    clipUrl:`/api/projects/${project.id}/clips/${j.id}`,
    duration:Number(j.duration||project.shotDuration||5),
    transition:{type:"cut",duration:0}
  }));
}
function saveTimeline(dir,projectId,timeline){
  fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,`${projectId}.json`);
  const record={projectId,updatedAt:new Date().toISOString(),items:timeline};
  fs.writeFileSync(file,JSON.stringify(record,null,2));
  return record;
}
function loadTimeline(dir,projectId){
  const file=path.join(dir,`${projectId}.json`);
  if(!fs.existsSync(file))return null;
  try{return JSON.parse(fs.readFileSync(file,"utf8"));}catch{return null;}
}
module.exports={orderedApprovedShots,buildTimeline,saveTimeline,loadTimeline};
