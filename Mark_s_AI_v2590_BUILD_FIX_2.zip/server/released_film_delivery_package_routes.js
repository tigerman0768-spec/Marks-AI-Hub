const path=require("path");
const {getProject}=require("./film_projects");
const {buildReleasedFilmDeliveryPackage}=require("./released_film_delivery_package");
function registerReleasedFilmDeliveryPackageRoutes(app){
  app.get("/api/projects/:id/final-render/library-release/delivery-package",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,package:p.finalMasterReleasedFilmDeliveryPackage||null});
  });
  app.post("/api/projects/:id/final-render/library-release/delivery-package/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=buildReleasedFilmDeliveryPackage(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliveryPackageRoutes};
