const path=require("path");
const {getProject}=require("./film_projects");
const {createReleaseRecord}=require("./final_master_release_record");
function registerFinalMasterReleaseRecordRoutes(app){
  app.get("/api/projects/:id/final-render/release-record",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,record:p.finalMasterReleaseRecord||null});
  });
  app.post("/api/projects/:id/final-render/release-record/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleaseRecord(p);
    res.status(result.released?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterReleaseRecordRoutes};
