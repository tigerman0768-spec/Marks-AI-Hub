const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function buildReleasedFilmDeliveryPackage(project){
  const release=project?.finalMasterLibraryRelease;
  const verification=project?.finalMasterLibraryReleaseVerification;
  if(!release?.libraryReleaseId) return {ready:false,blockers:["library release is missing"]};
  if(!verification?.verified) return {ready:false,blockers:["released film must pass verification"]};
  const output=release.outputPath;
  if(!output||!fs.existsSync(output)) return {ready:false,blockers:["released film file is missing"]};

  const packageId=`delivery_package_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_package");
  fs.mkdirSync(dir,{recursive:true});

  const manifest={
    packageId,projectId:project.id,libraryReleaseId:release.libraryReleaseId,
    catalogId:project.finalMasterReleaseCatalog?.catalogId||null,
    title:release.title,filename:release.filename,bytes:release.bytes,
    sha256:release.sha256,duration:release.duration||0,
    video:release.video||null,audio:release.audio||null,
    sourcePath:output,createdAt:new Date().toISOString(),status:"ready"
  };
  fs.writeFileSync(path.join(dir,"delivery_manifest.json"),JSON.stringify(manifest,null,2));
  fs.writeFileSync(path.join(dir,"release_verification.json"),JSON.stringify(verification,null,2));

  const pkg={
    packageId,manifestPath:path.join(dir,"delivery_manifest.json"),
    verificationPath:path.join(dir,"release_verification.json"),
    outputPath:output,status:"ready",createdAt:manifest.createdAt
  };
  project.finalMasterReleasedFilmDeliveryPackage=pkg;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,package:pkg,manifest};
}
module.exports={buildReleasedFilmDeliveryPackage};
