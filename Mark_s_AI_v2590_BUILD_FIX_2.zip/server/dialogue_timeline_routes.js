const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {loadDialogue,editDialogue}=require("./dialogue_timeline");
function registerDialogueTimelineRoutes(app){
  const dir=path.join(process.cwd(),"dialogue");
  app.get("/api/projects/:id/timeline/dialogue",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(loadDialogue(dir,p.id));
  });
  app.patch("/api/projects/:id/timeline/dialogue",(req,res)=>{
    try{
      const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
      if(!p)return res.status(404).json({error:"project not found"});
      const result=editDialogue(dir,p.id,req.body?.action,req.body||{});
      saveProject(path.join(process.cwd(),"projects"),{...p,dialogueTracks:result.tracks});
      res.json(result);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerDialogueTimelineRoutes};
