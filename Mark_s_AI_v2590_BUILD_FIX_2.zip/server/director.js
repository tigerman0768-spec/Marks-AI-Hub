const crypto = require("crypto");

function chooseShot(scene, index) {
  const beats = [
    { type: "wide", movement: "slow push-in", purpose: "establish location and geography" },
    { type: "medium", movement: "gentle tracking", purpose: "follow the main action" },
    { type: "close-up", movement: "subtle handheld", purpose: "capture emotion and dialogue" },
    { type: "over-the-shoulder", movement: "locked-off", purpose: "emphasise the character interaction" },
    { type: "wide", movement: "slow pan", purpose: "show the scene transition or consequence" },
  ];
  const b = beats[index % beats.length];
  return {
    id: crypto.randomUUID(),
    sceneId: scene.id || `scene-${index + 1}`,
    shotNumber: index + 1,
    shotType: b.type,
    cameraMovement: b.movement,
    purpose: b.purpose,
    emotion: scene.emotion || "natural",
    lighting: scene.lighting || "cinematic",
    continuity: {
      preserveCharacters: scene.characters || [],
      preserveLocation: scene.location || "",
      wardrobe: scene.wardrobe || "consistent",
    }
  };
}

function buildDirectorPlan(scenes = []) {
  return scenes.map((scene, i) => {
    const count = Math.max(3, Math.min(6, Number(scene.shotCount || 4)));
    return {
      sceneId: scene.id || `scene-${i + 1}`,
      sceneTitle: scene.title || `Scene ${i + 1}`,
      shots: Array.from({length: count}, (_, j) => chooseShot(scene, j))
    };
  });
}

module.exports = { buildDirectorPlan };
