const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {reviewClip,getReviewSet}=require("./real_clip_review");

function registerRealClipReviewRoutes(app){
  app.get("/api/projects/:id/clips/review",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,clips:getReviewSet(p),approvedGeneratedClips:p.approvedGeneratedClips||[]});
  });
  app.post("/api/projects/:id/clips/review/:clipId",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=reviewClip(p,req.params.clipId,req.body?.decision,req.body?.notes);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerRealClipReviewRoutes};
