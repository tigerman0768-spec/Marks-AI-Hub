const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectProductionSummaryRoutes(app){
  app.get("/api/projects/:id/production-summary",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const jobs=p.videoJobs||[];
    const accepted=Object.values(p.clipReviews||{}).filter(x=>x?.decision==="accepted").length;
    res.json({
      projectId:p.id,title:p.title||"Untitled Film",status:p.status||"draft",
      scenes:(p.scenes||[]).length,videoJobs:jobs.length,acceptedClips:accepted,
      hasScreenplay:Boolean(p.screenplay),hasProductionPlan:Boolean(p.characterBible||p.storyboard||p.shotCards),
      hasEdit:Boolean(p.aiEditPlan||p.finalTimeline),hasFinalCut:Boolean(p.finalCutRender||p.finalTimeline),
      hasAudio:Boolean((p.dialogueTracks||[]).length||p.musicPath||p.backgroundMusicPath),
      hasSubtitles:Boolean(p.subtitleFile),hasFinishing:Boolean(p.finalFinishingPlan)
    });
  });
}
module.exports={registerProjectProductionSummaryRoutes};
