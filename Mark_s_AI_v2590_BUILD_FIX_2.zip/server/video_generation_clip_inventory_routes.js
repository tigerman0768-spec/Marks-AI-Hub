const path = require("path");
const fs = require("fs");
const { getProject } = require("./film_projects");

function registerVideoGenerationClipInventoryRoutes(app) {
  app.get("/api/projects/:id/video-generation/clip-inventory", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const clips = Array.isArray(p.generatedClips) ? p.generatedClips : [];
    const inventory = clips.map(c => {
      const fileExists = Boolean(c.path && fs.existsSync(c.path));
      return {
        id: c.id,
        jobId: c.jobId,
        shotId: c.shotId,
        scene: c.scene,
        index: c.index,
        path: c.path || null,
        provider: c.provider || null,
        duration: c.duration || 0,
        status: fileExists ? "available" : "missing_file",
        fileExists
      };
    });

    res.json({
      projectId: p.id,
      total: inventory.length,
      available: inventory.filter(c => c.fileExists).length,
      missing: inventory.filter(c => !c.fileExists).length,
      inventory
    });
  });
}

module.exports = { registerVideoGenerationClipInventoryRoutes };
