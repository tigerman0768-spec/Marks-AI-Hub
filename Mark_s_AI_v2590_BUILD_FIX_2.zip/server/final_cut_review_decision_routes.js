const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const allowed=["pending","keep","remove","trim"];
function registerFinalCutReviewDecisionRoutes(app){
  app.patch("/api/projects/:id/final-cut/review/:timelineId",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const d=p.finalCutReview?.decisions?.find(x=>x.timelineId===req.params.timelineId);
    if(!d)return res.status(404).json({error:"review item not found"});
    const status=String(req.body?.status||"");
    if(!allowed.includes(status))return res.status(400).json({error:"invalid status",allowed});
    d.status=status;d.note=req.body?.note?String(req.body.note):null;d.updatedAt=new Date().toISOString();
    saveProject(dir,p);res.json(d);
  });
}
module.exports={registerFinalCutReviewDecisionRoutes};
