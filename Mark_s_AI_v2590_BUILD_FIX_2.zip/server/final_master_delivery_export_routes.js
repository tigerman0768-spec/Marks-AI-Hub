const path=require("path");
const {getProject}=require("./film_projects");
const {writeDeliveryExport}=require("./final_master_delivery_export");
function registerFinalMasterDeliveryExportRoutes(app){
  app.get("/api/projects/:id/final-render/delivery-export",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,export:require("./final_master_delivery_export").getDeliveryExport(p)});
  });
  app.post("/api/projects/:id/final-render/delivery-export/write",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=writeDeliveryExport(p);
    res.status(result.exportable?200:409).json({projectId:p.id,export:result});
  });
}
module.exports={registerFinalMasterDeliveryExportRoutes};
