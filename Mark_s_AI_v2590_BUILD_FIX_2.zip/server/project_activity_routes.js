const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectActivityRoutes(app){
 app.get("/api/projects/:id/activity",(req,res)=>{
  const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  const events=[];
  const add=(type,label,value)=>{if(value)events.push({type,label,value});};
  add("created","Created",p.createdAt);add("updated","Last updated",p.updatedAt);
  add("screenplay","Screenplay ready",p.screenplay);add("production","Production plan",p.characterBible||p.storyboard||p.shotCards);
  add("edit","AI edit prepared",p.aiEditPlan||p.finalTimeline);add("finish","Final finishing prepared",p.finalFinishingPlan);
  add("status","Lifecycle status",p.status);
  res.json({projectId:p.id,title:p.title,events:events.reverse()});
 });
}
module.exports={registerProjectActivityRoutes};
