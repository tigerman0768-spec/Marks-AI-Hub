const path = require("path");
const fs = require("fs");
const { getProject, saveProject } = require("./film_projects");

function registerGeneratedClipReviewSetRoutes(app) {
  app.post("/api/projects/:id/generated-clips/review-set", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const clips = Array.isArray(p.generatedClips) ? p.generatedClips : [];
    const available = clips.filter(c => c.path && fs.existsSync(c.path));

    const reviewSet = {
      id: `review-set-${p.id}-${Date.now()}`,
      projectId: p.id,
      createdAt: new Date().toISOString(),
      clips: available.map((c, index) => ({
        id: c.id,
        shotId: c.shotId,
        scene: c.scene,
        index: c.index || index + 1,
        path: c.path,
        duration: c.duration || 0,
        reviewStatus: "pending"
      }))
    };

    p.clipReviewSet = reviewSet;
    saveProject(dir, p);
    res.status(201).json(reviewSet);
  });

  app.get("/api/projects/:id/generated-clips/review-set", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    if (!p.clipReviewSet) return res.status(404).json({ error: "review set not created" });
    res.json(p.clipReviewSet);
  });
}

module.exports = { registerGeneratedClipReviewSetRoutes };
