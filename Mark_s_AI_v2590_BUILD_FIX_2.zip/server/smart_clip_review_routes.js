const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {reviewProjectClips,scoreClip}=require("./smart_clip_review");

function registerSmartClipReviewRoutes(app){
  app.get("/api/projects/:id/clips/smart-review",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const results=reviewProjectClips(project);
      saveProject(dir,{...project,videoJobs:project.videoJobs,status:"smart_reviewed"});
      res.json({projectId:project.id,results});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/clips/:jobId/smart-review",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const job=(project.videoJobs||[]).find(j=>j.id===req.params.jobId);
      if(!job)return res.status(404).json({error:"clip job not found"});
      const review=scoreClip(job);
      job.smartReview=review;job.smartReviewAt=new Date().toISOString();
      saveProject(dir,{...project,videoJobs:project.videoJobs});
      res.json({jobId:job.id,review});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerSmartClipReviewRoutes};
