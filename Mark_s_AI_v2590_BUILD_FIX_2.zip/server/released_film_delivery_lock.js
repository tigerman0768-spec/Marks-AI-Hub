const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function lockReleasedFilmDelivery(project){
  const gate=project?.finalMasterReleasedFilmDeliveryGate;
  if(!gate?.ready)return {locked:false,blockers:["final release delivery gate must pass"]};
  if(!gate.outputPath||!fs.existsSync(gate.outputPath))return {locked:false,blockers:["final film file is missing"]};
  const stat=fs.statSync(gate.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(gate.outputPath)).digest("hex");
  if(sha!==gate.sha256||stat.size!==Number(gate.bytes))
    return {locked:false,blockers:["current final film no longer matches the delivery gate"]};

  const lock={
    lockId:`delivery_lock_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",
    outputPath:gate.outputPath,bytes:stat.size,sha256:sha,
    gateId:gate.gateId,lockedAt:new Date().toISOString(),status:"locked"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_lock");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"delivery_lock.json"),JSON.stringify(lock,null,2));
  project.finalMasterReleasedFilmDeliveryLock=lock;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {locked:true,lock};
}
module.exports={lockReleasedFilmDelivery};
