const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {downloadCompletedClips}=require("./auto_clip_download");

function registerAutoClipDownloadRoutes(app){
  app.post("/api/projects/:id/video-generation/download-completed",async(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      if(!project.videoGenerationRun)return res.status(400).json({error:"no generation run"});
      const result=await downloadCompletedClips(project,project.videoGenerationRun,{});
      const run={...project.videoGenerationRun,jobs:result.jobs};
      saveProject(dir,{...project,videoGenerationRun:run,videoJobs:run.jobs,status:"clips_downloaded"});
      res.json({projectId:project.id,results:result.results,run});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAutoClipDownloadRoutes};
