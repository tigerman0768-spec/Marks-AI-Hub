const path=require("path");
const {getProject}=require("./film_projects");
const {archiveDelivery}=require("./final_master_delivery_archive");
function registerFinalMasterDeliveryArchiveRoutes(app){
  app.get("/api/projects/:id/final-render/delivery-archive",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,archive:p.finalMasterDeliveryArchive||null});
  });
  app.post("/api/projects/:id/final-render/delivery-archive/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=archiveDelivery(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterDeliveryArchiveRoutes};
