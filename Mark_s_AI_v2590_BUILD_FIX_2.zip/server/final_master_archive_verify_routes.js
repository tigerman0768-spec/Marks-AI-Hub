const path=require("path");
const {getProject}=require("./film_projects");
const {verifyArchive}=require("./final_master_archive_verify");
function registerFinalMasterArchiveVerifyRoutes(app){
  app.get("/api/projects/:id/final-render/archive-verification",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,verification:p.finalMasterArchiveVerification||null});
  });
  app.post("/api/projects/:id/final-render/archive-verification/check",async(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const verification=verifyArchive(p);
    res.status(verification.verified?200:409).json({projectId:p.id,verification});
  });
}
module.exports={registerFinalMasterArchiveVerifyRoutes};
