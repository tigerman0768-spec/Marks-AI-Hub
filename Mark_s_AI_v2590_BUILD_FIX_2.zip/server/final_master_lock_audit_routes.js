const path=require("path");
const {getProject}=require("./film_projects");
const {appendLockAudit,getLockAudit}=require("./final_master_lock_audit");
function registerFinalMasterLockAuditRoutes(app){
  app.get("/api/projects/:id/final-render/lock-audit",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,audit:getLockAudit(p)});
  });
  app.post("/api/projects/:id/final-render/lock-audit",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const event=String(req.body?.event||"manual_review");
    const allowed=["manual_review","delivery_verified","master_locked","integrity_check"];
    if(!allowed.includes(event))return res.status(400).json({error:"unsupported audit event"});
    const entry=appendLockAudit(p,event,{note:String(req.body?.note||"")});
    res.status(201).json({projectId:p.id,entry,audit:getLockAudit(p)});
  });
}
module.exports={registerFinalMasterLockAuditRoutes};
