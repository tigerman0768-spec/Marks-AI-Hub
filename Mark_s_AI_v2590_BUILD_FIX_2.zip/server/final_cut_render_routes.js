const path=require("path");
const {getProject}=require("./film_projects");
const {loadTimeline}=require("./film_timeline");
const {buildAutomaticEdit}=require("./ai_editing_engine");

function buildRenderConfig(project,timeline){
  const items=(timeline?.items||[]).filter(x=>x.clipPath);
  return {
    projectId:project.id,title:project.title||"Untitled Film",
    idea:project.idea||"",genre:project.genre||"Drama",
    length:Number(project.length||5),style:project.style||"Cinematic",
    aspectRatio:project.aspectRatio||"16:9",
    clips:items.map((x,i)=>({
      id:x.id||`timeline-${i+1}`,jobId:x.jobId,sceneId:x.sceneId,
      shotNumber:x.shotNumber,clipPath:x.clipPath,duration:Number(x.duration||0),
      transition:x.transition||{type:"cut",duration:0}
    })),
    audio:{dialogue:project.dialogueAudio||null,music:project.musicPath||project.backgroundMusicPath||null,
      sfx:project.sfxPath||null},
    subtitles:project.subtitleFile||project.subtitles?.path||null
  };
}

function registerFinalCutRenderRoutes(app){
  app.get("/api/projects/:id/final-cut-render",(req,res)=>{
    const project=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!project)return res.status(404).json({error:"project not found"});
    const timeline=loadTimeline(path.join(process.cwd(),"timelines"),project.id);
    const config=buildRenderConfig(project,timeline||{items:project.finalTimeline?.items||[]});
    res.json({...config,ready:config.clips.length>0});
  });
}
module.exports={buildRenderConfig,registerFinalCutRenderRoutes};
