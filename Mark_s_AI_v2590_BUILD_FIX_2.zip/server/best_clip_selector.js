function scoreVersion(v={}){
  const smart=Number(v.smartReview?.score);
  if(Number.isFinite(smart)) return smart;
  const q=v.qualityReport||{};
  let score=50;
  if(q.valid) score+=25;
  if(q.playable) score+=15;
  if(q.width&&q.height) score+=5;
  if(q.issues?.length) score-=Math.min(20,q.issues.length*5);
  return Math.max(0,Math.min(100,score));
}
function selectBestVersions(record={}){
  const groups={};
  for(const v of record.versions||[])(groups[v.shotKey] ||= []).push(v);
  const selections=[];
  for(const [shotKey,versions] of Object.entries(groups)){
    const ranked=versions.map(v=>({...v,selectionScore:scoreVersion(v)}))
      .sort((a,b)=>b.selectionScore-a.selectionScore||b.version-a.version);
    if(ranked[0]) selections.push({shotKey,bestVersionId:ranked[0].id,
      version:ranked[0].version,score:ranked[0].selectionScore,clipPath:ranked[0].clipPath});
  }
  return selections;
}
function applyBestVersions(project,selections=[]){
  const jobs=project.videoJobs||[];
  for(const s of selections){
    for(const job of jobs){
      if(`${job.sceneId}:${job.shotNumber}`!==s.shotKey) continue;
      job.selectedVersionId=s.bestVersionId;
      job.selectedClipPath=s.clipPath;
      job.bestVersion=true;
      job.bestVersionScore=s.score;
    }
  }
  return jobs;
}
module.exports={scoreVersion,selectBestVersions,applyBestVersions};
