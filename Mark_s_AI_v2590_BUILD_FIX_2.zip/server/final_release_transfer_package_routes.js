const path=require('path');
const fs=require('fs');
const {getProject}=require('./film_projects');
const {buildTransferPackage}=require('./final_release_transfer_package');
function registerFinalReleaseTransferPackageRoutes(app){
  app.get('/api/projects/:id/final-render/release-package',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    const outputDir=path.join(process.cwd(),'projects',req.params.id,'final_render','release_package');
    buildTransferPackage(p,outputDir).then(result=>res.status(result.available?200:409).json({projectId:p.id,title:p.title,...result}));
  });
  app.get('/api/projects/:id/final-render/release-package/download',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    const file=path.join(process.cwd(),'projects',req.params.id,'final_render','release_package',`marks_ai_${p.id}_release_package.zip`);
    if(!fs.existsSync(file))return res.status(404).json({error:'release package not generated'});
    res.download(path.resolve(file),path.basename(file));
  });
}
module.exports={registerFinalReleaseTransferPackageRoutes};
