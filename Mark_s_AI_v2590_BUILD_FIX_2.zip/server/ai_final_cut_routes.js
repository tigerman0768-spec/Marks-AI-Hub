const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildFinalCutPlan}=require("./ai_final_cut_planner");

function registerFinalCutRoutes(app){
  app.get("/api/projects/:id/final-cut-plan",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildFinalCutPlan(project);
      saveProject(dir,{...project,finalCutPlan:plan});
      res.json(plan);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/final-cut-plan/apply",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const plan=buildFinalCutPlan(project);
      saveProject(dir,{...project,finalCutPlan:plan,status:"final_cut_planned"});
      res.json(plan);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalCutRoutes};
