const fs=require("fs");
const path=require("path");
const {normaliseTrack}=require("./timeline_audio_tracks");

function audioFile(dir,id){return path.join(dir,`${id}.json`);}
function loadProjectAudio(dir,projectId){
  const f=audioFile(dir,projectId);
  if(!fs.existsSync(f))return {projectId,tracks:[],updatedAt:null};
  try{return JSON.parse(fs.readFileSync(f,"utf8"));}catch{return {projectId,tracks:[],updatedAt:null};}
}
function saveProjectAudio(dir,projectId,tracks){
  fs.mkdirSync(dir,{recursive:true});
  const record={projectId,updatedAt:new Date().toISOString(),tracks:tracks.map(normaliseTrack)};
  fs.writeFileSync(audioFile(dir,projectId),JSON.stringify(record,null,2));
  return record;
}
function editProjectAudio(dir,projectId,action,payload={}){
  const current=loadProjectAudio(dir,projectId);
  let tracks=[...(current.tracks||[])];
  if(action==="add"){
    if(!payload.track)throw new Error("track required");
    tracks.push(normaliseTrack(payload.track));
  }else if(action==="update"){
    const index=Number(payload.index);
    if(!Number.isInteger(index)||index<0||index>=tracks.length)throw new Error("invalid audio track");
    tracks[index]=normaliseTrack({...tracks[index],...(payload.track||{})});
  }else if(action==="remove"){
    const index=Number(payload.index);
    if(!Number.isInteger(index)||index<0||index>=tracks.length)throw new Error("invalid audio track");
    tracks.splice(index,1);
  }else if(action==="reorder"){
    const from=Number(payload.from),to=Number(payload.to);
    if(from<0||to<0||from>=tracks.length||to>=tracks.length)throw new Error("invalid audio positions");
    const [x]=tracks.splice(from,1);tracks.splice(to,0,x);
  }else throw new Error("unsupported audio action");
  return saveProjectAudio(dir,projectId,tracks);
}
module.exports={loadProjectAudio,saveProjectAudio,editProjectAudio};
