const {getProject}=require("./film_projects");
const fs=require("fs");
function getReleaseStatus(projectId){
  const p=getProject(require("path").join(process.cwd(),"projects"),projectId);
  if(!p)return {found:false,error:"project not found"};
  const c=p.approvedFilmReleaseCertificate,a=p.approvedFilmReleaseApproval,
        s=p.approvedFilmReleaseSnapshot,l=p.approvedFilmDeliveryLock;
  let status="in-progress";
  if(c?.status==="released")status="released";
  else if(s&&a&&l)status="sealed";
  else if(a)status="approved";
  return {found:true,projectId:p.id,title:p.title||"Untitled Film",status,
    certificateId:c?.certificateId||null,sealId:p.approvedFilmReleaseSeal?.sealId||null,
    approvalId:a?.approvalId||null,snapshotId:s?.snapshotId||null,
    fileExists:!!l?.filmPath&&fs.existsSync(l.filmPath),
    filename:c?.filename||s?.filename||l?.filename||null,
    bytes:c?.bytes||s?.bytes||l?.bytes||null,
    sha256:c?.sha256||s?.sha256||l?.sha256||null};
}
module.exports={getReleaseStatus};
