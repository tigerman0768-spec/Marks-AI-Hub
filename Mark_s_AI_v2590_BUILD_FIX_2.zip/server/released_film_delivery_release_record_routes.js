const path=require("path");
const {getProject}=require("./film_projects");
const {createFinalReleaseRecord}=require("./released_film_delivery_release_record");
function registerFinalReleaseRecordRoutes(app){
  app.get("/api/projects/:id/final-render/final-release-record",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,release:p.finalMasterFinalReleaseRecord||null});
  });
  app.post("/api/projects/:id/final-render/final-release-record/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createFinalReleaseRecord(p);
    res.status(result.ready?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalReleaseRecordRoutes};
