const TRANSITIONS = {
  cut: { type:"cut", duration:0 },
  fade: { type:"fade", duration:0.5 },
  dissolve: { type:"dissolve", duration:0.8 },
  dipToBlack: { type:"dip-to-black", duration:0.7 },
  wipe: { type:"wipe", duration:0.6 }
};

function chooseTransition(current = {}, next = {}) {
  const a = String(current.mood || current.emotion || "").toLowerCase();
  const b = String(next.mood || next.emotion || "").toLowerCase();

  if (/dream|memory|flashback/.test(a + " " + b)) return TRANSITIONS.dissolve;
  if (/ending|death|dark|grief/.test(b)) return TRANSITIONS.dipToBlack;
  if (/action|chase|fight/.test(a + " " + b)) return TRANSITIONS.cut;
  return TRANSITIONS.cut;
}

function estimatePacing(scene = {}) {
  const mood = String(scene.mood || scene.emotion || "").toLowerCase();
  if (/action|chase|fight|panic/.test(mood)) return { rhythm:"fast", shotSeconds:2.5 };
  if (/sad|romantic|grief|reflection/.test(mood)) return { rhythm:"slow", shotSeconds:5.5 };
  if (/mystery|suspense|fear/.test(mood)) return { rhythm:"building", shotSeconds:4 };
  return { rhythm:"balanced", shotSeconds:4 };
}

function buildPacingPlan(scenes = []) {
  return scenes.map((scene, i) => ({
    sceneId: scene.id || `scene-${i + 1}`,
    pacing: estimatePacing(scene),
    transitionToNext: i < scenes.length - 1
      ? chooseTransition(scene, scenes[i + 1])
      : null
  }));
}

function applyPacing(jobs = [], scenes = []) {
  const plans = buildPacingPlan(scenes);
  const byScene = new Map(plans.map(p => [p.sceneId, p]));
  return jobs.map(job => {
    const p = byScene.get(job.sceneId);
    if (!p) return job;
    return {
      ...job,
      pacing: p.pacing,
      transitionToNext: p.transitionToNext,
      prompt: `${job.prompt}. Cinematic pacing: ${p.pacing.rhythm} rhythm, approximately ${p.pacing.shotSeconds}s per shot.`
    };
  });
}

module.exports = { chooseTransition, estimatePacing, buildPacingPlan, applyPacing, TRANSITIONS };
