const crypto=require("crypto");

function normaliseAsset(a={},fallback=""){
  return {
    id:a.id||crypto.randomUUID(),
    name:String(a.name||fallback),
    description:String(a.description||""),
    appearance:String(a.appearance||""),
    wardrobe:String(a.wardrobe||""),
    props:Array.isArray(a.props)?a.props:[],
    notes:String(a.notes||"")
  };
}
function buildCharacterContinuity(characters=[]){
  return characters.map(c=>normaliseAsset({
    id:c.id,name:c.name,description:c.appearance,appearance:c.appearance,
    wardrobe:c.wardrobe,notes:c.continuityNotes
  }, "Character"));
}
function buildSceneContinuity(scene={},characters=[]){
  const names=scene.characters||[];
  return {
    sceneId:scene.id||"scene",
    location:String(scene.location||""),
    time:String(scene.time||""),
    lighting:String(scene.lighting||""),
    wardrobe:String(scene.wardrobe||"consistent"),
    props:Array.isArray(scene.props)?scene.props:[],
    characters:characters.filter(c=>!names.length||names.includes(c.name)).map(c=>normaliseAsset(c,"Character")),
    continuityNotes:String(scene.continuityNotes||"")
  };
}
function buildVisualContinuityPlan(project={}){
  const characters=buildCharacterContinuity(project.characters||[]);
  const scenes=(project.scenes||[]).map(s=>buildSceneContinuity(s,characters));
  return {id:crypto.randomUUID(),updatedAt:new Date().toISOString(),characters,scenes};
}
function buildShotContinuityPrompt(continuity={},shot={}){
  const people=(continuity.characters||[]).map(c=>
    `${c.name}: appearance=${c.appearance||"consistent"}; wardrobe=${c.wardrobe||"consistent"}; props=${(c.props||[]).join(", ")}`
  ).join(" | ");
  return `VISUAL CONTINUITY: Preserve exactly these established details. ${people}. `+
    `Location: ${continuity.location||"consistent location"}. Time: ${continuity.time||"consistent time"}. `+
    `Lighting: ${continuity.lighting||"consistent lighting"}. `+
    `Shot-specific continuity: ${shot.continuity?.preserveLocation||""}. Do not change identity, clothing, hairstyle, props or environment between shots unless explicitly directed.`;
}
module.exports={buildCharacterContinuity,buildSceneContinuity,buildVisualContinuityPlan,buildShotContinuityPrompt};
