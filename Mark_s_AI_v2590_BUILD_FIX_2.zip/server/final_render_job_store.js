const fs=require("fs");
const path=require("path");

function storePath(dir,id){fs.mkdirSync(dir,{recursive:true});return path.join(dir,`${id}.json`);}
function createJob(dir,data){
  const now=new Date().toISOString();
  const job={...data,status:data.status||"queued",createdAt:now,updatedAt:now};
  fs.writeFileSync(storePath(dir,job.id),JSON.stringify(job,null,2));
  return job;
}
function getJob(dir,id){
  const p=storePath(dir,id);
  if(!fs.existsSync(p))return null;
  try{return JSON.parse(fs.readFileSync(p,"utf8"));}catch{return null;}
}
function updateJob(dir,id,patch){
  const job=getJob(dir,id); if(!job)return null;
  const next={...job,...patch,updatedAt:new Date().toISOString()};
  fs.writeFileSync(storePath(dir,id),JSON.stringify(next,null,2)); return next;
}
function listJobs(dir){
  if(!fs.existsSync(dir))return [];
  return fs.readdirSync(dir).filter(x=>x.endsWith(".json")).map(x=>getJob(dir,path.basename(x,".json"))).filter(Boolean);
}
module.exports={createJob,getJob,updateJob,listJobs};
