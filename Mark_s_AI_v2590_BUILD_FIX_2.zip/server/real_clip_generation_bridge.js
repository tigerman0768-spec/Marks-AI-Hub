const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");
const {buildOrchestratedJobs}=require("./video_generation_orchestrator");

function shotFromProject(project,shotId){
  const shots=project?.shotCards||project?.directorPlan?.shotCards||[];
  return shots.find(s=>String(s.id||s.shotId||s.cardId)===String(shotId))||null;
}

function buildRealClipRequest(project,shotId,overrides={}){
  const shot=shotFromProject(project,shotId);
  if(!shot)return {ready:false,blockers:["shot card not found"]};
  const prompt=String(overrides.prompt||shot.videoPrompt||shot.prompt||shot.description||shot.action||"").trim();
  if(!prompt)return {ready:false,blockers:["shot has no video prompt"]};
  const request={
    requestId:`clip_request_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,shotId:String(shotId),title:project.title||"Untitled Film",
    prompt,duration:Number(overrides.duration||shot.duration||5),
    aspectRatio:String(overrides.aspectRatio||project.aspectRatio||"16:9"),
    style:String(overrides.style||project.style||"Cinematic"),
    createdAt:new Date().toISOString(),status:"ready_to_submit"
  };
  return {ready:true,request,shot};
}

function createRealClipJob(project,shotId,overrides={}){
  const built=buildRealClipRequest(project,shotId,overrides);
  if(!built.ready)return built;
  let jobs=[];
  try{
    jobs=buildOrchestratedJobs(project,[{
      shotId:String(shotId),
      prompt:built.request.prompt,
      duration:built.request.duration,
      aspectRatio:built.request.aspectRatio,
      style:built.request.style
    }])||[];
  }catch(e){
    return {ready:false,blockers:[`video orchestration failed: ${e.message}`]};
  }
  const job=jobs[0]||null;
  if(!job)return {ready:false,blockers:["video orchestrator returned no job"]};
  const record={
    ...built.request,
    providerJob:job,
    status:"queued",
    updatedAt:new Date().toISOString()
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"video_generation","real_clips");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,`${record.requestId}.json`),JSON.stringify(record,null,2));
  project.realClipGenerationJobs=[...(project.realClipGenerationJobs||[]),record];
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,record};
}

function getRealClipJobs(project){
  return project?.realClipGenerationJobs||[];
}
module.exports={buildRealClipRequest,createRealClipJob,getRealClipJobs};
