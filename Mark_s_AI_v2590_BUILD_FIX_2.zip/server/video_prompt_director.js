function buildVideoShotPrompt(project={},scene={},shot={},cinematic={},performance={},continuity={}){
  const characters=(continuity.characters||[]).map(c=>
    `${c.name}: appearance ${c.appearance||"consistent"}; wardrobe ${c.wardrobe||"consistent"}`
  ).join(" | ");
  const beat=(performance.shotDirection||[]).find(x=>x.shotId===shot.id)||{};
  return [
    `CINEMATIC FILM SHOT`,
    `Genre: ${project.genre||"Drama"}. Style: ${project.style||"Cinematic"}.`,
    `Scene: ${scene.title||"Scene"}. Location: ${scene.location||"consistent"}. Time: ${scene.time||"consistent"}.`,
    `Action: ${scene.action||scene.description||"natural scene action"}.`,
    `Performance: ${beat.performanceFocus||"natural ensemble performance"}.`,
    `Emotion: ${scene.emotion||performance.emotionalArc||"natural"}.`,
    `Framing: ${cinematic.framing||shot.shotType||"medium"}. Lens: ${cinematic.lens||"cinematic lens"}.`,
    `Camera: ${cinematic.movement||shot.cameraMovement||"controlled cinematic movement"}.`,
    `Lighting: ${cinematic.lighting||scene.lighting||"cinematic lighting"}.`,
    `Composition: ${cinematic.composition||"strong cinematic composition"}. Depth of field: ${cinematic.depthOfField||"moderate"}.`,
    `Characters and continuity: ${characters||"preserve established character identity, wardrobe and props"}.`,
    `Visual continuity: ${cinematic.continuityPrompt||"maintain continuity with previous and following shots"}.`,
    `Shot purpose: ${shot.purpose||cinematic.visualPurpose||"advance the story"}.`,
    `Generate realistic, coherent motion and preserve identity, wardrobe, environment and spatial relationships throughout the shot.`
  ].join(" ");
}
function buildProjectVideoPrompts(project={}){
  const cinematic=project.cinematicShotPlan||[];
  const performance=project.performancePlan||[];
  const continuity=project.visualContinuityPlan||{};
  const director=project.directorPlan||[];
  return (project.scenes||[]).flatMap(scene=>{
    const cp=cinematic.find(x=>x.sceneId===scene.id)||{};
    const pp=performance.find(x=>x.sceneId===scene.id)||{};
    const cont=(continuity.scenes||[]).find(x=>x.sceneId===scene.id)||{};
    const shots=(director.find(x=>x.sceneId===scene.id)||{}).shots||[];
    return shots.map((shot,i)=>{
      const c=(cp.shots||[]).find(x=>x.shotId===shot.id)||(cp.shots||[])[i]||{};
      return {sceneId:scene.id,shotId:shot.id,shotNumber:shot.shotNumber||i+1,
        prompt:buildVideoShotPrompt(project,scene,shot,c,pp,cont)};
    });
  });
}
module.exports={buildVideoShotPrompt,buildProjectVideoPrompts};
