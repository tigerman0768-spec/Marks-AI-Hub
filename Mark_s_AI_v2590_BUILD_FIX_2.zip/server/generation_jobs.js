const { buildDirectorPlan } = require("./director");

/**
 * Convert a scene + director shot plan into provider-neutral generation jobs.
 * Each job can be handed to Runway or another video provider.
 */
function buildSceneGenerationJobs(scenes = [], options = {}) {
  const plan = buildDirectorPlan(scenes);
  const style = options.style || "cinematic";
  const aspectRatio = options.aspectRatio || "16:9";
  const duration = Number(options.duration || 5);

  return plan.flatMap(scene => scene.shots.map(shot => ({
    id: shot.id,
    sceneId: scene.sceneId,
    shotNumber: shot.shotNumber,
    provider: options.provider || "runway",
    duration,
    aspectRatio,
    prompt: [
      style,
      shot.shotType + " shot",
      shot.cameraMovement,
      shot.purpose,
      `emotion: ${shot.emotion}`,
      `lighting: ${shot.lighting}`,
      scene.continuity.preserveCharacters.length
        ? `keep characters consistent: ${scene.continuity.preserveCharacters.join(", ")}`
        : "maintain character continuity",
      scene.continuity.preserveLocation
        ? `location continuity: ${scene.continuity.preserveLocation}`
        : "",
      scene.continuity.wardrobe
        ? `wardrobe: ${scene.continuity.wardrobe}`
        : "",
      `scene: ${scene.sceneTitle}`
    ].filter(Boolean).join(". ")
  })));
}

module.exports = { buildSceneGenerationJobs };
