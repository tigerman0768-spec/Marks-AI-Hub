const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {createScreenplayDraft}=require("./screenplay_generator");
function registerFilmCreatorRoutes(app){
  app.post("/api/projects/:id/screenplay/generate",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const merged={...project,...req.body};
      const draft=createScreenplayDraft(merged);
      const saved=saveProject(dir,{...project,screenplay:draft,scenes:draft.scenes,status:"screenplay_ready"});
      res.status(201).json({project:saved,screenplay:draft});
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.get("/api/creator/:id",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,creator:{title:p.title,idea:p.idea,genre:p.genre,length:p.length,style:p.style,aspectRatio:p.aspectRatio}});
  });
}
module.exports={registerFilmCreatorRoutes};
