const fs = require("fs");
const path = require("path");

function checkAsset(filePath) {
  if (!filePath) return { ok:false, reason:"missing path" };
  if (!fs.existsSync(filePath)) return { ok:false, reason:"file not found" };
  const stat = fs.statSync(filePath);
  if (!stat.isFile() || stat.size === 0) return { ok:false, reason:"empty or invalid file" };
  return { ok:true, size:stat.size };
}

function validateGenerationBatch(jobs = []) {
  const errors = [];
  const seen = new Set();
  for (const job of jobs) {
    if (!job.id) errors.push("job is missing id");
    if (seen.has(job.id)) errors.push(`duplicate job id: ${job.id}`);
    if (job.id) seen.add(job.id);
    if (!job.sceneId) errors.push(`${job.id || "job"} missing sceneId`);
    if (!job.prompt) errors.push(`${job.id || "job"} missing prompt`);
    if (!Number.isFinite(Number(job.duration)) || Number(job.duration) <= 0)
      errors.push(`${job.id || "job"} has invalid duration`);
  }
  return { ok: errors.length === 0, errors, count: jobs.length };
}

function buildRenderReadiness(jobs = [], assets = []) {
  const batch = validateGenerationBatch(jobs);
  const assetChecks = assets.map(a => ({
    id: a.id,
    path: a.path,
    ...checkAsset(a.path)
  }));
  return {
    ready: batch.ok && assetChecks.every(a => a.ok),
    batch,
    assets: assetChecks
  };
}

module.exports = { checkAsset, validateGenerationBatch, buildRenderReadiness };
