const fs=require("fs");
const path=require("path");
const {downloadVoiceAsset}=require("./tts_provider");

async function pollTtsTask({client,taskId,job,assetsDir,timeoutMs=300000,intervalMs=5000}){
  if(!client||!client.tasks||typeof client.tasks.retrieve!=="function")
    throw new Error("TTS task client is not configured");
  if(!taskId) throw new Error("taskId required");
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    const task=await client.tasks.retrieve(taskId);
    const status=String(task?.status||"").toLowerCase();
    if(status==="succeeded"||status==="completed"){
      const url=task?.output?.[0]||task?.output?.url||task?.output;
      if(!url) throw new Error("TTS completed without an output URL");
      const destination=path.join(assetsDir,`voice_${job.id||taskId}.mp3`);
      const file=await downloadVoiceAsset(url,destination);
      return {taskId,jobId:job.id,status:"stored",url,path:file.path,bytes:file.bytes};
    }
    if(status==="failed"||status==="error") throw new Error(task?.failure||task?.error||"TTS task failed");
    await new Promise(r=>setTimeout(r,intervalMs));
  }
  throw new Error(`TTS task timed out: ${taskId}`);
}

function attachStoredVoiceToScene(scene,voice){
  return {...scene,voiceAssets:[...(scene.voiceAssets||[]),{
    id:voice.jobId||voice.taskId,type:"dialogue",localPath:voice.path,
    filmStart:Number(voice.filmStart||0),bytes:voice.bytes,status:"stored"
  }]};
}
module.exports={pollTtsTask,attachStoredVoiceToScene};
