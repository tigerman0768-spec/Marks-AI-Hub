const path=require("path");
const {getProject}=require("./film_projects");
const {evaluateFinalMasterGate}=require("./final_render_master_gate");

function registerFinalRenderMasterGateRoutes(app){
  app.get("/api/projects/:id/final-render/master-gate",async(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const gate=p.finalMasterGate||null;
    res.json({projectId:p.id,gate});
  });
  app.post("/api/projects/:id/final-render/master-gate/evaluate",async(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const gate=await evaluateFinalMasterGate(p);
    res.status(gate.ready?200:409).json({projectId:p.id,gate});
  });
}
module.exports={registerFinalRenderMasterGateRoutes};
