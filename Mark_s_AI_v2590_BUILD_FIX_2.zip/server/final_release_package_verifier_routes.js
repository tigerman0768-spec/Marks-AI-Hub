const path=require('path');
const {getProject}=require('./film_projects');
const {buildTransferPackage}=require('./final_release_transfer_package');
const {verifyReleasePackage}=require('./final_release_package_verifier');
const {recordIntegrityVerification}=require('./release_package_integrity_history');
function registerFinalReleasePackageVerifierRoutes(app){
  app.get('/api/projects/:id/final-render/release-package/verify',async(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    const dir=path.join(process.cwd(),'projects',req.params.id,'final_render','release_package');
    try{
      const built=await buildTransferPackage(p,dir);
      if(!built.available)return res.status(409).json({verified:false,available:false,reason:built.reason});
      const verification=await verifyReleasePackage(built.path);
      recordIntegrityVerification(p,verification,path.join(process.cwd(),'projects'));
      res.json(verification);
    }catch(e){res.status(500).json({verified:false,available:false,reason:e.message});}
  });
}
module.exports={registerFinalReleasePackageVerifierRoutes};
