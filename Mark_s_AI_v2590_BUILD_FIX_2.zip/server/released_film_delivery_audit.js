const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function recordReleaseDeliveryAudit(project,event,details={}){
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","delivery_audit");
  fs.mkdirSync(dir,{recursive:true});
  const existing=Array.isArray(project.finalMasterReleasedFilmDeliveryAudit)
    ? project.finalMasterReleasedFilmDeliveryAudit : [];
  const entry={
    auditId:`delivery_audit_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,event:String(event),details,
    timestamp:new Date().toISOString()
  };
  existing.push(entry);
  project.finalMasterReleasedFilmDeliveryAudit=existing;
  fs.writeFileSync(path.join(dir,"audit_history.json"),JSON.stringify(existing,null,2));
  saveProject(path.join(process.cwd(),"projects"),project);
  return entry;
}
function getReleaseDeliveryAudit(project){
  return Array.isArray(project?.finalMasterReleasedFilmDeliveryAudit)
    ? project.finalMasterReleasedFilmDeliveryAudit : [];
}
module.exports={recordReleaseDeliveryAudit,getReleaseDeliveryAudit};
