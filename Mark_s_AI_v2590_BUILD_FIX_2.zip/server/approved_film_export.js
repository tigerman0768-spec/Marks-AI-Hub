const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");
const {appendExportHistory}=require("./approved_film_export_history");

function createExportRecord(project,options={}){
  const film=project?.approvedFilmLibraryFilm;
  if(!film?.outputPath||!fs.existsSync(film.outputPath))
    return {ready:false,blockers:["completed Film Library film is required"]};
  const stat=fs.statSync(film.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(film.outputPath)).digest("hex");
  const exportId=`film_export_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const record={
    exportId,projectId:project.id,title:project.title||"Untitled Film",
    sourcePath:film.outputPath,filename:String(options.filename||path.basename(film.outputPath)),
    bytes:stat.size,sha256:sha,clipCount:film.clipCount||0,
    exportedAt:new Date().toISOString(),status:"ready"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","exports");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,`${exportId}.json`),JSON.stringify(record,null,2));
  project.approvedFilmExport=record;
  saveProject(path.join(process.cwd(),"projects"),project);
  appendExportHistory(project,record);
  return {ready:true,record};
}
module.exports={createExportRecord};
