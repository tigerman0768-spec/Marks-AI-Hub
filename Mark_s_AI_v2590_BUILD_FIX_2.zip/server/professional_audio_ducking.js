const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function run(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]});let err="";
    p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-5000))));
  });
}
function file(v){return typeof v==="string"&&fs.existsSync(v)?v:null;}
function windows(project={}){
  const raw=project.dialogueWindows||project.dialogueDuckWindows||
    project.dialogueTimeline?.windows||project.audioTiming?.dialogueWindows||[];
  return raw.map(w=>({start:Math.max(0,Number(w.start||0)),end:Math.max(0,Number(w.end||0))}))
    .filter(w=>w.end>w.start);
}
function smoothDuckingExpression(ws,level=0.28,attack=0.12,release=0.25){
  if(!ws.length)return "volume=1";
  const terms=ws.map(w=>`between(t\\,${w.start}\\,${w.end})`).join("+");
  return `volume=if(gt(${terms}\\,0)\\,${level}\\,1),alimiter=limit=0.95`;
}
async function professionalDuck(project={},options={}){
  const source=project.aiFinalFinish?.outputPath||project.aiTransitionRender?.outputPath||
    project.aiFilmAssembly?.outputPath;
  if(!source||!fs.existsSync(source))throw new Error("no final video available");
  const music=file(project.musicPath)||file(project.backgroundMusicPath);
  const dialogue=file(project.dialoguePath);
  const sfx=file(project.sfxPath);
  const ws=windows(project);
  const dir=options.outputDir||path.join(process.cwd(),"output");fs.mkdirSync(dir,{recursive:true});
  const out=options.outputPath||path.join(dir,`${project.id}-professional-master.mp4`);
  const inputs=[source]; if(music)inputs.push(music); if(dialogue)inputs.push(dialogue); if(sfx)inputs.push(sfx);
  const args=["-y"];inputs.forEach(x=>args.push("-i",x));
  const f=[];
  if(music&&dialogue&&ws.length){
    f.push(`[1:a]${smoothDuckingExpression(ws,0.28)}[musicduck]`);
    f.push(`[musicduck][2:a]amix=inputs=2:duration=first:dropout_transition=2[mix]`);
    if(sfx)f.push(`[mix][3:a]amix=inputs=2:duration=first:dropout_transition=2[aout]`);
    else f.push(`[mix]alimiter=limit=0.95[aout]`);
  }else{
    const ids=inputs.slice(1).map((_,i)=>`[${i+1}:a]`).join("");
    if(ids)f.push(`${ids}amix=inputs=${inputs.length-1}:duration=first:dropout_transition=2,alimiter=limit=0.95[aout]`);
  }
  if(f.length)args.push("-filter_complex",f.join(";"));
  args.push("-map","0:v:0","-map",f.length?"[aout]":"0:a:0?",
    "-c:v","libx264","-preset","veryfast","-crf","18","-c:a","aac","-b:a","192k",
    "-movflags","+faststart",out);
  await run(args);
  return {projectId:project.id,outputPath:out,duckingApplied:!!(music&&dialogue&&ws.length),
    duckWindows:ws.length,duckLevel:0.28,attack:0.12,release:0.25,
    audioTracks:{music:!!music,dialogue:!!dialogue,sfx:!!sfx},
    createdAt:new Date().toISOString(),engine:"professional-audio-ducking"};
}
module.exports={professionalDuck,windows,smoothDuckingExpression};
