const ALLOWED=["cut","fade","dissolve","dip-to-black"];
function normaliseTransition(value){
  const type=String(value?.type||value||"cut");
  const duration=Number(value?.duration??0);
  if(!ALLOWED.includes(type))throw new Error(`unsupported transition: ${type}`);
  if(!Number.isFinite(duration)||duration<0||duration>5)throw new Error("transition duration must be 0-5 seconds");
  return {type,duration};
}
function setTransition(items,index,value){
  if(!Array.isArray(items)||index<0||index>=items.length)throw new Error("invalid timeline index");
  const next=items.map(x=>({...x}));
  next[index].transition=normaliseTransition(value);
  return next.map((x,i)=>({...x,order:i}));
}
module.exports={ALLOWED,normaliseTransition,setTransition};
