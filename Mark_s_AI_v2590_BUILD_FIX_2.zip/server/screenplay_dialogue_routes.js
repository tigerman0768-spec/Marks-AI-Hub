const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {saveDialogue}=require("./dialogue_timeline");
const {extractDialogue}=require("./screenplay_dialogue_extractor");

function registerScreenplayDialogueRoutes(app){
  app.post("/api/projects/:id/screenplay/extract-dialogue",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const replace=Boolean(req.body?.replace);
      const existing=project.dialogueTracks||project.dialogue?.tracks||[];
      if(existing.length&&!replace){
        return res.json({projectId:project.id,tracks:existing,created:0,existing:true});
      }
      const tracks=extractDialogue(project);
      const record=saveDialogue(path.join(process.cwd(),"dialogue"),project.id,tracks);
      saveProject(dir,{...project,dialogueTracks:record.tracks,status:"dialogue_ready"});
      res.json({projectId:project.id,tracks:record.tracks,created:record.tracks.length,existing:false});
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerScreenplayDialogueRoutes};
