const path=require("path");
const {getProject}=require("./film_projects");
const {sealReleasedFilmDelivery}=require("./released_film_delivery_seal");
function registerReleasedFilmDeliverySealRoutes(app){
  app.get("/api/projects/:id/final-render/release-delivery-seal",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,seal:p.finalMasterReleasedFilmDeliverySeal||null});
  });
  app.post("/api/projects/:id/final-render/release-delivery-seal/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=sealReleasedFilmDelivery(p);
    res.status(result.sealed?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerReleasedFilmDeliverySealRoutes};
