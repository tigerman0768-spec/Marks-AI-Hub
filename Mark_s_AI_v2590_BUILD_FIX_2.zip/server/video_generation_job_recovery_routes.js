const path = require("path");
const { getProject, saveProject } = require("./film_projects");

function registerVideoGenerationJobRecoveryRoutes(app) {
  app.post("/api/projects/:id/video-generation/jobs/:jobId/retry", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const jobs = Array.isArray(p.videoGenerationJobs) ? p.videoGenerationJobs : [];
    const i = jobs.findIndex(j => j.id === req.params.jobId);
    if (i < 0) return res.status(404).json({ error: "job not found" });
    const job = jobs[i];
    if (!["failed", "cancelled"].includes(job.status)) {
      return res.status(409).json({ error: "only failed or cancelled jobs can be retried", status: job.status });
    }
    job.status = "queued";
    job.progress = 0;
    job.error = null;
    job.clipPath = null;
    job.providerJobId = null;
    job.retryCount = Number(job.retryCount || 0) + 1;
    job.updatedAt = new Date().toISOString();
    saveProject(dir, p);
    res.json(job);
  });
}

module.exports = { registerVideoGenerationJobRecoveryRoutes };
