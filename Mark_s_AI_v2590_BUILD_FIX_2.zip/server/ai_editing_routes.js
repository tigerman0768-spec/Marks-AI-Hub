const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildAutomaticEdit}=require("./ai_editing_engine");
const {saveTimeline}=require("./film_timeline");

function registerAiEditingRoutes(app){
  app.get("/api/projects/:id/ai-edit",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      res.json(buildAutomaticEdit(project));
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects/:id/ai-edit/apply",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const edit=buildAutomaticEdit(project);
      saveTimeline(path.join(process.cwd(),"timelines"),project.id,edit.items);
      saveProject(dir,{...project,finalTimeline:{...edit,items:edit.items},aiEditPlan:edit,status:"ai_edit_applied"});
      res.json(edit);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerAiEditingRoutes};
