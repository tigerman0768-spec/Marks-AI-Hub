const SHOTS = {
  establishing: { lens:"24mm", framing:"wide", movement:"slow push-in" },
  dialogue: { lens:"50mm", framing:"medium two-shot", movement:"subtle dolly" },
  emotional: { lens:"85mm", framing:"close-up", movement:"very slow push-in" },
  action: { lens:"35mm", framing:"dynamic medium-wide", movement:"tracking" },
  reveal: { lens:"35mm", framing:"wide", movement:"slow pan reveal" },
  overShoulder: { lens:"50mm", framing:"over-the-shoulder", movement:"locked-off" }
};

const LIGHTING = {
  day: "natural soft daylight, realistic shadows",
  goldenHour: "warm low-angle golden-hour light",
  night: "controlled night lighting with practicals and soft rim light",
  noir: "high-contrast noir lighting with deep shadows",
  neon: "colourful practical neon with cinematic rim light",
  candle: "warm candlelight with soft falloff"
};

function chooseCinematography(scene = {}) {
  const mood = String(scene.mood || scene.emotion || "").toLowerCase();
  let shot = SHOTS.dialogue;
  if (/action|chase|fight|explosion|running/.test(mood)) shot = SHOTS.action;
  else if (/sad|fear|love|angry|grief|emotional/.test(mood)) shot = SHOTS.emotional;
  else if (/reveal|surprise|mystery/.test(mood)) shot = SHOTS.reveal;
  else if (scene.establishing) shot = SHOTS.establishing;

  const lightingKey = String(scene.lighting || "day");
  const lighting = LIGHTING[lightingKey] || lightingKey;

  return {
    shot,
    lighting,
    depthOfField: shot.lens === "85mm" ? "shallow" : "cinematic",
    exposure: "natural",
    colour: scene.colourGrade || "cinematic neutral"
  };
}

function applyCinematography(jobs = [], scenes = []) {
  const map = new Map(scenes.map(s => [s.id, s]));
  return jobs.map(job => {
    const scene = map.get(job.sceneId) || {};
    const cinema = chooseCinematography(scene);
    const direction = [
      `${cinema.shot.framing} framing`,
      `${cinema.shot.lens} lens`,
      `${cinema.shot.movement} camera movement`,
      cinema.lighting,
      `${cinema.depthOfField} depth of field`,
      `${cinema.colour} colour grade`
    ].join(", ");
    return {
      ...job,
      cinematography: cinema,
      prompt: `${job.prompt}. Cinematography: ${direction}.`
    };
  });
}

module.exports = { chooseCinematography, applyCinematography };
