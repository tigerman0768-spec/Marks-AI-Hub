const fs=require("fs");
const path=require("path");
function registerGeneratedClipRoutes(app){
  app.get("/api/projects/:id/clips/:jobId",(req,res)=>{
    const dir=path.join(process.cwd(),"assets","clips",req.params.id);
    const p=path.join(dir,`${req.params.jobId}.mp4`);
    if(!fs.existsSync(p))return res.status(404).json({error:"clip not found"});
    res.sendFile(path.resolve(p));
  });
}
module.exports={registerGeneratedClipRoutes};
