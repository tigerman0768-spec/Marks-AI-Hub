const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function createFinalReleaseRecord(project){
  const rec=project?.finalMasterReleasedFilmSealedDeliveryRecord;
  if(rec?.status!=="sealed")return {ready:false,blockers:["sealed delivery record is required"]};
  if(!rec.outputPath||!fs.existsSync(rec.outputPath))return {ready:false,blockers:["final film file is missing"]};
  const stat=fs.statSync(rec.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(rec.outputPath)).digest("hex");
  const blockers=[];
  if(sha!==rec.sha256)blockers.push("final film hash no longer matches sealed delivery record");
  if(stat.size!==Number(rec.bytes))blockers.push("final film size no longer matches sealed delivery record");
  const release={
    releaseRecordId:`final_release_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
    projectId:project.id,title:project.title||"Untitled Film",outputPath:rec.outputPath,
    bytes:stat.size,sha256:sha,sealedDeliveryRecordId:rec.recordId,
    createdAt:new Date().toISOString(),status:blockers.length?"blocked":"released",blockers
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"library_release","final_release_record");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"final_release_record.json"),JSON.stringify(release,null,2));
  project.finalMasterFinalReleaseRecord=release;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:blockers.length===0,release};
}
module.exports={createFinalReleaseRecord};
