const path=require("path");
const {getProject}=require("./film_projects");
const {createReleaseSnapshot}=require("./final_master_release_snapshot");
function registerFinalMasterReleaseSnapshotRoutes(app){
  app.get("/api/projects/:id/final-render/release-snapshot",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json({projectId:p.id,snapshot:p.finalMasterReleaseSnapshot||null});
  });
  app.post("/api/projects/:id/final-render/release-snapshot/create",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const result=createReleaseSnapshot(p);
    res.status(result.created?200:409).json({projectId:p.id,...result});
  });
}
module.exports={registerFinalMasterReleaseSnapshotRoutes};
