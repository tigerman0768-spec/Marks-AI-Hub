const path=require("path");
const fs=require("fs");
const crypto=require("crypto");
const {getProject,saveProject}=require("./film_projects");

function handoffApprovedFilm(project){
  const job=project?.approvedFilmRender;
  if(job?.status!=="completed"||!job.outputPath||!fs.existsSync(job.outputPath))
    return {ready:false,blockers:["completed approved-film render is required"]};
  const stat=fs.statSync(job.outputPath);
  const sha=crypto.createHash("sha256").update(fs.readFileSync(job.outputPath)).digest("hex");
  const libraryId=`approved_film_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const film={
    filmId:libraryId,projectId:project.id,title:project.title||"Untitled Film",
    duration:Number(project.approvedFilmTimeline?.totalDuration||0),
    outputPath:job.outputPath,bytes:stat.size,sha256:sha,
    clipCount:Number(job.clipCount||project.approvedFilmTimeline?.clipCount||0),
    createdAt:new Date().toISOString(),status:"ready"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","approved_film");
  fs.mkdirSync(dir,{recursive:true});
  fs.writeFileSync(path.join(dir,"film.json"),JSON.stringify(film,null,2));
  project.approvedFilmLibraryFilm=film;
  saveProject(path.join(process.cwd(),"projects"),project);
  return {ready:true,film};
}
module.exports={handoffApprovedFilm};
