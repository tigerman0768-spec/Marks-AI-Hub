const path = require("path");
const fs = require("fs");
const { getProject, saveProject } = require("./film_projects");

function registerApprovedClipEditBridgeRoutes(app) {
  app.get("/api/projects/:id/approved-clips", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });
    const clips = Array.isArray(p.approvedGeneratedClips) ? p.approvedGeneratedClips : [];
    const inventory = clips.map(c => ({
      ...c,
      available: Boolean(c.path && fs.existsSync(c.path))
    }));
    res.json({
      projectId: p.id,
      finalizedAt: p.generatedClipReviewFinalizedAt || null,
      count: inventory.length,
      availableCount: inventory.filter(c => c.available).length,
      clips: inventory
    });
  });

  app.post("/api/projects/:id/approved-clips/prepare-edit", (req, res) => {
    const dir = path.join(process.cwd(), "projects");
    const p = getProject(dir, req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const clips = Array.isArray(p.approvedGeneratedClips) ? p.approvedGeneratedClips : [];
    const missing = clips.filter(c => !c.path || !fs.existsSync(c.path));
    if (!clips.length || missing.length) {
      return res.status(409).json({
        error: "approved clips are not ready for editing",
        approved: clips.length,
        missing: missing.length
      });
    }

    const timeline = clips.map((c, i) => ({
      id: `approved-${c.id || i + 1}`,
      clipId: c.id,
      shotId: c.shotId,
      scene: c.scene,
      sourcePath: c.path,
      start: 0,
      end: Number(c.duration) > 0 ? Number(c.duration) : null,
      order: i,
      transition: i === 0 ? "cut" : "dissolve"
    }));

    p.approvedClipEditTimeline = timeline;
    p.editInputSource = "approvedGeneratedClips";
    p.editInputPreparedAt = new Date().toISOString();
    saveProject(dir, p);

    res.json({
      projectId: p.id,
      ready: true,
      source: "approvedGeneratedClips",
      clipCount: timeline.length,
      timeline
    });
  });
}
module.exports = { registerApprovedClipEditBridgeRoutes };
