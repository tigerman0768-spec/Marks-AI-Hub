const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

function ensureProjects(dir){fs.mkdirSync(dir,{recursive:true});return dir;}
function file(dir,id){return path.join(dir,`${id}.json`);}
function saveProject(dir,data={}){
  ensureProjects(dir);
  const id=data.id||crypto.randomUUID();
  const now=new Date().toISOString();
  const existing=getProject(dir,id);
  const project={...(existing||{}),...data,
    id,
    title:String(data.title??existing?.title??"Untitled Film"),
    idea:String(data.idea??existing?.idea??""),
    genre:String(data.genre??existing?.genre??"Drama"),
    length:Number(data.length??existing?.length??5),
    style:String(data.style??existing?.style??"Cinematic"),
    aspectRatio:String(data.aspectRatio??existing?.aspectRatio??"16:9"),
    status:String(data.status??existing?.status??"draft"),
    screenplay:data.screenplay??existing?.screenplay??"",
    characters:data.characters??existing?.characters??[],
    scenes:data.scenes??existing?.scenes??[],
    updatedAt:now,createdAt:existing?.createdAt||now};
  fs.writeFileSync(file(dir,id),JSON.stringify(project,null,2));
  return project;
}
function getProject(dir,id){
  const p=file(dir,id); if(!fs.existsSync(p))return null;
  try{return JSON.parse(fs.readFileSync(p,"utf8"));}catch{return null;}
}
function listProjects(dir){
  ensureProjects(dir);
  return fs.readdirSync(dir).filter(x=>x.endsWith(".json")).map(x=>{
    try{return JSON.parse(fs.readFileSync(path.join(dir,x),"utf8"));}catch{return null;}
  }).filter(Boolean).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)));
}
function deleteProject(dir,id){
  const p=file(dir,id); if(!fs.existsSync(p))return false;
  fs.unlinkSync(p); return true;
}
module.exports={ensureProjects,saveProject,getProject,listProjects,deleteProject};
