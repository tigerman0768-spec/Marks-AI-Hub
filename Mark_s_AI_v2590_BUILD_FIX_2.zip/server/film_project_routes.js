const path=require("path");
const {listProjects,getProject,saveProject,deleteProject}=require("./film_projects");
const {resumeProject,saveCreatorState}=require("./project_resume");
function dir(){return path.join(process.cwd(),"projects");}
function registerFilmProjectRoutes(app){
  app.get("/api/projects",(req,res)=>res.json(listProjects(dir())));
  app.get("/api/projects/:id",(req,res)=>{
    const p=getProject(dir(),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(p);
  });
  app.get("/api/projects/:id/resume",(req,res)=>{
    const p=resumeProject(dir(),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    res.json(p);
  });
  app.put("/api/projects/:id/creator-state",(req,res)=>{
    try{
      const p=saveCreatorState(dir(),req.params.id,req.body||{});
      if(!p)return res.status(404).json({error:"project not found"});
      res.json(p);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/projects",(req,res)=>{
    try{res.status(201).json(saveProject(dir(),req.body||{}));}
    catch(e){res.status(400).json({error:e.message});}
  });
  app.patch("/api/projects/:id",(req,res)=>{
    try{
      const p=saveProject(dir(),{...(req.body||{}),id:req.params.id});
      res.json(p);
    }catch(e){res.status(400).json({error:e.message});}
  });
  app.delete("/api/projects/:id",(req,res)=>{
    if(!deleteProject(dir(),req.params.id))return res.status(404).json({error:"project not found"});
    res.json({ok:true});
  });
}
module.exports={registerFilmProjectRoutes};
