const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function buildReleasedFilmIndex(){
  const projectsDir=path.join(process.cwd(),"projects");
  if(!fs.existsSync(projectsDir)) return {count:0,films:[]};
  const films=[];
  for(const name of fs.readdirSync(projectsDir)){
    const dir=path.join(projectsDir,name);
    if(!fs.statSync(dir).isDirectory()) continue;
    const p=getProject(projectsDir,name);
    const r=p?.finalMasterLibraryRelease;
    if(r?.status==="ready_for_library") films.push({
      libraryReleaseId:r.libraryReleaseId,projectId:p.id,title:r.title,
      filename:r.filename,bytes:r.bytes,duration:r.duration,
      sha256:r.sha256,preparedAt:r.preparedAt,
      outputPath:r.outputPath,video:r.video||null,audio:r.audio||null
    });
  }
  films.sort((a,b)=>String(b.preparedAt).localeCompare(String(a.preparedAt)));
  return {count:films.length,films,indexedAt:new Date().toISOString()};
}
module.exports={buildReleasedFilmIndex};
