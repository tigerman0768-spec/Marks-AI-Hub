const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {checkCinematicConsistency}=require("./cinematic_consistency_engine");

function registerCinematicConsistencyRoutes(app){
  app.get("/api/projects/:id/clips/cinematic-consistency",(req,res)=>{
    try{
      const dir=path.join(process.cwd(),"projects");
      const project=getProject(dir,req.params.id);
      if(!project)return res.status(404).json({error:"project not found"});
      const report=checkCinematicConsistency(project);
      saveProject(dir,{...project,cinematicConsistencyReport:report});
      res.json(report);
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerCinematicConsistencyRoutes};
