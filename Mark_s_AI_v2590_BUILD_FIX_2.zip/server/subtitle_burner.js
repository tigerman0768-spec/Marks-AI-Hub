const fs = require("fs");
const { spawn } = require("child_process");

function escapeFilterPath(p) {
  return String(p).replace(/\\/g, "/").replace(/:/g, "\\:").replace(/'/g, "\\'");
}

function burnSubtitles({ videoPath, srtPath, outputPath, ffmpeg, fontSize = 24 }) {
  if (!videoPath || !fs.existsSync(videoPath)) throw new Error("video file not found");
  if (!srtPath || !fs.existsSync(srtPath)) throw new Error("subtitle file not found");
  if (!outputPath) throw new Error("outputPath is required");

  const exe = ffmpeg || process.env.FFMPEG_BIN || "ffmpeg";
  const subtitlePath = escapeFilterPath(srtPath);
  const filter = `subtitles='${subtitlePath}':force_style='FontSize=${Number(fontSize)}'`;

  const args = [
    "-y", "-i", videoPath,
    "-vf", filter,
    "-c:v", "libx264", "-preset", "medium", "-crf", "20",
    "-pix_fmt", "yuv420p",
    "-c:a", "copy",
    "-movflags", "+faststart",
    outputPath
  ];

  return new Promise((resolve, reject) => {
    const child = spawn(exe, args, { stdio: ["ignore","ignore","pipe"] });
    let stderr = "";
    child.stderr.on("data", d => stderr += d.toString());
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) return reject(new Error(`subtitle burn failed (${code}): ${stderr.slice(-2000)}`));
      if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0)
        return reject(new Error("subtitle-rendered film is empty"));
      resolve({ outputPath, bytes: fs.statSync(outputPath).size });
    });
  });
}

module.exports = { burnSubtitles };
