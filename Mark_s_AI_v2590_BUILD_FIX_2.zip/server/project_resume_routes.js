const path=require("path");
const {getProject}=require("./film_projects");
function registerProjectResumeRoutes(app){
 app.get("/api/projects/:id/resume",(req,res)=>{
  const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
  if(!p)return res.status(404).json({error:"project not found"});
  let stage="creator",label="Start your film",route="creator";
  if(p.finalMasterReady||p.status==="complete"){stage="library";label="Open finished film";route="library";}
  else if(p.finalFinishingPlan){stage="final_master";label="Finish and render master";route="final-master";}
  else if(p.finalTimeline||p.status==="edit_ready"){stage="final_cut";label="Review final cut";route="final-cut";}
  else if(p.aiEditPlan||p.status==="edit_ready"){stage="ai_edit";label="Review AI edit";route="ai-edit";}
  else if((p.shotCards||[]).length){stage="video_generation";label="Generate and review shots";route="video-generation";}
  else if(p.characterBible||p.storyboard){stage="production_plan";label="Review production plan";route="production-plan";}
  else if(p.screenplay||p.scenes?.length){stage="screenplay";label="Review screenplay";route="screenplay";}
  res.json({projectId:p.id,title:p.title,status:p.status||"draft",nextStage:stage,nextLabel:label,nextRoute:route,updatedAt:p.updatedAt||null});
 });
}
module.exports={registerProjectResumeRoutes};
