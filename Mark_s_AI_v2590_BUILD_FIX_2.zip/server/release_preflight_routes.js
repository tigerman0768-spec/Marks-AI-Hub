const path = require('path');
const cp = require('child_process');

function runPreflight(){
  const script = path.join(process.cwd(), 'tools', 'release_preflight.cjs');
  try{
    const stdout = cp.execFileSync(process.execPath, [script], {encoding:'utf8'});
    return {status:0, result:JSON.parse(stdout)};
  }catch(e){
    const stdout = String(e.stdout || '').trim();
    if(stdout){
      try{return {status:Number(e.status||2), result:JSON.parse(stdout)};}catch{}
    }
    return {status:Number(e.status||1), result:{version:'v2540', readyForSourceRelease:false, error:e.message}};
  }
}

function registerReleasePreflightRoutes(app){
  app.get('/api/release-preflight',(req,res)=>{
    const out=runPreflight();
    res.status(200).json(out.result);
  });
}

module.exports={registerReleasePreflightRoutes};
