const fs=require("fs");
const crypto=require("crypto");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {recordReleaseEvent}=require("./approved_film_release_history");

function sealRelease(project){
  const a=project?.approvedFilmReleaseApproval;
  const s=project?.approvedFilmReleaseSnapshot;
  if(!a||a.status!=="approved")return {sealed:false,reason:"final release approval is required"};
  if(!s?.snapshotId)return {sealed:false,reason:"release snapshot is missing"};
  if(!a.sha256||a.sha256!==s.sha256||Number(a.bytes)!==Number(s.bytes))
    return {sealed:false,reason:"approval and snapshot file identity do not match"};
  if(!s.snapshotPath||!fs.existsSync(s.snapshotPath))return {sealed:false,reason:"release snapshot record is missing"};
  const sealId=`release_seal_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const seal={
    sealId,approvalId:a.approvalId,snapshotId:s.snapshotId,deliveryId:a.deliveryId,
    lockId:a.lockId,projectId:project.id,filename:a.filename,bytes:a.bytes,sha256:a.sha256,
    sealedAt:new Date().toISOString(),status:"sealed"
  };
  const dir=path.join(process.cwd(),"projects",String(project.id),"film_library","deliveries");
  fs.mkdirSync(dir,{recursive:true});
  const sealPath=path.join(dir,`${sealId}.json`);
  fs.writeFileSync(sealPath,JSON.stringify(seal,null,2));
  project.approvedFilmReleaseSeal={...seal,sealPath};
  saveProject(path.join(process.cwd(),"projects"),project);
  recordReleaseEvent(project,{event:"release-sealed",id:seal.sealId});
  return {sealed:true,seal};
}
module.exports={sealRelease};
