const fs=require("fs"),path=require("path");
function registerProjectFavouritesRoutes(app){
 app.get("/api/projects/:id/favourite",(req,res)=>{const f=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(f))return res.status(404).json({error:"project not found"});const p=JSON.parse(fs.readFileSync(f,"utf8"));res.json({projectId:p.id,favourite:p.favourite===true});});
 app.patch("/api/projects/:id/favourite",(req,res)=>{const f=path.join(process.cwd(),"projects",`${req.params.id}.json`);if(!fs.existsSync(f))return res.status(404).json({error:"project not found"});const p=JSON.parse(fs.readFileSync(f,"utf8"));p.favourite=req.body?.favourite===true;p.updatedAt=new Date().toISOString();fs.writeFileSync(f,JSON.stringify(p,null,2));res.json({projectId:p.id,favourite:p.favourite});});
}
module.exports={registerProjectFavouritesRoutes};
