const fs=require("fs");
const path=require("path");
const {spawn}=require("child_process");

function run(args){
  return new Promise((resolve,reject)=>{
    const p=spawn("ffmpeg",args,{stdio:["ignore","pipe","pipe"]}); let err="";
    p.stderr.on("data",d=>err+=d);
    p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-5000))));
  });
}
function file(v){return typeof v==="string"&&fs.existsSync(v)?v:null;}
function subtitleFile(project){
  return file(project.subtitleFile)||file(project.subtitles?.path)||file(project.subtitleExport?.path);
}
async function masterFilm(project={},options={}){
  const source=project.aiFinalFinish?.outputPath||project.aiTransitionRender?.outputPath;
  if(!source||!fs.existsSync(source))throw new Error("no final video available");
  const dir=options.outputDir||path.join(process.cwd(),"output"); fs.mkdirSync(dir,{recursive:true});
  const out=options.outputPath||path.join(dir,`${project.id}-master.mp4`);
  const sub=subtitleFile(project);
  const music=file(project.musicPath)||file(project.backgroundMusicPath);
  const dialogue=file(project.dialoguePath);
  const sfx=file(project.sfxPath);
  const inputs=[source]; const tracks=[];
  for(const p of [music,dialogue,sfx])if(p){inputs.push(p);tracks.push(inputs.length-1);}
  const args=["-y"]; inputs.forEach(x=>args.push("-i",x));
  let audioFilter="";
  if(tracks.length){
    const labels=tracks.map(i=>`[${i}:a]`).join("");
    audioFilter=`${labels}amix=inputs=${tracks.length}:duration=first:dropout_transition=2,alimiter=limit=0.95[aout]`;
  }
  const filters=[];
  if(sub)filters.push(`[0:v]subtitles=${sub.replace(/\\/g,"/").replace(/'/g,"\\\\'")}[vout]`);
  if(audioFilter)filters.push(audioFilter);
  if(filters.length)args.push("-filter_complex",filters.join(";"));
  args.push("-map",sub?"[vout]":"0:v:0", "-map",audioFilter?"[aout]":"0:a:0?",
    "-c:v","libx264","-preset","veryfast","-crf","18","-c:a","aac","-b:a","192k",
    "-movflags","+faststart",out);
  await run(args);
  return {projectId:project.id,outputPath:out,subtitlesBurned:!!sub,
    audioMastered:tracks.length>0,audioTracks:{music:!!music,dialogue:!!dialogue,sfx:!!sfx},
    duckingApplied:false,createdAt:new Date().toISOString(),engine:"ai-master-finish"};
}
module.exports={masterFilm};
