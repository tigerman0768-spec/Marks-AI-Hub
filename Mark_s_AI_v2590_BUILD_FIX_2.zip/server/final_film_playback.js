const fs=require("fs");
const path=require("path");
const {getFinalFilmResult}=require("./final_render_lifecycle");
function getPlayableFinalFilm(jobId){
 const result=getFinalFilmResult(jobId);
 if(!result)return null;
 if(!result.ready||!result.outputPath)return {...result,playable:false,reason:"final film is not ready"};
 const absolute=path.resolve(result.outputPath);
 if(!fs.existsSync(absolute))return {...result,playable:false,reason:"final film file not found"};
 return {...result,playable:true,fileSize:fs.statSync(absolute).size};
}
module.exports={getPlayableFinalFilm};
