const path=require('path');
const {getProject}=require('./film_projects');
const {buildReleasePackageDashboard}=require('./release_package_dashboard');
function registerReleasePackageDashboardRoutes(app){
  app.get('/api/projects/:id/final-render/release-package-dashboard',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    res.json(buildReleasePackageDashboard(p));
  });
}
module.exports={registerReleasePackageDashboardRoutes};
