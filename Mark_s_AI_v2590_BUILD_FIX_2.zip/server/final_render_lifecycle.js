const path=require("path");
const {getJob}=require("./final_render_job_store");
const {getFinalRenderJobStatus}=require("./final_render_job_status");
const DIR=path.join(process.cwd(),"final-render-jobs");
function getFinalFilmResult(id){
 const job=getJob(DIR,id); if(!job)return null;
 const r=job.result||{}, outputPath=r.outputPath||job.outputPath||null;
 return {jobId:id,projectId:job.projectId,title:job.title||"Untitled Film",
 status:job.status,ready:job.status==="completed"&&!!outputPath,outputPath,
 thumbnailPath:r.thumbnailPath||job.thumbnailPath||null,duration:Number(r.duration||job.duration||0),
 libraryId:r.libraryId||job.libraryId||null,quality:r.finalQuality||r.quality||null,
 error:job.error||null,renderStatus:getFinalRenderJobStatus(id)};
}
module.exports={getFinalFilmResult};
