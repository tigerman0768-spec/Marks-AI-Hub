const crypto=require("crypto");
const {finishFilm}=require("./finish_film");
const {registerFinishedFilm}=require("./auto_library");
const runs=new Map();

function createFinishRun(config={}){
  if(!config.videoPath) throw new Error("videoPath required");
  if(!config.outputPath) throw new Error("outputPath required");
  const id=crypto.randomUUID();
  const run={id,status:"queued",stage:"Queued",progress:0,createdAt:new Date().toISOString(),error:null,result:null};
  runs.set(id,run);
  setImmediate(async()=>{
    try{
      run.status="running"; run.stage="Audio Mix"; run.progress=20;
      const result=await finishFilm({...config,onStage:(stage,progress)=>{
        run.stage=stage; run.progress=progress;
      }});
      run.result=result; run.outputPath=result.outputPath;
      try{run.libraryRecord=await registerFinishedFilm(config,result);}catch(libraryErr){run.libraryError=libraryErr.message;}
      run.stage="Complete"; run.progress=100;
      run.status="completed"; run.finishedAt=new Date().toISOString();
    }catch(err){
      run.status="failed"; run.stage="Failed"; run.error=err.message;
      run.finishedAt=new Date().toISOString();
    }
  });
  return run;
}
function getFinishRun(id){return runs.get(id)||null;}
module.exports={createFinishRun,getFinishRun};
