const path = require("path");
const { getProject } = require("./film_projects");

function registerAiProviderRoutes(app) {
  app.get("/api/ai/provider-status", (req, res) => {
    const textConfigured = Boolean(process.env.AI_API_KEY);
    const videoConfigured = Boolean(process.env.RUNWAY_API_KEY || process.env.VIDEO_API_KEY);
    res.json({
      text: { configured: textConfigured, mode: textConfigured ? "provider" : "local-fallback" },
      video: { configured: videoConfigured, mode: videoConfigured ? "provider" : "dry-run" },
      accountRequired: false
    });
  });

  app.get("/api/projects/:id/ai-readiness", (req, res) => {
    const p = getProject(path.join(process.cwd(), "projects"), req.params.id);
    if (!p) return res.status(404).json({ error: "project not found" });

    const checks = [
      ["idea", Boolean(p.idea)],
      ["screenplay", Boolean(p.screenplay || (p.scenes || []).length)],
      ["characters", Boolean(p.characterBible || (p.characters || []).length)],
      ["shotCards", Boolean((p.shotCards || []).length)],
      ["videoProvider", Boolean(process.env.RUNWAY_API_KEY || process.env.VIDEO_API_KEY)]
    ];
    const missing = checks.filter(x => !x[1]).map(x => x[0]);
    res.json({
      projectId: p.id,
      readyForTextAI: Boolean(p.idea || p.screenplay),
      readyForVideoProvider: checks.every(x => x[1]),
      missing,
      checks: Object.fromEntries(checks)
    });
  });
}

module.exports = { registerAiProviderRoutes };
