const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildFinalMixArgs}=require("./final_audio_mix");
const {buildDuckedMixArgs,buildDuckingWindows}=require("./audio_ducking");
const {buildSubtitleBurnArgs}=require("./subtitle_export");

function registerFinalFinishingOrchestratorRoutes(app){
  app.get("/api/projects/:id/final-finishing-plan",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const source=p.finalTimeline?.outputPath||p.finalCutRender?.outputPath||null;
    const subtitle=p.subtitleFile||null;
    const dialogueTracks=p.dialogueTracks||[];
    res.json({
      projectId:p.id,title:p.title,sourceVideo:source,
      stages:{
        audioMix:Boolean(source && (dialogueTracks.length||p.musicPath||p.backgroundMusicPath||p.sfxPath)),
        ducking:Boolean(source && dialogueTracks.length),
        subtitles:Boolean(source && subtitle),
        finalRender:Boolean(source)
      },
      outputDirectory:path.join(process.cwd(),"films")
    });
  });

  app.post("/api/projects/:id/final-finishing/prepare",(req,res)=>{
    const dir=path.join(process.cwd(),"projects");
    const p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const plan={
      projectId:p.id,sourceVideo:p.finalTimeline?.outputPath||null,
      subtitleFile:p.subtitleFile||null,
      dialogueTracks:p.dialogueTracks||[],
      musicPath:p.musicPath||p.backgroundMusicPath||null,sfxPath:p.sfxPath||null,
      duckingWindows:buildDuckingWindows({scenes:p.screenplay?.scenes||p.scenes||[]}),
      preparedAt:new Date().toISOString()
    };
    const saved=saveProject(dir,{...p,finalFinishingPlan:plan,status:"final_finishing_ready"});
    res.json({plan,status:saved.status});
  });
}
module.exports={registerFinalFinishingOrchestratorRoutes};
