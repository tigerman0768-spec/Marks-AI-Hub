const {getHistory}=require("./final_render_job_history");
function registerFinalRenderJobHistoryRoutes(app){
  app.get("/api/final-render/jobs/:id/history",(req,res)=>{
    const result=getHistory(req.params.id);
    if(!result)return res.status(404).json({error:"render job not found"});
    res.json(result);
  });
}
module.exports={registerFinalRenderJobHistoryRoutes};
