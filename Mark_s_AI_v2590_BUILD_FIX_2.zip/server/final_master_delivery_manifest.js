const crypto=require("crypto");
const fs=require("fs");
const path=require("path");
const {getProject,saveProject}=require("./film_projects");
const {buildDeliveryPackage}=require("./final_master_delivery_package");

function buildDeliveryManifest(project){
  const pkg=project.finalMasterDeliveryPackage||buildDeliveryPackage(project);
  if(!pkg.ready)return {ready:false,blockers:pkg.blockers||["delivery package is not ready"]};
  const file=pkg.outputPath;
  if(!file||!fs.existsSync(file))return {ready:false,blockers:["final output file is missing"]};
  const stat=fs.statSync(file);
  const hash=crypto.createHash("sha256");
  const data=fs.readFileSync(file); hash.update(data);
  return {
    ready:true,projectId:project.id,title:project.title||"Untitled Film",
    filename:path.basename(file),outputPath:file,bytes:stat.size,
    sha256:hash.digest("hex"),duration:pkg.duration||0,
    video:pkg.video||null,audio:pkg.audio||null,
    generatedAt:new Date().toISOString()
  };
}
function saveDeliveryManifest(project){
  const manifest=buildDeliveryManifest(project);
  project.finalMasterDeliveryManifest=manifest;
  saveProject(path.join(process.cwd(),"projects"),project);
  return manifest;
}
module.exports={buildDeliveryManifest,saveDeliveryManifest};
