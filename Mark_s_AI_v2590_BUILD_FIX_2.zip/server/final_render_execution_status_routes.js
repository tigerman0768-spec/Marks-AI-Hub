const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");
function registerFinalRenderExecutionStatusRoutes(app){
  app.get("/api/projects/:id/final-render/execution-status",(req,res)=>{
    const p=getProject(path.join(process.cwd(),"projects"),req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord||{};
    const exists=Boolean(q.outputPath&&fs.existsSync(q.outputPath));
    res.json({projectId:p.id,status:q.status||"not_queued",stage:q.stage||"waiting",
      progress:q.progress||0,workerJobId:q.workerJobId||null,outputPath:q.outputPath||null,
      outputExists:exists,finalRenderReady:p.finalRenderReady===true,error:q.error||null});
  });
}
module.exports={registerFinalRenderExecutionStatusRoutes};
