const path=require("path");
const fs=require("fs");
const {getProject,saveProject}=require("./film_projects");
const queue=require("./final_render_worker_queue");

function registerFinalRenderWorkerAutoRunRoutes(app){
  app.post("/api/projects/:id/final-render/worker-run",(req,res)=>{
    const dir=path.join(process.cwd(),"projects"),p=getProject(dir,req.params.id);
    if(!p)return res.status(404).json({error:"project not found"});
    const q=p.finalRenderQueueRecord;
    if(!q?.workerJobId)return res.status(409).json({error:"render has not been dispatched"});
    if(!["dispatched","running"].includes(q.status))
      return res.status(409).json({error:"render is not runnable",status:q.status});
    const jobs=queue.activeJobs().concat(queue.queuedJobs());
    const job=jobs.find(x=>x.id===q.workerJobId);
    if(!job)return res.status(409).json({error:"worker job not found"});
    q.status="running";q.stage="worker_running";q.progress=Math.max(Number(q.progress)||0,1);
    q.workerRunRequestedAt=new Date().toISOString();
    q.workerRunMode=req.body?.mode?String(req.body.mode):"worker";
    saveProject(dir,p);
    res.status(202).json({projectId:p.id,workerJobId:q.workerJobId,status:q.status,stage:q.stage,mode:q.workerRunMode});
  });
}
module.exports={registerFinalRenderWorkerAutoRunRoutes};
