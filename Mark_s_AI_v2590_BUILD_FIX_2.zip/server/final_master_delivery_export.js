const path=require("path");
const fs=require("fs");
const {getProject}=require("./film_projects");

function getDeliveryExport(project){
  const receipt=project.finalMasterDeliveryReceipt;
  const manifest=project.finalMasterDeliveryManifest;
  const gate=project.finalMasterGate;
  const lock=project.finalMasterLock;
  const output=project.finalRenderOutput||project.finalRenderQueueRecord?.outputPath||null;
  const exists=Boolean(output&&fs.existsSync(output));
  return {
    exportable:Boolean(gate?.ready&&receipt?.status==="verified"&&manifest?.ready&&lock?.locked&&exists),
    projectId:project.id,title:project.title||"Untitled Film",
    gate:gate||null,manifest:manifest||null,receipt:receipt||null,lock:lock||null,
    outputPath:exists?output:null,
    exportedAt:new Date().toISOString()
  };
}
function writeDeliveryExport(project){
  const pkg=getDeliveryExport(project);
  const dir=path.join(process.cwd(),"projects");
  const file=path.join(dir,String(project.id),"final_master_delivery.json");
  if(pkg.exportable){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,JSON.stringify(pkg,null,2));pkg.file=file;}
  return pkg;
}
module.exports={getDeliveryExport,writeDeliveryExport};
