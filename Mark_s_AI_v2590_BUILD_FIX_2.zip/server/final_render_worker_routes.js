const path=require("path");
const {inspectWorkers,takeOverInterruptedJobs}=require("./final_render_worker_manager");
function registerFinalRenderWorkerRoutes(app){
  app.get("/api/final-render/workers",(_req,res)=>{
    try{res.json({workers:inspectWorkers()});}
    catch(e){res.status(400).json({error:e.message});}
  });
  app.post("/api/final-render/workers/takeover",async(_req,res)=>{
    try{res.json({status:"ok",results:await takeOverInterruptedJobs({outputDir:path.join(process.cwd(),"output")})});}
    catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalRenderWorkerRoutes};
