const path=require('path');
const {getProject}=require('./film_projects');
const {getIntegrityHistory}=require('./release_package_integrity_history');
function registerReleasePackageIntegrityHistoryRoutes(app){
  app.get('/api/projects/:id/final-render/release-package/integrity-history',(req,res)=>{
    const p=getProject(path.join(process.cwd(),'projects'),req.params.id);
    if(!p)return res.status(404).json({error:'project not found'});
    res.json(getIntegrityHistory(p));
  });
}
module.exports={registerReleasePackageIntegrityHistoryRoutes};
