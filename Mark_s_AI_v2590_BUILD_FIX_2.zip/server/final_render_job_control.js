const path=require("path");
const {getJob,updateJob}=require("./final_render_job_store");
const {restartProjectFinalRender}=require("./final_render_project_recovery");
const {cancelProcess,getProcessState}=require("./final_render_process_registry");
const DIR=path.join(process.cwd(),"final-render-jobs");

function controlJob(jobId,action){
  const job=getJob(DIR,jobId); if(!job)throw new Error("render job not found");
  if(action==="cancel"){
    if(job.status==="completed")return {status:"already_completed",job};
    const result=cancelProcess(jobId);
    if(!result.cancelled && result.reason==="process_not_owned")
      return {status:"cancel_requested",job:updateJob(DIR,jobId,{status:"cancel_requested",cancelRequested:true,cancelledAt:new Date().toISOString(),recoveryMessage:"Cancellation requested; active render process was not found in this server instance."})};
    return {status:"cancel_requested",process:result,job:updateJob(DIR,jobId,{status:"cancel_requested",cancelRequested:true,cancelledAt:new Date().toISOString(),recoveryMessage:"Render process termination requested by user."})};
  }
  if(action==="reset_recovery"){
    if(job.status!=="recovery_exhausted")return {status:"not_exhausted",job};
    return {status:"recovery_reset",job:updateJob(DIR,jobId,{status:"recoverable",recoveryAttempts:0,recoveryMessage:"Recovery limit reset by user."})};
  }
  throw new Error("unsupported action");
}
async function restartJob(jobId){
  const job=getJob(DIR,jobId);if(!job)throw new Error("render job not found");
  return restartProjectFinalRender(job.projectId);
}
module.exports={controlJob,restartJob};
