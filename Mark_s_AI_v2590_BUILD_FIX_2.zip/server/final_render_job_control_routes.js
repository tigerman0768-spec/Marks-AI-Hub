const {controlJob,restartJob}=require("./final_render_job_control");
function registerFinalRenderJobControlRoutes(app){
  app.post("/api/final-render/jobs/:id/control",async(req,res)=>{
    try{
      const action=String(req.body?.action||"");
      if(action==="restart"){
        const result=await restartJob(req.params.id);
        return res.json(result);
      }
      res.json(controlJob(req.params.id,action));
    }catch(e){res.status(400).json({error:e.message});}
  });
}
module.exports={registerFinalRenderJobControlRoutes};
