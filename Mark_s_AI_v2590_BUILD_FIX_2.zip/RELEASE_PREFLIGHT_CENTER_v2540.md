# Mark's AI v2540 — Release Preflight Center

The final release preflight is now available inside the app as well as the command-line tool.

Endpoint:
`GET /api/release-preflight`

Flutter screen:
`lib/release_preflight_screen.dart`

The screen reports the actual state of:
- Flutter project metadata
- Android release workflow
- Android release metadata
- Local Flutter SDK
- Release APK
- Release AAB

No missing build artifact is marked as ready.
